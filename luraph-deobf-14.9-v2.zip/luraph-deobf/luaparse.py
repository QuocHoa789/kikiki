#!/usr/bin/env python3
"""
Luraph v14.9 stage-2 beautifier / source deobfuscator.

Transforms the stylistic obfuscation layer of the VM loader source:
  1. numeric literal normalization (0X19_ / 0B10_1 / 0x1__2 / 1_000 -> decimal)
  2. string escape decoding -> readable string literals
  3. constant opaque-predicate folding (if <const> then / for <const-range> unrolling)
  4. control-flow unflattening of the `while true do if S==n ... end end` machines
     whose state transitions are constant numbers
  5. proper re-indentation

If a construct is not recognized it is emitted verbatim (never dropped).
"""

import sys
from luatoken import tokenize, KEYWORDS

MAX_UNROLL = 128
MAX_STATES = 512

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def norm_number(text: str):
    """Normalize a numeric literal; returns decimal string or None to keep."""
    t = text.replace("_", "")
    try:
        if t[:2].lower() == "0x":
            v = int(t[2:], 16)
        elif t[:2].lower() == "0b":
            v = int(t[2:], 2)
        else:
            if any(c in t for c in ".eE"):
                f = float(t)
                if f == int(f) and "e" not in t.lower():
                    return str(int(f))
                return repr(f)
            return str(int(t))
        return str(v)
    except ValueError:
        return None


def decode_lua_string(text: str):
    """Decode escapes inside a quoted Lua/Luau string; returns a re-quoted
    literal, or the original text when decoding is unsafe."""
    quote = text[0]
    body = text[1:-1]
    out = []
    i = 0
    n = len(body)
    while i < n:
        c = body[i]
        if c != "\\":
            out.append(c)
            i += 1
            continue
        if i + 1 >= n:
            return text
        nx = body[i + 1]
        if nx.isdigit():
            j = i + 1
            num = ""
            while j < n and len(num) < 3 and body[j].isdigit():
                num += body[j]
                j += 1
            out.append(chr(int(num)))
            i = j
        elif nx == "x":
            if i + 3 >= n + 1:
                return text
            try:
                out.append(chr(int(body[i + 2 : i + 4], 16)))
            except ValueError:
                return text
            i += 4
        elif nx == "z":
            i += 2
            while i < n and body[i] in " \t\r\n":
                i += 1
        elif nx == "u":
            if i + 2 < n and body[i + 2] == "{":
                k = body.find("}", i)
                if k == -1:
                    return text
                try:
                    out.append(chr(int(body[i + 3 : k], 16)))
                except ValueError:
                    return text
                i = k + 1
            else:
                return text
        else:
            simple = {"n": "\n", "t": "\t", "r": "\r", "a": "\a", "b": "\b",
                      "f": "\f", "v": "\v", "\\": "\\", "'": "'", '"': '"',
                      "\n": ""}
            if nx in simple:
                out.append(simple[nx])
                i += 2
            else:
                return text
    s = "".join(out)
    if all(32 <= ord(ch) < 127 for ch in s):
        return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'
    # keep escapes for non printable
    lit = []
    for ch in s:
        if 32 <= ord(ch) < 127:
            lit.append(ch)
        else:
            lit.append("\\x%02x" % ord(ch))
    return '"' + "".join(lit).replace('"', '\\"') + '"'


def const_value(tokens):
    """If the token span is a single numeric constant, return its float value."""
    if len(tokens) == 1 and tokens[0][0] == "NUMBER":
        try:
            return float(norm_number(tokens[0][1]))
        except (TypeError, ValueError):
            return None
    return None


def eval_cmp(op, a, b):
    try:
        if op == "==":
            return a == b
        if op == "~=":
            return a != b
        if op == "<":
            return a < b
        if op == "<=":
            return a <= b
        if op == ">":
            return a > b
        if op == ">=":
            return a >= b
    except TypeError:
        pass
    return None


# ---------------------------------------------------------------------------
# statement parser (subset)
# ---------------------------------------------------------------------------

STMT_START_KEYWORDS = {"local", "function", "if", "while", "for", "repeat",
                       "do", "return", "break", "continue", "goto"}
EXPR_END_KEYWORDS = {"then", "elseif", "else", "end", "do", "until", "in"}


class Parser:
    def __init__(self, toks):
        self.toks = toks
        self.i = 0

    def peek(self, k=0):
        j = self.i + k
        return self.toks[j] if j < len(self.toks) else ("EOF", "")

    def next(self):
        t = self.peek()
        self.i += 1
        return t

    # -- expression span ---------------------------------------------------
    def expr_span(self, stop_at_do=False):
        """Collect tokens until an expression boundary at depth 0."""
        start = self.i
        depth = 0
        seen_eq = False
        while True:
            kind, val = self.peek()
            if kind == "EOF":
                break
            if kind == "OP":
                if val in "([{":
                    depth += 1
                elif val in ")]}":
                    if depth == 0:
                        break
                    depth -= 1
                elif val == ";" and depth == 0:
                    break
                elif val == "=" and depth == 0:
                    seen_eq = True
                elif val in ("+=", "-=", "*=", "/=", "%=", "^=", "..=") and \
                        depth == 0:
                    seen_eq = True
                elif val == "," and depth == 0:
                    if seen_eq or self._comma_continues_assign():
                        self.next()
                        continue
                    break
            elif kind == "KEYWORD":
                if depth == 0 and (val in EXPR_END_KEYWORDS or
                                   val in STMT_START_KEYWORDS):
                    if stop_at_do and val == "do":
                        break
                    if val == "in":
                        break
                    # 'and'/'or'/'not'/'function' continue expressions
                    if val not in ("and", "or", "not", "function"):
                        break
                if val == "function":
                    # anonymous function expression: consume params + body
                    self.next()
                    self._skip_func_expr()
                    continue
            self.next()
        return self.toks[start:self.i]

    def _skip_func_expr(self):
        """Consume an anonymous function's parameter list and body (assumes
        the 'function' keyword has just been consumed)."""
        # parameter list
        pd = 0
        while not self.at_eof():
            kind, val = self.peek()
            self.next()
            if kind == "OP":
                if val == "(":
                    pd += 1
                elif val == ")":
                    pd -= 1
                    if pd == 0:
                        break
        # body with block tracking
        bstack = []
        skip_do = False
        while not self.at_eof():
            kind, val = self.peek()
            if kind == "OP" and val in "([{":
                bstack.append("paren")
            elif kind == "OP" and val in ")]}":
                if bstack and bstack[-1] == "paren":
                    bstack.pop()
            elif kind == "KEYWORD":
                if skip_do and val == "do":
                    skip_do = False
                    self.next()
                    continue
                if val == "repeat":
                    bstack.append("until")
                elif val in ("function", "if"):
                    bstack.append("end")
                elif val in ("for", "while"):
                    bstack.append("end")
                    skip_do = True
                elif val == "until":
                    if bstack and bstack[-1] == "until":
                        bstack.pop()
                elif val == "end":
                    if bstack and bstack[-1] == "end":
                        bstack.pop()
                    elif not bstack:
                        self.next()
                        return
            self.next()

    def at_eof(self):
        return self.peek()[0] == "EOF"

    # -- anonymous function extraction -------------------------------------
    @staticmethod
    def parse_anon_func(toks, i):
        """Parse `function (params) body end` starting at toks[i] (the
        'function' keyword).  Returns (params, body_toks, next_i)."""
        n = len(toks)
        i += 1  # skip 'function'
        params = []
        pd = 0
        while i < n:
            k, v = toks[i]
            i += 1
            if k == "OP":
                if v == "(":
                    pd += 1
                    continue
                if v == ")":
                    pd -= 1
                    if pd == 0:
                        break
                if pd >= 1 and v == "...":
                    params.append("...")
                    continue
                if pd >= 1 and v != ",":
                    params.append(v)
        body = []
        bstack = []
        skip_do = False
        while i < n:
            k, v = toks[i]
            if k == "OP" and v in "([{":
                bstack.append("paren")
            elif k == "OP" and v in ")]}":
                if bstack and bstack[-1] == "paren":
                    bstack.pop()
            elif k == "KEYWORD":
                if skip_do and v == "do":
                    skip_do = False
                    body.append((k, v))
                    i += 1
                    continue
                if v == "repeat":
                    bstack.append("until")
                elif v in ("function", "if"):
                    bstack.append("end")
                elif v in ("for", "while"):
                    bstack.append("end")
                    skip_do = True
                elif v == "until":
                    if bstack and bstack[-1] == "until":
                        bstack.pop()
                elif v == "end":
                    if bstack and bstack[-1] == "end":
                        bstack.pop()
                    elif not bstack:
                        return params, body, i + 1
            body.append((k, v))
            i += 1
        return params, body, i

    @staticmethod
    def top_level_eq(sp):
        """Index of the last top-level '=' in a token span, or None."""
        depth = 0
        eq = None
        for j, (k, v) in enumerate(sp):
            if k == "OP" and v in "([{":
                depth += 1
            elif k == "OP" and v in ")]}":
                depth -= 1
            elif k == "OP" and v == "=" and depth == 0:
                eq = j
        return eq

    def _comma_continues_assign(self):
        """After a top-level comma, is there an '=' (assignment) before a
        statement boundary?  Used to keep multi-target assignments together."""
        j = self.i + 1
        depth = 0
        while j < len(self.toks):
            kind, val = self.toks[j]
            if kind == "OP":
                if val in "([{":
                    depth += 1
                elif val in ")]}":
                    depth -= 1
                elif depth == 0:
                    if val == "=":
                        return True
                    if val in ("+=", "-=", "*=", "/=", "%=", "^=", "..="):
                        return True
                    if val in (",", ";"):
                        j += 1
                        continue
                    return False
            elif kind == "KEYWORD" and depth == 0 and \
                    val in EXPR_END_KEYWORDS and val != "in":
                return False
            j += 1
        return False

    # -- blocks ------------------------------------------------------------
    def parse_block(self, stoppers):
        """Parse statements until one of `stoppers` keywords at depth 0."""
        stmts = []
        while True:
            kind, val = self.peek()
            if kind == "EOF":
                return stmts
            if kind == "KEYWORD" and val in stoppers:
                return stmts
            if kind == "OP" and val == ";":
                self.next()
                continue
            st = self.parse_stmt()
            if st is not None:
                stmts.append(st)
            else:
                return stmts

    def parse_stmt(self):
        kind, val = self.peek()
        if kind == "EOF":
            return None
        if kind == "KEYWORD":
            if val == "local":
                return self.parse_local()
            if val == "function":
                return self.parse_function()
            if val == "if":
                return self.parse_if()
            if val == "while":
                return self.parse_while()
            if val == "for":
                return self.parse_for()
            if val == "repeat":
                return self.parse_repeat()
            if val == "do":
                self.next()
                body = self.parse_block({"end"})
                if self.peek() == ("KEYWORD", "end"):
                    self.next()
                return ("do", body)
            if val == "return":
                self.next()
                exprs = []
                while True:
                    exprs.append(self.expr_span())
                    if self.peek() == ("OP", ","):
                        self.next()
                        continue
                    break
                if self.peek() == ("OP", ";"):
                    self.next()
                # upgrade: returning an anonymous function
                if len(exprs) == 1 and exprs[0] and \
                        exprs[0][0] == ("KEYWORD", "function"):
                    params, body, nxt = self.parse_anon_func(exprs[0], 0)
                    sub = Parser(list(body) + [("EOF", "")])
                    body_stmts = sub.parse_block({"EOF"})
                    return ("funcreturn", params, body_stmts)
                return ("return", exprs)
            if val in ("break", "continue"):
                self.next()
                if self.peek() == ("OP", ";"):
                    self.next()
                return (val, None)
            if val == "goto":
                self.next()
                lbl = self.next()
                if self.peek() == ("OP", ";"):
                    self.next()
                return ("goto", lbl[1])
            # unknown keyword statement
            self.next()
            return ("raw", [(kind, val)])
        # expression statement (call or assignment)
        exprs = [self.expr_span()]
        if not exprs[0]:
            self.next()  # skip a stray token to guarantee progress
            return ("raw", [self.toks[self.i - 1]])
        if self.peek() == ("OP", ","):
            while self.peek() == ("OP", ","):
                self.next()
                exprs.append(self.expr_span())
        if self.peek() == ("OP", ";"):
            self.next()
        # upgrade: RHS is an anonymous function -> funcassign
        if len(exprs) == 1:
            sp = exprs[0]
            eq = self.top_level_eq(sp)
            if eq is not None and eq + 1 < len(sp):
                j = eq + 1
                opened = False
                if sp[j] == ("OP", "(") and j + 1 < len(sp) and \
                        sp[j + 1] == ("KEYWORD", "function"):
                    j += 1
                    opened = True
                if sp[j] == ("KEYWORD", "function"):
                    params, body, nxt = self.parse_anon_func(sp, j)
                    trailing = sp[nxt:]
                    if opened and trailing and trailing[-1] == ("OP", ")"):
                        trailing = trailing[:-1]
                    sub = Parser(list(body) + [("EOF", "")])
                    body_stmts = sub.parse_block({"EOF"})
                    return ("funcassign", sp[:eq], params, body_stmts,
                            trailing)
        return ("expr", exprs)

    def parse_local(self):
        self.next()  # local
        names = []
        while self.peek()[0] == "NAME":
            names.append(self.next()[1])
            if self.peek() == ("OP", ","):
                self.next()
        exprs = []
        if self.peek() == ("OP", "="):
            self.next()
            while True:
                exprs.append(self.expr_span())
                if self.peek() == ("OP", ","):
                    self.next()
                    continue
                break
        if self.peek() == ("OP", ";"):
            self.next()
        return ("local", names, exprs)

    def parse_function(self):
        self.next()  # function
        if self.peek() == ("KEYWORD", "local"):
            self.next()
        name = []
        while True:
            kind, val = self.peek()
            if kind == "NAME":
                name.append(val)
                self.next()
            elif (kind, val) == ("OP", ".") or (kind, val) == ("OP", ":"):
                name.append(val)
                self.next()
            else:
                break
        params, body = self.parse_funcbody()
        return ("func", ".".join(name), params, body)

    def parse_funcbody(self):
        # name parts already consumed; expect ( ... )
        params = []
        if self.peek() == ("OP", "("):
            self.next()
            while self.peek() != ("OP", ")"):
                kind, val = self.next()
                if kind in ("NAME", "KEYWORD"):
                    params.append(val)
                elif val == "...":
                    params.append("...")
                elif val == ",":
                    continue
            self.next()  # )
        body = self.parse_block({"end"})
        if self.peek() == ("KEYWORD", "end"):
            self.next()
        return params, body

    def parse_if(self):
        self.next()  # if
        cond = self.expr_span()
        if self.peek() == ("KEYWORD", "then"):
            self.next()
        then = self.parse_block({"else", "elseif", "end"})
        arms = [(cond, then)]
        els = []
        while True:
            kind, val = self.peek()
            if (kind, val) == ("KEYWORD", "elseif"):
                self.next()
                c = self.expr_span()
                if self.peek() == ("KEYWORD", "then"):
                    self.next()
                b = self.parse_block({"else", "elseif", "end"})
                arms.append((c, b))
            elif (kind, val) == ("KEYWORD", "else"):
                self.next()
                els = self.parse_block({"end"})
                if self.peek() == ("KEYWORD", "end"):
                    self.next()
                break
            elif (kind, val) == ("KEYWORD", "end"):
                self.next()
                break
            else:
                break
        return ("if", arms, els)

    def parse_while(self):
        self.next()
        cond = self.expr_span(stop_at_do=True)
        if self.peek() == ("KEYWORD", "do"):
            self.next()
        body = self.parse_block({"end"})
        if self.peek() == ("KEYWORD", "end"):
            self.next()
        return ("while", cond, body)

    def parse_repeat(self):
        self.next()
        body = self.parse_block({"until"})
        if self.peek() == ("KEYWORD", "until"):
            self.next()
        cond = self.expr_span()
        return ("repeat", body, cond)

    def parse_for(self):
        self.next()
        names = [self.next()[1]]
        while self.peek() == ("OP", ","):
            self.next()
            names.append(self.next()[1])
        if self.peek() == ("OP", "="):
            self.next()
            vals = [self.expr_span()]
            while self.peek() == ("OP", ","):
                self.next()
                vals.append(self.expr_span())
            if self.peek() == ("KEYWORD", "do"):
                self.next()
            body = self.parse_block({"end"})
            if self.peek() == ("KEYWORD", "end"):
                self.next()
            return ("fornum", names[0], vals, body)
        # for ... in ...
        if self.peek() == ("KEYWORD", "in"):
            self.next()
            exprs = [self.expr_span()]
            while self.peek() == ("OP", ","):
                self.next()
                exprs.append(self.expr_span())
            if self.peek() == ("KEYWORD", "do"):
                self.next()
            body = self.parse_block({"end"})
            if self.peek() == ("KEYWORD", "end"):
                self.next()
            return ("forin", names, exprs, body)
        return ("raw", [( "KEYWORD", "for")])
