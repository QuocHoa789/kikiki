#!/usr/bin/env python3
"""Reference (slow) decompressor using BitReader, for verifying the optimized one."""
import sys
sys.path.insert(0, ".")
from luraph_deobf import BitReader, new_length_model


def decompress_ref(data: bytes) -> bytes:
    rc = BitReader(data)
    literal_models = [[1024] * 0x300 for _ in range(8)]
    V = [[1024] for _ in range(12)]
    G = [1024] * 12
    d = [1024] * 12
    D = [1024] * 12
    j = [1024] * 12
    w = [[1024] for _ in range(12)]
    T = [[1024] * 65 for _ in range(4)]
    B = [1024] * 115
    P = [1024] * 16
    len_k = new_length_model()
    len_l = new_length_model()
    state_trans = {0: 0, 1: 0, 2: 0, 3: 0, 4: 1, 5: 2, 6: 3,
                   7: 4, 8: 5, 9: 6, 10: 4, 11: 5}
    out = bytearray()
    out.append(0)
    state = 0
    rep_t = rep_x = rep_e = dist = 0
    steps = 0
    while rc.pos <= len(data):
        steps += 1
        if rc.decode_bit(V[state], 0) == 0:
            prev = out[len(out) - 1]
            model = literal_models[prev >> 5]
            if state < 7:
                byte = rc.decode_tree(model, 8)
            else:
                match_byte = out[len(out) - dist - 1]
                byte = rc.decode_matched_byte(model, match_byte)
            out.append(byte)
            state = state_trans[state]
        else:
            length = None
            if rc.decode_bit(G, state) != 0:
                if rc.decode_bit(d, state) == 0:
                    if rc.decode_bit(w[state], 0) == 0:
                        state = 9 if state < 7 else 11
                        length = 1
                else:
                    if rc.decode_bit(D, state) == 0:
                        new_dist = rep_t
                    else:
                        if rc.decode_bit(j, state) == 0:
                            new_dist = rep_x
                        else:
                            new_dist = rep_e
                            rep_e = rep_x
                        rep_x = rep_t
                    rep_t = dist
                    dist = new_dist
                if length is None:
                    state = 8 if state < 7 else 11
                    length = 2 + ref_length(rc, len_l)
            else:
                rep_e = rep_x
                rep_x = rep_t
                rep_t = dist
                length = 2 + ref_length(rc, len_k)
                slot_idx = min(length - 2, 3)
                slot = rc.decode_tree(T[slot_idx], 6)
                if slot >= 4:
                    nbits = (slot >> 1) - 1
                    base = (2 + (slot & 1)) << nbits
                    if slot < 14:
                        dist = base + rc.decode_direct_tree(B, base - slot, nbits)
                    else:
                        dist = base + (rc.decode_direct_bits(nbits - 4) << 4) \
                               + rc.decode_direct_tree(P, 0, 4)
                        if dist == 0xFFFFFFFF:
                            break
                else:
                    dist = slot
                state = 7 if state < 7 else 10
                if dist >= len(out) - 1:
                    raise ValueError(f"invalid match distance at step {steps}, "
                                     f"out_len={len(out)}, dist={dist}")
            for _ in range(length):
                out.append(out[len(out) - dist - 1])
    return bytes(out[1:])


def ref_length(rc, lm):
    if rc.decode_bit(lm[1], 0) == 0:
        return rc.decode_tree(lm[3][0], 3)
    if rc.decode_bit(lm[2], 0) == 0:
        return 8 + rc.decode_tree(lm[4][0], 3)
    return 16 + rc.decode_tree(lm[5], 8)


if __name__ == "__main__":
    blob = open(sys.argv[1], "rb").read()
    r = decompress_ref(blob)
    print(len(r), r[:32].hex())
