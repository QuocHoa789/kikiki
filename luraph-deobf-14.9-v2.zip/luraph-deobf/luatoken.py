#!/usr/bin/env python3
"""
Lua/Luau tokenizer for the Luraph v14.9 beautifier.
Produces a token list: (kind, value) where kind in
  NAME, NUMBER, STRING, LONGSTRING, OP, KEYWORD, EOF
Handles Luau extensions: binary literals, underscores in numerals,
\\z \\x \\u escapes, compound assignments (+=, -=, *=, /=, ..=, %=, ^=).
"""

import re

KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while", "continue",
}

TOKEN_RE = re.compile(r"""
    (?P<SPACE>\s+)
  | (?P<COMMENT>--\[(?P<lq>=*)\[.*?\](?P=lq)\] | --[^\n]*)
  | (?P<LONGSTRING>\[(?P<leq>=*)\[.*?\](?P=leq)\])
  | (?P<NUMBER>
        0[xX][0-9a-fA-F_]+(?:\.[0-9a-fA-F_]*)?(?:[pP][-+]?\d+)?
      | 0[bB][01_]+
      | \d[\d_]*(?:\.[\d_]*)?(?:[eE][-+]?\d+)?
    )
  | (?P<NAME>[A-Za-z_][A-Za-z_0-9]*)
  | (?P<STRING>
        "(?:\\.|[^"\\])*"
      | '(?:\\.|[^'\\])*'
    )
  | (?P<OP>\.\.\.|\.\.|==|~=|<=|>=|\+=|-=|\*=|/=|//=|%=|\^=|\.\.=|::|->|.)
""", re.DOTALL | re.VERBOSE)


def tokenize(src: str):
    toks = []
    pos = 0
    n = len(src)
    while pos < n:
        m = TOKEN_RE.match(src, pos)
        if not m:
            toks.append(("OP", src[pos]))
            pos += 1
            continue
        pos = m.end()
        kind = m.lastgroup
        text = m.group()
        if kind in ("SPACE", "COMMENT"):
            continue
        if kind == "LONGSTRING":
            toks.append(("LONGSTRING", text))
        elif kind == "NUMBER":
            toks.append(("NUMBER", text))
        elif kind == "NAME":
            if text in KEYWORDS:
                toks.append(("KEYWORD", text))
            else:
                toks.append(("NAME", text))
        elif kind == "STRING":
            toks.append(("STRING", text))
        else:
            toks.append(("OP", text))
    toks.append(("EOF", ""))
    return toks
