-- lifted Lua source - proto #12
-- 148 instructions (linear order, control flow via labels/gotos)
::L1::
goto L127
-- ??? opcode 139 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
r15 = r15(r16)
-- ??? opcode 139 (UNKNOWN)
::L7::
goto L100
-- ??? opcode 52 (UNKNOWN)
::L9::
goto L98
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
r16 = r16()
-- ??? opcode 139 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
::L16::
goto L44
::L17::
goto L73
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
r15 = r5[(r15(r16))]
if not (V[A[n]]) then goto L44 end
::L26::
goto L9
r3 = 1
::L28::
-- ??? opcode 110 (UNKNOWN)
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
-- ??? opcode 139 (UNKNOWN)
::L38::
goto L61
r11 = r11()
-- ??? opcode 139 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
::L44::
goto L116
r5[r14] = r5[(r15(r16))]
-- ??? opcode 139 (UNKNOWN)
r14 = r14()
::L48::
goto L106
r8 = 1
-- ??? opcode 110 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
r14 = (r14())()
if not (notV[A[n]]) then goto L17 end
::L54::
goto L114
r5[((r14())())] = r5[(r15(r16))]
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
r15 = r5[(r15(r16))]()
goto L1
-- ??? opcode 88 (UNKNOWN)
::L61::
goto L28
-- numeric for-loop (var rNone+3, jump LNone)
::L63::
-- numeric for-loop (var rNone+3, jump LNone)
r12 = r12()
-- ??? opcode 139 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
r5[r10] = (r11())
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
::L71::
goto L38
-- ??? opcode 88 (UNKNOWN)
::L73::
goto L7
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
goto L54
r10 = 0
r11 = 255
r12 = 1
::L84::
goto L96
-- ??? opcode 52 (UNKNOWN)
::L86::
goto L86
r5 = {}
r6 = 0
r7 = 255
::L90::
goto L48
-- ??? opcode 88 (UNKNOWN)
::L92::
goto L115
-- ??? opcode 139 (UNKNOWN)
r14 = ((r14())())()
goto L17
::L96::
-- ??? opcode 104 (UNKNOWN)
::L97::
-- ??? opcode 110 (UNKNOWN)
::L98::
-- ??? opcode 110 (UNKNOWN)
-- ??? opcode 88 (UNKNOWN)
::L100::
goto L84
r16 = (r16())()
-- ??? opcode 139 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 45 (UNKNOWN)
{}[(((r14())())())] = (r5[(r15(r16))]())
::L106::
goto L71
-- ??? opcode 139 (UNKNOWN)
r15 = (r5[(r15(r16))]())()
if not (notV[A[n]]) then goto L54 end
::L110::
goto L16
r1 = 1
-- ??? opcode 139 (UNKNOWN)
r2 = r2()
::L114::
goto L26
::L115::
goto L92
::L116::
goto L141
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
-- ??? opcode 139 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
{}[0] = 255
::L127::
goto L90
goto L110
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
-- ??? opcode 139 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
::L141::
goto L63
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
r7 = 255()
r8 = 1
goto L97
