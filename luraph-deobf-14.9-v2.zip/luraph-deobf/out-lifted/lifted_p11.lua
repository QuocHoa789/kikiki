-- lifted Lua source - proto #11
-- 36 instructions (linear order, control flow via labels/gotos)
::L1::
goto L24
::L2::
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 140 (UNKNOWN)
r1 = r1["byte"]
::L6::
goto L6
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
r4 = r2
r5 = " "
r6 = 8
r4 = r2(" ", 8)
::L16::
goto L31
r10 = r9
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
if not (notV[A[n]]) then goto L1 end
::L24::
goto L25
::L25::
goto L2
r10 = r9
-- ??? opcode 30 (UNKNOWN)
::L28::
goto L16
-- numeric for-loop (var rNone+3, jump LNone)
-- numeric for-loop (var rNone+3, jump LNone)
::L31::
goto L16
-- numeric for-loop (var rNone+3, jump LNone)
-- numeric for-loop (var rNone+3, jump LNone)
-- numeric for-loop (var rNone+3, jump LNone)
goto L28
if not (V[A[n]]<=KA[n]) then goto L422 end
