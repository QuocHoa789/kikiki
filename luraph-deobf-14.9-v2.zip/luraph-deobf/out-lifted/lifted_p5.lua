-- lifted Lua source - proto #5
-- 40 instructions (linear order, control flow via labels/gotos)
::L1::
goto L6
if not (KA[n]<V[A[n]]) then goto L27 end
::L3::
goto L14
if not (not(V[A[n]]<KA[n])) then goto L32 end
goto L21
::L6::
-- ??? opcode 18 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
r2 = <upvalue table index>
r3 = 1006007762
r4 = nil
::L12::
goto L12
r5 = 124
::L14::
goto L19
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r4 = r1
r4 = not r1
::L19::
goto L29
if not (not(V[A[n]]<KA[n])) then goto L27 end
::L21::
goto L1
r5 = 21
r2 = upvalue_index[not (r1)]
::L24::
goto L19
r5 = 43
::L27::
goto L19
if not (KA[n]<V[A[n]]) then goto L3 end
::L29::
goto L24
::L30::
goto L19
if not (not(V[A[n]]<KA[n])) then goto L19 end
::L32::
goto L34
if not (KA[n]<V[A[n]]) then goto L19 end
::L34::
goto L30
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
