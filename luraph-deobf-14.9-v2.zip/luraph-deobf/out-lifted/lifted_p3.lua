-- lifted Lua source - proto #3
-- 78 instructions (linear order, control flow via labels/gotos)
::L1::
goto L60
r4 = r4 + nil
r5 = 807122005
::L5::
goto L47
-- ??? opcode 65 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r7 = <upvalue table index>
r4 = 807122005 .. r6 .. upvalue_index
r4 = 614537606
r5 = 1005978591
if not (not(V[A[n]]<V[B[n]])) then goto L27 end
::L20::
goto L59
r6 = r1
r5 = 1005978591(r1)
r6 = <upvalue table index>
::L25::
goto L5
if not (KA[n]<V[A[n]]) then goto L35 end
::L27::
goto L77
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 99 (UNKNOWN)
-- ??? opcode 112 (UNKNOWN)
::L34::
goto L1
::L35::
-- numeric for-loop (var rNone+3, jump LNone)
if not (not(V[A[n]]<KA[n])) then goto L25 end
::L37::
goto L76
r5 = <upvalue table index>
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
::L46::
goto L72
::L47::
goto L34
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 99 (UNKNOWN)
-- ??? opcode 112 (UNKNOWN)
::L54::
goto L66
r5 = not r1
-- ??? opcode 79 (UNKNOWN)
goto L64
::L59::
-- ??? opcode 58 (UNKNOWN)
::L60::
goto L46
-- numeric for-loop (var rNone+3, jump LNone)
r2 = 74
r3 = 660648444
::L64::
goto L25
r2 = 33
::L66::
goto L25
r3 = 660648444 - nil
-- ??? opcode 143 (UNKNOWN)
if not (KA[n]<V[A[n]]) then goto L409 end
-- numeric for-loop (var rNone+3, jump LNone)
r217 = r54 + nil
::L72::
goto L34
r6 = upvalue_index(upvalue_index)
-- ??? opcode 65 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
::L76::
goto L20
::L77::
goto L37
goto L54
