-- lifted Lua source - proto #7
-- 83 instructions (linear order, control flow via labels/gotos)
::L1::
goto L22
if not (KA[n]<V[A[n]]) then goto L20 end
::L3::
goto L8
-- ??? opcode 110 (UNKNOWN)
if not (KA[n]<V[A[n]]) then goto L1 end
::L6::
goto L29
-- ??? opcode 88 (UNKNOWN)
::L8::
goto L67
r5 = r2
r11 = r6
::L12::
goto L58
r11 = r6 + nil
r11 = (r6 + nil) + nil
::L17::
goto L69
if not (((r6 + nil) + nil) == 975672630) then goto L25 end
::L20::
goto L23
r4 = r1
::L22::
goto L6
::L23::
goto L37
r6 = not r6
::L25::
goto L6
r3 = r3 - nil
::L29::
goto L48
if not (not(V[A[n]]<KA[n])) then goto L41 end
::L31::
goto L17
r6 = nil
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r8 = 220
r9 = 18
::L37::
goto L3
-- numeric for-loop (var rNone+3, jump LNone)
r3 = 430369519
::L41::
goto L43
r11 = nil
::L43::
-- numeric for-loop (var rNone+3, jump LNone)
r4 = <upvalue table index>
r5 = <upvalue table index>
goto L31
::L48::
-- ??? opcode 43 (UNKNOWN)
r11 = nil + nil
-- ??? opcode 59 (UNKNOWN)
-- ??? opcode 114 (UNKNOWN)
-- ??? opcode 15 (UNKNOWN)
-- ??? opcode 42 (UNKNOWN)
-- ??? opcode 109 (UNKNOWN)
-- ??? opcode 138 (UNKNOWN)
-- ??? opcode 131 (UNKNOWN)
::L58::
goto L12
r12 = upvalue_index
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r11 = (nil + nil)(upvalue_index, r13)
r6 = ((nil + nil)(upvalue_index, r13))
::L67::
goto L6
-- ??? opcode 52 (UNKNOWN)
::L69::
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 1 (UNKNOWN)
-- ??? opcode 153 (UNKNOWN)
-- ??? opcode 38 (UNKNOWN)
-- ??? opcode 151 (UNKNOWN)
-- ??? opcode 118 (UNKNOWN)
-- ??? opcode 131 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 161 (UNKNOWN)
-- ??? opcode 129 (UNKNOWN)
if not (V[A[n]]<=V[B[n]]) then goto L342 end
-- ??? opcode 153 (UNKNOWN)
goto L6
