-- lifted Lua source - proto #13
-- 44 instructions (linear order, control flow via labels/gotos)
::L1::
goto L29
-- ??? opcode 139 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
r3 = 1
::L5::
goto L35
-- ??? opcode 139 (UNKNOWN)
r7 = r2
r8 = 16
r6 = r6(r2, 16)
goto L39
::L11::
-- ??? opcode 55 (UNKNOWN)
r5 = r5 * nil
-- ??? opcode 139 (UNKNOWN)
r7 = 1
::L15::
goto L24
::L16::
-- numeric for-loop (var rNone+3, jump LNone)
r8 = 8
r6 = (r6(r2, 16))(1, 8)
-- ??? opcode 129 (UNKNOWN)
-- ??? opcode 135 (UNKNOWN)
-- ??? opcode 161 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
::L24::
goto L15
r8 = 32
r6 = ((r6(r2, 16))(1, 8))(1, 32)
r6 = (((r6(r2, 16))(1, 8))(1, 32)) * nil
-- ??? opcode 33 (UNKNOWN)
::L29::
goto L5
::L30::
goto L1
r6 = r4
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r5 = (r5 * nil)(r4, 1)
::L35::
goto L11
r4 = 4
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 139 (UNKNOWN)
::L39::
goto L30
r6 = r4 * nil
-- ??? opcode 33 (UNKNOWN)
-- ??? opcode 139 (UNKNOWN)
r7 = r1
goto L16
