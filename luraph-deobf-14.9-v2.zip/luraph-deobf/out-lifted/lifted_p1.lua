-- lifted Lua source - proto #1
-- 343 instructions (linear order, control flow via labels/gotos)
::L1::
goto L120
r2[111] = "gsub"
r2[51] = "rawget"
r2[164] = "readu8"
r2[8] = "\ucf65\ucd15\ucd8b\ub8fc\uc68a\ubd56\ubdab\ub7ba"
r2[12] = "next"
::L7::
goto L96
-- ??? opcode 162 (UNKNOWN)
r2[182] = "GetAsync"
r2[39] = "\u1101\u1175\u11af\u110e\u1172\u11af\u110a\u116d\u11aa\u1103\u116d\u11b1\u110d\u1167\u11aa\u1104\u116f\u11b0"
r2[21] = "FromName"
::L12::
goto L241
r2[55] = "setstack"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L16::
goto L207
r3 = r3["new"]
-- ??? opcode 141 (UNKNOWN)
-- ??? opcode 143 (UNKNOWN)
-- ??? opcode 70 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r2[130] = "IsA"
r2[153] = "userdata"
::L24::
goto L290
r2[24] = "Instance"
r2[74] = "Enum"
r2[135] = "error"
-- ??? opcode 140 (UNKNOWN)
::L29::
goto L324
-- ??? opcode 162 (UNKNOWN)
r2[67] = "HttpService"
-- ??? opcode 140 (UNKNOWN)
goto L121
::L35::
-- ??? opcode 45 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r2[19] = "number"
r2[158] = "function"
r2[75] = "tonumber"
-- ??? opcode 31 (UNKNOWN)
r2 = r2(r3["new"])
::L42::
goto L278
(r2(r3["new"]))[77] = "Connect"
(r2(r3["new"]))[88] = "sl"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[94] = "status"
::L49::
goto L299
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 22 (UNKNOWN)
-- ??? opcode 71 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[20] = "sub"
(r2(r3["new"]))[96] = "rawset"
(r2(r3["new"]))[72] = "Clone"
(r2(r3["new"]))[103] = "Random"
::L60::
goto L1
(r2(r3["new"]))[93] = "format"
(r2(r3["new"]))[116] = "getstack"
-- ??? opcode 140 (UNKNOWN)
::L64::
goto L7
(r2(r3["new"]))[178] = "gmatch"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[147] = "what"
::L70::
goto L307
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[139] = "ClassName"
(r2(r3["new"]))[83] = "delay"
::L76::
goto L193
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[141] = "getupvalue"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[13] = "wait"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[1] = "wrap"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[46] = "pcall"
(r2(r3["new"]))[114] = "traceback"
::L96::
goto L295
(r2(r3["new"]))[95] = "Disconnect"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[134] = "spawn"
::L102::
goto L60
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[169] = "type"
(r2(r3["new"]))[162] = "\":(%d+)[:\\r\\"
(r2(r3["new"]))[34] = "setmetatable"
(r2(r3["new"]))[137] = "Shuffle"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[150] = "Position"
::L116::
goto L12
(r2(r3["new"]))[136] = true
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]
::L120::
goto L170
::L121::
goto L229
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 87 (UNKNOWN)
-- ??? opcode 62 (UNKNOWN)
(r2(r3["new"]))[145] = "PostAsync"
(r2(r3["new"]))[86] = "source"
(r2(r3["new"]))[119] = "resume"
(r2(r3["new"]))[5] = "create"
(r2(r3["new"]))[28] = "defer"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[22] = "running"
(r2(r3["new"]))[100] = "FromValue"
(r2(r3["new"]))[3] = "byte"
(r2(r3["new"]))[110] = "IsServer"
::L138::
goto L189
(r2(r3["new"]))[9] = "linedefined"
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 87 (UNKNOWN)
-- ??? opcode 62 (UNKNOWN)
(r2(r3["new"]))[101] = "setconstant"
-- ??? opcode 140 (UNKNOWN)
::L145::
goto L76
(r2(r3["new"]))[38] = "DescendantRemoving"
(r2(r3["new"]))[64] = "getinfo"
-- ??? opcode 140 (UNKNOWN)
::L149::
goto L198
(r2(r3["new"]))[80] = "currentline"
(r2(r3["new"]))[90] = "[C]"
(r2(r3["new"]))[57] = "EnumItem"
(r2(r3["new"]))[53] = "select"
-- ??? opcode 140 (UNKNOWN)
::L155::
goto L70
(r2(r3["new"]))[170] = "tostring"
(r2(r3["new"]))[31] = "getmetatable"
(r2(r3["new"]))[146] = ""
(r2(r3["new"]))[176] = "RequestAsync"
(r2(r3["new"]))[59] = false
::L161::
goto L249
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[11] = "writeu16"
(r2(r3["new"]))[157] = "GetChildren"
::L166::
goto L225
(r2(r3["new"]))[160] = "Name"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L170::
goto L221
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]
-- ??? opcode 162 (UNKNOWN)
::L175::
goto L166
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[107] = "cancel"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L183::
goto L155
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]["lrotate"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[43] = "NormalId"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L189::
goto L102
(r2(r3["new"]))[44] = "ScreenGui"
(r2(r3["new"]))[52] = "Y"
-- ??? opcode 140 (UNKNOWN)
::L193::
goto L49
(r2(r3["new"]))[149] = "C"
(r2(r3["new"]))[69] = "char"
(r2(r3["new"]))[61] = "NextInteger"
(r2(r3["new"]))[25] = "yield"
::L198::
goto L138
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[66] = "insert"
-- ??? opcode 140 (UNKNOWN)
::L202::
goto L16
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
::L207::
goto L183
(r2(r3["new"]))[109] = "table"
(r2(r3["new"]))[92] = "Value"
(r2(r3["new"]))[42] = "Workspace"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[87] = "pack"
(r2(r3["new"]))[18] = "NextUnitVector"
::L215::
goto L116
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]["lrotate"]["lshift"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[47] = "WaitForChild"
(r2(r3["new"]))[165] = "writeu8"
::L221::
goto L42
(r2(r3["new"]))[181] = "setupvalue"
(r2(r3["new"]))[132] = "__index"
(r2(r3["new"]))[117] = "RunService"
::L225::
goto L149
(r2(r3["new"]))[144] = "Parent"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L229::
goto L280
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 72 (UNKNOWN)
(r2(r3["new"]))[30] = "getupvalues"
(r2(r3["new"]))[152] = "close"
(r2(r3["new"]))[40] = "IsStudio"
(r2(r3["new"]))[89] = "slnaf"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]["lrotate"]["lshift"]["new"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[173] = "new"
::L241::
goto L215
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[60] = "Connected"
(r2(r3["new"]))[168] = "info"
(r2(r3["new"]))[56] = "EnumType"
(r2(r3["new"]))[6] = "copy"
(r2(r3["new"]))[91] = "StarterPlayer"
::L249::
goto L314
(r2(r3["new"]))[108] = "getconstant"
(r2(r3["new"]))[122] = "unpack"
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]["lrotate"]["lshift"]["new"]["sub"]
::L254::
goto L263
(r2(r3["new"]))[123] = "namewhat"
(r2(r3["new"]))[183] = "isvararg"
(r2(r3["new"]))[142] = "NextNumber"
-- ??? opcode 140 (UNKNOWN)
::L259::
goto L267
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]["lrotate"]["lshift"]["new"]["sub"]["insert"]
-- ??? opcode 162 (UNKNOWN)
::L263::
goto L161
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L267::
goto L24
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]["lrotate"]["lshift"]["new"]["sub"]["insert"]["countlz"]
::L271::
goto L175
(r2(r3["new"]))[70] = "string"
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 87 (UNKNOWN)
-- ??? opcode 62 (UNKNOWN)
(r2(r3["new"]))[98] = "ChildAdded"
-- ??? opcode 140 (UNKNOWN)
::L278::
goto L202
-- numeric for-loop (var rNone+3, jump LNone)
::L280::
-- numeric for-loop (var rNone+3, jump LNone)
(r2(r3["new"]))[37] = "Scale"
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 87 (UNKNOWN)
-- ??? opcode 62 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
::L290::
goto L35
(r2(r3["new"]))[76] = "Folder"
(r2(r3["new"]))[163] = "Path2D"
(r2(r3["new"]))[99] = "short_src"
(r2(r3["new"]))[177] = "=[C]"
::L295::
goto L254
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
::L299::
goto L29
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[151] = "Enums"
::L307::
goto L145
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]["lrotate"]["lshift"]["new"]["sub"]["insert"]["countlz"]["countrz"]
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[112] = "match"
::L314::
goto L336
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
r3 = r3["new"]["bor"]["format"]["nfdnormalize"]["unpack"]["bnot"]["rshift"]["gmatch"]["concat"]["byte"]["rep"]["new"]["match"]["lrotate"]["lshift"]["new"]["sub"]["insert"]["countlz"]["countrz"]["nfcnormalize"]
-- ??? opcode 162 (UNKNOWN)
::L324::
goto L259
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[115] = "DataModel"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[128] = "abs"
(r2(r3["new"]))[49] = "getconstants"
(r2(r3["new"]))[32] = "writeu32"
(r2(r3["new"]))[81] = "find"
(r2(r3["new"]))[65] = "The metatable is locked"
(r2(r3["new"]))[14] = "nparams"
(r2(r3["new"]))[79] = "lastlinedefined"
::L336::
goto L64
(r2(r3["new"]))[143] = "Frame"
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 140 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(r3["new"]))[154] = "X"
goto L271
