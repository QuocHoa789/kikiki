-- lifted Lua source - proto #14
-- 48 instructions (linear order, control flow via labels/gotos)
::L1::
goto L38
-- ??? opcode 82 (UNKNOWN)
-- ??? opcode 129 (UNKNOWN)
-- ??? opcode 44 (UNKNOWN)
-- ??? opcode 77 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
-- ??? opcode 82 (UNKNOWN)
::L8::
goto L14
r5 = r1 % nil
r6 = r2 % nil
-- ??? opcode 121 (UNKNOWN)
::L12::
goto L21
if not (not(V[A[n]]<V[B[n]])) then goto L36 end
::L14::
goto L19
r2 = r7 / nil
r3 = r3 * nil
::L17::
goto L17
if not (KA[n]<V[A[n]]) then goto L12 end
::L19::
goto L26
r1 = (r7 / nil)
::L21::
goto L36
-- ??? opcode 33 (UNKNOWN)
::L23::
goto L1
r5 = (r7 / nil) % nil
if not (KA[n]<V[A[n]]) then goto L28 end
::L26::
goto L42
if not (KA[n]<V[A[n]]) then goto L12 end
::L28::
goto L8
-- ??? opcode 82 (UNKNOWN)
r1 = (r2 % nil) / nil
r3 = (r3 * nil) * nil
::L32::
goto L32
::L33::
goto L36
r5 = r4
-- numeric for-loop (var rNone+3, jump LNone)
::L36::
-- ??? opcode 134 (UNKNOWN)
if not (KA[n]<V[A[n]]) then goto L33 end
::L38::
goto L23
-- numeric for-loop (var rNone+3, jump LNone)
r3 = 1
r4 = 0
::L42::
goto L17
-- ??? opcode 129 (UNKNOWN)
-- ??? opcode 135 (UNKNOWN)
-- ??? opcode 161 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
goto L28
