-- lifted Lua source - proto #8
-- 207 instructions (linear order, control flow via labels/gotos)
::L1::
goto L192
r5 = r2
::L3::
goto L41
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r8 = 929445053
r10 = r10 - nil
-- ??? opcode 2 (UNKNOWN)
r340 = B  -- loader upvalue
-- ??? opcode 43 (UNKNOWN)
-- ??? opcode 145 (UNKNOWN)
r194 = nil
::L19::
goto L171
r5 = r1
::L21::
goto L137
if not (KA[n]<V[A[n]]) then goto L83 end
goto L110
if not (KA[n]<V[A[n]]) then goto L177 end
::L25::
goto L32
if not (KA[n]<V[A[n]]) then goto L47 end
::L27::
goto L125
if not (r9 == 143) then goto L57 end
::L29::
goto L181
-- ??? opcode 110 (UNKNOWN)
if not (KA[n]<V[A[n]]) then goto L19 end
::L32::
goto L91
if not (not(V[A[n]]<KA[n])) then goto L177 end
goto L1
if not (KA[n]<V[A[n]]) then goto L157 end
if not (notV[A[n]]) then goto L150 end
::L37::
goto L159
if not (r9 == 200) then goto L27 end
::L39::
goto L59
if not (notV[A[n]]) then goto L120 end
::L41::
goto L52
-- ??? opcode 88 (UNKNOWN)
::L43::
goto L201
if not (not(V[A[n]]<KA[n])) then goto L73 end
::L45::
goto L85
r3 = r6
::L47::
goto L171
if not (KA[n]<V[A[n]]) then goto L173 end
::L49::
goto L96
goto L104
if not (r9 == 257) then goto L86 end
::L52::
goto L183
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r12 = 251
r13 = 41
::L57::
-- ??? opcode 110 (UNKNOWN)
-- ??? opcode 88 (UNKNOWN)
::L59::
goto L75
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
::L65::
goto L57
if not (notV[A[n]]) then goto L189 end
::L67::
goto L112
r3 = r15
::L69::
goto L73
r5 = r1
r7 = 95
::L72::
goto L47
::L73::
goto L41
-- ??? opcode 88 (UNKNOWN)
::L75::
goto L139
-- ??? opcode 52 (UNKNOWN)
r6 = <upvalue table index>
r7 = 81
r8 = 161
r9 = 20
::L81::
-- ??? opcode 110 (UNKNOWN)
::L83::
goto L73
if not (KA[n]<V[A[n]]) then goto L41 end
::L85::
goto L165
::L86::
goto L141
if not (20 == 86) then goto L37 end
::L88::
goto L163
r4 = <upvalue table index>
r15[r1] = upvalue_index
::L91::
goto L135
r11 = <upvalue table index>
-- ??? opcode 56 (UNKNOWN)
::L94::
goto L98
r9 = 683278368
::L96::
goto L47
if not (not(V[A[n]]<KA[n])) then goto L173 end
::L98::
goto L88
-- ??? opcode 52 (UNKNOWN)
::L100::
goto L72
-- ??? opcode 139 (UNKNOWN)
::L102::
goto L41
if not (notV[A[n]]) then goto L72 end
::L104::
goto L49
r11 = <upvalue table index>
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r13 = 198
r14 = 31
::L110::
goto L29
if not (not(V[A[n]]<KA[n])) then goto L83 end
::L112::
goto L39
r5 = r2
r15 = <upvalue table index>
-- ??? opcode 56 (UNKNOWN)
::L116::
goto L189
-- ??? opcode 88 (UNKNOWN)
::L118::
goto L169
if not (KA[n]<V[A[n]]) then goto L21 end
::L120::
goto L132
-- ??? opcode 139 (UNKNOWN)
r5 = r1
r6 = <upvalue table index>
r15[r1] = upvalue_index
::L125::
goto L41
-- ??? opcode 139 (UNKNOWN)
r7 = 0
::L128::
goto L47
r19 = r15
::L130::
-- numeric for-loop (var rNone+3, jump LNone)
if not (not(V[A[n]]<KA[n])) then goto L167 end
::L132::
goto L65
r3 = r15[r1]
r6 = r15[r1]
::L135::
goto L41
if not (161 == 126261213) then goto L3 end
::L137::
goto L45
-- ??? opcode 88 (UNKNOWN)
::L139::
goto L98
-- ??? opcode 52 (UNKNOWN)
::L141::
goto L120
r5 = r2
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r16 = r2
r15 = upvalue_index(r2)
::L150::
goto L67
r3 = <upvalue table index>
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
::L157::
-- numeric for-loop (var rNone+3, jump LNone)
if not (KA[n]<V[A[n]]) then goto L167 end
::L159::
goto L130
r15 = 40
r16 = 138
r17 = 75
::L163::
-- ??? opcode 110 (UNKNOWN)
::L165::
goto L57
if not (not(V[A[n]]<KA[n])) then goto L41 end
::L167::
goto L100
if not (not(V[A[n]]<KA[n])) then goto L187 end
::L169::
goto L81
-- ??? opcode 52 (UNKNOWN)
::L171::
goto L139
r10 = upvalue_index
::L173::
-- numeric for-loop (var rNone+3, jump LNone)
if not (not(V[A[n]]<KA[n])) then goto L25 end
::L175::
goto L69
r3 = true
::L177::
goto L116
if not (not(V[A[n]]<KA[n])) then goto L118 end
goto L102
if not (KA[n]<V[A[n]]) then goto L175 end
::L181::
goto L128
r4 = true
::L183::
goto L57
r10 = true
r11 = r2
r10 = true(r2)
::L187::
goto L190
if not (KA[n]<V[A[n]]) then goto L73 end
::L189::
goto L43
::L190::
goto L73
r3 = (true(r2))
::L192::
goto L57
-- numeric for-loop (var rNone+3, jump LNone)
r3 = <upvalue table index>
r4 = <upvalue table index>
r5 = <upvalue table index>
r6 = 86
r7 = 257
r8 = 57
::L201::
-- ??? opcode 110 (UNKNOWN)
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r8 = 126260821
goto L94
-- ??? opcode 42 (UNKNOWN)
