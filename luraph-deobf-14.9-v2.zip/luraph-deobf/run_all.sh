#!/data/data/com.termux/files/usr/bin/bash
cd ~/luraph-deobf
find "zain20m-samples/Luraph/Luraph v14.9 samples" sixzens-samples/Luraph/V14.9 -name '*.lua' | while read f; do
  python3 luraph_deobf.py "$f" out-all
done > run_all.log 2>&1
echo DONE >> run_all.log
