#!/usr/bin/env python3
"""
Parse the Luraph VM dispatch tree (if/else chain keyed on the shuffled opcode
W) and extract: shuffled_opcode -> handler source text.
"""
import re, sys, json

TOKEN_RE = re.compile(r'''
    (?P<ws>\s+)
  | (?P<hex>0[xX][0-9a-fA-F_]+)
  | (?P<bin>0[bB][01_]+)
  | (?P<num>\d[\d_]*(?:\.\d[\d_]*)?)
  | (?P<str>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')
  | (?P<op2>>=|<=|==|~=|//|\.\.)
  | (?P<id>[A-Za-z_][A-Za-z_0-9]*)
  | (?P<op>[-+*/%^#<>=(){}\[\];:,.])
''', re.X)

KEYWORDS = {'if','then','else','elseif','end','do','for','while','repeat','until',
            'function','local','return','not','and','or','in','break','continue',
            'nil','true','false'}

OPENERS = ('if', 'for', 'while', 'function', 'repeat')   # each has one closer

def tokenize(text):
    toks = []
    i = 0
    while i < len(text):
        m = TOKEN_RE.match(text, i)
        if not m:
            raise ValueError(f"tokenize failed at {i}: {text[i:i+30]!r}")
        i = m.end()
        kind = m.lastgroup
        if kind == 'ws':
            continue
        val = m.group()
        if kind == 'id' and val in KEYWORDS:
            toks.append(('kw', val))
        elif kind in ('hex', 'bin', 'num'):
            n = val.replace('_', '')
            if n.lower().startswith('0x'):
                toks.append(('num', int(n, 16)))
            elif n.lower().startswith('0b'):
                toks.append(('num', int(n, 2)))
            else:
                toks.append(('num', float(n)))
        else:
            toks.append((kind, val))
    return toks

class Parser:
    def __init__(self, toks, dvar='W'):
        self.t = toks
        self.i = 0
        self.dvar = dvar

    def peek(self, k=0):
        j = self.i + k
        return self.t[j] if j < len(self.t) else (None, None)

    def next(self):
        tok = self.t[self.i] if self.i < len(self.t) else (None, None)
        self.i += 1
        return tok

    # ---------- block utilities ----------
    def skip_to_then(self):
        """Consume tokens until 'then' at paren depth 0."""
        d = 0
        while True:
            kind, val = self.next()
            if kind is None:
                return
            if val == '(':
                d += 1
            elif val == ')':
                d -= 1
            elif d == 0 and kind == 'kw' and val == 'then':
                return

    def skip_balanced(self):
        """Skip one balanced statement (if/for/while/do/function/repeat or
        simple statement) starting at the current token."""
        kind, val = self.next()
        if kind is None:
            return
        if kind == 'kw' and val in OPENERS:
            if val == 'repeat':
                self._run_to_closer('until')
            else:
                if val in ('for', 'while'):
                    self.skip_to_do()
                else:
                    self.skip_to_then()
                self._run_to_closer('end')
        elif kind == 'kw' and val == 'do':
            self._run_to_closer('end')
        elif kind == 'kw' and val in ('local', 'return', 'break', 'continue'):
            while True:
                k2, v2 = self.peek()
                if k2 is None:
                    break
                if k2 == 'op' and v2 == ';':
                    self.next()
                    break
                if k2 == 'kw' and v2 in ('end', 'else', 'elseif'):
                    break
                # a function literal or nested block inside the expression
                if k2 == 'kw' and v2 == 'function':
                    self.next()
                    self._run_to_closer('end')
                    continue
                self.next()
        # anything else: single token, already consumed

    def skip_to_do(self):
        d = 0
        while True:
            kind, val = self.next()
            if kind is None:
                return
            if val == '(':
                d += 1
            elif val == ')':
                d -= 1
            elif d == 0 and kind == 'kw' and val == 'do':
                return

    def _run_to_closer(self, closer):
        d = 1
        while d > 0:
            kind, val = self.next()
            if kind is None:
                return
            if kind == 'kw':
                if val in OPENERS:
                    d += 1
                elif val == 'end' or val == 'until':
                    d -= 1

    # ---------- dispatch parsing ----------
    def parse_statements(self, results, lo, hi):
        """Parse statements in range [lo,hi] until 'end' (consumed) or
        'else'/'elseif' (left for caller). A single-value range is a leaf."""
        if lo == hi:
            results[lo] = self.capture_leaf()
            k2, v2 = self.peek()
            if k2 == 'kw' and v2 == 'end':
                self.next()
            return
        while True:
            kind, val = self.peek()
            if kind is None:
                return
            if kind == 'kw' and val == 'end':
                self.next()
                return
            if kind == 'kw' and val in ('else', 'elseif'):
                return
            if kind == 'kw' and val == 'if':
                save = self.i
                cond_start = self.i + 1
                self.skip_to_then()
                cond_toks = self.t[cond_start:self.i - 1]
                wcond = classify_cond(cond_toks, self.dvar)
                if wcond is not None:
                    self.dispatch_node(results, lo, hi, wcond)
                else:
                    self.i = save
                    self.skip_balanced()
                continue
            self.skip_balanced()

    def _minus(self, lo, hi, n):
        """Range [lo,hi] excluding n."""
        if lo == n:
            return n + 1, hi
        if hi == n:
            return lo, n - 1
        return lo, hi

    def dispatch_node(self, results, lo, hi, wcond):
        kind, op, n = wcond
        # 'then' was already consumed by skip_to_then in the caller
        if op == '==':
            results[n] = self.capture_leaf()
            tlo, thi = self._minus(lo, hi, n)
            k2, v2 = self.peek()
            if k2 == 'kw' and v2 == 'else':
                self.next()
                self.parse_statements(results, tlo, thi)
            elif k2 == 'kw' and v2 == 'end':
                self.next()
            return
        if op == '~=':
            # then-branch: context minus n; else-branch: exactly n
            tlo, thi = self._minus(lo, hi, n)
            self.parse_statements(results, tlo, thi)
            k2, v2 = self.peek()
            if k2 == 'kw' and v2 == 'else':
                self.next()
                results[n] = self.capture_leaf()
                k3, v3 = self.peek()
                if k3 == 'kw' and v3 == 'end':
                    self.next()
            elif k2 == 'kw' and v2 == 'end':
                self.next()
            return
        if op == '>=' and kind == 'then':
            # W>=N: then-branch is the high range
            tlo, thi = max(lo, n), hi
            elo, ehi = lo, min(hi, n - 1)
        elif op == '>=' and kind == 'else':
            # not(W>=N): then-branch is the low range
            tlo, thi = lo, min(hi, n - 1)
            elo, ehi = max(lo, n), hi
        elif op == '<' and kind == 'then':
            # plain W<N: then-branch is the low range
            tlo, thi = lo, min(hi, n - 1)
            elo, ehi = max(lo, n), hi
        elif op == '<' and kind == 'else':
            # not(W<N): then-branch is the high range
            tlo, thi = max(lo, n), hi
            elo, ehi = lo, min(hi, n - 1)
        else:
            self.parse_statements(results, lo, hi)
            self.consume_else_or_end(results, lo, hi)
            return
        self.parse_statements(results, tlo, thi)
        self.consume_else_or_end(results, elo, ehi)

    def consume_else_or_end(self, results, elo, ehi):
        k2, v2 = self.peek()
        if k2 == 'kw' and v2 == 'else':
            self.next()
            self.parse_statements(results, elo, ehi)
        elif k2 == 'kw' and v2 == 'elseif':
            # elseif chain: parse its condition and recurse
            self.next()
            cond_start = self.i
            self.skip_to_then()
            cond_toks = self.t[cond_start:self.i - 1]
            wcond = classify_cond(cond_toks, self.dvar)
            if wcond is not None:
                self.dispatch_node(results, elo, ehi, wcond)
            else:
                self.parse_statements(results, elo, ehi)
        elif k2 == 'kw' and v2 == 'end':
            self.next()

    def capture_leaf(self):
        """Consume tokens until 'end'/'else'/'elseif' at depth 0; return text."""
        start = self.i
        d = 0
        while True:
            kind, val = self.peek()
            if kind is None:
                break
            if d == 0 and kind == 'kw' and val in ('end', 'else', 'elseif'):
                break
            if kind == 'kw' and val in OPENERS:
                d += 1
            elif kind == 'kw' and val in ('end', 'until'):
                d -= 1
            self.next()
        return self.render(self.t[start:self.i])

    def render(self, toks):
        parts = []
        for kind, val in toks:
            parts.append(str(val))
        return ' '.join(parts)


def classify_cond(toks, dvar='W'):
    """Returns ('then'|'else', op, num) for dispatch-variable conditions."""
    if not toks:
        return None
    if len(toks) == 3 and toks[0] == ('id', dvar):
        op_tok = toks[1]
        op = op_tok[1] if op_tok[0] in ('op2', 'op') else None
        if op in ('>=', '<', '==', '~='):
            return ('then', op, toks[2][1])
    if toks[0] == ('kw', 'not'):
        inner = [t for t in toks if t not in (('op', '('), ('op', ')'))]
        if len(inner) == 4 and inner[1] == ('id', dvar) \
                and inner[2][0] in ('op2', 'op'):
            iop = inner[2][1]
            if iop == '<':
                return ('else', '<', inner[3][1])
            if iop == '>=':
                return ('else', '>=', inner[3][1])
    return None


def main():
    disp = open(sys.argv[1]).read()
    disp = re.sub(r'^\s*local\s+W\s*=\s*B\[n\]\s*;', '', disp)
    toks = tokenize(disp)
    p = Parser(toks)
    results = {}
    p.parse_statements(results, 0, 2**31)
    print(f"extracted {len(results)} opcode handlers")
    out = {str(w): results[w] for w in sorted(results)}
    for w in sorted(results):
        print(f"W={w}: {results[w][:130]}")
    json.dump(out, open(sys.argv[2], 'w'), indent=1)
    if p.i < len(p.t):
        print(f"NOTE: {len(p.t) - p.i} tokens left unconsumed")

if __name__ == '__main__':
    main()
