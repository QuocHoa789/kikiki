#!/usr/bin/env python3
"""
Build an instrumented Luau runner for Luraph 14.9 mode-B files (inline VM).

Replaces the single `buffer` library reference with a logging wrapper so every
buffer read/write the VM performs is logged in order. Run with: luau runner.luau
"""
import re, sys, os

PRELUDE = r'''
-- ===== Luraph deobf instrumentation prelude =====
unpack = unpack or table.unpack
-- force-replace getfenv: Luau CLI has a builtin that returns the real env
getfenv = function() return __FAKEENV end
setfenv = function(f, t) return f end

-- ===== fake Roblox environment (lets the VM run past Instance.new etc.) =====
local function __stub(name)
    return setmetatable({}, {
        __index = function(t, k)
            local v = __stub(name .. "." .. tostring(k))
            rawset(t, k, v)
            return v
        end,
        __call = function(t, ...) return __stub(name .. "()") end,
        __tostring = function() return "<stub " .. name .. ">" end,
        __newindex = function() end,
    })
end
local __fakes = {'Instance', 'game', 'workspace', 'Enum', 'script', 'Vector3',
                 'CFrame', 'Color3', 'UDim2', 'UDim', 'Vector2', 'TweenInfo',
                 'Ray', 'Region3', 'NumberRange', 'NumberSequence',
                 'ColorSequence', 'BrickColor', 'task', 'shared', 'Tick', 'plugin',
                 'RunService', 'Players', 'HttpService', 'UserInputService'}
for _, fname in ipairs(__fakes) do
    if _G[fname] == nil then
        pcall(function() rawset(_G, fname, __stub(fname)) end)
    end
end
-- fallback: if _G is readonly, expose stubs via a table the shim returns
__FAKEENV = setmetatable({}, {__index = function(t, k)
    -- catch-all: any unknown global becomes a stub (lets the VM keep running)
    local v = __stub(tostring(k))
    rawset(t, k, v)
    return v
end})
for _, fname in ipairs(__fakes) do
    __FAKEENV[fname] = __stub(fname)
end

-- ===== execution trace =====
__TRACE = {}
__V2CAP = nil
__SEEN = setmetatable({}, {__mode = "k"})
__NPROTO = 0
__PROTOMAP = setmetatable({}, {__mode = "k"})
__PROTDATA = {}
__TRACEBY = {}
__PROTOCONST = {}
__PROTOREGS = {}

local __ids = {n = 0}
local __name = setmetatable({}, {__mode = "k"})
local function bid(b)
    if not __name[b] then
        __ids.n += 1
        __name[b] = __ids.n
    end
    return __name[b]
end

local __log = {}
local function LOG(fmt, ...)
    __log[#__log + 1] = string.format(fmt, ...)
end
local function flush()
    -- chunked print to avoid arg limits
    local parts = {}
    for i, line in ipairs(__log) do
        parts[#parts + 1] = line
    end
    print(table.concat(parts, "\n"))
end

local real = buffer
BUFLOG = {}
BUFLOG.create = function(sz) local b = real.create(sz); LOG("create %d id=%d", sz, bid(b)); return b end
BUFLOG.fromstring = function(s) local b = real.fromstring(s); LOG("fromstring len=%d id=%d", #s, bid(b)); return b end
BUFLOG.tostring = function(b) LOG("tostring id=%d", bid(b)); return real.tostring(b) end
BUFLOG.len = function(b) LOG("len id=%d", bid(b)); return real.len(b) end
BUFLOG.copy = function(...) LOG("copy"); return real.copy(...) end
BUFLOG.readstring = function(b, o, n) LOG("readstring id=%d off=%d n=%d", bid(b), o, n); return real.readstring(b, o, n) end
BUFLOG.writestring = function(b, o, s) LOG("writestring id=%d off=%d n=%d", bid(b), o, #s); return real.writestring(b, o, s) end
BUFLOG.readu8   = function(b, o) local v = real.readu8(b, o);   LOG("readu8   id=%d off=%d = %d", bid(b), o, v); return v end
BUFLOG.readu16  = function(b, o) local v = real.readu16(b, o);  LOG("readu16  id=%d off=%d = %d", bid(b), o, v); return v end
BUFLOG.readu32  = function(b, o) local v = real.readu32(b, o);  LOG("readu32  id=%d off=%d = %d", bid(b), o, v); return v end
BUFLOG.readi8   = function(b, o) local v = real.readi8(b, o);   LOG("readi8   id=%d off=%d = %d", bid(b), o, v); return v end
BUFLOG.readi16  = function(b, o) local v = real.readi16(b, o);  LOG("readi16  id=%d off=%d = %d", bid(b), o, v); return v end
BUFLOG.readi32  = function(b, o) local v = real.readi32(b, o);  LOG("readi32  id=%d off=%d = %d", bid(b), o, v); return v end
BUFLOG.readf32  = function(b, o) local v = real.readf32(b, o);  LOG("readf32  id=%d off=%d = %f", bid(b), o, v); return v end
BUFLOG.readf64  = function(b, o) local v = real.readf64(b, o);  LOG("readf64  id=%d off=%d = %f", bid(b), o, v); return v end
BUFLOG.writeu8  = function(b, o, v) LOG("writeu8  id=%d off=%d = %d", bid(b), o, v); return real.writeu8(b, o, v) end
BUFLOG.writeu16 = function(b, o, v) LOG("writeu16 id=%d off=%d = %d", bid(b), o, v); return real.writeu16(b, o, v) end
BUFLOG.writeu32 = function(b, o, v) LOG("writeu32 id=%d off=%d = %d", bid(b), o, v); return real.writeu32(b, o, v) end
BUFLOG.writei8  = function(b, o, v) LOG("writei8  id=%d off=%d = %d", bid(b), o, v); return real.writei8(b, o, v) end
BUFLOG.writei16 = function(b, o, v) LOG("writei16 id=%d off=%d = %d", bid(b), o, v); return real.writei16(b, o, v) end
BUFLOG.writei32 = function(b, o, v) LOG("writei32 id=%d off=%d = %d", bid(b), o, v); return real.writei32(b, o, v) end
BUFLOG.writef32 = function(b, o, v) LOG("writef32 id=%d off=%d = %f", bid(b), o, v); return real.writef32(b, o, v) end
BUFLOG.writef64 = function(b, o, v) LOG("writef64 id=%d off=%d = %f", bid(b), o, v); return real.writef64(b, o, v) end

-- ===== VM state dumper (called right before the interpreter loop) =====
__OUT = {}
local function __ser(v, depth, seen)
    local t = type(v)
    if t == "string" then
        return string.format("%q", v)
    elseif t == "number" then
        if v == math.floor(v) and math.abs(v) < 2^53 then
            return string.format("%d", v)
        end
        return string.format("%.17g", v)
    elseif t == "boolean" then
        return tostring(v)
    elseif t == "nil" then
        return "nil"
    elseif t == "table" then
        if depth > 6 then return "<deep>" end
        if seen[v] then return "<cycle>" end
        seen[v] = true
        local parts = {}
        for k, val in pairs(v) do
            parts[#parts + 1] = tostring(k) .. "=" .. __ser(val, depth + 1, seen)
        end
        return "{" .. table.concat(parts, ",") .. "}"
    else
        return "<" .. t .. ">"
    end
end

__DUMP = function(state)
    for key, arr in pairs(state) do
        __OUT[#__OUT + 1] = "##ARR " .. tostring(key)
        if type(arr) == 'table' then
            for k, v in pairs(arr) do
                local ok, txt = pcall(__ser, v, 0, {})
                __OUT[#__OUT + 1] = tostring(k) .. "\t" .. (ok and txt or "<err>")
            end
        else
            __OUT[#__OUT + 1] = "<" .. type(arr) .. ">" .. tostring(arr)
        end
    end
    -- chunked output
    local acc = {}
    local size = 0
    for i, line in ipairs(__OUT) do
        acc[#acc + 1] = line
        size += #line + 1
        if size > 500000 then
            print(table.concat(acc, "\n"))
            acc = {}
            size = 0
        end
    end
    if #acc > 0 then print(table.concat(acc, "\n")) end
end
-- ===== end prelude =====
'''

def build_runner(path, out, wrap=True):
    src = open(path, "r", encoding="latin-1").read()
    # Replace the buffer library reference(s). Only bare `buffer` identifiers.
    n = len(re.findall(r'\bbuffer\b', src))
    src = re.sub(r'\bbuffer\b', 'BUFLOG', src)
    print(f"{path}: replaced {n} buffer refs")
    if wrap:
        # Inject the VM-state dump right before the interpreter loop.
        # Generic: find "while true do local OPC=(ARR[PC]);" or
        # "repeat ... local OPC=(ARR[PC]);"
        loop_re = re.compile(
            r'(?:while\s+true\s+do|repeat)(?:[^;{]{0,120}?;)??\s*local\s+(\w+)\s*=\s*\(?\s*(\w+)\s*\[\s*(\w+)\s*\]\s*\)?\s*;')
        m = loop_re.search(src)
        if m:
            opc, arr, pc = m.group(1), m.group(2), m.group(3)
            # Collect identifiers X referenced as X[pc] in the dispatch region
            tail = src[m.start():]
            ids = set(re.findall(r'\b([A-Za-z_]\w*)\s*\[\s*' + re.escape(pc) + r'\s*\]', tail))
            ids.discard(arr)
            parts = [f"{arr}={arr}", f"{pc}={pc}"]
            parts += [f"{i}={i}" for i in sorted(ids)]
            hook = "__DUMP({" + ",".join(parts) + "});\n"
            # detect the register stack: identifier written most via operand
            # arrays, i.e. IDENT[<pc-indexed-ident>[pc]]
            pc_ids = set(ids) | {arr}
            write_counts = {}
            region = tail[:tail.find(pc + '+')] if (pc + '+') in tail else tail
            for ident in set(re.findall(r'\b([A-Za-z_]\w*)\s*\[', region)) - pc_ids:
                cnt = 0
                for opid in pc_ids:
                    cnt += len(re.findall(
                        r'\b' + re.escape(ident) + r'\s*\[\s*' +
                        re.escape(opid) + r'\s*\[', region))
                if cnt:
                    write_counts[ident] = cnt
            regstack = max(write_counts, key=write_counts.get) if write_counts else None
            print(f"register stack detected: {regstack} (writes={write_counts})")
            # proto detection + per-proto trace: nested closures reuse the same
            # dispatch loop with different arrays -> snapshot each new proto
            proto_tbl = "{" + ",".join(parts) + "}"
            trace_hook = (
                f"if not __SEEN[{arr}] then "
                f"__SEEN[{arr}] = true; "
                f"__NPROTO = __NPROTO + 1; "
                f"__PROTOMAP[{arr}] = __NPROTO; "
                f"__PROTDATA[__NPROTO] = {proto_tbl}; "
                f"end\n"
                f"local __pi = __PROTOMAP[{arr}];\n"
                f"local __tl = __TRACEBY[__pi]; "
                f"if not __tl then __tl = {{}}; __TRACEBY[__pi] = __tl end\n"
                f"__tl[#__tl + 1] = {pc};\n")
            if regstack:
                # capture this proto's constant table whenever register [2]
                # holds a table (it is created by the runtime bootstrap)
                trace_hook += (f"local __v2 = {regstack}[2]; "
                               f"if type(__v2) == 'table' then "
                               f"__PROTOCONST[__pi] = __v2 end\n"
                               # and keep the whole register stack for analysis
                               f"__PROTOREGS[__pi] = {regstack};\n")
            loop_stmt = m.group(0)
            src = src[:m.start()] + hook + src[m.start():]
            # re-locate the loop statement after insertion and append trace inside
            pos2 = src.find(loop_stmt, m.start())
            src = src[:pos2 + len(loop_stmt)] + trace_hook + src[pos2 + len(loop_stmt):]
            print(f"dump hook injected (opc={opc}, arr={arr}, pc={pc}, "
                  f"arrays={sorted(ids)})")
        else:
            print("WARNING: interpreter loop marker not found")
        src = ("local __ok, __err = xpcall(function(...)\n" + src +
               "\nend, function(e)\n"
               "    print('=== ERROR ===')\n"
               "    print(debug.traceback(e, 2))\n"
               "    return e\n"
               "end)\n"
               "print('=== DONE ok=' .. tostring(__ok) .. ' ===')\n"
               "-- dump execution trace + captured register [2] (constant table)\n"
               "local __t = {}\n"
               "for i, v in ipairs(__TRACE) do __t[#__t + 1] = tostring(v) end\n"
               "print('=== TRACE ' .. #__TRACE .. ' ===')\n"
               "print(table.concat(__t, ' '))\n"
               "-- per-proto traces\n"
               "for pi, tl in pairs(__TRACEBY) do\n"
               "    local __pt = {}\n"
               "    for i, v in ipairs(tl) do __pt[#__pt + 1] = tostring(v) end\n"
               "    print('=== PTRACE ' .. pi .. ' ' .. #tl .. ' ===')\n"
               "    print(table.concat(__pt, ' '))\n"
               "end\n"
               "-- proto data snapshots\n"
               "for pi, pdata in pairs(__PROTDATA) do\n"
               "    print('=== PROTO ' .. pi .. ' ===')\n"
               "    for key, arr in pairs(pdata) do\n"
               "        print('##ARR ' .. tostring(key))\n"
               "        if type(arr) == 'table' then\n"
               "            for k, v in pairs(arr) do\n"
               "                local ok, s = pcall(function() return __ser(v, 0, {}) end)\n"
               "                print(tostring(k) .. '\\t' .. (ok and s or '<err>'))\n"
               "            end\n"
               "        else\n"
               "            print('<' .. type(arr) .. '>' .. tostring(arr))\n"
               "        end\n"
               "    end\n"
               "end\n"
               "-- per-proto constant tables\n"
               "for pi, ct in pairs(__PROTOCONST) do\n"
               "    print('=== PCONST ' .. pi .. ' ===')\n"
               "    if type(ct) == 'table' then\n"
               "        for k, v in pairs(ct) do\n"
               "            local ok, s = pcall(function() return __ser(v, 0, {}) end)\n"
               "            print(tostring(k) .. '\\t' .. (ok and s or '<err>'))\n"
               "        end\n"
               "    else\n"
               "        print('<' .. type(ct) .. '>' .. tostring(ct))\n"
               "    end\n"
               "end\n"
               "-- per-proto register stacks (table registers as key/value lines)\n"
               "for pi, regs in pairs(__PROTOREGS) do\n"
               "    if type(regs) == 'table' then\n"
               "        for k, v in pairs(regs) do\n"
               "            if type(v) == 'table' then\n"
               "                print('=== PREGS ' .. pi .. ' reg ' .. k .. ' ===')\n"
               "                for kk, vv in pairs(v) do\n"
               "                    local ok, s = pcall(function() return __ser(vv, 0, {}) end)\n"
               "                    print(tostring(kk) .. '\\t' .. (ok and s or '<err>'))\n"
               "                end\n"
               "            end\n"
               "        end\n"
               "    end\n"
               "end\n"
               "if __V2CAP then\n"
               "    print('=== V2 ===')\n"
               "    local __k = {}\n"
               "    for k, v in pairs(__V2CAP) do\n"
               "        local ok, s = pcall(function() return __ser(v, 0, {}) end)\n"
               "        __k[#__k + 1] = tostring(k) .. '\\t' .. (ok and s or '<err>')\n"
               "    end\n"
               "    print(table.concat(__k, '\\n'))\n"
               "end\n")
    open(out, "w", encoding="latin-1").write(PRELUDE + "\n" + src)
    print(f"runner written: {out} ({os.path.getsize(out)} bytes)")
    if m:
        return m.group(2), m.group(3), sorted(ids)
    return None

if __name__ == "__main__":
    build_runner(sys.argv[1], sys.argv[2])
