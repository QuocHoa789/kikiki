#!/usr/bin/env python3
"""
Luraph 14.9 blob extractor.

Luraph v14.9 loader structure:
    return(function()
      ... z85 decoder (X) ...
      local h,F = X([[BLOB1]]), X([[BLOB2]])
      ... LZMA range decoder (g) ...
      local U = g(h)   -- blob1 -> LZMA -> Lua 5.1 bytecode chunk (main VM)
      h = g(F)         -- blob2 -> LZMA -> serialized VM data (buffer)
      return loadstring(U)(h)
    end)(...)

This script extracts both long-string blobs, z85-decodes them and
LZMA-decompresses the raw streams.
"""
import re, sys, os, lzma, struct

# ---------------------------------------------------------------- z85
Z85_OFFSET = 33
POW = (52200625, 614125, 7225, 85, 1)  # (c1..c5) multipliers, matches loader

def z85_decode(s: str) -> bytes:
    """Mirrors the loader: strip 5-char header, 'z' -> '!!!!!', 5 chars -> 4 bytes LE."""
    if s[:3] != "LPH":
        raise ValueError(f"bad blob header: {s[:8]!r}")
    s = s[4:]                       # string.sub(b, 5) is 1-indexed -> strips 4 chars
    s = s.replace("z", "!!!!!")     # 'z' stands for '!!!!!' (4 zero bytes)
    if len(s) % 5:
        raise ValueError(f"payload not multiple of 5 after header: {len(s)}")
    out = bytearray()
    for i in range(0, len(s), 5):
        grp = s[i:i+5]
        m = 0
        for ch, p in zip(grp, POW):
            m += (ord(ch) - Z85_OFFSET) * p
        out += struct.pack("<I", m & 0xFFFFFFFF)
    return bytes(out)

# ---------------------------------------------------------------- blob scan
LONGSTR = re.compile(rb'\[(=*)\[', re.S)

def find_long_strings(data: bytes):
    """Yield (start, end, content) of every [=[...]=] / [[...]] long string."""
    res = []
    i = 0
    while i < len(data):
        m = LONGSTR.match(data, i)
        if not m:
            i += 1
            continue
        eq = m.group(1)
        opener = b'[' + eq + b'['
        closer = b']' + eq + b']'
        j = data.find(closer, m.end())
        if j == -1:
            i = m.end()
            continue
        content = data[m.end():j]
        res.append((i, j + len(closer), content))
        i = j + len(closer)
    return res

def is_luraph_blob(content: bytes) -> bool:
    """A Luraph 14.9 z85 blob starts with 'LPH' and only holds base85 chars."""
    if len(content) < 16 or not content.startswith(b"LPH"):
        return False
    body = content[4:]                           # header = first 4 chars ('LPH?')
    allowed = set(range(33, 118)) | {ord('z')}   # base85 + z escape
    # length is a multiple of 5 only AFTER expanding 'z' -> '!!!!!'
    expanded = len(body) + 4 * body.count(b"z")
    return all(c in allowed for c in body[:4096]) and expanded % 5 == 0

# ---------------------------------------------------------------- lzma
def try_lzma(raw: bytes, lc=3, lp=0, pb=2, dict_size=1 << 24):
    filt = [{"id": lzma.FILTER_LZMA1, "lc": lc, "lp": lp, "pb": pb,
             "dict_size": dict_size}]
    d = lzma.LZMADecompressor(format=lzma.FORMAT_RAW, filters=filt)
    return d.decompress(raw)

def smart_lzma(raw: bytes, label=""):
    """The embedded decoder reads a 5-byte range-coder init (no props byte),
    so the stream is raw LZMA1 with hardcoded lc/lp/pb. Try common combos."""
    for lc, lp, pb in [(3,0,2),(0,0,2),(3,0,0),(1,0,2),(2,0,2),(0,2,2),(3,0,3)]:
        try:
            out = try_lzma(raw, lc, lp, pb)
            print(f"  [{label}] LZMA ok (lc={lc},lp={lp},pb={pb}) -> {len(out)} bytes, "
                  f"head={out[:8]!r}")
            return out, (lc, lp, pb)
        except Exception:
            continue
    return None, None

# ---------------------------------------------------------------- main
def extract(path, outdir):
    data = open(path, "rb").read()
    os.makedirs(outdir, exist_ok=True)
    blobs = [(s, e, c) for s, e, c in find_long_strings(data) if is_luraph_blob(c)]
    print(f"{path}: {len(blobs)} Luraph blob(s)")
    results = []
    for idx, (s, e, content) in enumerate(blobs):
        raw = z85_decode(content.decode("latin-1"))
        base = f"blob{idx+1}"
        open(os.path.join(outdir, f"{base}.z85raw"), "wb").write(raw)
        print(f"  {base}: {len(content)} chars @ {s} -> {len(raw)} raw bytes")
        out, params = smart_lzma(raw, base)
        if out is not None:
            open(os.path.join(outdir, f"{base}.out"), "wb").write(out)
            results.append((base, out, params))
        else:
            print(f"  {base}: LZMA failed - all param combos exhausted")
    return results

if __name__ == "__main__":
    for f in sys.argv[1:]:
        name = os.path.splitext(os.path.basename(f))[0]
        extract(f, os.path.join("out", name))
