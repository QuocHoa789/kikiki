#!/usr/bin/env python3
"""
Luraph v14.9 Deobfuscator
=========================

Pipeline (mode B - inline VM):
  1. Detect Luraph 14.9 and extract the z85-encoded data blob.
  2. Build an instrumented Luau runner that logs every buffer operation and
     dumps the deserialized VM state right before the interpreter loop runs.
  3. Run it with the `luau` CLI, capture the VM state (instruction arrays,
     constants, globals, upvalues).
  4. Parse the VM dispatch tree from the obfuscated file to recover the
     shuffled opcode -> real operation mapping.
  5. Emit a readable disassembly of every deserialized proto.

Usage:
  python3 luraph_deobf.py <obfuscated.lua> [outdir]

Requires: python3, luau CLI (https://github.com/luau-lang/luau)
"""
import re, sys, os, json, subprocess, tempfile, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from luraph_extract import find_long_strings, z85_decode, is_luraph_blob
from parse_dispatch import Parser, tokenize, classify_cond
import make_runner

# --------------------------------------------------------------------------
# handler classification: shuffled opcode -> Luau/Lua operation name
# --------------------------------------------------------------------------

def norm(txt):
    t = re.sub(r'\s+', '', txt)
    return t.replace('(', '').replace(')', '')

def _abstract(txt, pc):
    """Abstract per-file identifier names to canonical tokens:
    pc-indexed arrays -> K0..Kn, other identifiers -> R0..Rm."""
    t = norm(txt)
    ids = sorted(set(re.findall(r'(\w+)\s*\[\s*' + re.escape(pc) + r'\s*\]', t)))
    for i, name in enumerate(ids):
        t = re.sub(r'\b' + re.escape(name) + r'(?=\[)', f'K{i}', t)
    others = sorted(set(re.findall(r'\b([A-Za-z_]\w*)\b', t))
                    - set(f'K{i}' for i in range(len(ids)))
                    - KEYWORDS)
    for i, name in enumerate(others):
        t = re.sub(r'\b' + re.escape(name) + r'\b', f'R{i}', t)
    return t

KEYWORDS = {'and','break','do','else','elseif','end','false','for','function','if',
            'in','local','nil','not','or','repeat','return','then','true','until',
            'while','continue','n','pc','t','w','g','m','l','e','h','x','y','k',
            'j','f','b','s','o','d','i','a','c','u','v','q','r','p','z'}

def role_abstract(txt, roles, pc=None):
    """Rewrite a handler body using detected roles:
    pc -> n, reg_stack -> V, operands -> A/B/C.., constants -> KA/KB...
    Replacements run on the ORIGINAL text (before whitespace stripping) so
    glued tokens like `thenS` are handled; parens are KEPT."""
    if not roles:
        return re.sub(r'\s+', '', txt)
    t = txt
    pcid = pc or roles.get('pc')
    if pcid:
        t = re.sub(r'(?<![\w.])' + re.escape(pcid) + r'(?![\w])', ' PCX ', t)
    if roles.get('reg_stack'):
        t = re.sub(r'(?<![\w.])' + re.escape(roles['reg_stack']) + r'(?![\w])', ' V ', t)
    if roles.get('env'):
        t = re.sub(r'(?<![\w.])' + re.escape(roles['env']) + r'(?![\w])', ' E ', t)
    # normalize trailing .0 on numbers
    t = re.sub(r'(\d+)\.0\b', r'\1', t)
    # operands: map to A, B, C... (single letters, per field)
    if roles.get('operands'):
        seen = {}
        def opmap(m):
            name = m.group(1)
            if name not in seen:
                seen[name] = 'ABCDEF'[len(seen)] if len(seen) < 6 else 'O%d' % len(seen)
            return ' ' + seen[name] + ' '
        pat = r'(?<![\w.])(' + '|'.join(re.escape(o) for o in roles['operands']) + r')(?![\w])'
        t = re.sub(pat, opmap, t)
    if roles.get('constants'):
        seen2 = {}
        def cstmap(m):
            name = m.group(1)
            if name not in seen2:
                seen2[name] = ['KA', 'KB', 'KC', 'KD'][len(seen2)] if len(seen2) < 4 else 'K%d' % len(seen2)
            return ' ' + seen2[name] + ' '
        pat = r'(?<![\w.])(' + '|'.join(re.escape(c) for c in roles['constants']) + r')(?![\w])'
        t = re.sub(pat, cstmap, t)
    t = re.sub(r'\s+', '', t)
    t = t.replace('(V)', 'V').replace('(V)', 'V')
    return re.sub(r'PCX', 'n', t)


_ARITH = {'+': 'ADD', '-': 'SUB', '*': 'MUL', '/': 'DIV', '%': 'MOD', '^': 'POW'}
_CMPS = {'==': 'EQ', '~=': 'NE', '<': 'LT', '<=': 'LE', '>': 'GT', '>=': 'GE'}


def classify_handler(txt, pc='n', _role_ctx=None):
    # --- pass 0: role-based abstraction (accurate across layouts) ---
    if _role_ctx:
        t = role_abstract(txt, _role_ctx, pc)
        IDX = r'(?:[^\[\]]|\[(?:[^\[\]]|\[[^\[\]]*\])*\])+'
        m = re.search(r'V\[(' + IDX + r')\]=V\[\1\]\(([^()]*)\)', t)
        if m:
            args = m.group(2).strip()
            if args == '':
                return 'CALL_0R_0A'
            if args == '...':
                return 'CALL_0R_VARARG'
            return 'CALL_%dA' % (args.count(',') + 1)
        m = re.search(r'V\[(' + IDX + r')\]=V\[\1\]\((.+?)\)', t)
        if m:
            inner = m.group(2)
            if inner.strip() == '...':
                return 'CALL_0R_VARARG'
            return 'CALL_%dA' % (inner.count(',') + 1)
        m = re.search(r'V\[' + IDX + r']\(([^()]*)\)', t)
        if m and 'V[' in t:
            args = m.group(1).strip()
            if args == '...':
                return 'CALL_VARARG'
            if args == '':
                return 'CALL_0R_0A'
            return 'CALL_%dA' % (args.count(',') + 1)
        if re.search(r'V\[' + IDX + r']\(\.\.\.', t):
            return 'CALL_VARARG'
        # ---- table indexing ----
        if re.search(r'V\[' + IDX + r']\[' + IDX + r']=V\[' + IDX + r']', t):
            return 'SETTABLE'
        if re.search(r'\w+\[[^\]]*\]\[[^\]]*\]=V\[', t):
            return 'SETTABLE'
        if re.search(r'\w+\[\d+\]\[\w+\[[^\]]*\]\]=\(?\(?V\[', t):
            return 'SETTABLE'
        if re.search(r'V\[' + IDX + r']=V\[' + IDX + r']\[', t):
            return 'GETTABLE'
        if re.search(r'V\[' + IDX + r']\[[^\]]*\]\.', t):
            return 'GETTABLE_LEN'
        # env (global) access
        if re.search(r'E\[[^\]]*\]=', t):
            return 'SETGLOBAL'
        if re.search(r'=E\[[^\]]*\]', t):
            return 'GETGLOBAL'
        # ---- arithmetic: V[x] = V[y] op V[z] ----
        m = re.search(r'V\[(' + IDX + r')\]=V\[(' + IDX + r')\]([+\-*/%^])V\[(' + IDX + r')\]', t)
        if m:
            return _ARITH[m.group(3)]
        m = re.search(r'V\[' + IDX + r']=\(?\(?V\[' + IDX + r']\)?([+\-*/%^])K[\w\[\]]*', t)
        if m:
            return _ARITH[m.group(1)] + '_K'
        m = re.search(r'V\[' + IDX + r']=\(?\(?K[\w\[\]]*\)?([+\-*/%^])V\[' + IDX + r']', t)
        if m:
            return _ARITH[m.group(1)] + '_K'
        m = re.search(r'V\[' + IDX + r']=V\[' + IDX + r']([+\-*/%^])K[\w\[\]]*', t)
        if m:
            return _ARITH[m.group(1)] + '_K'
        m = re.search(r'V\[' + IDX + r']=K[\w\[\]]*([+\-*/%^])V\[' + IDX + r']', t)
        if m:
            return _ARITH[m.group(1)] + '_K'
        # more table-op variants
        if re.search(r'\)\[[A-Z]\[n\]\]=V\[', t):
            return 'SETTABLE'
        if re.search(r'\)\[V\[' + IDX + r'\]\]=V\[', t):
            return 'SETTABLE'
        if re.search(r'=\(?\(?W\[' + IDX + r']\[K[\w\[\]]*\)?', t):
            return 'GETTABLE_UPVAL'
        if re.search(r'V\[' + IDX + r'=F\[', t):
            return 'MOVE_UPVAL'
        # method-call setup: V[x+1]=t; V[x]=t[K] (SELF)
        if re.search(r'V\[' + IDX + r'\+1\]=\(?t\)?;?V\[' + IDX + r']=\(?t\[K', t):
            return 'SELF'
        # calls via upvalue locals
        if re.search(r'=\(?\(?C\[\d+\]\(\(?V\[', t):
            return 'CALL_UPVAL'
        if re.search(r'\w=\(\w\[f\]\);\w=\w\(\);', t) or re.search(r'=\(T\[f\]\);T=T\(\);', t):
            return 'CALL_UPVAL'
        # bare identifier stores (upvalue mov)
        if re.search(r'V\[' + IDX + r']=[A-Z];$', t):
            return 'MOV_UPVAL'
        if re.search(r'^t=\(?A\[n\]\)?;?$', t) or re.search(r'^\w=\w\[_\];$', t):
            return 'ALIAS'
        # ---- value-producing comparison ----
        if re.search(r'V\[\w+\]=V\[\w+\](==|~=|<|<=|>|>=)', t) and 'if' not in t:
            m = re.search(r'(==|~=|<|<=|>|>=)', t)
            return 'CMP(' + _CMPS[m.group(1)] + ')'
        # ---- jumps ----
        m = re.search(r'if(.+?)thenn=\(?([A-C])\[n\]\)?;', t)
        if m:
            return 'JMP_IF(' + m.group(1) + ')'
        m = re.search(r'if(.+?)thenelsen=\(?([A-C])\[n\]\)?;', t)
        if m:
            return 'JMP_IF_NOT(' + m.group(1) + ')'
        if re.search(r'n=\(?[A-C]\[n\]\)\?;?$', t):
            return 'JMP'
        # stateful alias moves (operands shuffled between locals)
        if re.search(r'^[A-Z]=\(?\(?V\)?;?', t) or \
                re.search(r't=\(?A\[n\]\)?;T=\(?V\)?;', t) or \
                re.search(r't=\(?E\)?;T=\(?\(?\d+\)?\)?;', t):
            return 'ALIAS'
        if t == '':
            return 'EMPTY'
        # ---- misc ----
        if re.search(r'V\[\w+\]=nil', t):
            return 'LOADNIL'
        if re.search(r'V\[\w+\]=\{\}', t):
            return 'NEWTABLE'
        if re.search(r'#V\[\w+\]', t):
            return 'LEN'
        if re.search(r'C\[\d+\]\(', t) and re.search(r'V\[\w+\]\(', t):
            return 'CONCAT'
        if re.search(r'=\w+\(\)', t) and 'V[' in t:
            return 'CALL_UPVAL'
        if re.search(r'V\[\w+\]=not', t):
            return 'NOT'
        if re.search(r'V\[\w+\]=-V', t):
            return 'UNM'
        if re.search(r'for\w+,\w+in\w+do', t) and \
                re.search(r'\w+\[\w+\]=\(?\(?nil\)?\)?', t):
            return 'CLOSE_UPVAL'
        if re.search(r'V\[\w+\]=F\[\w+\]', t):
            return 'GETUPVAL'
        if re.search(r'F\[\w+\]=V\[\w+\]', t):
            return 'SETUPVAL'
        if re.search(r'for\w+=V\[\w+\],V\[\w+\]do', t):
            return 'FORLOOP'
        if re.search(r'for\w+=K\w*\[\w*\],K\w*\[?\w*\]?', t):
            return 'FORPREP'
        # pc-flow aliases / state ops
        if re.fullmatch(r'[A-Z]=\[?\w+\]?;?', t):
            return 'ALIAS_SETUP'
        if re.fullmatch(r'\w+=nil;?', t):
            return 'ALIAS_CLEAR'
        if re.search(r'S=[A-C]\[n\]', t):
            return 'JMP'
        return 'UNKNOWN'
    # --- pass 1: legacy patterns (no role context) ---
    t = norm(txt)
    if re.search(r'localN=Z\[n\]', t):
        return 'CLOSURE'
    if re.search(r'B\[n\]=j;', t):
        return 'FORLOOP?'
    if re.search(r'l\[54\]\(\.\.\.\)', t):
        return 'VARARG_PREP'
    if re.search(r'localN=\{\.+\.?\}[,;]forj=1,', t):
        return 'VARARG_PREP'
    if re.search(r'v-M-1', t) and re.search(r'Q\[p\+j\]', t):
        return 'VARARG'
    if re.search(r'V\[O\[n\]\]=x\[Z\[n\]\]', t):
        return 'GETGLOBAL'
    if re.search(r'V\[r\[n\]\]\[L\[n\]\]=V\[U\[n\]\]', t):
        return 'SETTABLE_K_REG'
    if re.search(r'V\[r\[n\]\]\[L\[n\]\]=I\[n\]', t):
        return 'SETTABLE_K_CONST'
    if re.search(r'V\[U\[n\]\]=V\[r\[n\]\]\[L\[n\]\]', t):
        return 'GETTABLE_K'
    if re.search(r'V\[O\[n\]\]=V\[r\[n\]\]\[V\[U\[n\]\]\]', t):
        return 'GETTABLE'
    if re.search(r'V\[O\[n\]\]\[V\[U\[n\]\]\]=V\[r\[n\]\]', t):
        return 'SETTABLE'
    if '..' in t:
        return 'CONCAT'
    if re.search(r'V\[[OU]\[n\]\]=\{\}', t):
        return 'NEWTABLE'
    if re.search(r'=#V\[[OU]\[n\]\]', t):
        return 'LEN'
    if re.search(r'V\[[OU]\[n\]\]=notV\[[OU]\[n\]\]', t):
        return 'NOT'
    if re.search(r'V\[[OU]\[n\]\]=-V\[', t):
        return 'UNM'
    m = re.search(r'if(.+?)thenelsen=\(?([OUr])\[n\]\)?;', t)
    if m:
        return 'JMP_IF_NOT(' + cmp_target(m.group(1)) + ')'
    m = re.search(r'if(.+?)thenn=\(?([OUr])\[n\]\)?;', t)
    if m:
        return 'JMP_IF(' + cmp_target(m.group(1)) + ')'
    if re.fullmatch(r'n=\(?O\[n\]\)?;?', t):
        return 'JMP'
    if re.fullmatch(r'n=\(?([OUr])\[n\]\)?;?', t):
        return 'JMP'
    # calls
    if re.search(r'V\[i\]=V\[i\]\(.{0,60}l\[25\]', t):
        return 'CALL_1R_VARARGS'
    if re.search(r'V\[i\]=V\[i\]\(V\[i\+1\],V\[i\+2\]\)', t):
        return 'CALL_1R_2A'
    if re.search(r'V\[i\]=V\[i\]\(V\[i\+1\]\)', t):
        return 'CALL_1R_1A'
    if re.search(r'V\[N\]\(V\[N\+1\],V\[N\+2\]\)', t):
        return 'CALL_0R_2A'
    if re.search(r'V\[N\]\(V\[N\+1\]\)', t):
        return 'CALL_0R_1A'
    if re.search(r'V\[y\]\(\)', t):
        return 'CALL_0R_0A'
    if re.search(r'V\[N\]\(l\[25\]', t):
        return 'CALL_0R_VARARGS'
    if re.search(r'V\[r\[n\]\]=F\[O\[n\]\]', t):
        return 'GETUPVAL'
    if re.search(r'F\[U\[n\]\].{0,30}=V\[r\[n\]\]', t):
        return 'SETUPVAL'
    if re.search(r'X\[1\]=X', t) or re.search(r'j\[1\]=j', t):
        return 'CLOSE_UPVAL'
    if re.search(r'forN=O\[n\],r\[n\]do', t):
        return 'LOADNIL'
    if re.fullmatch(r'V\[[OUr]\[n\]\]=[OUr];?', t):
        return 'ALIAS_SETUP'
    if re.search(r'=x;', t):
        return 'ALIAS_SETUP'
    # alias step/clear (stateful interleaving ops)
    if re.fullmatch(r'a=r\[n\];_=_[a];?', t):
        return 'ALIAS_STEP'
    if re.fullmatch(r'\w+=nil;?', t):
        return 'ALIAS_CLEAR'
    if re.fullmatch(r'c=nil;?', t):
        return 'ALIAS_CLEAR'
    # value-producing comparisons
    if re.search(r'==Z\[n\]', t) and '=V[' in t:
        return 'EQ_K'
    if re.search(r'==V\[', t) and '=V[' in t and 'then' not in t:
        return 'EQ'
    if re.search(r'~=V\[', t) and '=V[' in t:
        return 'NE'
    if re.search(r'<=V\[', t) and '=V[' in t and 'then' not in t:
        return 'LE'
    if re.search(r'>=V\[', t) and '=V[' in t:
        return 'GE'
    if re.search(r'<Z\[n\]', t) and '=V[' in t:
        return 'LT_K'
    if re.search(r'<V\[', t) and '=V[' in t and 'then' not in t:
        return 'LT'
    if re.search(r'>V\[', t) and '=V[' in t and 'then' not in t:
        return 'GT'
    # arithmetic by operator (VREF handles nested brackets like V[U[n]])
    VREF = r'V\[(?:[^\[\]]|\[[^\[\]]*\])*\]'
    for op, name in [('^', 'POW'), ('//', 'IDIV'), ('%', 'MOD'), ('*', 'MUL'),
                     ('/', 'DIV'), ('+', 'ADD')]:
        pat = re.escape(op)
        if re.search(rf'={VREF}{pat}{VREF}', t) or re.search(rf'{pat}I\[n\]', t) \
           or re.search(rf'{pat}Z\[n\]', t) or re.search(rf'{pat}L\[n\]', t) \
           or re.search(rf'I\[n\]{pat}', t) or re.search(rf'L\[n\]{pat}', t) \
           or re.search(rf'Z\[n\]{pat}', t):
            if name == 'ADD' and re.search(rf'={VREF}-', t):
                continue
            return name
    if re.search(rf'={VREF}-', t) or re.search(r'-Z\[n\]', t) or \
       re.search(r'-I\[n\]', t) or re.search(r'-L\[n\]', t):
        return 'SUB'
    # LOADK: register = constant directly
    if re.search(r'=\(?L\[n\]\)?\s*;', t) or re.search(r'=L\[n\];', t):
        return 'LOADK'
    if re.search(r'=\(?I\[n\]\)?\s*;', t) or re.search(r'=I\[n\];', t):
        return 'LOADK'
    # MOVE: reg = reg
    if re.search(r'V\[[OU]\[n\]\]=V\[[OU]\[n\]\]', t):
        return 'MOVE'

    # --- pass 2: role-based generic fallback (works for any per-file names) ---
    try:
        import roles as _roles
        if _role_ctx is not None:
            t = _roles.abstract(txt, _role_ctx)
            K = r'CST'
            P = r'OPR'
            S = r'STK'
            # CLOSURE: loads a proto object from a constant array
            if re.search(rf'localR\d+={K};', t) and re.search(rf'{K}\[0\]', t):
                return 'CLOSURE'
            if '..' in t:
                return 'CONCAT'
            if re.search(r'=\{\};', t):
                return 'NEWTABLE'
            if re.fullmatch(rf'R\d+={K};', t) or re.fullmatch(rf'R\d+=R\d+;', t):
                return 'ALIAS_SETUP'
            if re.fullmatch(r'R\d+=nil;?', t):
                return 'ALIAS_CLEAR'
            if re.fullmatch(rf'R\d+={P};{S}={S}\[R\d+\];?', t):
                return 'ALIAS_STEP'
            # writes to the register stack
            if re.search(rf'{S}\[{P}\]\[{K}\]={S}\[{P}\]', t):
                return 'SETTABLE_K_REG'
            if re.search(rf'{S}\[{P}\]\[{K}\]="', t):
                return 'SETTABLE_K_CONST'
            if re.search(rf'{S}\[{P}\]\[{K}\]=R\d+', t):
                return 'SETTABLE_K_CONST'
            if re.search(rf'{S}\[{P}\]={S}\[{P}\]\[{K}\]', t):
                return 'GETTABLE_K'
            if re.search(rf'{S}\[{P}\]={S}\[{P}\]\[{S}\[{P}\]\]', t):
                return 'GETTABLE'
            if re.search(rf'{S}\[{P}\]\[{S}\[{P}\]\]={S}\[{P}\]', t):
                return 'SETTABLE'
            if re.search(rf'{S}\[{P}\]=ENV\[{K}\]', t):
                return 'GETGLOBAL'
            # jumps
            pcname = _role_ctx['pc']
            if re.fullmatch(rf'{pcname}={P};?', t) or re.fullmatch(rf'{pcname}=R\d+;?', t):
                return 'JMP'
            m2 = re.search(r'if(.+?)then(?:else)?' + re.escape(pcname) + r'=(OPR|R\d+);', t)
            if m2:
                cmp_ = m2.group(1)
                neg = 'NOT' in cmp_ or 'not' in cmp_
                kind = 'JMP_IF_NOT' if neg else 'JMP_IF'
                return f'{kind}({cmp_})'
            # calls
            if re.search(rf'{S}\[{P}\]=R\d+\({S},', t) or re.search(rf'{S}\[{P}\]\({S},', t):
                return 'CALL_VARARGS'
            if re.search(rf'{S}\[{P}\]\({S}\)', t) or re.search(rf'{S}\[{P}\]={S}\[{P}\]\({S}\)', t):
                return 'CALL'
            # arithmetic
            for op, name in [('^', 'POW'), ('//', 'IDIV'), ('%', 'MOD'), ('*', 'MUL'),
                             ('/', 'DIV'), ('+', 'ADD')]:
                if re.search(rf'{S}\[{P}\]{re.escape(op)}{S}\[{P}\]', t):
                    if name == 'DIV' and '//' in t:
                        continue
                    return name
            if re.search(rf'{S}\[{P}\]-{S}\[{P}\]', t):
                return 'SUB'
            if re.search(rf'=-{S}\[{P}\]', t):
                return 'UNM'
            if re.search(rf'{S}\[{P}\]=#{S}\[{P}\]', t):
                return 'LEN'
            if re.search(rf'{S}\[{P}\]=not{S}\[{P}\]', t):
                return 'NOT'
            if re.search(rf'{S}\[{P}\]=R\d+\[{K}\]', t):
                return 'GETUPVAL'
            if re.search(rf'R\d+\[{K}\]\[{K}\]={S}\[{P}\]', t):
                return 'SETUPVAL'
            if re.search(r'R\d+\[0\]=R\d+;', t) or re.search(r'F\[0\]=F', t):
                return 'CLOSE_UPVAL'
            if re.search(r'="', t) and '..' not in t:
                return 'SETCONST'
            if re.search(r'=-', t) and '..' not in t:
                return 'SUB'
    except Exception:
        pass
    return 'UNKNOWN'

def cmp_target(cmp_):
    """Human readable comparison for jump ops."""
    c = cmp_.replace('[n]', '')
    c = re.sub(r'not\((.+)\)', r'not \1', c)
    return c

# --------------------------------------------------------------------------
# disassembly
# --------------------------------------------------------------------------

def render_const(v):
    if isinstance(v, str):
        return json.dumps(v)
    if isinstance(v, float) and v == int(v) and abs(v) < 2**53:
        return str(int(v))
    return json.dumps(v)

def disassemble(state, arr_id, pc_id, ids, opmap, handler_names, out_path, title=""):
    """Generic disassembly. state: {id: {idx: value}}; ids: array names."""
    arrays = {name: state.get(name, {}) for name in ids + [arr_id]}
    # The opcode array is arr_id. Others are operands/constants.
    operands = [n for n in ids if n != arr_id]

    lines = []
    lines.append(f"; {title}")
    lines.append(f"; {len(arrays[arr_id])} instructions")
    lines.append("; pc | opcode | operands (per-instruction arrays)")
    B = arrays[arr_id]
    for pc in sorted(int(k) for k in B):
        w = int(B[str(pc)])
        parts = []
        for name in operands:
            v = arrays[name].get(str(pc))
            if v is not None:
                parts.append(f"{name}={render_const(v)}")
        name = handler_names.get(w, f'op{w}')
        lines.append(f"{pc:>4}  {name:<30} {' '.join(parts)}")
    with open(out_path, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    return len(lines)

# --------------------------------------------------------------------------
# main flow
# --------------------------------------------------------------------------

def extract_blob(data):
    """Return the raw (decoded) Luraph data blob bytes, or None."""
    blobs = [(s, e, c) for s, e, c in find_long_strings(data) if is_luraph_blob(c)]
    if not blobs:
        return None
    s, e, content = blobs[-1]
    return z85_decode(content.decode('latin-1'))

def run_dump(obf_path, outdir, workdir):
    """Build + run the instrumented runner; return (state, arr, pc, ids)."""
    runner_path = os.path.join(outdir, 'runner.luau')
    info = make_runner.build_runner(obf_path, runner_path)
    log_path = os.path.join(outdir, 'run.log')
    try:
        res = subprocess.run(['luau', runner_path], capture_output=True,
                             timeout=600)
        out = res.stdout.decode('utf-8', errors='replace')
        err = res.stderr.decode('utf-8', errors='replace')
    except FileNotFoundError:
        print("ERROR: luau CLI not found in PATH", file=sys.stderr)
        sys.exit(1)
    with open(log_path, 'w') as f:
        f.write(out)
        if err:
            f.write('\n--- stderr ---\n' + err)

    state = {}
    cur = None
    ptraces = {}          # proto index -> [pcs]
    protos = {}           # proto index -> {arr_name: {idx: value}}
    proto_cur = None
    arr_cur = None
    for line in out.splitlines():
        if line.startswith('##ARR ') and proto_cur is None:
            cur = line[6:].strip()
            state[cur] = {}
        elif line.startswith('=== PTRACE '):
            proto_cur = None
            arr_cur = None
            parts = line.split()
            # === PTRACE <pi> <count> ===
            pi = int(parts[2])
            ptraces[pi] = {'count': int(parts[3]), 'pcs': []}
        elif line.startswith('=== PROTO '):
            proto_cur = int(line.split()[2])
            arr_cur = None
            protos[proto_cur] = {}
        elif proto_cur is not None and line.startswith('##ARR '):
            arr_cur = line[6:].strip()
            protos[proto_cur][arr_cur] = {}
        elif proto_cur is not None and arr_cur is not None and '\t' in line:
            idx, _, val = line.partition('\t')
            try:
                protos[proto_cur][arr_cur][idx] = json.loads(val)
            except Exception:
                protos[proto_cur][arr_cur][idx] = val
        elif cur is not None and '\t' in line:
            idx, _, val = line.partition('\t')
            try:
                state[cur][idx] = json.loads(val)
            except Exception:
                state[cur][idx] = val
        elif line.startswith('=== ERROR'):
            cur = None
    for pi, tinfo in ptraces.items():
        tinfo['pcs'] = []
    cur_pi = None
    for line in out.splitlines():
        if line.startswith('=== PTRACE '):
            cur_pi = int(line.split()[2])
        elif cur_pi is not None and line.strip() and not line.startswith('===') \
                and not line.startswith('##ARR'):
            ptraces[cur_pi]['pcs'] = [int(x) for x in line.split()]
            cur_pi = None
    # main proto trace = ptrace #1 (the legacy __TRACE is no longer filled)
    if 1 in ptraces and ptraces[1]['pcs']:
        state['__TRACE'] = ptraces[1]['pcs']
    if info:
        return state, info[0], info[1], info[2], ptraces, protos
    return state, None, None, [], ptraces, protos

def recover_opmap(obf_path, outdir):
    """Parse the dispatch tree from the obfuscated file. Generic: detect the
    dispatch variable, opcode array and pc variable from the interpreter loop."""
    data = open(obf_path, 'r', encoding='latin-1').read()
    loop_re = re.compile(
        r'(?:while\s+true\s+do|repeat)(?:[^;{]{0,120}?;)??\s*local\s+(\w+)\s*=\s*\(?\s*(\w+)\s*\[\s*(\w+)\s*\]\s*\)?\s*;')
    m = loop_re.search(data)
    if not m:
        return None
    opc, arr, pc = m.group(1), m.group(2), m.group(3)
    start = m.end()
    # dispatch ends at the pc increment: PC+=... / PC=PC+... / PC=...
    inc = re.search(
        re.escape(pc) + r'\s*(?:\+=|=\s*' + re.escape(pc) + r'\s*\+)\s*0?[bBxX0-9][\._0-9]*\s*;',
        data[start:])
    if inc:
        end = start + inc.start() + len(inc.group(0))
    else:
        # fallback: end at the matching loop closer
        end = min(len(data), start + 200000)
    disp = data[start:end]
    toks = tokenize(disp)
    p = Parser(toks, dvar=opc)
    results = {}
    p.parse_statements(results, 0, 2**31)
    opmap = {}
    for k, v in results.items():
        opmap[int(k)] = v
    return opmap

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    obf = sys.argv[1]
    outdir = sys.argv[2] if len(sys.argv) > 2 else \
        'out_' + os.path.splitext(os.path.basename(obf))[0]
    os.makedirs(outdir, exist_ok=True)

    data = open(obf, 'rb').read()
    print(f"[*] {obf} ({len(data)} bytes)")

    # 1. extract the data blob
    blob = extract_blob(data)
    if blob:
        p = os.path.join(outdir, 'data_blob.bin')
        open(p, 'wb').write(blob)
        print(f"[*] extracted data blob -> {p} ({len(blob)} bytes)")

    # 2. run the instrumented VM to dump its state
    print("[*] building + running instrumented Luau runner ...")
    state, arr_id, pc_id, ids, ptraces, protos = run_dump(obf, outdir, outdir)
    if not state or arr_id is None or arr_id not in state:
        print("ERROR: VM state dump missing (see run.log)", file=sys.stderr)
        log = open(os.path.join(outdir, 'run.log')).read()
        print(log[:2000])
        sys.exit(1)
    nj = len(state.get(arr_id, {}))
    main_trace = state.get('__TRACE', [])
    print(f"[*] dumped VM state: {nj} instructions (opcode array '{arr_id}', "
          f"pc '{pc_id}'), {len(main_trace)} executed, "
          f"{len(protos)} proto(s) captured")
    json.dump(state, open(os.path.join(outdir, 'vm_state.json'), 'w'), indent=1)
    json.dump({'ptraces': {str(k): v['pcs'] for k, v in ptraces.items()},
               'protos': protos},
              open(os.path.join(outdir, 'protos.json'), 'w'), indent=1)

    # 3. recover the opcode map
    opmap = recover_opmap(obf, outdir)
    if opmap is None:
        print("ERROR: dispatch tree not found", file=sys.stderr)
        sys.exit(1)
    print(f"[*] recovered {len(opmap)} opcode handlers from dispatch tree")

    # 4. classify handlers
    role_ctx = None
    try:
        import roles as _roles_mod
        role_ctx = _roles_mod.detect_roles(data.decode('latin-1'))
        if role_ctx:
            print(f"[*] roles detected: opc={role_ctx['opc']} arr={role_ctx['oparr']} "
                  f"pc={role_ctx['pc']} reg_stack={role_ctx['reg_stack']} "
                  f"operands={role_ctx['operands']} constants={role_ctx['constants']}")
    except Exception as e:
        print(f"[!] role detection failed: {e}")
    names = {}
    for w, txt in opmap.items():
        names[w] = classify_handler(txt, pc=pc_id or 'n', _role_ctx=role_ctx)
    json.dump({str(k): v for k, v in names.items()},
              open(os.path.join(outdir, 'opcode_names.json'), 'w'), indent=1)
    from collections import Counter
    dist = Counter(names.values())
    print("[*] opcode distribution:", dict(dist.most_common(12)))

    # 5. disassemble (main proto + all nested protos)
    out = os.path.join(outdir, 'disasm.lst')
    cnt = disassemble(state, arr_id, pc_id, ids, opmap, names, out,
                      title=f"Proto #1 (main) listing for {os.path.basename(obf)}")
    print(f"[*] disassembly -> {out} ({cnt} lines)")
    for pi, pdata in sorted(protos.items()):
        if pi == 1 or arr_id not in pdata:
            continue
        # convert the snapshot into the same shape as state
        pstate = dict(pdata)
        cnt2 = disassemble(pstate, arr_id, pc_id, sorted(pdata.keys()), opmap,
                           names, os.path.join(outdir, f'disasm_p{pi}.lst'),
                           title=f"Proto #{pi} listing")
        print(f"[*] proto #{pi} disassembly -> disasm_p{pi}.lst ({cnt2} lines)")

    # 6. save metadata + emit pseudo-source (main + nested)
    json.dump({'arr': arr_id, 'pc': pc_id, 'ids': ids,
               'title': f"Deobfuscated pseudo-source of {os.path.basename(obf)}"},
              open(os.path.join(outdir, 'meta.json'), 'w'))
    try:
        import decompile
        n = decompile.decompile_file(outdir)
        print(f"[*] pseudo-source -> {os.path.join(outdir, 'pseudo.lua')} ({n} lines)")
        for pi, pdata in sorted(protos.items()):
            if pi == 1 or arr_id not in pdata:
                continue
            pstate = dict(pdata)
            pmeta = {'arr': arr_id, 'pc': pc_id, 'ids': sorted(pdata.keys()),
                     'title': f"Proto #{pi} pseudo-source"}
            json.dump(pmeta, open(os.path.join(outdir, f'meta_p{pi}.json'), 'w'))
            # write a mini run.log section with this proto's trace for decompile_file
            pcs = ptraces.get(pi, {}).get('pcs', [])
            mini = '=== TRACE %d ===\n%s\n' % (len(pcs), ' '.join(map(str, pcs)))
            with open(os.path.join(outdir, f'run_p{pi}.log'), 'w') as f:
                f.write(mini)
            n2 = decompile.decompile_file(outdir, proto=pi)
            print(f"[*] proto #{pi} pseudo-source -> pseudo_p{pi}.lua ({n2} lines)")
    except Exception as e:
        print(f"[!] decompile failed: {e}")

if __name__ == '__main__':
    main()
