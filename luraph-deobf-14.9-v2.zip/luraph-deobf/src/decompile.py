#!/usr/bin/env python3
"""
Decompiler for the Luraph 14.9 deobfuscator.

Turns the dumped VM proto into readable pseudo-Lua:

  * replays the bootstrap to build the constant table (register stack [2])
  * tracks registers symbolically through the real execution order (trace)
  * inlines constants and global names into expressions
  * emits one readable line per executed instruction
"""
import json, re, os

def render(v):
    if isinstance(v, str):
        return json.dumps(v)
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, (int, float)):
        if isinstance(v, float) and v == int(v) and abs(v) < 2**53:
            return str(int(v))
        return str(v)
    if v is None:
        return 'nil'
    return json.dumps(str(v))

class Decompiler:
    def __init__(self, state, arr_id, ids, names, trace, const_tbl):
        self.B = state.get(arr_id, {})
        self.arrays = {n: state.get(n, {}) for n in ids if n != arr_id}
        self.names = names
        self.trace = trace
        self.const = dict(const_tbl or {})   # index -> value (string repr)
        self.registers = {}                  # reg idx -> symbolic string
        self.out = []

    # ---------- helpers ----------
    def reg(self, idx):
        if idx is None:
            return '?'
        v = self.registers.get(int(idx))
        return v if v is not None else f'r{int(idx)}'

    def opvals(self, pc):
        return {n: self.arrays[n].get(str(pc)) for n in self.arrays}

    # ---------- instruction handlers ----------
    def step(self, pc, w):
        op = self.names.get(w, f'op{w}')
        v = self.opvals(pc)
        line = None

        if op == 'GETGLOBAL':
            name = v.get('Z')
            self.registers[int(v['O'])] = str(name) if name is not None else '?'
            line = f'{self.reg(int(v["O"]))} = {name}'
        elif op == 'LOADK':
            val = v.get('L', v.get('I'))
            tgt = v.get('O', v.get('U'))
            if tgt is not None and val is not None:
                self.registers[int(tgt)] = render(val)
                line = f'{self.reg(int(tgt))} = {render(val)}'
        elif op == 'SETTABLE_K_REG':
            key = v.get('L')
            src = v.get('U')
            base = int(v['r'])
            if key is not None:
                # base 2 = constant table: remember the mapping
                if base == 2 and src is not None:
                    self.const[str(key)] = self.registers.get(int(src), f'r{int(src)}')
                line = f'{self.reg(base)}[{render(key)}] = {self.reg(src)}'
        elif op == 'SETTABLE_K_CONST':
            key = v.get('L')
            val = v.get('I')
            base = int(v['r'])
            if key is not None and val is not None:
                if base == 2:
                    self.const[str(key)] = render(val)
                line = f'{self.reg(base)}[{render(key)}] = {render(val)}'
        elif op == 'GETTABLE_K':
            tgt = v.get('U')
            base = v.get('r')
            key = v.get('L')
            if key is None:
                line = None
            else:
                try:
                    kidx = str(int(key))
                    if base == 2 and tgt is not None and kidx in self.const:
                        self.registers[int(tgt)] = self.const[kidx]
                        line = f'{self.reg(int(tgt))} = {self.const[kidx]}'
                    else:
                        line = f'{self.reg(tgt)} = {self.reg(base)}[{render(key)}]'
                except (ValueError, TypeError):
                    # key is a literal string, not an index into the const table
                    if base == 2 and tgt is not None and str(key) in self.const:
                        self.registers[int(tgt)] = self.const[str(key)]
                        line = f'{self.reg(int(tgt))} = {self.const[str(key)]}'
                    else:
                        line = f'{self.reg(tgt)} = {self.reg(base)}[{render(key)}]'
        elif op == 'GETTABLE':
            tgt, base, key = v.get('O'), v.get('r'), v.get('U')
            if key is not None:
                self.registers[int(tgt)] = f'{self.reg(base)}[{self.reg(key)}]'
                line = f'{self.reg(int(tgt))} = {self.reg(base)}[{self.reg(key)}]'
        elif op == 'SETTABLE':
            a, b, c = v.get('O'), v.get('U'), v.get('r')
            line = f'{self.reg(a)}[{self.reg(b)}] = {self.reg(c)}'
        elif op in ('ADD', 'SUB', 'MUL', 'DIV', 'IDIV', 'MOD', 'POW'):
            sym = {'ADD': '+', 'SUB': '-', 'MUL': '*', 'DIV': '/', 'IDIV': '//', 'MOD': '%', 'POW': '^'}[op]
            a, b, c = v.get('O'), v.get('U'), v.get('r')
            if a is not None:
                expr = f'{self.reg(b)} {sym} {self.reg(c)}'
                self.registers[int(a)] = f'({expr})'
                line = f'{self.reg(int(a))} = {expr}'
        elif op == 'CONCAT':
            a, b, c = v.get('O'), v.get('U'), v.get('r')
            if a is not None:
                self.registers[int(a)] = f'({self.reg(b)} .. {self.reg(c)})'
                line = f'{self.reg(int(a))} = {self.reg(b)} .. {self.reg(c)}'
        elif op == 'NEWTABLE':
            a = v.get('O')
            if a is not None:
                self.registers[int(a)] = '{}'
                line = f'{self.reg(int(a))} = {{}}'
        elif op == 'LEN':
            a, b = v.get('O'), v.get('U')
            if a is not None:
                self.registers[int(a)] = f'#{self.reg(b)}'
                line = f'{self.reg(int(a))} = #{self.reg(b)}'
        elif op == 'NOT':
            a, b = v.get('O'), v.get('U')
            if a is not None:
                self.registers[int(a)] = f'not {self.reg(b)}'
                line = f'{self.reg(int(a))} = not {self.reg(b)}'
        elif op == 'UNM':
            a, b = v.get('O'), v.get('r')
            if a is not None:
                self.registers[int(a)] = f'-{self.reg(b)}'
                line = f'{self.reg(int(a))} = -{self.reg(b)}'
        elif op in ('EQ', 'NE', 'LT', 'LE', 'GT', 'GE', 'EQ_K', 'LT_K'):
            a, b, c = v.get('O'), v.get('U'), v.get('r')
            syms = {'EQ': '==', 'NE': '~=', 'LT': '<', 'LE': '<=', 'GT': '>', 'GE': '>='}
            sym = syms.get(op, '==')
            rhs = v.get('I', v.get('Z', c))
            line = f'{self.reg(b)} {sym} {self.reg(c) if rhs is None or isinstance(rhs, int) and rhs < 256 else render(rhs)}'
        elif op == 'MOVE':
            a, b = v.get('U'), v.get('O')
            if a is not None and b is not None:
                self.registers[int(a)] = self.registers.get(int(b), f'r{int(b)}')
                line = f'{self.reg(int(a))} = {self.reg(int(b))}'
        elif op == 'LOADNIL':
            a, b = v.get('O'), v.get('r')
            if a is not None:
                for i in range(int(a), int(b) + 1):
                    self.registers[i] = 'nil'
                line = f'r{int(a)}..r{int(b)} = nil'
        elif op.startswith('CALL'):
            m = re.match(r'CALL_(\d)R_(\d)A', op)
            a = v.get('O', v.get('U', v.get('r')))
            if m:
                nr, na = int(m.group(1)), int(m.group(2))
                callee = self.reg(a)
                args = [self.reg((a or 0) + i + 1) for i in range(na)]
                call = f'{callee}({", ".join(args)})'
                if nr:
                    self.registers[int(a)] = f'({call})'
                    line = f'{self.reg(int(a))} = {call}'
                else:
                    line = call
            else:
                line = f'call {self.reg(a)}'
        elif op == 'JMP':
            line = f'goto {v.get("O")}'
        elif op.startswith('JMP_IF'):
            tgt = v.get('O', v.get('U', v.get('r')))
            cond = op[7:-1] if op.endswith(')') else ''
            line = f'if {cond} then goto {tgt}'
        elif op == 'CLOSURE':
            a = v.get('O')
            if a is not None:
                self.registers[int(a)] = '<closure>'
                line = f'{self.reg(int(a))} = function(...)'
        elif op == 'VARARG_PREP':
            line = '-- vararg prep'
        elif op == 'VARARG':
            line = '-- vararg fetch'
        elif op.startswith('ALIAS'):
            line = None   # interleaving noise - skip
        elif op == 'FORLOOP?':
            line = '-- for-loop op (self-modifying)'
        elif op == 'UNKNOWN' or op.startswith('op'):
            # unclassified: keep the listing useful with raw operands
            parts = [f'{n}={render(x)}' for n, x in v.items() if x is not None]
            line = '-- ' + op + ' ' + ' '.join(parts)
        else:
            line = f'-- {op}'
        return line

    def run(self, title=""):
        self.out = [f'-- {title}',
                    f'-- {len(self.trace)} instructions (execution order)',
                    '-- pseudo-Lua: constants inlined, registers tracked']
        for pc in self.trace:
            if str(pc) not in self.B:
                continue
            w = int(self.B[str(pc)])
            line = self.step(pc, w)
            if line:
                self.out.append(f'{pc:>4}  {line}')
        return self.out

def decompile_file(outdir, title=None, proto=None):
    suffix = '' if proto is None else f'_p{proto}'
    names = {int(float(k)): v for k, v in
             json.load(open(os.path.join(outdir, 'opcode_names.json'))).items()}
    if proto is None:
        state = json.load(open(os.path.join(outdir, 'vm_state.json')))
    else:
        # nested proto state lives in protos.json
        pfile = json.load(open(os.path.join(outdir, 'protos.json')))
        psnap = pfile['protos'].get(str(proto), {})
        state = {k: v for k, v in psnap.items()}
        state['__TRACE'] = pfile['ptraces'].get(str(proto), [])
    meta = json.load(open(os.path.join(outdir, f'meta{suffix}.json')))
    log_path = os.path.join(outdir, f'run{suffix}.log')
    log = open(log_path).read() if os.path.exists(log_path) else ''
    # trace comes from state['__TRACE'] (per-proto) when present
    if '__TRACE' in state:
        trace = list(state['__TRACE'])
    else:
        trace = []
        m = re.search(r'=== TRACE (\d+) ===\n(.*)', log)
        if m:
            trace = [int(x) for x in m.group(2).split()]
    const_tbl = {}
    # the constant table lives in the MAIN run.log (V2 capture applies to all)
    main_log_path = os.path.join(outdir, 'run.log')
    main_log = open(main_log_path).read() if os.path.exists(main_log_path) else log
    m2 = re.search(r'=== V2 ===\n(.*?)\n--- stderr', main_log, re.S)
    if not m2:
        m2 = re.search(r'=== V2 ===\n(.*)', main_log, re.S)
    if m2:
        for line in m2.group(1).splitlines():
            if '\t' not in line:
                break
            k, _, v = line.partition('\t')
            try:
                const_tbl[k] = json.loads(v)
            except Exception:
                const_tbl[k] = v
    # per-proto constant tables (PCONST sections) for nested protos
    pconsts = {}
    cur_pc = None
    for line in main_log.splitlines():
        if line.startswith('=== PCONST '):
            cur_pc = int(line.split()[2])
            pconsts[cur_pc] = {}
        elif cur_pc is not None:
            if line.startswith('===') or line.startswith('---'):
                cur_pc = None
            elif '\t' in line:
                k, _, v = line.partition('\t')
                try:
                    pconsts[cur_pc][k] = json.loads(v)
                except Exception:
                    pconsts[cur_pc][k] = v
    if proto is not None and proto in pconsts and pconsts[proto]:
        const_tbl = pconsts[proto]
    d = Decompiler(state, meta['arr'], meta['ids'], names, trace, const_tbl)
    lines = d.run(title or meta.get('title', ''))
    path = os.path.join(outdir, f'pseudo{suffix}.lua')
    with open(path, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    return len(lines)

if __name__ == '__main__':
    import sys
    outdir = sys.argv[1] if len(sys.argv) > 1 else '.'
    n = decompile_file(outdir)
    print(f"pseudo-source: {n} lines -> {os.path.join(outdir, 'pseudo.lua')}")
