#!/usr/bin/env python3
"""
Per-file role detection for the Luraph 14.9 deobfuscator.

From the obfuscated file's dispatch region, detects which local variables play
which role in the VM:

  opc        - the shuffled opcode variable
  oparr      - the opcode array
  pc         - the program counter variable
  reg_stack  - the register stack (written most via operand arrays)
  operands   - the per-instruction operand arrays (used as register indices)
  constants  - the per-instruction constant arrays (used as literal values)
  env        - the environment scalar (source of GETGLOBAL)
"""
import re

def detect_roles(data):
    m = re.search(
        r'(?:while true do|repeat)(?:[^;{]{0,120}?;)??\s*local\s+(\w+)=\(?\s*(\w+)\s*\[\s*(\w+)\s*\]\s*\)?\s*;',
        data)
    if not m:
        return None
    opc, arr, pc = m.group(1), m.group(2), m.group(3)
    start = m.end()
    inc = re.search(re.escape(pc) + r'\s*\+=', data[start:])
    disp = data[start:start + (inc.start() if inc else 100000)]

    ids = sorted(set(re.findall(r'(\w+)\[' + re.escape(pc) + r'\]', disp)))
    non_pc = set(re.findall(r'\b(\w+)\s*\[', disp)) - set(ids) - {arr, pc}

    # reg stack: non-pc id used most as ID[<expr containing [pc]>]
    regstack_use = {}
    for cand in non_pc:
        cnt = len(re.findall(
            re.escape(cand) + r'\[[^\[\]]*\[\s*' + re.escape(pc) + r'\s*\]\]', disp))
        if cnt:
            regstack_use[cand] = cnt
    reg_stack = max(regstack_use, key=regstack_use.get) if regstack_use else None

    operands, constants = [], []
    if reg_stack:
        for i in ids:
            n = len(re.findall(
                re.escape(reg_stack) + r'\[' + re.escape(i) + r'\[', disp))
            (operands if n else constants).append(i)
    else:
        constants = list(ids)

    # env: non-pc, non-regstack scalar used as ID[K[pc]] (getglobal source)
    env = None
    if reg_stack:
        for cand in non_pc - {reg_stack}:
            if re.search(re.escape(reg_stack) + r'\[' + re.escape(operands[0] if operands else '?') +
                         r'\[' + re.escape(pc) + r'\]\]\s*=\s*\(?' + re.escape(cand) + r'\[', disp):
                env = cand
                break

    return {'opc': opc, 'oparr': arr, 'pc': pc, 'reg_stack': reg_stack,
            'operands': operands, 'constants': constants, 'env': env}


def abstract(txt, roles):
    """Abstract per-file identifiers to canonical tokens:
    reg_stack -> STK, operands -> OPR, constants -> CST, env -> ENV."""
    t = re.sub(r'\s+', '', txt).replace('(', '').replace(')', '')
    pc = roles['pc']
    # 1. constants FIRST (their names may collide with canonical tokens)
    for k in roles['constants']:
        t = re.sub(r'\b' + re.escape(k) + r'\b(?=\[)', 'CST', t)
    # 2. reg stack
    if roles['reg_stack']:
        t = re.sub(r'\b' + re.escape(roles['reg_stack']) + r'\b(?=\[)', 'STK', t)
    # 3. operands
    for op in roles['operands']:
        t = re.sub(r'\b' + re.escape(op) + r'\b(?=\[)', 'OPR', t)
    # 4. env
    if roles.get('env'):
        t = re.sub(r'\b' + re.escape(roles['env']) + r'\b(?=\[)', 'ENV', t)
    # 5. strip pc indexing LAST
    t = t.replace(f'[{pc}]', '')
    # any remaining identifiers -> R (generic scalars/tables)
    others = sorted(set(re.findall(r'\b([A-Za-z_]\w*)\b', t))
                    - {'STK', 'OPR', 'CST', 'ENV'})
    for i, name in enumerate(others):
        t = re.sub(r'\b' + re.escape(name) + r'\b', f'R{i}', t)
    return t
