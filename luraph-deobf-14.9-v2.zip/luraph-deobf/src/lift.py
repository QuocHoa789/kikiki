#!/usr/bin/env python3
"""
Lifter: reconstruct real Lua source from Luraph 14.9 VM bytecode dumps.

Input:  the pipeline dump directory (vm_state.json / protos.json / run.log),
        plus the original obfuscated file (for handler semantics).
Output: real Lua source per proto - registers tracked symbolically, constants
        and global names inlined, control flow as labels + gotos (exact logic).

Usage:  python3 lift.py <obfuscated.lua> <dump_dir> [outdir]
"""
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import luraph_deobf as L  # recover_opmap, role_abstract, roles


# ---------------------------------------------------------------------------
# handler -> semantic template
# ---------------------------------------------------------------------------

def build_token_map(roles):
    """Abstract token -> array name (GLOBAL default; superseded per-handler)."""
    tm = {}
    for i, o in enumerate(roles.get("operands", [])):
        tm["ABCDEF"[i] if i < 6 else "O%d" % i] = o
    for i, c in enumerate(roles.get("constants", [])):
        tm[["KA", "KB", "KC", "KD"][i] if i < 4 else "K%d" % i] = c
    return tm


def per_handler_map(orig_txt, roles):
    """Replicate role_abstract's token assignment: operands get A/B/C... by
    first occurrence in the text, then constants get KA/KB... the same way."""
    t = re.sub(r"\s+", "", orig_txt)
    ops = roles.get("operands", [])
    csts = roles.get("constants", [])
    optoks = ["A", "B", "C", "D", "E", "F"]
    cstoks = ["KA", "KB", "KC", "KD"]
    events = []
    for name in ops:
        m = re.search(r"(?<![\w.])" + re.escape(name) + r"(?![\w])", t)
        if m:
            events.append((m.start(), name, "op"))
    for name in csts:
        m = re.search(r"(?<![\w.])" + re.escape(name) + r"(?![\w])", t)
        if m:
            events.append((m.start(), name, "cst"))
    events.sort(key=lambda e: e[0])
    tm = {}
    oi = ci = 0
    for _, name, which in events:
        if which == "op":
            tm[optoks[oi] if oi < len(optoks) else "O%d" % oi] = name
            oi += 1
        else:
            tm[cstoks[ci] if ci < len(cstoks) else "K%d" % ci] = name
            ci += 1
    return tm


CALL_RE_IND = re.compile(r"^(\w)=\(?([A-D])\[n\]\)?;\)?V\[\1\]=V\[\1\]\(([^()]*)\)")
CALL_RE_DIR = re.compile(r"V\[(\w)\[n\]\]=V\[\1\[n\]\]\(([^()]*)\)")
CALL_RE_UP = re.compile(r"V\[(\w)\[n\]\]=\(?\(?C\[\d+\]\(([^()]*)\)")
CALL_RE_TEMP = re.compile(r"(\w)=\(T\[f\]\);T=T\(\);\(E\)\[t\]=\(T\)")
CMP_RE = re.compile(r"\(V\)\[(\w)\[n\]\]=V\[(\w)\[n\]\](==|~=|<|<=|>|>=)V\[(\w)\[n\]\];")
BINOP_RE = re.compile(r"\(?V\)?\[(\w)\[n\]\]=\(?K(\w?)\[n\]\)?([+\-*/%^])\(?V\)?\[(\w)\[n\]\];")
BINOP2_RE = re.compile(r"\(?V\)?\[(\w)\[n\]\]=\(?\(?V\)?\[(\w)\[n\]\]\)?([+\-*/%^])\(?K\w?\[n\]\)?;")
BINOP3_RE = re.compile(r"V\[(\w)\[n\]\]=V\[(\w)\[n\]\]([+\-*/%^])V\[(\w)\[n\]\];")
SETTBL_RE = re.compile(r"V\[(\w)\[n\]\]\[V\[(\w)\[n\]\]\]=V\[(\w)\[n\]\];")
GETTBL_RE = re.compile(r"V\[(\w)\[n\]\]=V\[(\w)\[n\]\]\[V\[(\w)\[n\]\]\];")
GETTBLK_RE = re.compile(r"V\[(\w)\[n\]\]=\(?\(?W\[(\w)\[n\]\]\[K\w?\[n\]\]\)?;")
JMPIF_RE = re.compile(r"ifV\[(\w)\[n\]\](==|~=|<|<=|>|>=)K\w?\[n\]thenn=\(?(\w)\[n\]\)?;")
JMPIF2_RE = re.compile(r"ifV\[(\w)\[n\]\](==|~=|<|<=|>|>=)V\[(\w)\[n\]\]thenn=\(?(\w)\[n\]\)?;")
JMPIF3_RE = re.compile(r"ifV\[(\w)\[n\]\](==|~=|<|<=|>|>=)K\w?\[n\]thenelsen=\(?(\w)\[n\]\)?;")
JMP_RE = re.compile(r"^n=\(?(\w)\[n\]\)?;?$")
NIL_RE = re.compile(r"\(?V\)?\[(\w)\[n\]\]=nil;")
NEW_RE = re.compile(r"V\[(\w)\[n\]\]=\{\};")
LEN_RE = re.compile(r"\(?V\)?\[(\w)\[n\]\]=#V\[(\w)\[n\]\];")
NOT_RE = re.compile(r"V\[(\w)\[n\]\]=notV\[(\w)\[n\]\];")
UNM_RE = re.compile(r"\(?V\)?\[(\w)\[n\]\]=-\(?V\)?\[(\w)\[n\]\];")
MOVUP_RE = re.compile(r"V\[(\w)\[n\]\]=([A-Z]);$")
SELF_RE = re.compile(r"^(\w)=A\[n\];t=V\[(\w)\[n\]\];V\[\1\+1\]=\(t\);V\[\1\]=\(t\[K\w?\[n\]\]\);")
GETUP_RE = re.compile(r"^(\w)=\(?\(?W\[(\w)\[n\]\]\)?;?")
SETUP_RE = re.compile(r"^(?!n)(\w)=\(?([A-D])\[n\]\)?;$")
MOVE_RE = re.compile(r"^V\[(\w)\[n\]\]=V\[(\w)\[n\]\];$")
LOADK_RE = re.compile(r"^V\[(\w)\[n\]\]=(K\w?)\[n\];$")
GETTK_RE = re.compile(r"^V\[(\w)\[n\]\]=\(?\(?V\[(\w)\[n\]\]\[K\w?\[n\]\]\)?;?$")
SETKK_RE = re.compile(r"^V\[(\w)\[n\]\]\[K\w?\[n\]\]=\(?\(?K\w?\[n\]\)?;?$")
JMPIF4_RE = re.compile(r"^ifnot\((.+?)\)thenn=\(?(\w)\[n\]\)?;(?:end;)?$")
JMPIF5_RE = re.compile(r"^ifnot\((.+?)\)thenelsen=\(?(\w)\[n\]\)?;(?:end;)?$")
CONCAT_RE = re.compile(r"^(\w)=A\[n\];\w+=\1\+B\[n\]-1;\(?V\)?\[\1\]\(C\[\d+\]\(\w+,\1\+1,V\)\);\w+=\1-1;$")
GETTBL2_RE = re.compile(r"^V\[(\w)\[n\]\]=\(?\(?V\[(\w)\[n\]\]\[V\[(\w)\[n\]\]\]\)?;?$")
CALLDIS_RE = re.compile(r"^(\w)=A\[n\];\(?V\)?\[\1\]\(V\[\1\+1\],V\[\1\+2\]\);L=\1-1;$")
CALL0A_RE = re.compile(r"^L=A\[n\];V\[L\]=V\[L\]\(\);$")
FORLOOP_RE = re.compile(r"^E=\(false\);h\+=g;ifg<=0thenE=\(h>=q\);elseE=\(h<=q\);end;ifnot\(E\)thenelseV\[(\w)\[n\]\]\+3=\(h\);n=\((\w)\[n\]\);end;$")


def parse_template(abs_text, roles):
    """Parse an abstracted handler into (kind, spec).

    spec values reference abstract tokens (A/B/C operand arrays, KA/KB...
    constant arrays) which map to real array names via the token map.
    """
    t = abs_text
    if CALL_RE_TEMP.search(t):
        return ("CALL_TEMP", {})
    m = CONCAT_RE.search(t)
    if m:
        return ("CONCAT_RANGE", {"dst": "A", "cnt": "B"})
    m = MOVE_RE.search(t)
    if m:
        return ("MOVE", {"dst": m.group(1), "src": m.group(2)})
    m = LOADK_RE.search(t)
    if m:
        return ("LOADK", {"dst": m.group(1), "carr": m.group(2)})
    m = GETTK_RE.search(t)
    if m:
        return ("GETTABLE_K", {"dst": m.group(1), "t": m.group(2), "carr": "K"})
    m = SETKK_RE.search(t)
    if m:
        return ("SETTABLE_KK", {"t": m.group(1)})
    m = JMPIF4_RE.search(t)
    if m:
        return ("JMP_IF_NOT", {"cond": m.group(1), "tgt": m.group(2)})
    m = JMPIF5_RE.search(t)
    if m:
        return ("JMP_IF_NOT", {"cond": m.group(1), "tgt": m.group(2)})
    m = GETTBL2_RE.search(t)
    if m:
        return ("GETTABLE", {"dst": m.group(1), "t": m.group(2), "k": m.group(3)})
    m = CALLDIS_RE.search(t)
    if m:
        return ("CALL_DISCARD", {"dst": m.group(1), "nargs": 2})
    m = CALL0A_RE.search(t)
    if m:
        return ("CALL_0A", {"dst": "A"})
    m = FORLOOP_RE.search(t)
    if m:
        return ("FORLOOP", {"var": m.group(1), "tgt": m.group(2)})
    m = CALL_RE_IND.search(t)
    if m:
        args = m.group(3)
        nargs = args.count(",") + 1 if args.strip() else 0
        return ("CALL", {"dst": m.group(2), "nargs": nargs})
    m = CALL_RE_DIR.search(t)
    if m:
        args = m.group(2)
        nargs = args.count(",") + 1 if args.strip() else 0
        return ("CALL", {"dst": m.group(1), "nargs": nargs})
    m = CALL_RE_UP.search(t)
    if m:
        args = m.group(2)
        nargs = args.count(",") + 1 if args.strip() else 0
        return ("CALL_UPVAL", {"dst": m.group(1), "nargs": nargs})
    m = CMP_RE.search(t)
    if m:
        return ("CMP", {"dst": m.group(1), "a": m.group(2), "op": m.group(3), "b": m.group(4)})
    m = BINOP_RE.search(t)
    if m:
        return ("BINOP_K1", {"dst": m.group(1), "carr": "K" + m.group(2), "op": m.group(3), "src": m.group(4)})
    m = BINOP2_RE.search(t)
    if m:
        return ("BINOP_K2", {"dst": m.group(1), "src": m.group(2), "op": m.group(3), "carr": "K"})
    m = BINOP3_RE.search(t)
    if m:
        return ("BINOP", {"dst": m.group(1), "a": m.group(2), "op": m.group(3), "b": m.group(4)})
    m = SETTBL_RE.search(t)
    if m:
        return ("SETTABLE", {"t": m.group(1), "k": m.group(2), "v": m.group(3)})
    m = GETTBL_RE.search(t)
    if m:
        return ("GETTABLE", {"dst": m.group(1), "t": m.group(2), "k": m.group(3)})
    m = GETTBLK_RE.search(t)
    if m:
        return ("GETTABLE_UPVAL", {"dst": m.group(1), "u": m.group(2)})
    m = JMPIF3_RE.search(t)
    if m:
        return ("JMP_IF_NOT", {"a": m.group(1), "op": m.group(2), "b": "K", "tgt": m.group(3)})
    m = JMPIF_RE.search(t)
    if m:
        return ("JMP_IF_NOT", {"a": m.group(1), "op": m.group(2), "b": "K", "tgt": m.group(3)})
    m = JMPIF2_RE.search(t)
    if m:
        return ("JMP_IF_NOT", {"a": m.group(1), "op": m.group(2), "b": m.group(3), "tgt": m.group(4)})
    m = NIL_RE.search(t)
    if m:
        return ("LOADNIL", {"dst": m.group(1)})
    m = NEW_RE.search(t)
    if m:
        return ("NEWTABLE", {"dst": m.group(1)})
    m = LEN_RE.search(t)
    if m:
        return ("LEN", {"dst": m.group(1), "src": m.group(2)})
    m = NOT_RE.search(t)
    if m:
        return ("NOT", {"dst": m.group(1), "src": m.group(2)})
    m = UNM_RE.search(t)
    if m:
        return ("UNM", {"dst": m.group(1), "src": m.group(2)})
    m = SELF_RE.search(t)
    if m:
        return ("SELF", {"dst": m.group(1), "obj": m.group(2)})
    m = MOVUP_RE.search(t)
    if m:
        return ("MOV_UPVAL", {"dst": m.group(1), "name": m.group(2)})
    m = SETUP_RE.search(t)
    if m:
        return ("ALIAS", {"dst": m.group(1), "src": m.group(2)})
    m = GETUP_RE.search(t)
    if m:
        return ("ALIAS", {"dst": m.group(1), "src": None})
    m = JMP_RE.search(t)
    if m:
        return ("JMP", {"tgt": m.group(1)})
    if "for" in t and "do" in t:
        return ("FORLOOP", {})
    if "fork," in t and "=nil" in t:
        return ("CLOSE_UPVAL", {})
    if t == "":
        return ("EMPTY", {})
    return ("UNKNOWN", {})


# ---------------------------------------------------------------------------
# symbolic execution + emission
# ---------------------------------------------------------------------------

ARITH = {"+": "+", "-": "-", "*": "*", "/": "/", "%": "%", "^": "^"}
CMPS = {"==": "==", "~=": "~=", "<": "<", "<=": "<=", ">": ">", ">=": ">="}


def luaval(v):
    """Render a constant value as a Lua literal."""
    if isinstance(v, str):
        return json.dumps(v)
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        if isinstance(v, float) and v == int(v) and abs(v) < 2 ** 53:
            return str(int(v))
        return str(v)
    if v is None:
        return "nil"
    return json.dumps(str(v))


class Lifter:
    def __init__(self, arrays, semantics):
        self.arr = arrays
        self.sem = semantics          # opcode value -> (kind, spec, pmap)
        self.reg = {}                 # reg idx -> expr
        self.loc = {}                 # shared handler-local -> expr
        self.globals = {}
        self.lines = []
        self.gototargets = set()

    def arrval(self, tok, pc, pmap):
        """Value of an operand/constant array at pc."""
        name = (pmap or {}).get(tok, tok)
        d = self.arr.get(name, {})
        return d.get(str(pc), d.get(pc))

    def regname(self, idx):
        return "r%s" % idx

    def R(self, idx):
        """Symbolic value of a register."""
        return self.reg.get(idx, self.regname(idx))

    def emit(self, pc, text, note=""):
        label = "::L%s::" % pc if pc in self.gototargets else ""
        if label:
            self.lines.append(label)
        if note:
            self.lines.append("-- pc %s %s" % (pc, note))
        if text:
            self.lines.append(text)

    def step(self, pc):
        w = self.arr.get("G", {}).get(str(pc))
        if w is None:
            return
        kind, spec, pmap = self.sem.get(w, ("UNKNOWN", {}, {}))

        def rv(tok):
            return self.arrval(tok, pc, pmap)

        def needs(*toks):
            return all(rv(t) is not None for t in toks)

        if kind in ("CALL", "CALL_UPVAL", "CALL_DISCARD", "CALL_0A") and \
                not needs(spec.get("dst")):
            kind = "UNKNOWN"
        elif kind in ("CMP", "BINOP", "BINOP_K1", "BINOP_K2", "SETTABLE",
                      "GETTABLE", "LEN", "NOT", "UNM", "SELF", "MOV_UPVAL",
                      "LOADNIL", "NEWTABLE", "JMP_IF_NOT", "JMP_IF", "JMP"):
            toks = [v for v in spec.values()
                    if isinstance(v, str) and
                    (v in (pmap or {}) or re.fullmatch(r"[A-F]|K[A-D]", v))]
            if not needs(*toks):
                kind = "UNKNOWN"

        if kind == "CALL":
            dst = rv(spec["dst"])
            nargs = spec["nargs"]
            callee = self.R(dst)
            args = [self.R(dst + i + 1) for i in range(nargs)]
            call = "%s(%s)" % (callee, ", ".join(args))
            self.reg[dst] = "(%s)" % call
            self.emit(pc, "%s = %s" % (self.regname(dst), call))
        elif kind == "CALL_UPVAL":
            dst = rv(spec["dst"])
            nargs = spec["nargs"]
            # upvalue function held by the loader table; emit abstract call
            callee = self.R(dst)
            args = [self.R(dst + i + 1) for i in range(nargs)]
            call = "%s(%s)" % (callee, ", ".join(args))
            self.reg[dst] = "(%s)" % call
            self.emit(pc, "%s = %s" % (self.regname(dst), call))
        elif kind == "CALL_TEMP":
            self.emit(pc, "-- call via loader upvalue")
        elif kind == "CMP":
            dst = rv(spec["dst"])
            a = self.R(rv(spec["a"]))
            b = self.R(rv(spec["b"]))
            op = CMPS[spec["op"]]
            self.reg[dst] = "(%s %s %s)" % (a, op, b)
            self.emit(pc, "%s = %s %s %s" % (self.regname(dst), a, op, b))
        elif kind == "BINOP":
            dst = rv(spec["dst"])
            a = self.R(rv(spec["a"]))
            b = self.R(rv(spec["b"]))
            self.reg[dst] = "(%s %s %s)" % (a, spec["op"], b)
            self.emit(pc, "%s = %s %s %s" % (self.regname(dst), a, spec["op"], b))
        elif kind == "BINOP_K1":
            dst = rv(spec["dst"])
            c = rv(spec["carr"])
            b = self.R(rv(spec["src"]))
            expr = "%s %s %s" % (luaval(c), spec["op"], b)
            self.reg[dst] = "(%s)" % expr
            self.emit(pc, "%s = %s" % (self.regname(dst), expr))
        elif kind == "BINOP_K2":
            dst = rv(spec["dst"])
            a = self.R(rv(spec["src"]))
            c = rv(spec["carr"])
            expr = "%s %s %s" % (a, spec["op"], luaval(c))
            self.reg[dst] = "(%s)" % expr
            self.emit(pc, "%s = %s" % (self.regname(dst), expr))
        elif kind == "SETTABLE":
            tb = rv(spec["t"])
            k = self.R(rv(spec["k"]))
            v = self.R(rv(spec["v"]))
            self.emit(pc, "%s[%s] = %s" % (self.R(tb), k, v))
        elif kind == "GETTABLE":
            dst = rv(spec["dst"])
            tb = self.R(rv(spec["t"]))
            k = self.R(rv(spec["k"]))
            self.reg[dst] = "%s[%s]" % (tb, k)
            self.emit(pc, "%s = %s[%s]" % (self.regname(dst), tb, k))
        elif kind == "GETTABLE_UPVAL":
            dst = rv(spec["dst"])
            self.reg[dst] = "upvalue_index"
            self.emit(pc, "%s = <upvalue table index>" % self.regname(dst))
        elif kind == "MOVE":
            dst = rv(spec["dst"])
            src = self.R(rv(spec["src"]))
            self.reg[dst] = src
            self.emit(pc, "%s = %s" % (self.regname(dst), src))
        elif kind == "LOADK":
            dst = rv(spec["dst"])
            c = rv(spec["carr"])
            self.reg[dst] = luaval(c)
            self.emit(pc, "%s = %s" % (self.regname(dst), luaval(c)))
        elif kind == "GETTABLE_K":
            dst = rv(spec["dst"])
            tb = self.R(rv(spec["t"]))
            key = luaval(rv("KA"))
            self.reg[dst] = "%s[%s]" % (tb, key)
            self.emit(pc, "%s = %s[%s]" % (self.regname(dst), tb, key))
        elif kind == "SETTABLE_KK":
            tb = rv(spec["t"])
            key = luaval(rv("KA"))
            val = luaval(rv("KB"))
            self.emit(pc, "%s[%s] = %s" % (self.R(tb), key, val))
        elif kind == "CONCAT_RANGE":
            first = rv("A")
            cnt = rv("B")
            last = first + cnt - 1
            parts = [self.R(i) for i in range(first + 1, last + 1)]
            expr = " .. ".join(parts) if parts else "''"
            self.reg[first] = "(%s)" % expr
            self.emit(pc, "%s = %s" % (self.regname(first), expr))
        elif kind == "CALL_DISCARD":
            dst = rv(spec["dst"])
            args = [self.R(dst + i + 1) for i in range(spec["nargs"])]
            self.emit(pc, "%s(%s)" % (self.R(dst), ", ".join(args)))
        elif kind == "CALL_0A":
            dst = rv(spec["dst"])
            call = "%s()" % self.R(dst)
            self.reg[dst] = "(%s)" % call
            self.emit(pc, "%s = %s" % (self.regname(dst), call))
        elif kind == "FORLOOP":
            self.emit(pc, "-- numeric for-loop (var r%s+3, jump L%s)"
                      % (rv(spec.get("var")), rv(spec.get("tgt"))))
        elif kind in ("JMP_IF_NOT", "JMP_IF"):
            if "cond" in spec:
                cond = spec["cond"]
                tgt = rv(spec["tgt"])
                self.gototargets.add(tgt)
                self.emit(pc, "if not (%s) then goto L%s end" % (cond, tgt))
                return
            a = self.R(rv(spec["a"]))
            if spec["b"] == "K" or spec["b"] not in (pmap or {}):
                bs = luaval(rv("KA"))
            else:
                bs = self.R(rv(spec["b"]))
            tgt = rv(spec["tgt"])
            op = CMPS.get(spec["op"], spec["op"])
            cond = "%s %s %s" % (a, op, bs)
            self.gototargets.add(tgt)
            if kind == "JMP_IF_NOT":
                self.emit(pc, "if not (%s) then goto L%s end" % (cond, tgt))
            else:
                self.emit(pc, "if %s then goto L%s end" % (cond, tgt))
        elif kind == "JMP":
            tgt = rv(spec["tgt"])
            self.gototargets.add(tgt)
            self.emit(pc, "goto L%s" % tgt)
        elif kind == "LOADNIL":
            dst = rv(spec["dst"])
            self.reg[dst] = "nil"
            self.emit(pc, "%s = nil" % self.regname(dst))
        elif kind == "NEWTABLE":
            dst = rv(spec["dst"])
            self.reg[dst] = "{}"
            self.emit(pc, "%s = {}" % self.regname(dst))
        elif kind == "LEN":
            dst = rv(spec["dst"])
            src = self.R(rv(spec["src"]))
            self.reg[dst] = "#%s" % src
            self.emit(pc, "%s = #%s" % (self.regname(dst), src))
        elif kind == "NOT":
            dst = rv(spec["dst"])
            src = self.R(rv(spec["src"]))
            self.reg[dst] = "not (%s)" % src
            self.emit(pc, "%s = not %s" % (self.regname(dst), src))
        elif kind == "UNM":
            dst = rv(spec["dst"])
            src = self.R(rv(spec["src"]))
            self.reg[dst] = "-(%s)" % src
            self.emit(pc, "%s = -%s" % (self.regname(dst), src))
        elif kind == "SELF":
            dst = rv(spec["dst"])
            obj = self.R(rv(spec["obj"]))
            key = luaval(rv("KA"))
            self.reg[dst + 1] = obj
            self.reg[dst] = "%s[%s]" % (obj, key)
            self.emit(pc, "%s, %s = %s, %s[%s]  -- method setup"
                      % (self.regname(dst), self.regname(dst + 1), obj, obj, key))
        elif kind == "MOV_UPVAL":
            dst = rv(spec["dst"])
            name = spec["name"]
            self.reg[dst] = name
            self.emit(pc, "%s = %s  -- loader upvalue" % (self.regname(dst), name))
        elif kind == "ALIAS":
            self.emit(pc, None)  # state shuffling - no output
        elif kind == "CLOSE_UPVAL":
            self.emit(pc, "-- close upvalues")
        elif kind == "FORLOOP":
            self.emit(pc, "-- numeric for-loop op")
        elif kind == "EMPTY":
            self.emit(pc, None)
        else:
            self.emit(pc, "-- ??? opcode %s (%s)" % (w, kind))


def lift_proto(num, arrays, semantics, outdir):
    if not arrays.get("G"):
        return 0
    lifter = Lifter(arrays, semantics)
    # collect jump targets first (labels)
    for pc in range(1, len(arrays["G"]) + 1):
        w = arrays["G"].get(str(pc))
        if w is None:
            continue
        kind, spec, pmap = semantics.get(w, ("UNKNOWN", {}, {}))
        if kind in ("JMP", "JMP_IF", "JMP_IF_NOT"):
            try:
                name = (pmap or {}).get(spec.get("tgt"), spec.get("tgt"))
                tgt = arrays.get(name, {}).get(str(pc))
                if tgt is not None:
                    lifter.gototargets.add(tgt)
            except Exception:
                pass
    # linear emission
    for pc in sorted(arrays["G"], key=lambda x: int(x)):
        lifter.step(int(pc))
    path = os.path.join(outdir, "lifted_p%s.lua" % num)
    header = [
        "-- lifted Lua source - proto #%s" % num,
        "-- %s instructions (linear order, control flow via labels/gotos)" % len(arrays["G"]),
    ]
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(header) + "\n")
        f.write("\n".join(l for l in lifter.lines if l is not None))
        f.write("\n")
    return len(lifter.lines)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    obf = sys.argv[1]
    dumpdir = sys.argv[2]
    outdir = sys.argv[3] if len(sys.argv) > 3 else dumpdir
    os.makedirs(outdir, exist_ok=True)

    protos = json.load(open(os.path.join(dumpdir, "protos.json")))
    data = open(obf, "r", encoding="latin-1").read()
    roles = L.__dict__["roles"].detect_roles(data) if "roles" in dir(L) else None
    if roles is None:
        import roles as roles_mod
        roles = roles_mod.detect_roles(data)
    print("[*] roles:", roles)
    tm = build_token_map(roles)

    opmap = L.recover_opmap(obf, ".")
    print("[*] handlers:", len(opmap or []))
    semantics = {}
    for w, txt in (opmap or {}).items():
        abs_text = L.role_abstract(txt, roles, roles["pc"])
        kind, spec = parse_template(abs_text, roles)
        pmap = per_handler_map(txt, roles)
        semantics[w] = (kind, spec, pmap)
    from collections import Counter
    dist = Counter(k for k, _, _ in semantics.values())
    print("[*] semantic distribution:", dict(dist.most_common(14)))

    total = 0
    for num in sorted(protos["protos"], key=lambda x: int(x)):
        arrays = protos["protos"][num]
        n = lift_proto(num, arrays, semantics, outdir)
        if n:
            total += n
            print("[*] proto #%s -> lifted_p%s.lua (%s lines)" % (num, num, n))
    print("[*] done: %s lines total" % total)


if __name__ == "__main__":
    main()
