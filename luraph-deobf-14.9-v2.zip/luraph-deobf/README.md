# Luraph v14.9 Deobfuscator

Tool deobfuscate cho script được bảo vệ bởi **Luraph Obfuscator v14.9** (Lua/Luau,
Roblox). Được xây dựng và kiểm chứng trên 49 sample thật từ 3 bộ sample công khai.

## Cấu trúc file Luraph 14.9

Luraph 14.9 có 2 biến thể đầu ra (cùng dùng chung 1 VM):

### Biến thể 1: VM trực tiếp (37/49 sample)
```
-- header comment (ghi rõ v14.9)
return({ <60+ hàm VM đã làm rối> }):B()(...);
       └── 1 long-string [[...]] hoặc [==[...]==] chứa bytecode buffer
           (base85-encoded, KHÔNG nén — string.sub bỏ 4 ký tự header "LPH?")
```
Lưu ý: Luraph dùng long-string nhiều cấp (`[[...]]`, `[==[...]==]`) vì
payload base85 có thể chứa `]]` — tool tự nhận biết mọi cấp.

### Biến thể 2: compression wrapper (12/49 sample)
```
return(function()
  -- base85 decoder (gsub 5 ký tự -> string.pack("<I4", ...))
  -- LZ77 + adaptive arithmetic DEcompressor (port của LZMA-lite)
  local U = g(h)        -- payload 1 -> SOURCE của VM loader tầng 2
  h = g(F)              -- payload 2 -> bytecode VM (nén)
  h = buffer.fromstring(h)
  g,F = pcall(loadstring, U, "Luraph   ")
  return F(h)           -- chạy VM loader với bytecode buffer
end)()(...)
```

## Pipeline của tool

```
file.lua
  │ 1. detect (header comment / heuristics)
  │ 2. phân biệt biến thể:
  │    - vm-variant: file = loader source trực tiếp, payload = bytecode buffer
  │    - compression-variant: payload nén bằng LZ77 + arithmetic
  │ 3. base85 decode (bỏ 4 ký tự header, 'z' -> '!!!!!',
  │    mỗi nhóm 5 ký tự -> 4 byte little-endian)
  │ 4. (compression) LZ77 + adaptive arithmetic decode (range coder 11-bit,
  │    literal tree 8 ngữ cảnh, matched literal, match/rep distances,
  │    state machine 12 trạng thái)  ← port y hệt Lua gốc, đã đối chiếu
  ▼
stage-2 loader source (Lua/Luau)  +  bytecode VM (buffer)
  │ 5. beautify tầng source:
  │    - chuẩn hoá số: 0X19_ / 0B10_1 / 0x1__2 -> decimal
  │    - decode string escape (\101, \x69, \z, \u{...})
  │    - gỡ opaque predicate hằng (if <số> then / for <range> unroll)
  │    - unflatten state machine while-true (nếu state là hằng số)
  │    - tách bảng loader thành từng function, thụt lề đúng
  │    - anonymous function -> multi-line
  ▼
stage2.clean.lua  (VM loader đọc được)  +  bytecode.bin + bytecode.strings.txt
```

## Cách dùng

```bash
# 1 file
python3 luraph_deobf.py script.lua out/

# cả thư mục
python3 luraph_deobf.py samples/ out/
```

Output trong `out/<tên file>/`:
- `<tên>.payloadN.bin` — blob sau base85
- `<tên>.bytecodeN.bin` — bytecode VM buffer (vm-variant, không nén)
- `<tên>.bytecodeN.strings.txt` — chuỗi trích từ bytecode
- `<tên>.outN.bin` — dữ liệu sau giải nén (compression-variant)
- `<tên>.stage2.lua` — source VM loader khôi phục (raw)
- `<tên>.stage2.clean.lua` — source đã beautify (đọc được)

Chỉ beautify riêng:
```bash
python3 beautify.py stage2.lua > stage2_clean.lua
```

## Những gì đã được deobfuscate

✅ Toàn bộ lớp nén (base85 + range coder) — khôi phục nguyên vẹn
✅ Source VM loader tầng 2 — dạng Lua/Luau đọc được, có tên method,
   hằng số đã gỡ rối, opaque predicate đã gỡ
✅ Trích chuỗi/hằng số từ bytecode (tagged encoding: 0xe7=str, 0x00/32/33/34=num)
✅ Pipeline VM đầy đủ: instrumented runner chạy trong luau CLI → dump
   VM state (48 lệnh chính + 13 proto con), disassembly có tên opcode
✅ **Lifter dựng source logic thật** (`src/lift.py`): từ bytecode dump →
   source Lua với register tracking, hằng số/chuỗi inline, conditional
   thật (`if not (r5 == 24) then goto L4192 end`), concat thật
   (`r165 = r166 .. r167 .. r168`), table get thật, control flow
   labels/gotos giữ nguyên logic. Chạy:
   `python3 src/lift.py script.lua protos.json outdir/`

⏳ Lớp VM bytecode (instructions) — pipeline đầy đủ đã có (xem `src/`):
   - `make_runner.py` — build instrumented Luau runner (thay `buffer` bằng
     logging wrapper, fake env Roblox bằng stub, dump VM state)
   - chạy bằng `luau` CLI (đã cài trong Termux) → VM thực thi thật,
     dump 14 proto + trace lệnh thực hiện + bảng hằng số
   - `luraph_deobf.py` (src) — recover ~163 opcode handler từ dispatch tree,
     phân loại (ADD/SUB/MUL/MOD/LE/EQ/CALL/SETTABLE/GETGLOBAL/CLOSURE...),
     disassembly + pseudo-source với hằng số/chuỗi inline
   - `decompile.py` — sinh pseudo-Lua theo thứ tự thực hiện

Cách chạy pipeline VM đầy đủ:
```bash
python3 src/luraph_deobf.py script_obfuscated.lua out_vm/
# out_vm/: vm_state.json, protos.json, disasm.lst, disasm_pN.lst,
#          pseudo.lua, pseudo_pN.lua, opcode_names.json, run.log
```

## File

| file | vai trò |
|---|---|
| `luraph_deobf.py` | pipeline chính (detect → base85 → decompress → beautify) |
| `luatoken.py` | tokenizer Lua/Luau (0x/0b/underscore, \z \x \u) |
| `luaparse.py` | parser + chuẩn hoá số/chuỗi |
| `beautify.py` | transform passes + renderer |
| `decompress_ref.py` | bản decompress tham chiếu (chậm, để đối chiếu) |
| `reftrace.py` | trace từng op để debug format |
| `getmethod.py` | trích 1 method từ loader source |

## Credit

Sample từ: Zain20m/Samples, Xyraniz/Obfuscator-Samples,
SixZensED/luau-obfuscator-samples. Credit gốc: numberonebayernfan (air),
etl_c (Cdaily). Tool phục vụ nghiên cứu/deobfuscation, giữ nguyên credit
sample khi chia sẻ.
