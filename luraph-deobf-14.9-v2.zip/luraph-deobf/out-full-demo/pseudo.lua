-- Deobfuscated pseudo-source of 8.lua
-- 338 instructions (execution order)
-- pseudo-Lua: constants inlined, registers tracked
   1  -- UNKNOWN I=0 X=0 l=38
  44  -- UNKNOWN I=4 X=107 l=235
  45  -- UNKNOWN I=81 X=3 l=56
  46  -- UNKNOWN I=19 X=24 l=10
  47  -- SETGLOBAL
  48  -- UNKNOWN I=0 X=0 l=28
  17  -- UNKNOWN I=0 X=0 l=17
  18  if not(K[n]<V[A[n]]) then goto 0
  19  -- UNKNOWN I=0 X=0 l=26
  20  -- UNKNOWN I=1 X=0 l=2
  21  -- UNKNOWN I=0 X=0 l=36
  22  -- UNKNOWN I=4 X=3 l=4
  23  -- UNKNOWN I=0 X=0 l=1
  24  -- MOD_K
  25  if not(K[n]<V[A[n]]) then goto 0
  26  -- UNKNOWN I=0 X=0 l=42
  27  if not(K[n]<V[A[n]]) then goto 0
  28  -- UNKNOWN I=0 X=0 l=8
  29  -- UNKNOWN I=1 X=6 l=5
  13  if NOT(not(not(V[A[n]]<V[B[n]])) then goto None
  14  -- UNKNOWN I=0 X=0 l=19
  15  -- DIV_K
  16  -- MUL_K
  30  -- DIV_K
  31  -- MUL_K
  32  -- UNKNOWN I=0 X=0 l=32
  33  -- UNKNOWN I=0 X=0 l=36
   2  -- UNKNOWN I=1 X=7 l=5
   4  -- UNKNOWN I=33 X=7 b=2 l=36
   5  -- UNKNOWN I=160 X=62 l=127
   6  -- SETGLOBAL
   7  -- UNKNOWN I=2 X=7 l=6
   8  -- UNKNOWN I=0 X=0 l=14
   9  -- MOD_K
  10  -- MOD_K
  11  if NOT(V[A[n]]~=V[B[n]] then goto None
  12  -- UNKNOWN I=0 X=0 l=21
  36  -- UNKNOWN I=142 X=226 l=205
  37  if not(K[n]<V[A[n]]) then goto 0
  38  -- UNKNOWN I=0 X=0 l=23
  39  -- GETUPVAL
  40  -- UNKNOWN I=87 X=0 b=1 l=3
  41  -- UNKNOWN I=122 X=0 b=0 l=4
