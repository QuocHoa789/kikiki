#!/usr/bin/env python3
"""
Beautifier transform passes + renderer for the Luraph v14.9 stage-2 source.

Passes:
  * fold constant `if` predicates
  * unroll constant `for` loops (the obfuscator's favourite opacity trick)
  * unflatten `while true do if S==n ... end end` state machines
  * normalize `if X then else Y end` into `if not X then Y end`
  * normalize numbers / strings (done at render time)
"""

import sys

from luaparse import Parser
from luatoken import tokenize
from luaparse import norm_number, decode_lua_string, const_value, eval_cmp

MAX_UNROLL = 128
MAX_STATES = 512


# ---------------------------------------------------------------------------
# numeric literal normalization across a token span
# ---------------------------------------------------------------------------

def norm_span(toks):
    out = []
    for kind, val in toks:
        if kind == "NUMBER":
            n = norm_number(val)
            out.append((kind, n if n is not None else val))
        elif kind == "STRING":
            try:
                out.append((kind, decode_lua_string(val)))
            except Exception:
                out.append((kind, val))
        else:
            out.append((kind, val))
    return out


def span_str(toks):
    """Render a token span compactly with sensible spacing."""
    toks = norm_span(toks)
    parts = [v for _, v in toks]
    if not parts:
        return ""
    out = parts[0]
    prev = parts[0]
    NO_SPACE_BEFORE = {",", ")", "]", "}", ";", ":", ".", ")", "("}
    NO_SPACE_AFTER = {"(", "[", "{", ".", ":", "#", "-", "-"}
    for p in parts[1:]:
        space = True
        if prev in {"(", "[", "{", ".", ":", "#", "@", "$"}:
            space = False
        if p in {",", ")", "]", "}", ";", ":", "."}:
            space = False
        if prev == "-" and p.isdigit():   # negative number literal
            space = False
        if prev in {"=", "==", "~=", "<", ">", "<=", ">=", "+", "-", "*", "/",
                    "%", "^", "..", "and", "or", "not"} or \
                p in {"=", "==", "~=", "<", ">", "<=", ">=", "+", "-", "*",
                      "/", "%", "^", "..", "and", "or"}:
            # keep spaces around binary operators, but not for unary minus
            space = True
        if prev == "(" and p == ")":
            space = False
        if prev == "(" :
            space = False
        if p == "(" and prev and (prev[-1].isalnum() or prev[-1] in "_]})"):
            space = True  # call or keyword
        if p == "[" and prev and (prev[-1].isalnum() or prev[-1] in "_]})"):
            space = False  # index
        if prev == "{" and p in ("}", ","):
            space = p == "," and False or False
        if p == "}":
            space = False
        out += (" " if space else "") + p
        prev = p
    return out


# ---------------------------------------------------------------------------
# transforms
# ---------------------------------------------------------------------------

def is_const_true(toks):
    v = const_value(toks)
    return v is not None and v != 0


def is_const_false(toks):
    v = const_value(toks)
    return v is not None and v == 0


def neg_cond_str(toks):
    """Best-effort readable negation of a comparison condition."""
    # pattern: A OP B  -> A NEG B
    if len(toks) == 3 and toks[1][0] == "OP" and \
            toks[1][1] in ("==", "~=", "<", "<=", ">", ">="):
        neg = {"==": "~=", "~=": "==", "<": ">=", ">=": "<",
               ">": "<=", "<=": ">"}[toks[1][1]]
        return f"{span_str([toks[0]])} {neg} {span_str([toks[2]])}"
    return "not (" + span_str(toks) + ")"


def state_of_condition(toks):
    """For `S == num` conditions, return (state_var_name, num) else None."""
    if len(toks) >= 3 and toks[1][0] == "OP" and toks[1][1] == "==":
        name = toks[0]
        num = const_value(toks[2:])
        if name[0] == "NAME" and num is not None:
            return name[1], num
    return None


def find_state_assigns(stmts, var):
    """Find constant assignments `var = num` in a statement list; returns
    list of (index, num)."""
    out = []
    for idx, st in enumerate(stmts):
        if st[0] == "local" and len(st[1]) == 1 and st[1][0] == var and \
                len(st[2]) == 1:
            v = const_value(st[2][0])
            if v is not None:
                out.append((idx, v))
        elif st[0] == "expr" and len(st[1]) == 1:
            toks = st[1][0]
            # var = num
            if len(toks) >= 3 and toks[0][0] == "NAME" and \
                    toks[0][1] == var and toks[1] == ("OP", "="):
                v = const_value(toks[2:])
                if v is not None:
                    out.append((idx, v))
    return out


def strip_state_jumps(stmts, var):
    """Remove `var = num` assignments and lone `continue` statements from a
    state-machine arm; keeps everything else."""
    out = []
    for st in stmts:
        if st[0] == "local" and len(st[1]) == 1 and st[1][0] == var and \
                len(st[2]) == 1 and const_value(st[2][0]) is not None:
            continue
        if st[0] == "expr" and len(st[1]) == 1:
            toks = st[1][0]
            if len(toks) >= 3 and toks[0][0] == "NAME" and \
                    toks[0][1] == var and toks[1] == ("OP", "=") and \
                    const_value(toks[2:]) is not None:
                continue
        if st[0] == "continue":
            continue
        out.append(st)
    return out


def transform(stmts):
    out = []
    for st in stmts:
        out.append(transform_stmt(st))
    return out


def transform_stmt(st):
    tag = st[0]
    if tag == "if":
        return transform_if(st)
    if tag == "fornum":
        return transform_fornum(st)
    if tag == "while":
        return transform_while(st)
    if tag == "repeat":
        return transform_repeat(st)
    if tag == "do":
        return ("do", transform(st[1]))
    if tag == "func":
        return ("func", st[1], st[2], transform(st[3]))
    if tag == "funcassign":
        return ("funcassign", norm_span(st[1]), st[2], transform(st[3]),
                norm_span(st[4]) if len(st) > 4 else [])
    if tag == "funcreturn":
        return ("funcreturn", st[1], transform(st[2]))
    return st


def transform_if(st):
    _, arms, els = st
    if len(arms) == 1:
        cond, then = arms[0]
        info = state_of_condition(cond)
        if is_const_true(cond):
            return ("do", transform(then)) if then else ("nop", None)
        if is_const_false(cond):
            return ("do", transform(els)) if els else ("nop", None)
        # not(<const>)
        if len(cond) == 2 and cond[0] == ("KEYWORD", "not"):
            inner = [cond[1]]
            if is_const_true(inner):
                return ("do", transform(els)) if els else ("nop", None)
            if is_const_false(inner):
                return ("do", transform(then)) if then else ("nop", None)
        # empty then + non-empty else -> invert
        if not then and els:
            return ("if", [( [("OP","("), ("KEYWORD","not"), ("OP",")")][:0] or
                            [x for x in _neg_tokens(cond)] , els)], [])
    arms = [(c, transform(b)) for c, b in arms]
    els = transform(els) if els else []
    return ("if", arms, els)


def _neg_tokens(toks):
    """Return token span for `not (cond)`."""
    return [("KEYWORD", "not"), ("OP", "(")] + list(toks) + [("OP", ")")]


def transform_fornum(st):
    _, var, vals, body = st
    a = const_value(vals[0]) if vals else None
    b = const_value(vals[1]) if len(vals) > 1 else None
    c = const_value(vals[2]) if len(vals) > 2 else (1.0 if vals else None)
    if a is not None and b is not None and c not in (None, 0):
        # constant range -> unroll with per-iteration constant folding
        iters = []
        x = a
        steps = 0
        while ((c > 0 and x <= b) or (c < 0 and x >= b)) and steps < MAX_UNROLL:
            iters.append(x)
            x += c
            steps += 1
        if steps >= MAX_UNROLL:
            return ("fornum", var, [norm_span(v) for v in vals],
                    transform(body))
        emitted = []
        for iv in iters:
            emitted.extend(_fold_var(body, var, iv))
        return ("do", transform(emitted))
    return ("fornum", var, [norm_span(v) for v in vals], transform(body))


def _fold_var(stmts, var, val):
    """Execute a statement list for loop-var value val, folding conditions
    that depend only on var == const / var ~= const.  break/continue of the
    unrolled loop are dropped (continue ends the current iteration)."""
    out = []
    for st in stmts:
        got = _fold_stmt(st, var, val)
        if got is _BREAK:
            break
        if got is _CONTINUE:
            break
        out.extend(got)
    return out


_BREAK = object()
_CONTINUE = object()


def _fold_stmt(st, var, val):
    tag = st[0]
    if tag == "if":
        _, arms, els = st
        for cond, then in arms:
            res = _eval_cond_on(cond, var, val)
            if res is True:
                return _fold_var(then, var, val)
            if res is False:
                continue
            idx = arms.index((cond, then))
            rest = [(c, transform(b)) for c, b in arms[idx + 1:]]
            return [("if", [(cond, transform(then))] + rest,
                     transform(els) if els else [])]
        return _fold_var(els, var, val) if els else []
    if tag == "break":
        return _BREAK
    if tag == "continue":
        return _CONTINUE
    if tag == "fornum":
        return [transform_fornum(st)]
    return [transform_stmt(st)]


def _eval_cond_on(cond, var, val):
    """Evaluate `var == num`, `var ~= num`, `var < num` etc. for a bound var.
    Returns True/False/None (unknown)."""
    if len(cond) == 3 and cond[0][0] == "NAME" and cond[0][1] == var and \
            cond[1][0] == "OP" and cond[1][1] in ("==", "~=", "<", "<=", ">", ">="):
        rhs = const_value(cond[2:])
        if rhs is not None:
            return eval_cmp(cond[1][1], val, rhs)
    if len(cond) == 3 and cond[2][0] == "NAME" and cond[2][1] == var and \
            cond[1][0] == "OP" and cond[1][1] in ("==", "~=", "<", "<=", ">", ">="):
        lhs = const_value(cond[:1])
        if lhs is not None:
            return eval_cmp(cond[1][1], lhs, val)
    if len(cond) >= 2 and cond[0] == ("KEYWORD", "not"):
        inner = _eval_cond_on(cond[1:], var, val) if len(cond) == 4 else None
        if inner is not None:
            return not inner
    return None


def transform_while(st):
    _, cond, body = st
    if is_const_true(cond) or (len(cond) == 1 and cond[0][0] == "NUMBER"):
        res = unflatten_state_machine(body)
        if res is not None:
            return res
    return ("while", norm_span(cond), transform(body))


def transform_repeat(st):
    _, body, condv = st
    if len(condv) == 1 and condv[0] == ("NUMBER", "0") or \
            (len(condv) == 1 and condv[0][0] == "NAME" and condv[0][1] == "false"):
        res = unflatten_state_machine(body)
        if res is not None:
            return res
    return ("repeat", transform(body), norm_span(condv))


def unflatten_state_machine(body):
    """Unflatten `while true do if S==n1 then ... elseif S==n2 ... end end`
    where the state var is assigned constants.  Returns replacement statement
    or None when the machine cannot be followed."""
    # find the governing if-chain
    if not body or body[0][0] != "if":
        return None
    arms = body[0][1]
    var = None
    arm_map = {}
    for cond, then in arms:
        info = state_of_condition(cond)
        if info is None:
            return None
        v, num = info
        if var is None:
            var = v
        elif var != v:
            return None
        if num in arm_map:
            return None
        arm_map[num] = then
    # extra statements after the if (e.g. `until` conditions) -> bail
    if len(body) > 1 and any(st[0] not in ("nop",) for st in body[1:]):
        return None
    # initial state: an assignment before the loop is not visible here; try
    # the lowest state whose arm is reachable... instead: find any state that
    # is assigned from within arms but appears as "entry" — the obfuscator
    # always seeds the var before the loop, so approximate by starting at the
    # first state that is NOT a jump target of a preceding state.
    # Build transition graph
    trans = {}
    for num, then in arm_map.items():
        nxt = None
        for idx, v in find_state_assigns(then, var):
            nxt = v
        trans[num] = nxt
    # entry: states never assigned by any arm
    assigned = {v for v in trans.values() if v is not None}
    entries = [s for s in arm_map if s not in assigned]
    if len(entries) != 1:
        return None
    # walk the chain
    chain = []
    cur = entries[0]
    visited = set()
    loops_back = False
    while cur is not None and cur not in visited:
        visited.add(cur)
        arm = strip_state_jumps(transform(arm_map[cur]), var)
        # stop at break
        ended = False
        for st in arm:
            if st[0] == "break":
                ended = True
        chain.append(arm)
        nxt = trans.get(cur)
        if ended:
            break
        cur = nxt
    else:
        if cur in visited:
            loops_back = True
    if loops_back or cur is None and not ended:
        return None
    flat = []
    for arm in chain:
        flat.extend(arm)
    return ("do", flat)


# ---------------------------------------------------------------------------
# loader-table splitter: return({...}):METHOD()  ->  methods rendered one by one
# ---------------------------------------------------------------------------

def split_table_entries(toks, open_idx):
    """Given tokens and index of the opening '{', split the constructor into
    (entries, close_idx).  Commas at constructor level separate entries, but
    commas inside an entry's function body do not."""
    depth = 0
    i = open_idx
    entries = []
    cur = []
    n = len(toks)
    bstack = []      # block stack for keyword scopes inside an entry
    skip_do = False
    while i < n:
        kind, val = toks[i]
        if kind == "OP" and val in "([{":
            depth += 1
            if depth == 1 and val == "{":
                i += 1
                continue
        elif kind == "OP" and val in ")]}":
            depth -= 1
            if depth == 0:
                break
        if depth == 1 and kind == "OP" and val in (",", ";"):
            if not bstack:
                if cur:
                    entries.append(cur)
                cur = []
                i += 1
                continue
        if kind == "KEYWORD":
            if skip_do and val == "do":
                skip_do = False
                cur.append(toks[i])
                i += 1
                continue
            if val == "repeat":
                bstack.append("until")
            elif val in ("function", "if"):
                bstack.append("end")
            elif val in ("for", "while"):
                bstack.append("end")
                skip_do = True
            elif val == "until":
                if bstack and bstack[-1] == "until":
                    bstack.pop()
            elif val == "end":
                if bstack and bstack[-1] == "end":
                    bstack.pop()
        cur.append(toks[i])
        i += 1
    if cur:
        entries.append(cur)
    return entries, i


def parse_entry(entry):
    """(name, params, body_tokens, is_func) or (name, span, False, None, None)."""
    if len(entry) >= 4 and entry[1] == ("OP", "=") and \
            entry[2] == ("KEYWORD", "function"):
        name = entry[0][1]
        # params: tokens until matching ')' from index 3
        i = 3
        params = []
        pd = 0
        while i < len(entry):
            k, v = entry[i]
            if k == "OP" and v == "(":
                pd += 1
                if pd == 1:
                    i += 1
                    continue
            elif k == "OP" and v == ")":
                pd -= 1
                if pd == 0:
                    i += 1
                    break
            elif k == "OP" and v == "," and pd == 1:
                i += 1
                continue
            elif k == "OP" and v == "..." and pd == 1:
                params.append("...")
                i += 1
                continue
            if pd >= 1:
                params.append(v)
            i += 1
        # body until matching 'end' at depth 0 (proper block stack: repeat is
        # closed by 'until', everything else by 'end'; for/while push once and
        # swallow their `do`)
        body = []
        bstack = []
        skip_do = False
        while i < len(entry):
            k, v = entry[i]
            if k == "OP" and v in "([{":
                bstack.append("paren")
            elif k == "OP" and v in ")]}":
                if bstack and bstack[-1] == "paren":
                    bstack.pop()
            elif k == "KEYWORD":
                if skip_do and v == "do":
                    skip_do = False
                    body.append((k, v))
                    i += 1
                    continue
                if v == "repeat":
                    bstack.append("until")
                elif v in ("function", "if"):
                    bstack.append("end")
                elif v in ("for", "while"):
                    bstack.append("end")
                    skip_do = True
                elif v == "until":
                    if bstack and bstack[-1] == "until":
                        bstack.pop()
                elif v == "end":
                    if not bstack:
                        return name, params, body, True
                    if bstack[-1] == "end":
                        bstack.pop()
            body.append((k, v))
            i += 1
        return name, params, body, True
    # plain field
    if len(entry) >= 2 and entry[1] == ("OP", "="):
        return entry[0][1], None, entry[2:], False
    return None, None, entry, False


def split_loader_tables(stmts):
    """Replace return/expr statements that consist of an inline loader table
    with ("loadertable", prefix, entries, tail)."""
    out = []
    for st in stmts:
        tag = st[0]
        spans = None
        if tag == "return":
            spans = st[1]
        elif tag == "expr":
            spans = st[1]
        if spans:
            new_spans = []
            replaced = False
            for sp in spans:
                hit = False
                # find a '{' at depth 0 that starts a constructor with
                # function entries, preceded by '('
                for j, (k, v) in enumerate(sp):
                    if k == "OP" and v == "{":
                        entries, close = split_table_entries(sp, j)
                        funcs = [e for e in entries if
                                 len(e) > 2 and e[1] == ("OP", "=") and
                                 e[2] == ("KEYWORD", "function")]
                        if len(funcs) >= 2:
                            parsed = [parse_entry(e) for e in entries]
                            tail = sp[close + 1:]
                            out.append(("loadertable", parsed,
                                        span_str(tail) if tail else ""))
                            hit = True
                            replaced = True
                            break
                if not hit:
                    new_spans.append(sp)
            if replaced:
                if tag == "return":
                    # keep return if there are remaining spans
                    if new_spans:
                        out.append(("return", new_spans))
                elif new_spans:
                    out.append(("expr", new_spans))
                continue
        out.append(st)
    return out

class Renderer:
    def __init__(self):
        self.lines = []

    def w(self, depth, text):
        self.lines.append("    " * depth + text)

    def stmt(self, st, depth):
        tag = st[0]
        if tag == "nop":
            return
        if tag == "expr":
            for e in st[1]:
                if e:
                    self.w(depth, span_str(e))
            return
        if tag == "local":
            names = ", ".join(st[1])
            if st[2]:
                exprs = ", ".join(span_str(e) for e in st[2] if e)
                self.w(depth, f"local {names} = {exprs}")
            else:
                self.w(depth, f"local {names}")
            return
        if tag == "return":
            exprs = ", ".join(span_str(e) for e in st[1] if e)
            self.w(depth, f"return {exprs}" if exprs else "return")
            return
        if tag in ("break", "continue"):
            self.w(depth, tag)
            return
        if tag == "goto":
            self.w(depth, f"goto {st[1]}")
            return
        if tag == "do":
            self.w(depth, "do")
            for s in st[1]:
                self.stmt(s, depth + 1)
            self.w(depth, "end")
            return
        if tag == "if":
            first = True
            for cond, then in st[1]:
                kw = "if" if first else "elseif"
                self.w(depth, f"{kw} {span_str(cond)} then")
                for s in then:
                    self.stmt(s, depth + 1)
                first = False
            if st[2]:
                self.w(depth, "else")
                for s in st[2]:
                    self.stmt(s, depth + 1)
            self.w(depth, "end")
            return
        if tag == "while":
            self.w(depth, f"while {span_str(st[1])} do")
            for s in st[2]:
                self.stmt(s, depth + 1)
            self.w(depth, "end")
            return
        if tag == "repeat":
            self.w(depth, "repeat")
            for s in st[1]:
                self.stmt(s, depth + 1)
            self.w(depth, f"until {span_str(st[2])}")
            return
        if tag == "fornum":
            vals = ", ".join(span_str(v) for v in st[2])
            self.w(depth, f"for {st[1]} = {vals} do")
            for s in st[3]:
                self.stmt(s, depth + 1)
            self.w(depth, "end")
            return
        if tag == "forin":
            names = ", ".join(st[1])
            exprs = ", ".join(span_str(e) for e in st[2])
            self.w(depth, f"for {names} in {exprs} do")
            for s in st[3]:
                self.stmt(s, depth + 1)
            self.w(depth, "end")
            return
        if tag == "func":
            self.w(depth, f"function {st[1]}({', '.join(st[2])})")
            for s in st[3]:
                self.stmt(s, depth + 1)
            self.w(depth, "end")
            return
        if tag == "funcassign":
            lhs = span_str(st[1])
            self.w(depth, f"{lhs} = function({', '.join(st[2])})")
            for s in st[3]:
                self.stmt(s, depth + 1)
            tail = span_str(st[4]) if len(st) > 4 and st[4] else ""
            self.w(depth, "end" + ("" if not tail else " " + tail))
            return
        if tag == "funcreturn":
            self.w(depth, f"return function({', '.join(st[1])})")
            for s in st[2]:
                self.stmt(s, depth + 1)
            self.w(depth, "end")
            return
        if tag == "raw":
            self.w(depth, span_str(st[1]))
            return
        if tag == "loadertable":
            self.w(depth, "local VM = {}")
            for name, params, body, is_func in st[1]:
                if is_func:
                    self.w(depth, f"function VM.{name}({', '.join(params)})")
                    sub = Parser(body)
                    sub_stmts = sub.parse_block({"EOF"})
                    while sub.peek()[0] != "EOF":
                        s2 = sub.parse_stmt()
                        if s2 is None:
                            break
                        sub_stmts.append(s2)
                    sub_stmts = transform(sub_stmts)
                    for s in sub_stmts:
                        self.stmt(s, depth + 1)
                    self.w(depth, "end")
                elif name is not None:
                    self.w(depth, f"-- VM.{name} = {span_str(body)}")
                else:
                    self.w(depth, f"-- {span_str(body)}")
            if st[2]:
                self.w(depth, f"VM{st[2]}  -- entry call (was inline)")
            return
        self.w(depth, f"-- ??? {tag}")


def beautify(src: str) -> str:
    toks = tokenize(src)
    p = Parser(toks)
    stmts = p.parse_block({"EOF"})
    # also consume until real EOF
    while p.peek()[0] != "EOF":
        st = p.parse_stmt()
        if st is None:
            break
        stmts.append(st)
    stmts = transform(stmts)
    stmts = split_loader_tables(stmts)
    r = Renderer()
    for s in stmts:
        r.stmt(s, 0)
    return "\n".join(r.lines) + "\n"


if __name__ == "__main__":
    src = open(sys.argv[1], encoding="utf-8", errors="replace").read()
    print(beautify(src))
