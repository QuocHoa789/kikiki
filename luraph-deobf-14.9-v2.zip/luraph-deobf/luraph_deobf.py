#!/usr/bin/env python3
"""
Luraph v14.9 deobfuscation tool
- Detects Luraph-protected Lua/Luau files
- Extracts ASCII85 (base85) payloads
- Decodes the custom LZ77 + adaptive arithmetic (range) coder
- Dumps recovered bytecode / buffer data

Ported from the Lua decompressor emitted by Luraph Obfuscator v14.9.
"""

import re
import sys
import struct
from pathlib import Path


# ---------------------------------------------------------------------------
# Stage 1: detection
# ---------------------------------------------------------------------------

LURAPH_HEADER = re.compile(
    r"--\s*This file was protected using Luraph Obfuscator v?([\d.]+)",
    re.IGNORECASE,
)


def detect_luraph(source: str):
    """Return (is_luraph, version_string_or_None)."""
    m = LURAPH_HEADER.search(source)
    if m:
        return True, m.group(1)
    # heuristic fallback
    if "lura.ph" in source:
        return True, None
    return False, None


# ---------------------------------------------------------------------------
# Stage 2: payload extraction
# ---------------------------------------------------------------------------

LONG_STRING_RE = re.compile(
    r"\[(=*)\[(.*?)\]\1\]", re.DOTALL
)


def extract_payloads(source: str):
    """Extract every long-string payload (any bracket level) used by the loader."""
    return [m.group(2) for m in LONG_STRING_RE.finditer(source)]


# ---------------------------------------------------------------------------
# Stage 3: base85 decoding (Luraph variant)
#
# Lua side:
#   b  = string.sub(payload, 5)      -- drop 4-char header
#   b  = gsub(b, "z", "!!!!!")       -- 'z' encodes a zero group
#   for each 5-char group:
#       m = (c5-33) + (c4-33)*85 + (c3-33)*85^2 + (c2-33)*85^3 + (c1-33)*85^4
#       out = string.pack("<I4", m)  -- little-endian 4 bytes
# ---------------------------------------------------------------------------

B85_POW = [52200625, 614125, 7225, 85, 1]  # 85^4, 85^3, 85^2, 85, 1


def b85_decode(payload: str) -> bytes:
    if len(payload) < 4:
        raise ValueError("payload too short")
    body = payload[4:]              # string.sub(payload, 5)
    body = body.replace("z", "!!!!!")

    out = bytearray()
    n_groups = len(body) // 5
    for i in range(n_groups):
        chunk = body[i * 5 : i * 5 + 5]
        m = 0
        for c in chunk:
            m = m * 85 + (ord(c) - 33)
        out += struct.pack("<I", m & 0xFFFFFFFF)
    # trailing chars are left verbatim by gsub(".....")
    out += body[n_groups * 5 :].encode("latin-1")
    return bytes(out)


# ---------------------------------------------------------------------------
# Stage 4: LZ77 + adaptive arithmetic decoder
#
# Faithful port of the Lua decompressor.  All arithmetic is integral.
# ---------------------------------------------------------------------------

class BitReader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = -1          # next_byte() pre-increments, matches Lua o=o+1
        self.range = 0xFFFFFFFF
        code = 0
        for _ in range(5):
            code = (code << 8) | self.next_byte()
        self.code = code

    def next_byte(self) -> int:
        self.pos += 1
        if self.pos >= len(self.data):
            raise EOFError("compressed stream exhausted")
        return self.data[self.pos]

    # -- direct (uniform) bit decode --------------------------------------
    def decode_direct_bits(self, count: int) -> int:
        result = 0
        for _ in range(count):
            self.range >>= 1
            result <<= 1
            if self.code >= self.range:
                self.code -= self.range
                result |= 1
            if self.range <= 0x00FFFFFF:
                self.range <<= 8
                self.code = (self.code << 8) | self.next_byte()
        return result

    # -- adaptive bit decode ----------------------------------------------
    def decode_bit(self, probs: list, index: int) -> int:
        if index >= len(probs):
            probs.extend([1024] * (index + 1 - len(probs)))
        bound = (self.range // 2048) * probs[index]
        if self.code < bound:
            # bit 0
            self.range = bound
            probs[index] += (2048 - probs[index]) >> 5
            bit = 0
        else:
            # bit 1
            self.range -= bound
            self.code -= bound
            probs[index] -= probs[index] >> 5
            bit = 1
        if self.range <= 0x00FFFFFF:
            self.range <<= 8
            self.code = (self.code << 8) | self.next_byte()
        return bit

    # -- fixed-width tree decode: returns tree_value - (1 << bits) --------
    def decode_tree(self, probs: list, bits: int) -> int:
        node = 1
        for _ in range(bits):
            node = (node << 1) | self.decode_bit(probs, node)
        return node - (1 << bits)

    # -- LSB-first tree decode over a base index --------------------------
    def decode_direct_tree(self, probs: list, base: int, bits: int) -> int:
        node = 1
        value = 0
        for a in range(bits):
            bit = self.decode_bit(probs, base + node)
            node = (node << 1) | bit
            value |= bit << a
        return value

    # -- LZMA-style matched literal ----------------------------------------
    def decode_matched_byte(self, probs: list, match_byte: int) -> int:
        node = 1
        for shift in range(7, -1, -1):
            expected = (match_byte >> shift) & 1
            bit = self.decode_bit(probs, node + (expected << 8) + 256)
            node = (node << 1) | bit
            if expected != bit:
                while node < 0x100:
                    node = (node << 1) | self.decode_bit(probs, node)
                break
        return node & 0xFF

    # -- length decode: {1024, 1024, tree3[0], tree3[0], tree8(256)} -------
    def decode_length(self, length_model: list) -> int:
        if self.decode_bit(length_model, 1) == 0:
            return self.decode_tree(length_model[2], 3)
        if self.decode_bit(length_model, 2) == 0:
            return 8 + self.decode_tree(length_model[3], 3)
        return 16 + self.decode_tree(length_model[4], 8)


def make_length_model() -> list:
    return [
        1024,                              # [0] unused, [1] first selector
        1024,                              # [1] selector bit 1
        [1024] * 9,                        # [2] 3-bit tree (indices 1..7)
        [1024] * 9,                        # [3] 3-bit tree
        [1024] * 257,                      # [4] 8-bit tree (indices 1..255)
    ]
# note: Lua tables used {1024.0, 1024.0, a(1,8), a(1,8), L(256)} where
# index 1 and 2 are the selector probabilities; emulate with a flat list:
def make_length_model2() -> list:
    m = [0] * 5
    m[0] = [1024, 1024]                    # selectors at index 1 and 2
    m[1] = [1024] * 9                      # 3-bit tree
    m[2] = [1024] * 9
    m[3] = None
    m[4] = [1024] * 257
    return m


def new_length_model():
    """Index-based like the Lua table: t[1], t[2] selectors; t[3], t[4] 3-bit
    trees (context 0 only); t[5] 8-bit tree."""
    return {
        1: [1024],
        2: [1024],
        3: {0: [1024] * 9},
        4: {0: [1024] * 9},
        5: [1024] * 257,
    }


def decompress(data: bytes, trace=None) -> bytes:
    """LZ77 + adaptive arithmetic decoder (Luraph v14.9 stream format).

    Optimized: the range decoder state is kept in locals inside the hot loop.
    If `trace` is a list, (kind, state, length, dist) tuples are appended.
    """
    pos = -1
    n_data = len(data)

    def next_byte():
        nonlocal pos
        pos += 1
        if pos >= n_data:
            raise EOFError("compressed stream exhausted")
        return data[pos]

    rng = 0xFFFFFFFF
    code = 0
    for _ in range(5):
        code = (code << 8) | next_byte()

    # probability tables
    literal_models = [[1024] * 0x300 for _ in range(8)]
    V = [[1024] for _ in range(12)]
    G = [1024] * 12
    d = [1024] * 12
    D = [1024] * 12
    j = [1024] * 12
    w = [[1024] for _ in range(12)]
    T = [[1024] * 65 for _ in range(4)]
    B = [1024] * 115
    P = [1024] * 16
    sel_k1 = [1024]   # length model k selectors
    sel_k2 = [1024]
    sel_l1 = [1024]   # length model l selectors
    sel_l2 = [1024]
    tree_k3 = [1024] * 9   # 3-bit trees, context 0
    tree_k4 = [1024] * 9
    tree_l3 = [1024] * 9
    tree_l4 = [1024] * 9
    tree_k5 = [1024] * 257  # 8-bit trees
    tree_l5 = [1024] * 257

    state_trans = {0: 0, 1: 0, 2: 0, 3: 0, 4: 1, 5: 2, 6: 3,
                   7: 4, 8: 5, 9: 6, 10: 4, 11: 5}

    out = bytearray(b"\x00")            # m[0] = 0 sentinel
    out_len = 1
    state = 0
    rep_t = rep_x = rep_e = dist = 0

    max_out = max(1 << 24, len(data) * 64)   # safety: fail instead of hang
    max_steps = max(1 << 22, len(data) * 16)
    steps = 0
    while pos <= n_data:
        steps += 1
        if steps > max_steps or out_len > max_out:
            raise ValueError("not a compressed Luraph stream (desync)")
        # --- decode bit from V[state][0] (literal vs match) ---
        probs = V[state]
        pr = probs[0]
        bound = (rng // 2048) * pr
        if code < bound:
            rng = bound
            probs[0] = pr + ((2048 - pr) >> 5)
            if rng <= 0x00FFFFFF:
                rng <<= 8
                code = (code << 8) | next_byte()
            # ---- literal ----
            model = literal_models[out[out_len - 1] >> 5]
            if state < 7:
                # 8-bit tree decode
                node = 1
                for _ in range(8):
                    pr2 = model[node]
                    bound2 = (rng // 2048) * pr2
                    if code < bound2:
                        rng = bound2
                        model[node] = pr2 + ((2048 - pr2) >> 5)
                        node <<= 1
                    else:
                        rng -= bound2
                        code -= bound2
                        model[node] = pr2 - (pr2 >> 5)
                        node = (node << 1) | 1
                    if rng <= 0x00FFFFFF:
                        rng <<= 8
                        code = (code << 8) | next_byte()
                out.append(node & 0xFF)
            else:
                # matched literal with match byte
                mb = out[out_len - dist - 1]
                node = 1
                for shift in range(7, -1, -1):
                    expected = (mb >> shift) & 1
                    pr2 = model[node + (expected << 8) + 256]
                    bound2 = (rng // 2048) * pr2
                    if code < bound2:
                        rng = bound2
                        model[node + (expected << 8) + 256] = \
                            pr2 + ((2048 - pr2) >> 5)
                        bit = 0
                    else:
                        rng -= bound2
                        code -= bound2
                        model[node + (expected << 8) + 256] = pr2 - (pr2 >> 5)
                        bit = 1
                    node = (node << 1) | bit
                    if rng <= 0x00FFFFFF:
                        rng <<= 8
                        code = (code << 8) | next_byte()
                    if expected != bit:
                        while node < 0x100:
                            pr2 = model[node]
                            bound2 = (rng // 2048) * pr2
                            if code < bound2:
                                rng = bound2
                                model[node] = pr2 + ((2048 - pr2) >> 5)
                                node <<= 1
                            else:
                                rng -= bound2
                                code -= bound2
                                model[node] = pr2 - (pr2 >> 5)
                                node = (node << 1) | 1
                            if rng <= 0x00FFFFFF:
                                rng <<= 8
                                code = (code << 8) | next_byte()
                        break
                out.append(node & 0xFF)
            state = state_trans[state]
            if trace is not None:
                trace.append(("lit", state, 1, 0))
        else:
            rng -= bound
            code -= bound
            probs[0] = pr - (pr >> 5)
            if rng <= 0x00FFFFFF:
                rng <<= 8
                code = (code << 8) | next_byte()
            # ---- match ----
            length = None
            # G[state] bit
            pr = G[state]
            bound = (rng // 2048) * pr
            if code < bound:
                rng = bound
                G[state] = pr + ((2048 - pr) >> 5)
                g_bit = 0
            else:
                rng -= bound
                code -= bound
                G[state] = pr - (pr >> 5)
                g_bit = 1
            if rng <= 0x00FFFFFF:
                rng <<= 8
                code = (code << 8) | next_byte()
            if g_bit != 0:
                # rep family
                pr = d[state]
                bound = (rng // 2048) * pr
                if code < bound:
                    rng = bound
                    d[state] = pr + ((2048 - pr) >> 5)
                    d_bit = 0
                else:
                    rng -= bound
                    code -= bound
                    d[state] = pr - (pr >> 5)
                    d_bit = 1
                if rng <= 0x00FFFFFF:
                    rng <<= 8
                    code = (code << 8) | next_byte()
                if d_bit == 0:
                    pr = w[state][0]
                    bound = (rng // 2048) * pr
                    if code < bound:
                        rng = bound
                        w[state][0] = pr + ((2048 - pr) >> 5)
                        w_bit = 0
                    else:
                        rng -= bound
                        code -= bound
                        w[state][0] = pr - (pr >> 5)
                        w_bit = 1
                    if rng <= 0x00FFFFFF:
                        rng <<= 8
                        code = (code << 8) | next_byte()
                    if w_bit == 0:
                        state = 9 if state < 7 else 11
                        length = 1
                else:
                    pr = D[state]
                    bound = (rng // 2048) * pr
                    if code < bound:
                        rng = bound
                        D[state] = pr + ((2048 - pr) >> 5)
                        D_bit = 0
                    else:
                        rng -= bound
                        code -= bound
                        D[state] = pr - (pr >> 5)
                        D_bit = 1
                    if rng <= 0x00FFFFFF:
                        rng <<= 8
                        code = (code << 8) | next_byte()
                    if D_bit == 0:
                        new_dist = rep_t
                    else:
                        pr = j[state]
                        bound = (rng // 2048) * pr
                        if code < bound:
                            rng = bound
                            j[state] = pr + ((2048 - pr) >> 5)
                            j_bit = 0
                        else:
                            rng -= bound
                            code -= bound
                            j[state] = pr - (pr >> 5)
                            j_bit = 1
                        if rng <= 0x00FFFFFF:
                            rng <<= 8
                            code = (code << 8) | next_byte()
                        if j_bit == 0:
                            new_dist = rep_x
                        else:
                            new_dist = rep_e
                            rep_e = rep_x
                        rep_x = rep_t
                    rep_t = dist
                    dist = new_dist
                if length is None:
                    state = 8 if state < 7 else 11
                    # rep length decode from model l
                    pr = sel_l1[0]
                    bound = (rng // 2048) * pr
                    if code < bound:
                        rng = bound
                        sel_l1[0] = pr + ((2048 - pr) >> 5)
                        l_sel = 0
                    else:
                        rng -= bound
                        code -= bound
                        sel_l1[0] = pr - (pr >> 5)
                        l_sel = 1
                    if rng <= 0x00FFFFFF:
                        rng <<= 8
                        code = (code << 8) | next_byte()
                    if l_sel == 0:
                        node = 1
                        for _ in range(3):
                            pr2 = tree_l3[node]
                            bound2 = (rng // 2048) * pr2
                            if code < bound2:
                                rng = bound2
                                tree_l3[node] = pr2 + ((2048 - pr2) >> 5)
                                node <<= 1
                            else:
                                rng -= bound2
                                code -= bound2
                                tree_l3[node] = pr2 - (pr2 >> 5)
                                node = (node << 1) | 1
                            if rng <= 0x00FFFFFF:
                                rng <<= 8
                                code = (code << 8) | next_byte()
                        length = 2 + (node - 8)
                    else:
                        pr = sel_l2[0]
                        bound = (rng // 2048) * pr
                        if code < bound:
                            rng = bound
                            sel_l2[0] = pr + ((2048 - pr) >> 5)
                            l_sel2 = 0
                        else:
                            rng -= bound
                            code -= bound
                            sel_l2[0] = pr - (pr >> 5)
                            l_sel2 = 1
                        if rng <= 0x00FFFFFF:
                            rng <<= 8
                            code = (code << 8) | next_byte()
                        if l_sel2 == 0:
                            node = 1
                            for _ in range(3):
                                pr2 = tree_l4[node]
                                bound2 = (rng // 2048) * pr2
                                if code < bound2:
                                    rng = bound2
                                    tree_l4[node] = pr2 + ((2048 - pr2) >> 5)
                                    node <<= 1
                                else:
                                    rng -= bound2
                                    code -= bound2
                                    tree_l4[node] = pr2 - (pr2 >> 5)
                                    node = (node << 1) | 1
                                if rng <= 0x00FFFFFF:
                                    rng <<= 8
                                    code = (code << 8) | next_byte()
                            length = 2 + 8 + (node - 8)
                        else:
                            node = 1
                            for _ in range(8):
                                pr2 = tree_l5[node]
                                bound2 = (rng // 2048) * pr2
                                if code < bound2:
                                    rng = bound2
                                    tree_l5[node] = pr2 + ((2048 - pr2) >> 5)
                                    node <<= 1
                                else:
                                    rng -= bound2
                                    code -= bound2
                                    tree_l5[node] = pr2 - (pr2 >> 5)
                                    node = (node << 1) | 1
                                if rng <= 0x00FFFFFF:
                                    rng <<= 8
                                    code = (code << 8) | next_byte()
                            length = 2 + 16 + (node - 256)
            else:
                # new match
                rep_e = rep_x
                rep_x = rep_t
                rep_t = dist
                # match length from model k
                pr = sel_k1[0]
                bound = (rng // 2048) * pr
                if code < bound:
                    rng = bound
                    sel_k1[0] = pr + ((2048 - pr) >> 5)
                    k_sel = 0
                else:
                    rng -= bound
                    code -= bound
                    sel_k1[0] = pr - (pr >> 5)
                    k_sel = 1
                if rng <= 0x00FFFFFF:
                    rng <<= 8
                    code = (code << 8) | next_byte()
                if k_sel == 0:
                    node = 1
                    for _ in range(3):
                        pr2 = tree_k3[node]
                        bound2 = (rng // 2048) * pr2
                        if code < bound2:
                            rng = bound2
                            tree_k3[node] = pr2 + ((2048 - pr2) >> 5)
                            node <<= 1
                        else:
                            rng -= bound2
                            code -= bound2
                            tree_k3[node] = pr2 - (pr2 >> 5)
                            node = (node << 1) | 1
                        if rng <= 0x00FFFFFF:
                            rng <<= 8
                            code = (code << 8) | next_byte()
                    length = 2 + (node - 8)
                else:
                    pr = sel_k2[0]
                    bound = (rng // 2048) * pr
                    if code < bound:
                        rng = bound
                        sel_k2[0] = pr + ((2048 - pr) >> 5)
                        k_sel2 = 0
                    else:
                        rng -= bound
                        code -= bound
                        sel_k2[0] = pr - (pr >> 5)
                        k_sel2 = 1
                    if rng <= 0x00FFFFFF:
                        rng <<= 8
                        code = (code << 8) | next_byte()
                    if k_sel2 == 0:
                        node = 1
                        for _ in range(3):
                            pr2 = tree_k4[node]
                            bound2 = (rng // 2048) * pr2
                            if code < bound2:
                                rng = bound2
                                tree_k4[node] = pr2 + ((2048 - pr2) >> 5)
                                node <<= 1
                            else:
                                rng -= bound2
                                code -= bound2
                                tree_k4[node] = pr2 - (pr2 >> 5)
                                node = (node << 1) | 1
                            if rng <= 0x00FFFFFF:
                                rng <<= 8
                                code = (code << 8) | next_byte()
                        length = 2 + 8 + (node - 8)
                    else:
                        node = 1
                        for _ in range(8):
                            pr2 = tree_k5[node]
                            bound2 = (rng // 2048) * pr2
                            if code < bound2:
                                rng = bound2
                                tree_k5[node] = pr2 + ((2048 - pr2) >> 5)
                                node <<= 1
                            else:
                                rng -= bound2
                                code -= bound2
                                tree_k5[node] = pr2 - (pr2 >> 5)
                                node = (node << 1) | 1
                            if rng <= 0x00FFFFFF:
                                rng <<= 8
                                code = (code << 8) | next_byte()
                        length = 2 + 16 + (node - 256)
                slot_idx = min(length - 2, 3)
                tree = T[slot_idx]
                node = 1
                for _ in range(6):
                    pr2 = tree[node]
                    bound2 = (rng // 2048) * pr2
                    if code < bound2:
                        rng = bound2
                        tree[node] = pr2 + ((2048 - pr2) >> 5)
                        node <<= 1
                    else:
                        rng -= bound2
                        code -= bound2
                        tree[node] = pr2 - (pr2 >> 5)
                        node = (node << 1) | 1
                    if rng <= 0x00FFFFFF:
                        rng <<= 8
                        code = (code << 8) | next_byte()
                slot = node - 64
                if trace is not None:
                    trace.append(("slot", slot))
                if slot >= 4:
                    nbits = (slot >> 1) - 1
                    base = (2 + (slot & 1)) << nbits
                    if slot < 14:
                        # nbits low bits from B, base index base-slot
                        bnode = 1
                        value = 0
                        bidx = base - slot
                        for a in range(nbits):
                            pr2 = B[bidx + bnode]
                            bound2 = (rng // 2048) * pr2
                            if code < bound2:
                                rng = bound2
                                B[bidx + bnode] = pr2 + ((2048 - pr2) >> 5)
                                bit = 0
                            else:
                                rng -= bound2
                                code -= bound2
                                B[bidx + bnode] = pr2 - (pr2 >> 5)
                                bit = 1
                            bnode = (bnode << 1) | bit
                            value |= bit << a
                            if rng <= 0x00FFFFFF:
                                rng <<= 8
                                code = (code << 8) | next_byte()
                        dist = base + value
                    else:
                        # (nbits-4) direct bits * 16 + 4 bits from P
                        dval = 0
                        dn = nbits - 4
                        while dn > 0:
                            rng >>= 1
                            dval <<= 1
                            if code >= rng:
                                code -= rng
                                dval |= 1
                            if rng <= 0x00FFFFFF:
                                rng <<= 8
                                code = (code << 8) | next_byte()
                            dn -= 1
                        bnode = 1
                        value = 0
                        for a in range(4):
                            pr2 = P[bnode]
                            bound2 = (rng // 2048) * pr2
                            if code < bound2:
                                rng = bound2
                                P[bnode] = pr2 + ((2048 - pr2) >> 5)
                                bit = 0
                            else:
                                rng -= bound2
                                code -= bound2
                                P[bnode] = pr2 - (pr2 >> 5)
                                bit = 1
                            bnode = (bnode << 1) | bit
                            value |= bit << a
                            if rng <= 0x00FFFFFF:
                                rng <<= 8
                                code = (code << 8) | next_byte()
                        dist = base + (dval << 4) + value
                        if dist == 0xFFFFFFFF:
                            break        # end-of-stream marker
                else:
                    dist = slot
                state = 7 if state < 7 else 10
                if dist >= out_len - 1:
                    raise ValueError("invalid match distance")
            # copy `length` bytes from distance `dist + 1`
            for _ in range(length):
                out.append(out[out_len - dist - 1])
                out_len += 1
            if trace is not None:
                trace.append(("match", state, length, dist))
            continue
        out_len += 1
    return bytes(out[1:])


def decode_length_model(rc: BitReader, lm: dict) -> int:
    if rc.decode_bit(lm[1], 0) == 0:
        return rc.decode_tree(lm[3][0], 3)
    if rc.decode_bit(lm[2], 0) == 0:
        return 8 + rc.decode_tree(lm[4][0], 3)
    return 16 + rc.decode_tree(lm[5], 8)


# ---------------------------------------------------------------------------
# Lua 5.1 bytecode inspection
# ---------------------------------------------------------------------------

LUA51_SIGNATURE = b"\x1bLua"


def is_lua51_bytecode(data: bytes) -> bool:
    return data[:4] == LUA51_SIGNATURE


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def looks_like_vm_loader(source: str) -> bool:
    """True when the file itself is the VM loader (vm-variant output)."""
    head = source[:3000]
    tail = source[-400:]
    return ("string.pack" not in head and "return(" in head
            and re.search(r"\}\)\s*:\s*[A-Za-z_]\w*\s*\(", tail) is not None)


def extract_strings(data: bytes, min_len: int = 4):
    """Extract printable ASCII runs from a bytecode blob (quick strings view)."""
    out = []
    cur = []
    for b in data:
        if 32 <= b < 127:
            cur.append(chr(b))
        else:
            if len(cur) >= min_len:
                out.append("".join(cur))
            cur = []
    if len(cur) >= min_len:
        out.append("".join(cur))
    return out


def analyze(path: Path, outdir: Path):
    source = path.read_text(encoding="utf-8", errors="replace")
    is_l, version = detect_luraph(source)
    print(f"[+] {path.name}: Luraph detected={is_l}, version={version}")

    is_vm = looks_like_vm_loader(source)
    payloads = extract_payloads(source)
    print(f"[+] found {len(payloads)} long-string payload(s) "
          f"[{'vm-variant' if is_vm else 'compression-variant'}]")

    outdir.mkdir(parents=True, exist_ok=True)
    blobs = []
    for i, p in enumerate(payloads):
        try:
            blob = b85_decode(p)
        except Exception as exc:
            print(f"    payload {i}: base85 decode failed: {exc}")
            continue
        blobs.append(blob)
        (outdir / f"{path.stem}.payload{i}.bin").write_bytes(blob)

    recovered_sources = []
    if is_vm:
        # payload is the raw bytecode buffer, not compressed
        for i, blob in enumerate(blobs):
            print(f"    payload {i}: bytecode buffer, {len(blob):,} bytes "
                  f"head={blob[:8].hex()}")
            (outdir / f"{path.stem}.bytecode{i}.bin").write_bytes(blob)
            strs = extract_strings(blob)
            (outdir / f"{path.stem}.bytecode{i}.strings.txt").write_text(
                "\n".join(strs) + "\n", encoding="utf-8")
            print(f"    payload {i}: {len(strs)} string(s) extracted")
    else:
        for i, blob in enumerate(blobs):
            try:
                raw = decompress(blob)
            except Exception as exc:
                print(f"    payload {i}: decompress failed: {exc}")
                continue
            if is_lua51_bytecode(raw):
                kind = "lua51-bytecode"
            else:
                head = raw[:64]
                if all(9 <= b < 127 for b in head):
                    kind = "lua-source"
                else:
                    kind = "data"
            print(f"    payload {i}: decompressed {len(raw):,} bytes [{kind}]")
            (outdir / f"{path.stem}.out{i}.bin").write_bytes(raw)
            if kind == "lua-source":
                src_path = outdir / f"{path.stem}.stage2.lua"
                src_path.write_text(raw.decode("latin-1"), encoding="utf-8")
                recovered_sources.append(src_path)

    # beautify recovered stage-2 sources
    for src_path in recovered_sources:
        _beautify_file(src_path, outdir)

    # VM-variant: the file itself is the loader source
    if is_vm:
        loader = LONG_STRING_RE.sub("[[ /* bytecode payload */ ]]", source)
        loader_path = outdir / f"{path.stem}.stage2.lua"
        loader_path.write_text(loader, encoding="utf-8")
        print(f"    vm-variant: loader source -> {loader_path.name}")
        _beautify_file(loader_path, outdir)

def _beautify_file(src_path, outdir):
    try:
        from beautify import beautify
        clean = beautify(src_path.read_text(encoding="utf-8", errors="replace"))
        clean_path = outdir / (src_path.stem + ".clean.lua")
        clean_path.write_text(clean, encoding="utf-8")
        print(f"    beautified -> {clean_path.name}")
    except Exception as exc:
        print(f"    beautify failed: {exc}")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        print("usage: luraph_deobf.py <file-or-dir> [outdir]")
        sys.exit(1)
    target = Path(sys.argv[1])
    outdir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("out")
    files = sorted(target.rglob("*.lua")) if target.is_dir() else [target]
    for f in files:
        try:
            analyze(f, outdir / f.stem)
        except Exception as exc:
            print(f"[!] {f}: {exc}")


if __name__ == "__main__":
    main()
