#!/usr/bin/env python3
"""Extract VM method bodies from a stage2 loader source by finding balanced regions."""
import re
import sys


def find_methods(src: str):
    """Locate NAME=function starts inside the big loader table."""
    out = []
    for m in re.finditer(r'([A-Za-z_][A-Za-z_0-9]{0,3})=function', src):
        out.append((m.group(1), m.start(), m.end()))
    return out


def main():
    path = sys.argv[1]
    name = sys.argv[2]
    src = open(path, encoding="utf-8", errors="replace").read()
    ms = find_methods(src)
    # find requested method(s)
    for i, (n, s, e) in enumerate(ms):
        if n == name:
            # body ends before the next '=function' that is not nested... use paren balance
            depth = 0
            j = e  # after 'function'
            # scan for matching 'end' by tracking function/if/do blocks via parens is unreliable;
            # instead take until next top-level '=function' occurrence and let user trim
            nxt = ms[i + 1][1] if i + 1 < len(ms) else len(src)
            body = src[s:nxt]
            print(f"--- {n} @ {s} (next def @ {nxt}) len={len(body)} ---")
            print(body[:12000])
            return
    print("not found; available:", " ".join(sorted(set(n for n, _, _ in ms))))


if __name__ == "__main__":
    main()
