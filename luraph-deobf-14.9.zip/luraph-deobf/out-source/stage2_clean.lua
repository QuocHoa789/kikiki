local F = ...
local VM = {}
function VM._(K)
    local A = K[0]
    return function()
        local K = 945871
        local G = A[27]
        K = K * G
        G = 4033771
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
    end
end
function VM.m8(K, K, A, G)
    if K == 13 then
        A[44], A[14] = 119, (A[15])
        return G, 21418, K
    else
        if K == 102 then
            A[30], G = 165, G
            K = (13)
            return G, 61185, K
        end
    end
    return G, nil, K
end
function VM.Q(K, A, G)
    G[14464] = (- 1997767198 + (K.Dc ((K.uc (G[17825])) + G[17825] - G[31946] - K.H[6] - K.H[9])))
    A = (- 2302783405 + ((K.Ac ((K.mc (A, (G[17825]))) - G[31867] > G[8844] and K.H[5] or K.H[8])) + G[31867] - K.H[2]))
    (G)[2661] = (A)
    return A
end
function VM.hv(K, K, A)
    A = (K[29061])
    return A
end
function VM.e(K, A, G)
    A = - 317398 + (K.mc ((K.nc (K.H[4])) + G[18334] - G[7640] + G[17825] + G[8844], (G[17825])))
    G[15243] = (A)
    return A
end
function VM.L(K, A, G, N, Z)
    while true do
        if Z == 75 then
            A[7] = K.Hc
            if not G[30130] then
                Z = (- 13383 + ((K.nc ((K.Tc ((K.Ac (G[18334] - K.H[6])) >= G[20959] and K.H[8] or G[17825])))) == K.H[2] and G[7640] or K.H[1]))
                (G)[30130] = (Z)
            else
                Z = G[30130]
            end
        else
            if not (Z ~= 46) then
                (A)[8] = (N[K.m])
                break
            end
        end
    end
    (A)[9] = (N[K.O])
    (A)[10] = (N.readu16)
    A[11] = (nil)
    A[12] = nil
    A[13] = (nil)
    return Z
end
-- VM.P = bit32
function VM.W(K)
    local A, G, N, Z, D = {}
    D, Z = K:h (Z, D, A)
    local e, M
    D, e, M = K:k (Z, D, e, M, A)
    M, e = K:R (e, A, M, Z)
    e = K:L (A, Z, D, e)
    e = K:y (e, A, D, Z)
    e = K:d (Z, e, D, A)
    e = K:B (A, e, Z)
    e = K:lv (Z, A, e, M)
    K:mv (A)
    e = K:av (D, Z, A, e)
    K:Pv (A)
    e = K:iv (Z, e, A)
    local D, M, s
    D, M, s, G, e, N = K:C8 (D, M, Z, A, s, e)
    if G == - 2 then
        return N
    end
    G, e = K:_c (Z, A, D, s, e, M)
    return K.V (G)
end
function VM.p(K, K, A)
    K = (A[23406])
    return K
end
function VM.K8(K, K, A)
    K = A[35] ()
    return K
end
-- VM.m = "r\101\97\du\56"
-- VM.v = bit32.countlz
function VM._8(K, A, G, N, Z, D, e, M, s, k)
    if D == 0 then
        (M)[s] = (s - e)
    elseif D == 4 then
        if not (k[2]) then
            Z[s] = k[4][e]
        else
            local x, f = (k[4][e])
            do
                f = K:Sv (x, f)
                if k[26] ~= N then
                    x[f + 1] = A
                end
            end
            x[f + 2] = s
            (x)[f + 3] = 6
        end
    elseif D == 3 then
        K:Iv (s, e, M)
    elseif D == 5 then
        K:W8 (e, s, M)
    else
        if D == 6 then
            local K, A = 119
            while true do
                if not (K > 65) then
                    (k[19])[A + 1] = Z
                    k[19][A + 2] = (s)
                    break
                else
                    if K ~= 119 then
                        if k[38] == k[22] then
                            (k)[44] = (- (234 > 186))
                        end
                        K = (65)
                        continue
                    else
                        K = 106
                        A = (#k[19])
                    end
                end
            end
            (k[19])[A + 3] = e
        end
    end
    G = (104)
    return G
end
-- VM.Tc = bit32.bxor
function VM.i8(K, A, G, N, Z, D)
    local e, M
    if D == 199 then
        for s = 1, A, 1 do
            local k, x, f = Z[32] (), (68)
            while true do
                if x > 22 and x < 83 then
                    if not (k <= 52) then
                        local z = 8
                        repeat
                            if z < 71 then
                                if k <= 168 then
                                    local c = 51
                                    while true do
                                        if c < 118 then
                                            if k <= 95 then
                                                local B = 12
                                                while true do
                                                    if B == 123 then
                                                        f = K:w8 (f, Z)
                                                        break
                                                    else
                                                        if not (B ~= 12) then
                                                            B = 123
                                                            if Z[22] == G then
                                                                Z[26] = Z[22] / 206
                                                                if Z[53] then
                                                                    return - 2, N, G, 37
                                                                end
                                                            end
                                                            continue
                                                        end
                                                    end
                                                end
                                            else
                                                if A ~= G then
                                                    if k == 168 then
                                                        f = Z[45] ()
                                                    else
                                                        f = Z[39] ()
                                                    end
                                                end
                                            end
                                            c = 118
                                            continue
                                        else
                                            break
                                        end
                                    end
                                else
                                    e, f, M = K:b8 (k, f, Z)
                                    if not (e ~= - 2) then
                                        return - 2, N, G, M
                                    end
                                end
                                z = (71)
                                continue
                            else
                                if not (not (z > 8)) then
                                    K:c8 ()
                                    break
                                end
                            end
                        until false
                    else
                        if not (k > 30) then
                            do
                                if not (k > 0) then
                                    f = Z[32] ()
                                else
                                    f = K:h8 (A, k, Z, f)
                                end
                            end
                        else
                            if not (k > 45) then
                                f = K:a8 (f, Z)
                            else
                                if not (k > 50) then
                                    f = K:K8 (f, Z)
                                else
                                    f = Z[38] ()
                                end
                            end
                        end
                    end
                    x = (83)
                else
                    if x < 68 then
                        if G then
                            K:k8 (Z, f, s)
                        else
                            (Z[4])[s] = (f)
                        end
                        break
                    else
                        if x > 68 then
                            x = K:o8 (x)
                        end
                    end
                end
            end
        end
        return 9826, N, G
    elseif D == 133 then
        G = (Z[32] () ~= 0)
    else
        if D == 232 then
            N = K:Q8 (Z, N)
        else
            if D == 166 then
                Z[2] = G
                return 9826, N, G
            else
                if D == 100 then
                    (Z)[4] = Z[21] (A)
                    return 9826, N, G
                end
            end
        end
    end
    return nil, N, G
end
function VM.Iv(K, K, A, G)
    (G)[K] = (A)
end
function VM.D(K)
    local A = K[0]
    return function()
        local K = 532847
        local G = A[27]
        K = K * G
        G = 6355007
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 124243
        G = A[27]
        K = K * G
        G = 1437789
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 623881
        G = A[27]
        K = K * G
        G = 13664534
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 20347
        G = A[27]
        K = K * G
        G = 8430212
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 270165
        G = A[27]
        K = K * G
        G = 5037606
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 838395
        G = A[27]
        K = K * G
        G = 7483820
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 567565
        G = A[27]
        K = K * G
        G = 16585130
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 400527
        G = A[27]
        K = K * G
        G = 234893
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 850411
        G = A[27]
        K = K * G
        G = 3870701
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 589177
        G = A[27]
        K = K * G
        G = 6848003
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 122355
        G = A[27]
        K = K * G
        G = 8580980
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 206399
        G = A[27]
        K = K * G
        G = 1721089
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 975321
        G = A[27]
        K = K * G
        G = 12292802
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 715041
        G = A[27]
        K = K * G
        G = 183298
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 98039
        G = A[27]
        K = K * G
        G = 2959129
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 608263
        G = A[27]
        K = K * G
        G = 260831
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 215451
        G = A[27]
        K = K * G
        G = 1423370
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 71769
        G = A[27]
        K = K * G
        G = 11634447
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 988497
        G = A[27]
        K = K * G
        G = 9623985
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 686591
        G = A[27]
        K = K * G
        G = 13864385
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 30513
        G = A[27]
        K = K * G
        G = 14818286
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 75977
        G = A[27]
        K = K * G
        G = 8894543
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 930875
        G = A[27]
        K = K * G
        G = 14231290
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 878883
        G = A[27]
        K = K * G
        G = 9145849
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 1034631
        G = A[27]
        K = K * G
        G = 16129578
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
        K = 1014005
        G = A[27]
        K = K * G
        G = 2858728
        K = K + G
        G = 16777216
        K = K % G
        A[27] = K
    end
end
function VM.j(K, A, G)
    (G)[27637] = - 2797942223 + ((K.Ac ((K.Ac ((K.Hc ((K.Dc ((K.Dc (G[31867], G[18334])), K.H[7])))))))) - G[20959])
    A = (- 1233 + (K.lc ((K.Tc ((K.Tc ((K.rc (K.H[2] ~= K.H[9] and G[28007] or K.H[6], (G[17825]))), K.H[3], K.H[9])), G[17825], G[13997])) - K.H[3], (G[17825]))))
    G[23406] = (A)
    return A
end
function VM.Uv(K, K, A, G, N)
    (N)[K + 1] = (A)
    G = (79)
    return G
end
function VM.V8(K, A, G, N, Z, D)
    if not (G > 97) then
        if not (G < 161) then
        else
            Z = K:v8 (N, D, A, Z)
            return 41481, Z
        end
    end
    return nil, Z
end
function VM.u(...)
    (...)[...] = nil
end
function VM.fv(K, A, G, N, Z)
    local D, e, M = 85
    while true do
        if D < 79 then
            D = K:Uv (M, N, D, e)
            continue
        elseif D > 79 then
            e = (Z[4][G])
            D = 48
            M = (#e)
        else
            if D < 85 and D > 48 then
                (e)[M + 2] = A
                break
            end
        end
    end
    e[M + 3] = 1
end
function VM.d8(K, A, G, N)
    A[29][2] = A[52]
    if not N[1415] then
        G = K:s8 (N, G)
    else
        G = N[1415]
    end
    return G
end
function VM.Rv(K, A, G, N, Z, D, e, M, s)
    s = nil
    e = (nil)
    do
        s = {nil, K.q, nil, nil, nil, nil, nil, K.q, nil, K.q, nil}
        s[4] = N[41] ()
        K:gv (N, s)
        e = N[41] () - 42493
    end
    M = N[21] (e)
    D = N[21] (e)
    G = N[21] (e)
    A = nil
    Z = nil
    return G, M, D, A, Z, s, e
end
function VM.sv(K, K, A, G, N, Z)
    (Z[19])[G + 1] = K
    A = 90
    Z[19][G + 2] = N
    return A
end
function VM.x(K, A, G, N)
    N[15] = {}
    if not G[6918] then
        (G)[13997] = - 1 + (G[21428] + A - K.H[2] - G[22889] - K.H[2] - G[8844] <= G[22889] and G[1879] or K.H[6])
        A = (- 10485664 + (K.rc ((K.Hc ((K.Tc ((K.nc (K.H[3] + K.H[2])) - K.H[7], G[17825])), G[1879])), (G[27523]))))
        G[6918] = (A)
    else
        A = G[6918]
    end
    return A
end
function VM.s8(K, A, G)
    G = (13210 + (A[12707] - A[10454] + A[29061] - A[27329] + A[17668] + G - K.H[1]))
    A[1415] = (G)
    return G
end
function VM.Lv(K, K, A)
    A[2] = (K)
end
function VM.Bv(K, A, G, N, Z, D)
    if not (G[2]) then
        (Z)[D] = (G[4][A])
    else
        K:fv (D, A, N, G)
    end
end
function VM.g8(K, K, A, G)
    (K)[A] = G[53] ()
end
function VM.lv(K, A, G, N, Z)
    G[29] = (nil)
    N = (7)
    while true do
        if N < 58 then
            (G)[27] = function (D, e, M) if G[22] ~= G[15] then else (G)[22], G[5] = G[5], 107; (G)[15] = (G[1]); end; if G[26] ~= G[1] then else (G)[14], G[15] = G[1], (- G[1]); while true do (G)[22], G[15] = G[26], - G[5]; end; end; M = M or 1; e = (e or #D); if not ((e - M + 1) > 7997) then return G[23] (D, M, e); else return G[26] (D, e, M); end; end
            if not A[31215] then
                N = (- 2994049987 + (K.Ac ((K.rc (A[20959] + K.H[4] - A[28007] + A[10716] < K.H[1] and A[2970] or K.H[7], (A[23406]))))))
                A[31215] = (N)
            else
                N = K:S (A, N)
            end
        else
            if N < 81 and N > 7 then
                G[28] = 0
                if not (not A[24194]) then
                    N = K:I (N, A)
                else
                    A[3065] = - 4513293698 + ((K.Tc (A[15243] - A[1879] + A[26161])) - A[15243] + K.H[9] - K.H[3])
                    (A)[17668] = (- 266108903 + (K.lc ((K.Oc ((K.nc ((A[1879] >= K.H[7] and A[31867] or K.H[2]) < A[6918] and K.H[4] or A[27637])) - A[27637], (A[27523]))), (A[22889]))))
                    N = (- 5 + ((A[6918] == K.H[3] and A[21428] or A[28007]) + A[28007] + K.H[9] + A[31946] + K.H[9] <= A[30130] and A[8844] or A[8844]))
                    A[24194] = (N)
                end
            else
                if N > 58 then
                    K:Wv (G)
                    break
                end
            end
        end
    end
    (G)[30] = nil
    (G)[31] = (nil)
    N = 108
    while true do
        if N == 108 then
            for D = 0, 255 do
                if not (G[14] == G[29]) then
                    K:_v (G, Z, D)
                end
            end
            G[30] = 9007199254740992
            if not (not A[3219]) then
                N = K:Dv (N, A)
            else
                N = (- 1711133912 + ((K.Hc (A[18334] - N - A[1879] - A[3280] - N, A[27523])) + K.H[8]))
                (A)[3219] = N
            end
        else
            if N == 91 then
                G[31] = K.lc
                break
            end
        end
    end
    (G)[32] = function()
        local A, Z = (97)
        while true do
            if A ~= 76 then
                A, Z = K:Hv (Z, G, A)
                continue
            else
                if not (G[22] == G[29]) then
                    for A = 63, 229, 118 do
                        if A == 63 then
                            (G)[28] = (G[28] + 1)
                        else
                            return Z
                        end
                    end
                end
                break
            end
        end
    end
    (G)[33] = K.G
    (G)[34] = K.J
    G[35] = function()
        return (K:uv (G))
    end
    (G)[36] = function () local A, Z; A, Z = K:Av (G); if A ~= - 2 then else return Z; end; end
    return N
end
function VM.Vv(K, A, G)
    (A)[13600] = (13 + (K.nc (((K.Ac (A[6007])) + K.H[1] > A[17708] and A[28007] or A[15243]) + A[31215] < G and A[28007] or A[31215])))
    (A)[26111] = (- 84 + ((K.Hc ((A[13997] + A[1656] <= G and K.H[7] or A[9022]) <= A[13997] and A[30130] or A[22889], A[30130])) - A[7640] + A[31867]))
    G = (167 + ((K.nc (A[18334])) - A[31946] + A[32411] - A[14464] - A[27523] - A[10716]))
    (A)[29061] = (G)
    return G
end
function VM.gv(K, K, A)
    A[7] = K[41] ()
end
-- VM.X = table.create
function VM.Pv(K, K)
    (K)[45] = (nil)
    (K)[46] = (nil)
    (K)[47] = (nil)
    (K)[48] = (nil)
    (K)[49] = (nil)
end
function VM.P8(K, K)
    K = (true)
    return K
end
-- VM.V = unpack
function VM.Z(K, A, G)
    A = - 1711133997 + (K.Dc ((K.uc ((K.nc ((K.lc ((K.Hc (K.H[6])) + K.H[8], (G[7640]))))))), G[10280], K.H[8]))
    (G)[28007] = (A)
    return A
end
function VM.ev(K, A, G, N, Z, D, e, M)
    if e == 3 then
        A[M] = (G)
    elseif e == 4 then
        if Z[2] then
            K:Zv (N, G, Z, M)
        else
            K:zv (Z, M, D, G)
        end
    elseif e == 5 then
        (A)[M] = M + G
    elseif e == 6 then
        K:pv (G, Z, D, M)
    else
        if e == 0 then
            (A)[M] = (M - G)
        end
    end
end
function VM.Zv(K, K, A, G, N)
    local Z = G[4][A]
    G = #Z
    do
        if not (A <= 59) then
            if A == 121 then
                (Z)[G + 3] = (3)
            else
                (Z)[G + 2] = N
                continue
            end
        else
            Z[G + 1] = (K)
            continue
        end
        if not (A <= 59) then
            if A == 121 then
                (Z)[G + 3] = (3)
            else
                (Z)[G + 2] = N
                continue
            end
        else
            Z[G + 1] = (K)
            continue
        end
        if not (A <= 59) then
            if A == 121 then
                (Z)[G + 3] = (3)
            else
                (Z)[G + 2] = N
                continue
            end
        else
            Z[G + 1] = (K)
            continue
        end
    end
end
function VM.U8(K, K, A)
    A = K[21329]
    return A
end
function VM.S(K, K, A)
    A = K[31215]
    return A
end
function VM.Kv(K, A, G, N, Z)
    if Z == 82 then
        A[40] = (4503599627370496)
        if not N[1656] then
            Z = K:Ov (Z, N)
        else
            Z = N[1656]
        end
    else
        if Z == 9 then
            (A)[41] = function () local D, e = 0, 1; repeat local M = A[32] (); for s = 113, 207, 52 do if s < 165 then D += ((M > 127 and M - 128 or M) * e); else if s > 113 then e = K:Tv (e); break; end; end; end; until M < 128; return D; end
            if not N[6007] then
                Z = K:rv (Z, N)
            else
                Z = N[6007]
            end
            return 54730, Z
        else
            if Z == 32 then
                A[39] = function () local D, e = A[37] (), A[37] (); if e == 0 then return D; else if e >= A[14] then e -= A[22]; end; end; return e * A[22] + D; end
                if not N[19005] then
                    Z = K:Xv (Z, N)
                else
                    Z = (N[19005])
                end
                return 54730, Z
            elseif Z == 84 then
                A[42] = (G.readstring)
                return 19105, Z
            else
                if not (Z ~= 5) then
                    Z = K:Jv (N, A, Z)
                    return 54730, Z
                end
            end
        end
    end
    return nil, Z
end
function VM.O8(K, K)
    K[5] = K[44]
end
function VM.C(K, A, G, N, Z)
    G[18] = A.readf64
    if not Z[28007] then
        N = K:Z (N, Z)
    else
        N = K:z (N, Z)
    end
    return N
end
function VM.a8(K, K, A)
    K = A[44] ()
    return K
end
function VM.z8(K, A, G, N, Z, D)
    local e, M
    if Z < 101 then
        G = D ()
        if not N[27302] then
            Z = K:y8 (N, Z)
        else
            Z = N[27302]
        end
        return 11678, G, Z
    else
        if Z > 30 then
            e, M = K:Z8 (A)
            if not (e ~= - 2) then
                return - 2, G, Z, M
            end
            return 3712, G, Z
        end
    end
    return nil, G, Z
end
function VM.tv(K, K, A)
    A = K[11] (F, K[28])
    return A
end
function VM.I(K, K, A)
    K = A[24194]
    return K
end
function VM.pv(K, A, G, N, Z)
    local D, e = 73
    repeat
        if D == 73 then
            D, e = K:Cv (G, e, D)
        else
            if D == 99 then
                G[19][e + 2] = (Z)
                break
            else
                if not (D ~= 20) then
                    D = K:jv (G, D, N, e)
                    continue
                end
            end
        end
    until false
    G[19][e + 3] = A
end
function VM.L8(K, K, A, G)
    G = (K[A[41] ()])
    return G
end
function VM.D8(K, K)
    return K
end
function VM.Hv(K, K, A, G)
    G = (76)
    K = A[8] (F, A[28])
    return G, K
end
function VM.U(K, A, G)
    A = (2797942378 + ((K.nc (K.H[7] + K.H[4] - K.H[5] + K.H[2])) - G[10716] - K.H[7]))
    G[3280] = (A)
    return A
end
function VM.o(K, A, G)
    G = (62 + (K.Hc ((K.uc ((K.Ac (A[7640] + A[31946])) ~= A[31946] and K.H[6] or A[1879])) - K.H[1], A[31867])))
    A[20959] = G
    return G
end
function VM.h8(K, A, G, N, Z)
    local D
    do
        D, Z = K:V8 (N, e, A, Z, G)
        if D == 41481 then
            continue
        end
        D, Z = K:V8 (N, e, A, Z, G)
        if D == 41481 then
            continue
        end
    end
    return Z
end
function VM.Tv(K, K)
    K *= 128
    return K
end
function VM.Sv(K, K, A)
    A = #K
    return A
end
function VM.Ev(K, K, A, G, N, Z, D)
    (K)[1] = (Z)
    K[6] = (A)
    (K)[11] = D
    (K)[3] = (G)
    N = (nil)
    return N
end
function VM.w8(K, K, A)
    K = - A[32] ()
    return K
end
function VM.h(K, K, A, G)
    K = ({})
    (G)[1] = nil
    A = (nil)
    return A, K
end
function VM.w(K, A, G, N)
    (A)[2] = nil
    if not N[17825] then
        (N)[8844] = (- 4294604691 + (K.Dc ((K.Hc (N[31946] - G + K.H[2] - K.H[2])) + K.H[9], K.H[6])))
        G = 21 + (K.uc (((K.uc (N[7640] + K.H[9])) ~= K.H[4] and K.H[2] or N[7640]) + K.H[7] + N[1879]))
        (N)[17825] = G
    else
        G = N[17825]
    end
    return G
end
-- VM.rc = bit32.lshift
function VM.s(K, K, A)
    A = K[15243]
    return A
end
function VM.d(K, A, G, N, Z)
    Z[18] = (nil)
    Z[19] = nil
    G = 69
    repeat
        if G == 18 then
            (Z)[19] = nil
            break
        elseif G == 69 then
            G = K:x (G, A, Z)
        elseif G == 96 then
            Z[16] = N.readf32
            (Z)[17] = K.r
            if not A[10280] then
                G = - 2633408331 + (((K.Ac ((K.uc ((K.Dc (A[18334], K.H[5], K.H[4])))) + K.H[3])) <= K.H[7] and A[22889] or K.H[5]) >= A[13997] and A[22889] or K.H[3])
                (A)[10280] = (G)
            else
                G = A[10280]
            end
            continue
        else
            if not (G ~= 63) then
                G = K:C (N, Z, G, A)
            end
        end
    until false
    (Z)[20] = nil
    (Z)[21] = nil
    Z[22] = nil
    Z[23] = (nil)
    G = 56
    while true do
        if G == 1 then
            Z[23] = (unpack)
            break
        elseif G == 42 then
            (Z)[22] = (4294967296.0)
            if not (not A[23406]) then
                G = K:p (G, A)
            else
                G = K:j (G, A)
            end
            continue
        else
            if G == 56 then
                (Z)[20] = N.copy
                if not (not A[2970]) then
                    G = (A[2970])
                else
                    (A)[26161] = - 184 + ((K.Hc ((K.Ac (A[30130] < A[2661] and A[18334] or A[14464])) ~= A[2661] and A[1879] or A[18334])) + A[8844] + A[30130])
                    A[10716] = (4033588873 + ((K.Hc (A[7640] + A[14464] + A[10280])) - A[21428] - A[17825] - K.H[4]))
                    G = (- 1073741775 + (K.mc (((K.uc (K.H[6])) - A[2661] - A[21428] ~= A[1879] and A[20959] or K.H[8]) + A[17825], (A[22889]))))
                    (A)[2970] = G
                end
                continue
            else
                if G == 55 then
                    (Z)[21] = K.X
                    if not (not A[15243]) then
                        G = K:s (A, G)
                    else
                        G = K:e (G, A)
                    end
                end
            end
        end
    end
    return G
end
-- VM.Oc = bit32.lrotate
function VM.Wc(K, A, G, N, Z)
    if N == 107 then
        (A[29])[8] = K.H
        return 34533, N
    elseif N == 17 then
        (A[29])[10] = A[32]
        if not (not Z[6933]) then
            N = Z[6933]
        else
            (Z)[12656] = (- 58 + ((K.Hc ((K.Tc ((K.Oc (Z[27523], (Z[23406]))) - Z[15186], Z[13600], Z[28007])))) + K.H[9] <= Z[1879] and K.H[2] or Z[20959]))
            Z[5647] = (- 49 + (((K.nc ((K.Ac (Z[6918] - N)))) == Z[22889] and Z[19005] or Z[15243]) + Z[27302] - Z[22889]))
            N = (- 183500720 + ((K.rc (((K.Dc (Z[461] > Z[27329] and Z[1879] or Z[461])) >= Z[29820] and Z[8844] or K.H[6]) + Z[31946], (Z[29820]))) - Z[29820]))
            Z[6933] = (N)
        end
    else
        if N == 60 then
            A[29][6] = A[46]
            (A[29])[5] = A[15]
            if not Z[3106] then
                (Z)[7449] = - 4033588765 + ((K.uc (Z[7950] + Z[22889] - Z[7950] - Z[5647] - K.H[3])) + K.H[4])
                N = - 2851734968 + ((K.Dc ((K.H[4] ~= K.H[3] and Z[461] or Z[31215]) + Z[1656] + Z[1338])) + K.H[9] - Z[21329])
                (Z)[3106] = (N)
            else
                N = Z[3106]
            end
            return 2816, N
        else
            if not (N ~= 122) then
                (A[29])[1] = (G)
                if not (not Z[17835]) then
                    N = (Z[17835])
                else
                    N = K:I8 (Z, N)
                end
            end
        end
    end
    return nil, N
end
function VM.ov(K, A, G, N)
    local Z, D = 43
    while true do
        D, Z = K:kv (A, G, Z, N)
        if D == 27106 then
            break
        else
            if D == 15055 then
                continue
            end
        end
    end
end
function VM.xv(K, K, A)
    K = A[43] ()
    return K
end
-- VM.l = coroutine
function VM.Xv(K, A, G)
    A = - 1071644589 + (K.Ac ((K.rc (G[18334] + A + A + G[22889] > G[3280] and K.H[7] or K.H[1], (G[17825])))))
    G[19005] = A
    return A
end
function VM.p8(K, A, G, N)
    G[29][21] = K.lc
    if not (not N[461]) then
        A = N[461]
    else
        (N)[14536] = - 2633408364 + ((((K.lc (N[14464] - K.H[6], (N[10454]))) <= N[14464] and N[28007] or N[7640]) - N[6007] < N[2661] and K.H[3] or K.H[5]) + N[10454])
        A = - 4294967102 + (K.Ac (((K.lc (N[22889] - N[7640], (N[27329]))) - N[14464] == N[29061] and N[28007] or N[23406]) + N[27302]))
        N[461] = (A)
    end
    return A
end
function VM.E8(K, K)
    return K
end
function VM.Yv(K, K, A, G)
    G = K[16] (F, K[28])
    A = (118)
    return G, A
end
function VM.F(K, K, A)
    (K)[3] = (A.create)
end
-- VM.Xc = string.unpack
function VM.j8(K, A)
    (A[29])[27] = K.Y
    A[29][26] = K.P.band
    A[29][20] = K.v
    (A[29])[23] = K.mc
end
-- VM.t = coroutine.wrap
function VM.A8(K, A, G, N, Z)
    A[5] = (N)
    local D = (19)
    while true do
        if D >= 86 then
            return - 2, (K:D8 (A))
        else
            for A = 1, Z, 1 do
                local Z, e = (38)
                repeat
                    if Z == 77 then
                        if not (G[25][e]) then
                            local M, s
                            do
                                M = K:H8 (e, M)
                                s = ({[3] = M - M % 1, [1] = e % 4})
                                (G[25])[e] = (s)
                                K:u8 (A, s, N)
                            end
                        else
                            N[A] = G[25][e]
                        end
                        break
                    else
                        e, Z = K:n8 (e, Z, G)
                    end
                until false
            end
            D = 86
            continue
        end
    end
    return nil
end
function VM.W8(K, K, A, G)
    (G)[A] = A + K
end
function VM.f(K, A, G, N)
    (A)[24] = K.t
    if not (not G[3280]) then
        N = G[3280]
    else
        N = K:U (N, G)
    end
    return N
end
function VM.q8(K, K, A)
    K = (A[41] () - 32989)
    return K
end
function VM.Nv(K, A, G, N, Z, D, e, M)
    D = (nil)
    A = (nil)
    local s = 18
    while true do
        if s == 20 then
            s = 99
            D = M[21] (N)
            A = M[21] (N)
        else
            if s == 99 then
                K:Lv (Z, G)
                break
            elseif s == 18 then
                s = (73)
                e = M[21] (N)
                continue
            else
                if not (s ~= 73) then
                    s = 20
                    Z = M[21] (N)
                end
            end
        end
    end
    G[9] = e
    return e, D, Z, A
end
-- VM.n = buffer
function VM.vv(K, A, G, N)
    if G > 51 then
        (A)[28] = (A[28] + 4)
        return N, - 2, G, N
    else
        if G < 118 then
            N, G = K:Yv (A, G, N)
        end
    end
    return N, nil, G
end
function VM.i(K, A, G, N)
    (A)[4] = nil
    if not G[31867] then
        G[18334] = - 16 + ((K.uc ((K.nc ((K.Ac (G[1879])))) + K.H[3] - G[17825])) >= K.H[2] and K.H[5] or N)
        N = - 13438 + ((K.uc ((K.Ac (N - N)) - K.H[7])) + G[1879] + K.H[1])
        (G)[31867] = N
    else
        N = G[31867]
    end
    return N
end
function VM.yv(K, K, A, G, N, Z, D, e, M)
    G = nil
    local s
    A = nil
    N = (nil)
    M = nil
    D = (74)
    while true do
        if D == 33 then
            N = K[43] ()
            D = 12
        elseif D == 12 then
            M = s % 8
            break
        else
            if not (D ~= 74) then
                G = K[43] ()
                D = (33)
                s = K[43] ()
                A = G % 8
            end
        end
    end
    Z = (s - M) / 8
    e = (nil)
    return M, D, A, Z, N, G, e
end
function VM.n8(K, K, A, G)
    A = (77)
    K = G[41] ()
    return K, A
end
-- VM.J = getfenv
function VM.Y8(K, A, G, N)
    if G[36] ~= N then
        A = K:P8 (A)
    end
    return A
end
function VM.F8(K, K, A)
    K = A[36] ()
    return K
end
-- VM.Dc = bit32.bor
function VM.C8(K, A, G, N, Z, D, e)
    local M, s
    (Z)[53] = (nil)
    A = nil
    G = nil
    e = (70)
    while true do
        if e <= 70 then
            (Z)[53] = function()
                local k, x, f, z, c, B, u, p, V
                u, c, B, p, V, f, z = K:Rv (p, u, Z, V, B, z, c, f)
                local S, m
                p, S, V, m = K:Nv (m, f, z, V, S, p, Z)
                local U
                U = K:Ev (f, c, m, U, S, B)
                local l
                do
                    (f)[8] = u
                    for X = 1, z, 1 do
                        local a, P, j, E, b, W, C
                        E, b, P, W, j, a, C = K:yv (Z, P, a, j, W, b, C, E)
                        local q, r
                        do
                            C = K:xv (C, Z)
                            q = C % 8
                            r = (C - q) / 8
                        end
                        C = ((a - P) / 8)
                        b = (67)
                        while true do
                            if b == 109 then
                                (p)[X] = j
                                b = 104
                            elseif b == 70 then
                                if Z[48] ~= Z[1] then
                                    (V)[X] = (r)
                                end
                                b = 109
                                continue
                            elseif b == 104 then
                                (u)[X] = W
                                b = (39)
                            elseif b == 67 then
                                b = (70)
                                if f == Z[37] then
                                    (Z)[51] = (Z[14])
                                end
                                continue
                            else
                                if b == 39 then
                                    B[X] = (C)
                                    break
                                end
                            end
                        end
                        b = (109)
                        repeat
                            if not (b <= 39) then
                                if b ~= 109 then
                                    b = 39
                                    if P == 3 then
                                        B[X] = C
                                    else
                                        if P == 0 then
                                            B[X] = (X - C)
                                        elseif P == 6 then
                                            j = nil
                                            a = (104)
                                            while true do
                                                if a == 39 then
                                                    a = K:sv (S, a, j, X, Z)
                                                elseif a == 90 then
                                                    (Z[19])[j + 3] = C
                                                    break
                                                else
                                                    if a == 104 then
                                                        a = (39)
                                                        j = #Z[19]
                                                    end
                                                end
                                            end
                                        elseif P == 4 then
                                            local p = (16)
                                            while true do
                                                if p < 47 then
                                                    if not (Z[52] ~= Z[1]) then
                                                        K:dv ()
                                                        return
                                                    end
                                                    p = (47)
                                                else
                                                    if p > 16 then
                                                        K:Bv (C, Z, f, S, X)
                                                        break
                                                    end
                                                end
                                            end
                                        else
                                            if P == 5 then
                                                B[X] = X + C
                                            end
                                        end
                                    end
                                else
                                    b = K:_8 (f, b, C, c, E, W, u, X, Z)
                                    continue
                                end
                            else
                                K:ev (V, r, f, Z, m, q, X)
                                break
                            end
                        until false
                    end
                    if w < 339 and w > 115 then
                        U = Z[41] ()
                    else
                        if w > 227 then
                            l = Z[21] (U)
                            if Z[32] == z then
                                while 49 * Z[43] do
                                    return Z[47] <= Z[36]
                                end
                                if f then
                                    Z[30], Z[32] = - z, (Z[47])
                                end
                            end
                        end
                    end
                    if w < 339 and w > 115 then
                        U = Z[41] ()
                    else
                        if w > 227 then
                            l = Z[21] (U)
                            if Z[32] == z then
                                while 49 * Z[43] do
                                    return Z[47] <= Z[36]
                                end
                                if f then
                                    Z[30], Z[32] = - z, (Z[47])
                                end
                            end
                        end
                    end
                end
                do
                    if Z[47] == Z[22] then
                        if Z[52] then
                            u = (102)
                            repeat
                                z, k, u = K:m8 (u, Z, z)
                                if k == 61185 then
                                    continue
                                else
                                    if not (k ~= 21418) then
                                        break
                                    end
                                end
                            until false
                        end
                    end
                    k, x = K:l8 (f, l, Z, U)
                    if k == 57553 then
                        break
                    else
                        if not (k ~= - 2) then
                            return x
                        end
                    end
                end
            end
            if not N[8841] then
                N[19028] = - 19922924 + (K.Tc ((K.Oc ((K.mc (N[27523], (N[27329]))), (N[7640]))) + N[21428] - N[14464] + N[15186], N[21428], N[15243]))
                e = (130 + (((K.lc ((K.nc (K.H[9] - N[26161])), (N[10454]))) + K.H[3] < N[20959] and K.H[8] or N[15243]) - N[10280]))
                (N)[8841] = (e)
            else
                e = (N[8841])
            end
            continue
        else
            if e ~= 109 then
                G = function (...) local k; if Z[53] == Z[14] then local x = 77; while true do k, x = K:T8 (x, Z); if k ~= 20404 then else break; end; end; end; return (...) (); end
                break
            else
                A = function () local k, x, f, z; f, x, z = K:J8 (Z, z, f); if x ~= - 1 then else return; end; local c; z, x, f, c, k = K:N8 (c, Z, z, f); if x == - 2 then return k; else if x == - 1 then return; end; end; return (K:E8 (c)); end
                if not (not N[12707]) then
                    e = (N[12707])
                else
                    e = 104 + (K.mc ((K.Oc ((K.lc ((K.H[4] - N[6918] == K.H[1] and N[14464] or K.H[6]) + K.H[6], (N[10454]))), (N[23406]))), (N[17668])))
                    N[12707] = e
                end
                continue
            end
        end
    end
    D = nil
    e = 30
    while true do
        M, D, e, s = K:z8 (Z, D, N, e, A)
        if M == 3712 then
            break
        elseif M == 11678 then
            continue
        else
            if M == - 2 then
                return A, G, D, - 2, e, s
            end
        end
    end
    if not (Z[53] ~= Z[40]) then
        (Z)[30] = (G / 3)
    end
    return A, G, D, nil, e
end
function VM.k(K, A, G, N, Z, D)
    local e
    D[2] = (nil)
    (D)[3] = (nil)
    N = (43)
    while true do
        if N <= 14 then
            N = K:w (D, N, A)
        else
            G, e, N = K:c (A, D, G, N)
            if e == 26553 then
                break
            end
        end
    end
    D[4] = nil
    D[5] = nil
    Z = (nil)
    D[6] = nil
    return G, N, Z
end
-- VM.lc = bit32.rshift
function VM.l8(K, A, G, N, Z)
    local D, e
    if not (A == N[48]) then
        D, e = K:A8 (A, N, G, Z)
        if D ~= - 2 then
        else
            return - 2, e
        end
    end
    return 57553
end
function VM.r8(K, K)
    (K)[53] = (122)
end
function VM.Wv(K, K)
    (K)[29] = ({})
end
function VM.J8(K, A, G, N)
    local Z
    if A[41] == A[29] then
        if not (not (A[46])) then
            return N, - 1, G
        end
    end
    N = (nil)
    do
        Z, N = K:G8 (A, N, D)
        if Z == 27723 then
            break
        else
            if Z == 51441 then
                continue
            else
                if not (Z ~= - 1) then
                    return N, - 1, G
                end
            end
        end
        Z, N = K:G8 (A, N, D)
        if Z == 27723 then
            break
        else
            if Z == 51441 then
                continue
            else
                if not (Z ~= - 1) then
                    return N, - 1, G
                end
            end
        end
        Z, N = K:G8 (A, N, D)
        if Z == 27723 then
            break
        else
            if Z == 51441 then
                continue
            else
                if not (Z ~= - 1) then
                    return N, - 1, G
                end
            end
        end
    end
    G = (nil)
    return N, nil, G
end
function VM.wv(K, A, G, N)
    N[47] = type
    if not A[29061] then
        G = K:Vv (A, G)
    else
        G = K:hv (A, G)
    end
    return G
end
function VM.Av(K, A)
    local G, N, Z, D = 53
    repeat
        if G > 16 then
            G = (16)
            D = A[9] (F, A[28])
            continue
        else
            if G < 53 then
                N, Z = K:nv (A, D)
                if N == 48051 then
                    break
                else
                    if not (N ~= - 2) then
                        return - 2, Z
                    end
                end
            end
        end
    until false
    return nil
end
function VM.T8(K, A, G)
    if A == 77 then
        A = (72)
        (G)[38] = - (182 / 223)
    else
        if not (A ~= 72) then
            while G[48] do
                K:O8 (G)
            end
            return 20404, A
        end
    end
    return nil, A
end
function VM.cv(K, K, A)
    (K)[28] = (K[28] + A)
end
function VM.I8(K, A, G)
    (A)[7950] = (43 + (K.Hc (((K.Dc ((K.Hc (K.H[6], A[27523])), A[13600])) + A[27302] <= K.H[1] and A[3280] or A[3280]) <= A[27302] and A[3280] or A[23406], A[2661], A[22889])))
    G = - 5646884739 + ((K.mc ((K.Tc (A[13600], A[29820])) >= A[32411] and A[31867] or K.H[3], (A[22889]))) - A[13997] + K.H[7] - A[1656])
    (A)[17835] = (G)
    return G
end
function VM.y8(K, A, G)
    G = - 1170 + (K.Dc ((K.lc (((K.Tc (A[2661] <= A[1879] and A[27329] or A[2970], A[24194])) ~= A[27523] and A[15186] or A[27523]) + K.H[3], (A[17825]))), A[31867]))
    (A)[27302] = G
    return G
end
function VM.rv(K, A, G)
    G[3690] = - 4166918974 + ((K.mc (G[3219] + K.H[9] + K.H[6] + G[3065], (G[7640]))) + G[15243] - G[10280])
    A = (112 + ((K.Hc ((K.Dc (G[27523] + G[27523] - K.H[4] < K.H[6] and K.H[4] or K.H[6])), G[3280])) - G[21428]))
    (G)[6007] = A
    return A
end
function VM.H8(K, K, A)
    A = (K / 4)
    return A
end
function VM.v8(K, A, G, N, Z)
    if G <= 3 then
        Z = N[37] ()
    else
        Z = K:Y8 (Z, N, A)
    end
    return Z
end
function VM.u8(K, K, A, G)
    G[K] = (A)
end
function VM.nv(K, K, A)
    if not (K[32] == K[1]) then
        (K)[28] = (K[28] + 2)
        return - 2, A
    end
    return 48051
end
function VM.f8(K, A, G, N)
    G[29][9] = (G[45])
    if not N[21329] then
        A = 728775316 + (N[30130] - N[8841] - K.H[3] - N[10454] + N[8844] - N[23406] + K.H[2])
        N[21329] = (A)
    else
        A = K:U8 (N, A)
    end
    return A
end
function VM._v(K, K, A, G)
    (K[1])[G] = A (G)
end
-- VM.uc = bit32.countrz
function VM.uv(K, K)
    local A = K[10] (F, K[28])
    K[28] = K[28] + 2
    return A
end
function VM.Gv(K, A, G)
    A = - 5 + (K.Ac (((K.mc ((K.mc (G[20959], (G[7640]))), (G[7640]))) + K.H[9] ~= G[17668] and G[26161] or G[17668]) - G[20959]))
    (G)[10454] = A
    return A
end
function VM.bv(K, K, A, G, N)
    A = (31)
    G = N[42] (F, N[28], K)
    return A, G
end
function VM.c8(K)
end
function VM.E(K, A, G, N, Z)
    if G == 121 then
        N[11] = Z.readi32
        if not A[22889] then
            (A)[21428] = (- 2851735114 + ((K.lc ((K.Tc (A[31867] - A[2661])) - K.H[6] - A[2661], (A[17825]))) + K.H[9]))
            G = (- 2633408511 + ((K.Hc (((G == A[14464] and A[31867] or K.H[4]) - G == K.H[7] and A[20959] or A[18334]) > A[30130] and K.H[3] or K.H[7])) + G))
            (A)[22889] = (G)
        else
            G = A[22889]
        end
    elseif G == 4 then
        (N)[12] = (Z.readu32)
        if not (not A[27523]) then
            G = (A[27523])
        else
            G = (- 17 + ((K.uc ((K.uc ((K.uc ((K.Tc (A[22889], A[21428])) == K.H[9] and A[8844] or K.H[4])))))) + A[22889]))
            A[27523] = (G)
        end
        return 3658, G
    else
        if not (G ~= 19) then
            K:N (N)
            return 10529, G
        end
    end
    return nil, G
end
function VM.Jv(K, A, G, N)
    G[38] = function()
        local Z, D
        Z, D = K:qv (G)
        if Z == - 2 then
            return D
        end
    end
    if not A[10454] then
        N = K:Gv (N, A)
    else
        N = A[10454]
    end
    return N
end
-- VM.Ac = bit32.bnot
function VM.jv(K, K, A, G, N)
    K[19][N + 1] = (G)
    A = (99)
    return A
end
function VM.B(K, A, G, N)
    A[24] = nil
    A[25] = (nil)
    G = 47
    repeat
        if G ~= 47 then
            A[25] = K.q
            break
        else
            G = K:f (A, N, G)
        end
    until false
    (A)[26] = function (K, N, Z, D) if not (Z > N) then else return; end; D = N - Z + 1; if D >= 8 then return K[Z], K[Z + 1], K[Z + 2], K[Z + 3], K[Z + 4], K[Z + 5], K[Z + 6], K[Z + 7], A[26] (K, N, Z + 8); elseif D >= 7 then return K[Z], K[Z + 1], K[Z + 2], K[Z + 3], K[Z + 4], K[Z + 5], K[Z + 6], A[26] (K, N, Z + 7); elseif D >= 6 then return K[Z], K[Z + 1], K[Z + 2], K[Z + 3], K[Z + 4], K[Z + 5], A[26] (K, N, Z + 6); elseif D >= 5 then return K[Z], K[Z + 1], K[Z + 2], K[Z + 3], K[Z + 4], A[26] (K, N, Z + 5); elseif D >= 4 then return K[Z], K[Z + 1], K[Z + 2], K[Z + 3], A[26] (K, N, Z + 4); elseif D >= 3 then return K[Z], K[Z + 1], K[Z + 2], A[26] (K, N, Z + 3); else if not (D >= 2) then return K[Z], A[26] (K, N, Z + 1); else return K[Z], K[Z + 1], A[26] (K, N, Z + 2); end; end; end
    (A)[27] = nil
    A[28] = nil
    return G
end
-- VM.Y = bit32.lshift
-- VM.K = bit32.bnot
function VM.Qv(K, A, G)
    A = 68 + (K.lc (((K.Dc (G[15243], G[2661], G[2970])) + G[13600] - G[3065] <= G[30130] and G[21428] or G[28007]) + G[17825], (G[17668])))
    (G)[15186] = (A)
    return A
end
function VM.S8(K, A, G, N)
    A[29][7] = (A[38])
    if not G[29820] then
        N = - 4 + (K.Tc ((K.Oc ((K.Tc (G[32411] <= G[10454] and G[12707] or G[28007])) + G[3690] - G[14464], (G[21329])))))
        (G)[29820] = N
    else
        N = K:B8 (N, G)
    end
    return N
end
-- VM.H = {13429, 1904633119, 2633408394, 4033588856, 87550808, 3740432320, 2797942273, 1711134000, 2851734942}
function VM.dv(K)
    return
end
function VM.y(K, A, G, N, Z)
    local D
    A = (121)
    while true do
        D, A = K:E (Z, A, G, N)
        if D == 10529 then
            break
        else
            if D == 3658 then
                continue
            end
        end
    end
    (G)[14] = (2147483648.0)
    (G)[15] = (nil)
    G[16] = nil
    (G)[17] = nil
    return A
end
function VM._c(K, A, G, N, Z, D, e)
    local M
    (G[29])[19] = (K.P.countrz)
    (G[29])[29] = K.Xc
    D = 108
    repeat
        if D < 108 then
            K:j8 (G)
            break
        else
            if not (not (D > 91)) then
                D = K:p8 (D, G, A)
            end
        end
    until false
    D = 94
    while true do
        if D == 37 then
            (G[29])[11] = N
            if not A[1338] then
                D = K:e8 (D, A)
            else
                D = (A[1338])
            end
        else
            if D == 31 then
                (G[29])[4] = G[36]
                G[29][14] = (G[44])
                break
            else
                if D == 94 then
                    D = K:d8 (G, D, A)
                    continue
                else
                    if D == 64 then
                        D = K:f8 (D, G, A)
                        continue
                    end
                end
            end
        end
    end
    D = (73)
    while true do
        if D < 73 then
            G[29][13] = K.u
            (G[29])[3] = K
            break
        else
            if not (not (D > 20)) then
                D = K:S8 (G, A, D)
                continue
            end
        end
    end
    D = (122)
    repeat
        M, D = K:Wc (G, e, D, A)
        if M == 2816 then
            continue
        else
            if M == 34533 then
                break
            end
        end
    until false
    return {G[52] (Z, G[15])}, D
end
function VM.Z8(K, A)
    if A[53] ~= A[30] then
        K:x8 (A)
    end
    (A[29])[22] = K.K
    (A[29])[24] = K.a
    if A[14] == A[39] then
        if not (not (A[40])) then
            return - 2, A[48]
        end
        while - (- 170) do
            (A)[15] = (122 * A[14])
        end
    end
    return nil
end
-- VM.O = "readi16"
function VM.G8(K, A, G, N)
    local Z
    if N <= 0 then
        (A)[25] = {}
        return 51441, G
    else
        if N > 29 then
            if A[46] == A[40] then
                Z = K:t8 (A)
                if not (Z ~= - 1) then
                    return - 1, G
                end
            end
            return 27723, G
        else
            G = K:q8 (G, A)
            return 51441, G
        end
    end
    return nil, G
end
function VM.X8(K, A)
    while true do
        K:r8 (A)
    end
end
function VM.e8(K, A, G)
    A = (- 13450 + (((K.Ac ((K.Hc ((K.nc (G[10716] >= G[8841] and K.H[8] or G[23406])))))) == A and G[7640] or G[31867]) + K.H[1]))
    (G)[1338] = (A)
    return A
end
function VM.B8(K, K, A)
    K = A[29820]
    return K
end
-- VM.T = bit32.bxor
function VM.qv(K, A)
    local G
    do
        G = K:tv (A, G)
        (A)[28] = (A[28] + 4)
        return - 2, G
    end
    return nil
end
function VM.o8(K, K)
    K = 22
    return K
end
function VM.kv(K, A, G, N, Z)
    if not (N > 14) then
        K:cv (G, A)
        return 27106, N
    else
        (G[20]) (Z, 0, F, G[28], A)
        N = 14
        return 15055, N
    end
    return nil, N
end
function VM.iv(K, A, G, N)
    G = 103
    while true do
        if G == 103 then
            (N)[44] = function () local Z, D, e, M = (51); while true do M, D, Z, e = K:vv (N, Z, M); if D == - 2 then return e; end; end; end
            if not A[27329] then
                G = - 8035399655 + ((K.Dc ((A[31215] == A[7640] and A[20959] or A[1656]) - A[8844] + A[14464], A[27523], A[20959])) + A[3280] + K.H[6])
                (A)[27329] = (G)
            else
                G = (A[27329])
            end
            continue
        elseif G == 49 then
            G = K:wv (A, G, N)
        elseif G == 26 then
            (N)[45] = function()
                local Z, D = 2
                while true do
                    if Z == 121 then
                        Z = 4
                        (N)[28] = (N[28] + 8)
                        continue
                    else
                        if Z == 2 then
                            Z = (121)
                            D = N[18] (F, N[28])
                        else
                            if not (Z ~= 4) then
                                return D
                            end
                        end
                    end
                end
            end
            N[46] = function(...)
                return (K:Fv (...))
            end
            if not A[17708] then
                G = K:Mv (G, A)
            else
                G = (A[17708])
            end
        else
            if not (G ~= 92) then
                (N)[48] = function()
                    local Z, D, e = (37)
                    while true do
                        if Z > 31 then
                            if Z ~= 64 then
                                D = N[41] ()
                                Z = 64
                            else
                                Z, e = K:bv (D, Z, e, N)
                            end
                        else
                            (N)[28] = (N[28] + D)
                            break
                        end
                    end
                    return e
                end
                N[49] = function()
                    local Z, D
                    for e = 52, 472, 101 do
                        if e == 153 then
                            D = N[3] (Z)
                            continue
                        else
                            if e == 254 then
                                if N[29] ~= N[36] then
                                    K:ov (Z, N, D)
                                end
                            else
                                if e == 52 then
                                    Z = N[41] ()
                                    continue
                                else
                                    if e ~= 355 then
                                    else
                                        return D
                                    end
                                end
                            end
                        end
                    end
                end
                break
            end
        end
    end
    (N)[50] = nil
    N[51] = (nil)
    G = 57
    while true do
        if G < 68 then
            N[50] = (setfenv)
            if not (not A[15186]) then
                G = A[15186]
            else
                G = K:Qv (G, A)
            end
        else
            if not (not (G > 57)) then
                (N)[51] = function (...) local A = N[17] ("#", ...); if A ~= 0 then else return A, N[5]; end; return A, {...}; end
                break
            end
        end
    end
    N[52] = function()
        local D, e, M, s, k, x, f, z, c = A[4], A[3], A[1], A[8], A[6], A[2], A[11], (A[9])
        c = function (...) local B, u, p, V, S, m, U, l, w, X, a, P, j, E, b, W = 1, N[21] (D), 0, 1, (N[34] ()); local D, C, q, r, d, Y, I, h, L = 1; while true do local o = z[B]; if not (o < 88) then if o >= 132 then if o < 154 then if not (o >= 143) then if not (o < 137) then if not (o >= 140) then if o < 138 then u[x[B]] = u[f[B]]; else if o == 139 then P = P[h]; else u[f[B]] = f; end; end; else if o >= 141 then if o ~= 142 then if N[44] == N[22] then (N)[45], N[27] = N[46], N[36]; end; P = M[B]; h = P[5]; P = #h; I = P > 0 and {}; if not (I) then else for t = 1, P do b = (h[t]); l = (b[1]); d = b[3]; if l == 0 then (I)[t - 1] = (Z[d]); else if l == 1 then I[t - 1] = (u[d]); else if l ~= 2 then else if N[49] == N[30] then if not (- N[51]) then else N[51] = (N[43]); end; else if not r then r = {}; end; end; b = r[d]; if not (not b) then else b = ({[3] = d, [1] = u}); (r)[d] = (b); end; (I)[t - 1] = b; end; end; end; end; end; h = K[e[B]] (I); (N[50]) (h, S); u[s[B]] = h; else P = k[B]; h = P[5]; I = #h; b = I > 0 and {}; l = N[52] (P, b); (N[50]) (l, S); u[f[B]] = l; if N[44] == N[30] then return - (186 * 199); else if b then for K = 1, I do l = (h[K]); P = l[1]; d = l[3]; if P == 0 then if N[47] == N[5] then else b[K - 1] = Z[d]; end; else if P == 1 then (b)[K - 1] = u[d]; else if P ~= 2 then else if not (not r) then else r = {}; end; X = r[d]; if not X then X = ({[1] = u, [3] = d}); (r)[d] = X; end; b[K - 1] = (X); end; end; end; end; end; end; end; else h = h[I]; I = (P); end; end; else if not (o < 134) then if not (o < 135) then if o ~= 136 then h = P; I = (1); else (u)[f[B]] = u[s[B]] + e[B]; end; else u[f[B]] = (Z[s[B]][e[B]]); end; else if o ~= 133 then if N[40] == N[46] then else P = s[B]; h, I, b = L (); if N[15] == N[44] then (N)[47] = - (- 220); return N[40]; else if N[40] == N[47] then return; else if not (h) then else u[P + 1] = (I); (u)[P + 2] = (b); B = (f[B]); end; end; end; end; else u[s[B]] = u[f[B]] > u[x[B]]; end; end; end; else if not (o >= 148) then if not (o >= 145) then if o ~= 144 then P = (3); I = (I[P]); else P = (u); h = (f[B]); end; else if not (o < 146) then if N[15] == N[43] then N[51] = (N[38]); (N)[47] = (- N[14]); elseif N[43] == N[1] then return; else if o == 147 then if N[47] ~= N[15] then else return; end; p = x[B]; w, q = N[51] (...); for K = 1, p, 1 do u[K] = (q[K]); end; V = (p + 1); else P = (x[B]); u[P] = u[P] (u[P + 1], u[P + 2]); D = (P); end; end; else if u[x[B]] then B = s[B]; end; end; end; else if o >= 151 then if N[40] ~= N[39] then else return; end; if o < 152 then local K = (x[B]); if not (r) then else for t, n in r do if not (t >= K) then else n[1] = (n); n[2] = u[t]; n[3] = (2); (r)[t] = (nil); end; end; end; elseif o ~= 153 then (u[f[B]])[k[B]] = (u[x[B]]); else (u)[f[B]] = u[s[B]] - u[x[B]]; end; else if o < 149 then if N[47] == N[15] then if not (107) then else N[35], N[15] = N[1], (N[49]); N[15] = 53; end; repeat c = (89); until false; end; I = I (b); (P)[h] = (I); else if o ~= 150 then P = (Z); h = (s[B]); P = P[h]; else P = (x[B]); u[P] (u[P + 1]); D = (P - 1); end; end; end; end; end; else if not (o < 165) then if not (o < 171) then if not (o >= 174) then if N[1] == N[47] then return N[5]; elseif N[43] == N[40] then while N[40] do return 217 and 96; end; else if not (o < 172) then if o ~= 173 then u[s[B]] = ({}); else if N[46] ~= N[1] then h = (h[I]); I = P; end; P = (3); end; else (u)[x[B]] = N[28]; end; end; else if N[14] == N[37] then while N[29] ~= N[48] do (N)[26] = 139 ^ 175 or 141; (N)[48], N[30] = N[46], (N[47]); end; else if o < 175 then if not (not u[x[B]]) then else B = (f[B]); end; else if o ~= 176 then (u)[x[B]] = (k[B]); else if c == N[46] then else P = f[B]; D = P + x[B] - 1; end; u[P] = u[P] (N[27] (u, D, P + 1)); D = P; end; end; end; end; else if o < 168 then if not (o >= 166) then if c ~= N[43] then b = (s[B]); end; I = I[b]; b = M[B]; else if o == 167 then P = Z; h = (x[B]); P = P[h]; else if N[40] ~= N[47] then else return N[43]; end; P = (s[B]); h = f[B]; I = u[P]; N[33] (u, P + 1, D, h + 1, I); end; end; else if N[37] ~= c then else (N)[29], N[1] = - 192 + N[43], (N[26] and N[39]); while N[27] do return - 252; end; end; if o >= 169 then if N[38] == N[30] then N[47], N[43] = 8, N[51]; elseif N[27] == N[14] then while - (- 114) do return; end; else if o == 170 then u[x[B]] = #u[f[B]]; else if N[36] == N[29] then if not (232) then else return N[29]; end; end; if N[27] == N[22] then return; end; P = (x[B]); h = u[f[B]]; u[P + 1] = h; (u)[P] = h[k[B]]; end; end; else I = I[b]; b = u; end; end; end; else if N[5] == N[32] then if not (- 139 + 59 % 111) then else (N)[1], N[43] = 228, - (78 < 110); end; if not (c) then else N[44] = (52 <= 131) - N[39]; N[44] = - N[51]; end; end; if o < 159 then if not (o < 156) then if o < 157 then P = (x[B]); (u)[P] = u[P] (N[27] (u, D, P + 1)); D = (P); else if o == 158 then u[s[B]] = (F); else D = (f[B]); (u)[D] = u[D] (); end; end; else if o ~= 155 then if N[36] ~= N[1] then I = I[P]; end; P = (u); else b = b[l]; I = (I[b]); P[h] = I; end; end; else if o >= 162 then if N[40] ~= N[27] then else while N[14] do (N)[48], N[40] = N[14] * 86, (N[22] + N[29]); end; end; if not (o < 163) then if o ~= 164 then (u)[s[B]] = (M[B] ^ u[x[B]]); else if u[f[B]] == u[x[B]] then B = (s[B]); end; end; else h = (h[I]); I = (P); end; else if o < 160 then h = f[B]; I = (nil); else if o == 161 then if N[46] == N[1] then else u[f[B]] = (u[x[B]][u[s[B]]]); end; else P = ({...}); for K = 1, f[B], 1 do u[K] = P[K]; end; end; end; end; end; end; end; else if o >= 110 then if not (o >= 121) then if N[5] == N[46] then if not (- (91 > 145)) then else return; end; else if N[51] == N[5] then return; else if o < 115 then if N[15] == N[14] then if N[38] then return N[35]; end; while N[44] do N[51], N[40] = N[47], N[43]; end; else if N[36] == c then N[49] = (95); if not (N[35]) then else (N)[39] = N[15] >= N[49]; N[26] = (N[41]); end; elseif o >= 112 then if not (o < 113) then if o == 114 then P[h] = (I); else if N[5] ~= N[30] then P = (Z[x[B]]); P[1][P[3]] = u[f[B]]; end; end; else u[s[B]] = u[f[B]] == e[B]; end; else if N[45] == c then else if o ~= 111 then (u)[f[B]] = (k[B] + u[x[B]]); else (u)[x[B]] = (u[f[B]] ~= k[B]); end; end; end; end; else if not (o >= 118) then if o < 116 then u[f[B]] = x; else if o == 117 then if N[37] == N[5] then (N)[39], N[38] = 216, N[35]; end; if N[14] ~= N[43] then j = ({[3] = L, [1] = j, [2] = Y, [5] = W}); D = x[B]; P = N[24] (function (...) (N[6]) (); for K, t, n in ... do (N[6]) (true, K, t); end; end); P (u[D], u[D + 1], u[D + 2]); L = (P); B = (f[B]); end; else (u)[s[B]] = N[21] (x[B]); end; end; else if o >= 119 then if o == 120 then if N[47] ~= N[22] then (u)[f[B]] = nil; end; else (u)[f[B]] = (u[x[B]] - k[B]); end; else u[s[B]] = (u[f[B]] ~= u[x[B]]); end; end; end; end; end; else if not (o >= 126) then if not (o >= 123) then if o == 122 then P = (x[B]); h = f[B]; I = s[B]; if h == 0 then else D = P + h - 1; end; b, l = nil; if h ~= 1 then b, l = N[51] (u[P] (N[27] (u, D, P + 1))); else b, l = N[51] (u[P] ()); end; if I == 1 then D = P - 1; else if I == 0 then if N[40] ~= N[29] then else return; end; b = (b + P - 1); D = (b); else b = (P + I - 2); D = (b + 1); end; h = (0); for K = P, b, 1 do h += 1; (u)[K] = l[h]; end; end; else u[x[B]] = u[s[B]] * u[f[B]]; end; else if not (o < 124) then if o ~= 125 then for K = x[B], s[B] do (u)[K] = nil; end; else (u)[x[B]] = (N[13] (u[f[B]], k[B])); end; else u[s[B]] = u[x[B]] == u[f[B]]; end; end; else if o >= 129 then if N[30] == N[35] then (N)[32] = (- N[43]); if N[37] then (N)[46] = (N[27]); end; elseif N[26] == N[29] then return N[15]; else if not (o >= 130) then u[s[B]] = (M[B] * u[x[B]]); else if o ~= 131 then P = (P[h]); h = (P); else u[x[B]] = u[f[B]] <= u[s[B]]; end; end; end; else if not (o >= 127) then P = (u); h = (s[B]); else if o == 128 then if N[1] == N[41] then (N)[22] = (N[27]); if 91 >= (209 <= 206) then return N[26] ~= N[15]; end; end; u[s[B]] = A; else P[h] = (I); end; end; end; end; end; else if o < 99 then if N[45] ~= N[14] then else return N[49]; end; if not (o >= 93) then if o < 90 then if o ~= 89 then if N[44] == N[22] then else I = (I[b]); b = u; l = x[B]; end; else if not (u[x[B]] <= u[f[B]]) then B = (s[B]); end; end; else if not (o < 91) then if o ~= 92 then h = (u); I = x[B]; else if c ~= N[15] then L = j[3]; Y = (j[2]); end; W = (j[5]); j = (j[1]); end; else if N[36] == c then repeat N[35] = (- N[47]); N[46], N[14] = N[43], (N[40] * N[29]); until false; if - 193 + (4 < 185) then return N[39]; end; else if u[s[B]] ~= u[x[B]] then B = f[B]; end; end; end; end; else if o >= 96 then if not (o >= 97) then if N[36] == N[14] then else (u)[x[B]] = (- u[s[B]]); end; else if o ~= 98 then P = false; L += W; if W <= 0 then P = (L >= Y); else P = (L <= Y); end; if N[26] == N[14] then (N)[27], N[49] = N[32], N[35]; N[37], N[49] = N[43], (100 ^ N[5]); elseif P then (u)[x[B] + 3] = (L); B = s[B]; end; else if not (u[x[B]] < u[f[B]]) then B = s[B]; end; end; end; elseif o < 94 then u[f[B]] = (N[13] (u[x[B]], u[s[B]])); else if N[5] == c then (N)[29] = N[45]; N[45], N[27] = N[47], N[29]; end; if o == 95 then u[f[B]] = u[s[B]] + u[x[B]]; else u[s[B]] = (Z[x[B]]); end; end; end; else if not (o < 104) then if o >= 107 then if not (o < 108) then if N[38] == N[5] then while N[22] do N[49] = (N[35]); (N)[15] = N[48]; end; else if o == 109 then b = b[l]; else h = (x[B]); end; end; else if not (not (u[f[B]] < k[B])) then else B = x[B]; end; end; else if not (o < 105) then if N[51] == N[30] then if N[37] then return - N[45]; end; end; if o == 106 then if N[51] ~= N[1] then else if N[46] then N[27] = (N[46]); end; end; P = Z; h = f[B]; P = P[h]; else (u)[f[B]] = (u[s[B]] % u[x[B]]); end; else w, q = N[51] (...); end; end; else if o >= 101 then if o < 102 then if N[39] ~= N[29] then else return N[41] + N[14]; end; I = I[b]; else if N[38] ~= N[1] then if o ~= 103 then l = P; P = 3; l = (l[P]); else P = s[B]; (u[P]) (N[27] (u, D, P + 1)); D = (P - 1); end; end; end; else if N[39] == N[40] then while N[47] do N[29] = (- N[39]); (N)[37], N[36] = - (- 18), N[45]; end; end; if o == 100 then h[I] = (P); else if N[49] ~= N[40] then else (N)[1], N[15] = N[49], (- 165); if N[51] / N[44] then N[15] = 156; end; end; P = - 4294966676.0; h = 0; I = 4503599627370495; b = (nil); l = 121; while true do if l < 121 then b = 24; break; else if not (l > 4) then else h *= I; I = (N[29]); l = - 238 + (((N[29][21] (((N[29][25] (l, o, o)) >= o and o or o) - l, (19))) == l and l or l) + l); end; end; end; I = (I[b]); d = nil; X = (nil); l = (106); repeat if N[49] == N[1] then N[29], N[36] = N[35], (- 128) ^ 26; while N[30] do N[5], N[35] = 96, (104); end; elseif N[15] == N[44] then while N[35] do N[44] = (N[29]); c, N[27] = N[45], (N[48]); end; else if l == 106 then b = (N[29]); l = - 34 + ((N[29][21] ((N[29][21] (((N[29][22] (l)) <= l and o or l) + o, (12))), (21))) + o); else if l == 65 then d = 22; l = (- 327636 + (N[29][21] ((N[29][27] ((N[29][23] (o, (N[29][29] ("<i8", "\x0b\x00\x00\x00\x00\x00\x00\x00")))) - o - o, (28))) + o, (13)))); continue; elseif l == 62 then X = z[B]; break; elseif l == 44 then b = b[d]; l = (43 + ((N[29][20] ((N[29][19] ((N[29][23] (o - o <= l and o or l, (20))))))) - l)); continue; else if l == 27 then if N[49] ~= N[14] then else N[29] = (N[37]); return; end; if N[35] ~= N[22] then d = o; l = (- 10 + ((N[29][19] ((N[29][22] ((N[29][20] (l - o)))))) + o - l)); continue; end; end; end; end; end; until false; d += X; X = z[B]; d += X; X = (z[B]); l = 123; while true do if l == 95 then d = z[B]; break; elseif l == 30 then b = b (d); l = (69 + (N[29][19] ((N[29][24] ((N[29][21] ((N[29][26] (o >= o and l or o, o)) < l and l or o, (l)))))))); else if l == 123 then d -= X; l = - 93 + (N[29][24] ((N[29][21] ((N[29][19] (o)) + o, (31))) - o + o, l)); continue; else if l == 0 then b -= d; d = o; b -= d; l = (- 4 + (N[29][25] ((N[29][26] ((N[29][23] (l, (l))) + l)) + l + o, l))); continue; else if l == 101 then d = o; l = - 4294942108 + ((N[29][28] (o - o - l - o + l, (8))) - o); end; end; end; end; end; l = (116); repeat if l > 109 then if N[40] ~= N[44] then X = o; l = (67 + (N[29][19] (((N[29][24] ((N[29][23] ((N[29][25] (o, o, o)), (14))), o, l)) == l and o or o) + l))); continue; end; elseif l < 116 and l > 70 then I -= b; break; else if l > 67 and l < 109 then if N[43] == c then while N[51] do N[30], N[45] = 45, (72); return N[22]; end; N[48], N[30] = - 47, (- N[40]); end; b = (o); l = (- 22 + ((N[29][20] ((N[29][25] ((N[29][25] ((N[29][19] (o)) <= o and o or o, l)), l, o)))) + o)); else if not (l < 70) then else I = I (b, d, X); l = 65 + (N[29][20] ((N[29][23] ((N[29][26] (o, o)), (12))) + o - o - l)); end; end; end; until false; h += I; P += h; l = 76; repeat if l > 76 then if N[35] == N[15] then else h = (s[B]); end; l = - 300941275 + (N[29][27] (((N[29][28] ((N[29][19] (l)), (25))) <= l and o or o) + l + l, (20))); continue; elseif l < 59 then for K = P, h, 1 do if N[41] == N[5] then else for A = 36, 304, 73 do if A <= 36 then b = (u); else if A ~= 109 then X = nil; break; else d = K; continue; end; end; end; end; (b)[d] = X; end; break; else if l < 94 and l > 59 then (z)[B] = (P); l = (59 + (N[29][21] ((N[29][19] (((N[29][23] (o, (2))) > l and l or o) - l - l)), (14)))); else if l > 37 and l < 76 then P = (x[B]); l = - 4194308 + ((N[29][21] ((N[29][22] (o - l + l - l)), (N[29][29] (">i8", "\x00\x00\x00\x00\x00\x00\x00\x0a")))) + o); continue; end; end; end; until false; end; end; end; end; end; end; else if N[27] == N[15] then if B then (N)[44], N[36] = N[49], (N[43]); end; if 76 then (N)[39], N[51] = - (227 - 39), N[5]; end; end; if not (o >= 44) then if not (o >= 22) then if not (o < 11) then if o >= 16 then if o < 19 then if not (o >= 17) then P = x[B]; h = s[B]; else if N[15] == N[14] then elseif o == 18 then I = (u); b = (x[B]); I = I[b]; else P = Z; end; end; else if o < 20 then u[s[B]][e[B]] = (M[B]); else if o == 21 then if c == N[22] then N[46] = 172; while N[47] do return (44 or 164) - U; end; end; if N[43] ~= N[5] then P = (nil); h = nil; I = 71; end; while true do if I <= 17 then P = (P[h]); break; else if I ~= 71 then h = (s[B]); I = 17 + (N[29][26] ((N[29][20] ((N[29][19] (I)) + o - o - o)), I)); continue; else P = Z; I = (106 + ((N[29][24] ((N[29][24] ((N[29][26] (I - I + I)), o, I)))) - I)); continue; end; end; end; if N[44] == N[15] then else h = - 44040170.0; b = (nil); l = (nil); d = (nil); end; I = 81; if N[26] ~= N[22] then else while true do return N[14]; end; end; while true do if I == 81 then b = 0; I = - 4200595332 + (N[29][27] ((N[29][24] ((N[29][22] (I - o)), I)) - o + o, (o))); elseif I == 14 then if N[26] ~= c then else N[38], N[40] = N[38], (13); return N[47] * N[49]; end; if N[38] == N[5] then return; end; l = N[29]; d = (28); l = l[d]; break; else if I == 124 then l = (4503599627370495); I = - 48 + (N[29][22] ((N[29][20] ((N[29][26] ((N[29][19] ((N[29][20] (I)))), o)))) - I)); continue; else if I == 43 then b *= l; I = (- 4294967280 + ((N[29][22] ((N[29][25] (I - o, o, o)))) + I - I + o)); end; end; end; end; if N[30] == N[35] then else d = N[29]; X = 25; C = nil; I = (52); repeat if I == 3 then if N[5] == c then return; end; X = N[29]; C = (26); break; else if I == 52 then d = (d[X]); I = 3 + (N[29][19] ((N[29][25] ((N[29][22] ((N[29][19] ((N[29][28] (o, (o))))) - o)))))); continue; end; end; until false; end; X = X[C]; a = (nil); U = (nil); I = 116; repeat if N[29] == N[43] then elseif I == 104 then U = 24; break; elseif I == 70 then C = C[a]; I = 88 + (((N[29][19] ((N[29][22] (I + o)))) < o and o or I) - o + o); continue; else if I == 67 then a = (25); I = 28 + (((N[29][24] ((N[29][24] (o - I, o)) + I)) <= o and I or o) + o); else if I == 116 then C = N[29]; I = (- 28 + ((N[29][26] (o + I)) - o - o + o - o)); continue; else if I == 109 then a = (N[29]); I = (104 + (((N[29][28] ((N[29][19] ((N[29][19] (o)))), (o))) - o <= o and o or I) - I)); continue; end; end; end; end; until false; m = nil; E = nil; I = (23); while true do if I <= 23 then if not (I >= 23) then U = (o); I = (76 + ((N[29][23] ((N[29][22] ((N[29][27] ((N[29][20] (o)) - o, (I))))), (o))) == o and I or o)); else a = a[U]; I = 27 + ((N[29][20] ((N[29][27] ((N[29][19] (o + o)) + o, (o))))) - I); end; elseif I > 76 then m = o; I = - 4294967198 + ((N[29][22] ((N[29][19] ((N[29][22] ((I ~= o and o or I) + o)))))) - o); else E = (z[B]); break; end; end; a = a (U, m, E); I = (109); repeat if I == 109 then if N[43] == N[30] then else C = C (a); end; I = (- 42925 + (N[29][24] ((N[29][23] ((N[29][26] (I == o and o or o, o, o)) + I - I, (o))), o, o))); continue; else if I == 104 then X = X (C); break; end; end; until false; C = (z[B]); I = 89; repeat if N[26] == N[14] then elseif I == 100 then C = (z[B]); break; else X -= C; I = (- 94108 + (N[29][23] ((N[29][20] (I - o)) + o - I + I, (o)))); continue; end; until false; d = d (X, C); I = 120; repeat if I <= 65 then if N[37] ~= N[15] then else return 80; end; if not (I >= 65) then X = z[B]; break; else if N[5] ~= N[51] then d -= X; end; I = - 174080 + ((N[29][23] ((N[29][24] (I, I, o)) - o + o, (o))) - o + I); end; else if N[35] ~= N[29] then else (N)[47], N[47] = c ~= - 77, (N[44]); while N[22] do return; end; end; if not (I > 106) then X = (z[B]); I = - 11326 + (N[29][24] ((N[29][28] ((N[29][28] ((N[29][20] ((N[29][21] (o, (o))))) - o, (o))), (o))), o, I)); continue; else if I ~= 120 then d += X; I = 78 + (N[29][20] ((N[29][20] ((N[29][23] ((N[29][26] (I + o, o)) + I, (o))))))); continue; else X = (z[B]); I = 119 + (((N[29][25] ((N[29][21] ((N[29][21] (o, (o))), (o))) + I)) <= I and I or I) - I); continue; end; end; end; until false; I = (28); while true do if I < 75 and I > 28 then (z)[B] = (h); break; else if I < 46 then l = l (d, X); b += l; I = (41 + ((N[29][22] ((N[29][24] (o, o)) - I - I)) - o + o)); else if I > 46 then h += b; I = (52 + ((N[29][20] (o - I == I and I or o)) + o - I + o)); end; end; end; end; I = 18; while true do if c == N[26] then (N)[38], N[51] = N[37], 50 > - 52; (N)[46], N[51] = - N[44], (83); end; if I > 99 then l = l[d]; break; elseif I > 18 and I < 73 then l = (P); I = (59 + (((N[29][25] ((N[29][21] ((N[29][26] (I, o)), (I))) + o, I, I)) ~= I and I or I) + I)); continue; else if I > 73 and I < 102 then d = 1; I = - 4294967166 + ((N[29][22] ((N[29][20] (o)) - o)) + o - o - o); continue; else if I > 20 and I < 99 then b = (x[B]); I = (- 4139777934 + ((N[29][27] ((N[29][22] (I - o + o)), (o))) - I - o)); continue; else if I < 20 then h = (u); I = 11 + (N[29][24] (((N[29][27] (o, (I))) - o > I and o or I) + I + o, I)); end; end; end; end; end; I = (10); while true do if I > 76 then d = (d[X]); I = - 4091543454 + (N[29][25] ((N[29][22] ((N[29][28] (I - I + I, (o))))) - o)); elseif I < 97 and I > 10 then if N[41] == N[29] then else l = (l[d]); end; break; else if not (I < 76) then else d = (P); X = 3; I = (97 + (N[29][21] ((N[29][27] ((N[29][25] (I)) + o, (I))) + I < o and o or o, (o)))); continue; end; end; end; h[b] = (l); else Z[x[B]][M[B]] = u[s[B]]; end; end; end; else if o < 13 then if N[38] == N[30] then while 205 do return N[45] % N[29]; end; while 171 and N[35] do N[29], N[46] = N[36], 202; N[5], N[27] = N[44], - N[36]; end; elseif o == 12 then if r then for K, A in r do if not (K >= 1) then else A[1] = (A); A[2] = (u[K]); (A)[3] = 2; r[K] = nil; end; end; end; P = x[B]; return u[P] (u[P + 1]); else b = (s[B]); I = (I[b]); b = (e[B]); end; elseif c == N[36] then N[47] = N[48]; elseif N[48] == N[40] then N[29] = N[26] - N[43]; return; elseif o < 14 then if r then for K, A, t in r do if not (K >= 1) then else (A)[1] = A; (A)[2] = (u[K]); A[3] = 2; (r)[K] = (nil); end; end; end; return; else if N[37] ~= N[14] then else (N)[49], N[48] = N[48], - 40 and 160 ~= 131; N[45] = (- N[39]); end; if o == 15 then (u)[x[B]] = not u[s[B]]; else h = (x[B]); I = u; end; end; end; else if o < 5 then if o >= 2 then if N[47] == N[5] then N[49] = (c); while true do (N)[15] = (N[37]); N[41] = - (56 <= 85); end; else if not (o >= 3) then I *= b; P[h] = (I); else if o ~= 4 then if N[27] == N[1] then while N[46] do return; end; while true do return; end; end; P = u; h = f[B]; I = (u); else u[x[B]][u[f[B]]] = k[B]; end; end; end; else if o ~= 1 then b = x[B]; else I = u; b = s[B]; end; end; else if N[44] == N[1] then while a do (N)[49], c = m, N[35]; (N)[41], N[45] = 62 < 206 > N[51], (190); end; else if o < 8 then if o >= 6 then if o ~= 7 then if N[38] ~= N[29] then (u)[s[B]] = u[x[B]] / / u[f[B]]; end; else if N[26] ~= N[40] then b = (x[B]); I = (I[b]); (P)[h] = (I); end; end; else u[f[B]] = N[29][s[B]]; end; else if not (o < 9) then if N[51] ~= N[14] then if o ~= 10 then P = (nil); h = (nil); I = (nil); b = nil; l = nil; d = 7; repeat if N[26] == N[22] then N[46], N[32] = N[15], 188; while 81 do N[46] = N[35]; end; elseif N[47] == N[29] then (N)[48], N[36] = N[48], (- (- 99)); elseif d <= 43 then if d <= 7 then if N[30] == N[45] then if not (- (92 or 41)) then else (N)[47], N[32] = N[45], N[48]; N[49], N[47] = - N[45], c; end; end; P = 163; h = (0); d = 44 + (((N[29][21] (d + x[B] + x[B], x[B])) - d >= d and x[B] or d) + d); continue; else if d ~= 14 then I = I[b]; b = N[29]; l = (20); d = - 29 + ((N[29][22] (d)) + f[B] + d + d - x[B] > d and d or d); else b = (b[l]); break; end; end; else if not (d > 58) then I = (4503599627370495); h *= I; d = 78 + (N[29][21] (o - o + x[B] - x[B] + d + f[B], f[B])); continue; else if d >= 124 then b = (19); d = (43 + (N[29][20] ((N[29][21] (x[B] + d + f[B] + d, f[B])) - d))); else I = N[29]; d = (- 38 + (((((N[29][21] (f[B], (o))) <= d and o or d) >= o and x[B] or d) - d >= f[B] and o or d) + d)); continue; end; end; end; until false; X = nil; d = 91; while true do if N[5] == N[26] then elseif d < 63 then if not (not l) then else l = (x[B]); end; X = (o); break; elseif d > 96 then X = x[B]; d = - 4026531891 + ((N[29][23] ((N[29][19] (x[B] <= d and x[B] or d)) ~= d and d or o, x[B])) + d - o); elseif d > 91 and d < 126 then if N[32] == N[29] then while N[38] % 214 do return; end; end; l = l ~= X; d = (59 + ((N[29][20] ((N[29][24] (f[B] - x[B] + o, d, x[B])))) + x[B] >= d and d or f[B])); continue; elseif d < 69 and d > 18 then if l then l = (x[B]); end; d = (27 + ((N[29][21] ((f[B] < d and d or d) + x[B] + x[B] <= d and d or x[B], x[B])) - o)); elseif d > 69 and d < 96 then if N[29] == N[30] then else l = (o); d = (31 + ((N[29][21] ((N[29][25] ((N[29][21] (f[B], f[B])) - o, x[B])) + d, f[B])) + d)); end; continue; elseif d > 63 and d < 91 then if N[27] == N[29] then return N[32]; end; l -= X; X = z[B]; d = 88 + (N[29][26] (((N[29][27] (d + d + d, x[B])) < x[B] and d or d) + x[B], o)); continue; end; end; l -= X; d = (95); repeat if d == 95 then X = (o); l += X; b = b (l); d = 46 + (((N[29][23] ((N[29][20] (f[B])), f[B])) >= o and d or d) - f[B] - f[B] > d and o or f[B]); else if d == 50 then l = x[B]; b += l; d = (105 + (N[29][27] ((N[29][24] ((N[29][23] (d, x[B])) + d ~= x[B] and d or x[B])) - d, x[B]))); else if d ~= 105 then else l = f[B]; break; end; end; end; until false; d = (44); repeat if N[40] ~= N[41] then if not (d >= 44) then I = I (b); break; else b -= l; d = 18 + ((N[29][24] ((N[29][21] ((N[29][26] ((N[29][25] (o, d)), f[B], d)) + d, (o))))) + o); continue; end; end; until false; h += I; d = (95); repeat if d == 95 then P += h; d = - 877 + ((N[29][28] ((N[29][20] ((N[29][25] (o + d - x[B], o, d)))), x[B])) + d); continue; elseif d == 50 then (z)[B] = (P); d = (55 + (((N[29][20] ((N[29][22] (d)) == f[B] and f[B] or x[B])) + d >= f[B] and x[B] or d) >= o and f[B] or d)); else if d ~= 105 then else P = (u); break; end; end; until false; d = 71; while true do if d > 71 then if N[46] ~= N[14] then h = (u); end; d = (12 + (N[29][19] ((N[29][19] ((N[29][20] ((d < f[B] and o or d) - d - x[B]))))))); continue; elseif d < 122 and d > 17 then h = (f[B]); P = (P[h]); d = 122 + ((N[29][24] (((N[29][24] (d, d)) - d > d and d or f[B]) > f[B] and d or f[B], d, x[B])) - d); else if not (d < 71) then else I = (x[B]); break; end; end; end; h = (h[I]); d = (42); repeat if N[30] == N[47] then while N[40] do return; end; else if N[44] == N[5] then return; else if d == 1 then if not (P) then else for K = 2, 127, 24 do if K < 26 then P = s[B]; else if not (K > 2) then else B = P; break; end; end; end; end; break; else P = P == h; d = - 36 + ((N[29][20] ((N[29][20] (d)) - x[B] <= f[B] and d or f[B])) + f[B] + f[B]); end; end; end; until false; else (u[f[B]])[u[x[B]]] = (u[s[B]]); end; end; else b = f[B]; P = P[b]; end; end; end; end; end; else if o >= 33 then if not (o >= 38) then if not (o >= 35) then if o ~= 34 then u[s[B]] = (N[7] (u[x[B]], M[B])); else u[x[B]] = (u[s[B]] / / M[B]); end; else if not (o < 36) then if o == 37 then if N[46] ~= N[29] then else while N[49] do return; end; if N[1] then return N[36] and 154; end; end; h = (k[B]); I = u; else if u[x[B]] == M[B] then B = s[B]; end; end; else (u)[f[B]] = S[k[B]]; end; end; else if not (o < 41) then if N[37] == c then return N[46]; end; if not (o >= 42) then if N[38] ~= N[29] then P = (x[B]); h = (w - p - 1); end; if not (h < 0) then else h = - 1; end; I = (0); for K = P, P + h, 1 do u[K] = (q[V + I]); I += 1; end; D = P + h; else if o == 43 then for K = P, h, 1 do I = u; if N[30] ~= N[37] then b = (K); K = nil; end; I[b] = K; end; else I = M[B]; P[h] = (I); end; end; else if not (o < 39) then if o == 40 then b = e[B]; I += b; else P = (u); h = x[B]; end; else P = (f[B]); D = (P + s[B] - 1); (u[P]) (N[27] (u, D, P + 1)); D = P - 1; end; end; end; else if o < 27 then if o >= 24 then if N[32] == N[15] then N[15] = N[36] / N[47]; else if o < 25 then P = (u); h = f[B]; else if o == 26 then I = u; else (u)[x[B]] = (s); end; end; end; else if o == 23 then h = s[B]; P = (P[h]); h = e[B]; else P = (Z[s[B]]); (u)[x[B]] = (P[1][P[3]]); end; end; else if not (o < 30) then if N[35] == N[1] then N[39] = - 94; while N[39] do return N[22] == N[37]; end; end; if not (o < 31) then if o == 32 then if u[x[B]] == M[B] then else B = (s[B]); end; else if N[48] ~= N[30] then b = (b[l]); end; (h)[I] = (b); end; else h = f[B]; I = u; b = s[B]; end; else if o >= 28 then if o == 29 then if N[36] == N[22] then return - 100; end; u[f[B]] = u[x[B]] .. u[s[B]]; else j = {[3] = L, [1] = j, [2] = Y, [5] = W}; P = s[B]; W = u[P + 2] + 0; Y = (u[P + 1] + 0); L = u[P] - W; B = (f[B]); end; else P = f[B]; (u)[P] = u[P] (u[P + 1]); D = (P); end; end; end; end; end; else if not (o >= 66) then if not (o >= 55) then if not (o >= 49) then if not (o >= 46) then if o ~= 45 then u[f[B]] = (z); else I = 1; end; else if N[40] ~= N[49] then else return; end; if not (o >= 47) then if N[27] ~= N[30] then P = (nil); h = (nil); end; I = (nil); if N[27] ~= N[40] then else while N[35] do return - 125 + (92 ~= 246); end; return; end; b = 77; repeat if not (b <= 58) then if b ~= 72 then P = 37; b = 26 + ((N[29][24] ((N[29][23] (b + b, (3))) - o, o)) + b >= o and o or b); continue; else h = (0); b = (- 4294967334 + ((N[29][22] ((N[29][20] ((N[29][26] (b - b)) - o)))) + o)); end; else if N[51] == N[14] then return; else if b ~= 7 then h *= I; break; else I = 4503599627370495; b = 51 + ((N[29][19] ((N[29][19] (o + o ~= b and b or o)) ~= o and b or o)) + b); end; end; end; until false; I = N[29]; l = (21); if N[43] == c then else d = nil; end; b = (58); while true do if b > 58 then l = (N[29]); d = 26; break; else if N[35] == N[1] then if not (235) then else return; end; while N[46] or 65 do N[44], N[35] = N[39], (N[30]); end; end; I = (I[l]); b = 69 + ((N[29][24] ((N[29][25] ((N[29][25] (b, b, o)) - o + o, o)), b, b)) - o); continue; end; end; l = (l[d]); X = nil; b = 12; repeat if b > 12 then if N[44] == N[30] then (N)[15], N[48] = - N[37], (N[27]); end; d = d[X]; break; else if not (b < 123) then else d = (N[29]); X = (28); b = 122 + (N[29][19] ((N[29][27] ((N[29][21] (b, (b))), (b))) - o + b == o and o or o)); end; end; until false; X = (o); C = (z[B]); b = 88; while true do if N[22] ~= N[26] then if b == 88 then X -= C; b = - 1 + (N[29][24] ((N[29][20] (b - b + b)) + o >= b and o or b)); continue; elseif b == 33 then if c ~= N[14] then X = (z[B]); end; b = 11 + (N[29][19] (((N[29][19] ((N[29][27] (o, (21))))) >= o and o or o) - o >= o and o or o)); continue; elseif b == 123 then X = o; b = 30 + (N[29][21] ((N[29][22] ((N[29][19] ((N[29][24] (b - o, b)))) - b)), (31))); elseif b == 12 then d -= X; b = 77 + (N[29][24] ((N[29][23] ((N[29][21] (o + b, (b))), (b))) - b ~= b and b or o, o, b)); elseif b == 87 then C = (6); b = - 13 + ((N[29][21] ((N[29][28] ((N[29][22] (o)), (26))), (3))) + o + b < o and b or b); continue; elseif b == 74 then d = d (X, C); b = 33 + (((N[29][22] ((N[29][25] (b)) - b + o)) > o and b or o) - b); else if b == 30 then if N[1] ~= N[14] then else (N)[39], N[43] = N[44], (N[40]); return c; end; l = l (d, X); break; end; end; end; end; d = (15); I = I (l, d); l = (o); b = (115); repeat if not (b <= 54) then if N[22] == N[45] then else I += l; b = (8 + (((N[29][28] ((o < b and o or b) - b + b, (17))) == o and b or o) ~= b and o or b)); continue; end; else l = o; I += l; l = z[B]; break; end; until false; I += l; b = 67; repeat if b == 70 then P += h; if N[44] ~= N[1] then (z)[B] = P; break; end; else if b ~= 67 then else h += I; b = (3 + ((N[29][20] ((N[29][19] (o)) - b - o + b)) > o and b or b)); end; end; until false; b = (55); repeat if b == 1 then I = k[B]; b = (107 + ((N[29][21] ((N[29][21] ((o <= b and o or o) + o, (b))), (b))) - b <= b and b or b)); elseif b == 108 then P[h] = (I); break; elseif b == 55 then P = u; b = (42 + (N[29][19] (((N[29][28] ((N[29][20] (o)) - b, (19))) < o and o or o) <= b and b or b))); else if N[27] == N[15] then U, N[37] = - 124 ~= N[38], (N[27]); else if b ~= 42 then else if N[15] == N[30] then if not (N[51]) then else return 234 * N[14]; end; while true do (N)[37], m = - (- 216), (50); N[30], N[47] = N[47], N[26]; end; end; h = (x[B]); b = - 37 + ((o - o ~= o and b or o) - o + b - b + b); continue; end; end; end; until false; else if o ~= 48 then h = x[B]; I = u; b = s[B]; else P = u; b = (f[B]); P = P[b]; end; end; end; else if o < 52 then if o < 50 then P = u; else if o ~= 51 then if not (r) then else for K, A, p in r do if K >= 1 then (A)[1] = (A); A[2] = (u[K]); (A)[3] = (2); (r)[K] = nil; end; end; end; P = (s[B]); return u[P] (N[27] (u, D, P + 1)); else I = (k[B]); end; end; else if N[46] == c then else if o >= 53 then if o ~= 54 then if not (not (k[B] < u[x[B]])) then else B = (f[B]); end; else P = (nil); h = (nil); I = (nil); b = 121; while true do if b == 19 then h *= I; break; elseif b == 4 then h = (0); I = 4503599627370495; b = (- 27 + ((N[29][25] (((N[29][24] (b, b, o)) ~= o and b or o) + o, b)) - b - o)); elseif b == 121 then P = (17); b = (- 4294963183 + ((N[29][22] ((N[29][21] ((N[29][22] (b)), (20))))) + o - b + o)); continue; end; end; l = nil; d = nil; b = 72; while true do if b > 21 and b < 58 then l -= d; b = - 4294967281 + (N[29][25] ((N[29][24] ((N[29][22] ((N[29][27] (b, (18))) > o and o or o)))) + o, o, o)); continue; elseif b < 14 then l = 28; b = (- 4294967176 + (N[29][25] ((N[29][22] ((o - o + b >= b and o or o) + b)), b, b))); elseif b > 14 and b < 43 then l -= d; break; elseif b > 58 and b < 81 then I = N[29]; b = 1 + (N[29][28] ((N[29][19] (b + b + o + b - o)), (1))); elseif b < 72 and b > 43 then I = (I[l]); b = (27 + ((N[29][27] ((N[29][25] ((N[29][25] (b, o)), o)) - b, (2))) - o < b and o or o)); elseif b > 72 and b < 124 then l = (z[B]); b = (150 + ((N[29][22] ((N[29][20] ((N[29][20] (b)) >= b and o or b)) - b)) - b)); elseif b > 81 then d = z[B]; b = - 65 + ((N[29][24] ((b <= o and o or o) - o, b)) - b + o + o); continue; elseif b > 7 and b < 21 then d = z[B]; b = - 47 + (((N[29][24] (o - o + o - b)) ~= o and b or o) + o); end; end; d = (19); b = (34); while true do if b == 25 then l = (o); b = (- 4294967250 + ((N[29][24] ((N[29][22] (o - o > b and o or o)), b)) + o - b)); continue; elseif b == 36 then if N[38] == N[5] then return; end; I -= l; b = (- 23 + ((N[29][26] ((b > b and o or o) - o - o, o)) + b + b)); continue; elseif b == 51 then l = (o); break; elseif b == 34 then I = I (l, d); b = - 23 + (N[29][26] ((N[29][27] ((N[29][22] ((o >= b and o or b) == b and b or b)) - o, (4))), o)); continue; end; end; if N[44] == N[40] then return c; end; I += l; l = z[B]; b = (102); while true do if b == 102 then I = I ~= l; b = (8 + (N[29][19] ((N[29][26] ((N[29][25] ((N[29][22] (b)), b, b)) - b + o, b))))); elseif b == 8 then if not I then I = (z[B]); end; l = z[B]; break; elseif b == 13 then if not (I) then else I = (o); end; if N[43] == c then else b = (62 + ((N[29][25] ((N[29][21] (o + b - o - b, (b))))) - o)); end; end; end; I -= l; l = z[B]; I += l; b = (89); while true do if b == 54 then P = (s[B]); b = (- 25 + ((N[29][24] ((N[29][22] ((N[29][19] (b)))) - b)) - o > o and o or o)); elseif b == 29 then B = P; break; elseif b == 100 then P += h; b = (15 + (((N[29][21] (b - o, (21))) < o and b or o) - o - o > b and b or b)); elseif b == 115 then (z)[B] = (P); b = (- 1811939159 + ((N[29][28] ((N[29][24] ((o <= b and o or o) - b < o and o or o, o, o)), (25))) - b)); elseif b ~= 89 then else h += I; b = 68 + (N[29][20] ((N[29][21] ((N[29][20] ((b - b <= o and b or o) + b)), (31))))); continue; end; end; end; else l = (f[B]); b = (b[l]); end; end; end; end; else if N[43] == N[1] then else if not (o >= 60) then if N[46] == N[5] then while a do N[46], N[49] = N[45] ~= N[22], 52; return; end; if not (N[26]) then else (N)[39] = E; return; end; end; if N[22] == N[36] then return c; else if o < 57 then if o == 56 then b = (k[B]); I -= b; else P = 3; end; else if not (o < 58) then if o ~= 59 then h = (P); I = 1; else if not (not (M[B] <= u[x[B]])) then else B = (s[B]); end; end; else I = (I[P]); P = (e[B]); h[I] = (P); end; end; end; else if o < 63 then if o >= 61 then if o ~= 62 then if N[37] == N[1] then while - 123 do return N[1]; end; return c; end; h[I] = (P); else u[s[B]] = (u); end; else b = (f[B]); I = I[b]; P[h] = (I); end; else if N[39] ~= N[22] then if o < 64 then if N[1] == N[39] then else P = (x[B]); h = (s[B]); end; I = (u[P]); N[33] (u, P + 1, P + f[B], h + 1, I); else if o == 65 then I = (N[21]); b = (x[B]); else u[f[B]] = u[s[B]] / e[B]; end; end; end; end; end; end; end; else if not (o >= 77) then if not (o >= 71) then if not (o < 68) then if not (o < 69) then if o ~= 70 then D = (x[B]); u[D] (); D -= 1; else I += b; P[h] = I; end; else b = P; l = (1); b = b[l]; end; else if o ~= 67 then if not (r) then else if N[48] ~= N[29] then for K, A, p in r do if K >= 1 then (A)[1] = A; A[2] = u[K]; (A)[3] = 2; r[K] = nil; end; end; end; end; return u[s[B]]; else if not (not (u[f[B]] <= e[B])) then else B = (s[B]); end; end; end; else if c == N[49] then while 26 % 169 < - 12 do (N)[38], N[40] = - U, (N[39]); end; N[15], c = a, - (137 ~= 93); else if not (o >= 74) then if o >= 72 then if o ~= 73 then u[x[B]] = u[s[B]][M[B]]; else (u)[x[B]] = (u[s[B]] * M[B]); end; else B = s[B]; end; else if o < 75 then P = (u); h = (x[B]); I = (k[B]); else if o == 76 then if N[14] ~= N[27] then else if not (N[49] and 149 <= 120) then else N[26] = (N[30]); end; end; P = (nil); h = (nil); I = nil; b = (81); repeat if b <= 43 then if b < 43 then h *= I; break; else if N[36] ~= N[5] then else while - N[29] do return; end; end; I = 4503599627370495; b = (- 4294967281 + (N[29][22] ((N[29][26] ((N[29][20] ((N[29][22] ((N[29][20] (o + o)))))), o, b))))); continue; end; else if not (b > 81) then P = (11); b = (48 + ((N[29][19] ((N[29][20] ((N[29][22] ((N[29][22] (b)))))) ~= b and b or b)) + o)); else h = (0); b = (39 + (N[29][24] ((N[29][19] ((N[29][26] (b, o)) + b - o - o))))); continue; end; end; until false; I = (N[29]); l = (nil); b = (18); while true do if b == 18 then l = 19; b = (73 + (N[29][24] ((N[29][24] ((N[29][25] (o - o + b, o, b)), o)) - o))); continue; else if b ~= 73 then else I = I[l]; l = N[29]; break; end; end; end; d = 26; X = (nil); b = (116); repeat if b == 70 then X = 28; break; elseif b == 67 then d = (N[29]); b = (- 4294967234 + ((N[29][22] ((N[29][28] (o >= o and o or b, (11))) - b <= o and b or b)) + o)); else if b ~= 116 then else l = l[d]; b = 67 + (N[29][25] (((o < o and o or b) + b < b and b or b) - b ~= o and o or o, o)); end; end; until false; if N[45] ~= X then else if U then return N[15]; end; return; end; d = d[X]; X = z[B]; C = (nil); b = (126); while true do if b == 63 then d = o; b = (- 4294967138 + ((N[29][22] ((N[29][24] ((N[29][22] (o)) + o)) >= b and b or o)) - o)); continue; elseif b == 73 then d = (z[B]); l = l > d; break; else if b == 126 then C = (16); b = (- 2147483831 + ((N[29][24] ((N[29][27] ((N[29][25] ((b <= b and b or o) + o, o)), (30))), b, o)) + b)); elseif b == 69 then d = d (X, C); b = 27 + (N[29][25] ((N[29][21] (b - o - o, (1))) + b >= o and b or o)); else if b == 96 then X = (z[B]); l = l (d, X); b = (137 + ((N[29][19] ((((N[29][22] (b)) ~= b and o or o) == b and o or o) > b and b or o)) - o)); else if b ~= 18 then else l += d; b = (71 + (N[29][26] ((N[29][25] ((N[29][21] (o + o + o, (b))) - o, b, o)), b))); continue; end; end; end; end; end; b = 2; repeat if b > 86 then if N[46] ~= N[1] then if not l then l = (o); end; end; b = (- 8 + (N[29][26] ((N[29][28] (((N[29][24] (b)) >= b and b or o) - o, (2))) + b, o))); elseif b < 86 and b > 4 then if N[14] ~= N[47] then else N[45], N[30] = m <= 138, N[43]; if not (N[14]) then else return; end; end; l -= d; b = (67 + ((N[29][28] ((N[29][28] (o - o >= b and b or b, (b))) < o and o or b, (b))) > o and b or b)); continue; else if b > 2 and b < 19 then d = o; b = 19 + (N[29][26] (((N[29][20] ((N[29][26] (o + o, b, b)))) > b and o or o) + o, b, b)); elseif b < 4 then if not (l) then else l = (z[B]); end; b = - 2147483698 + ((N[29][23] ((N[29][23] ((N[29][27] (b + o, (b))), (b))), (b))) + o + o); continue; else if not (b < 121 and b > 19) then else I = I (l); break; end; end; end; until false; l = (o); b = 3; while true do if not (b <= 3) then if b == 6 then I = I ~= l; b = - 4294967248 + (N[29][24] ((N[29][22] ((N[29][19] (b + b)) - o + o)), o)); else if not (I) then else I = z[B]; end; break; end; else I += l; l = o; b = 6 + (((N[29][27] ((N[29][21] (b + o + o, (b))), (b))) >= o and b or o) - b); end; end; if not (not I) then else I = (z[B]); end; h += I; b = (52); while true do if b > 3 then P += h; b = (- 49 + ((N[29][24] ((N[29][28] ((b >= b and b or b) + o <= o and o or o, (5))), o)) >= b and b or b)); else if b < 52 then z[B] = P; P = (Z); break; end; end; end; h = (f[B]); b = (44); while true do if N[44] == N[40] then (N)[36], N[27] = - 78, (c); end; if b > 27 then P = P[h]; b = - 69 + (N[29][25] ((N[29][20] (b + b - o - b)) + o, b)); continue; else if not (b < 44) then else h = P; break; end; end; end; I = 1; h = (h[I]); I = P; b = 82; while true do if b > 9 and b < 82 then (h)[I] = l; break; else if b > 82 then if N[39] ~= N[29] then else while N[35] do return - (168 * 252); end; end; l = (e[B]); b = - 4829 + (N[29][23] ((N[29][23] ((N[29][26] ((N[29][26] (b - o)), o, b)), (9))) + o, (26))); elseif b < 35 then if N[49] == N[14] then if 225 then (N)[30], N[44] = - N[1], 233 * 17 / (242 < 68); return; end; if not (- m) then else return; end; end; I = I[l]; b = (56 + (N[29][20] (((N[29][20] ((N[29][21] (o, (b))))) <= b and b or b) + o - o))); else if b < 84 and b > 35 then l = 3; b = - 4294967285 + (N[29][24] (((N[29][24] ((N[29][27] (o, (14))) >= o and b or o)) ~= b and b or o) - b, b, o)); end; end; end; end; else if N[45] ~= N[40] then elseif not (61 < 16 >= N[41]) then else N[43], N[48] = N[15] <= N[14], N[22] >= N[41]; return; end; P = x[B]; (u[P]) (u[P + 1], u[P + 2]); D = P - 1; end; end; end; end; end; else if not (o >= 82) then if N[40] ~= N[1] then else return N[38]; end; if o < 79 then local K = 209; if o == 78 then (u)[s[B]] = (u[x[B]] >= u[f[B]]); else P = (192); h = (nil); I = (nil); b = (67); repeat if b ~= 67 then I = 4503599627370495; h *= I; break; else if K == 47 then return; end; h = 0; b = (- 1073741754 + (N[29][28] ((N[29][19] ((N[29][25] ((N[29][22] ((N[29][23] (o, (18))) - b)))))), (N[29][29] (">i8", "\x00\x00\x00\x00\x00\x00\x00\x1e"))))); continue; end; until false; I = o; l = z[B]; b = (51); repeat if not (b <= 51) then if b ~= 118 then if not I then I = (o); end; b = (- 8 + (N[29][19] ((N[29][19] (o - o ~= b and o or b)) + b - b))); continue; else if not (I) then else I = z[B]; end; b = (- 143 + (((N[29][22] ((N[29][27] ((N[29][22] (b - b)), (1))))) <= o and b or o) + b)); end; elseif b ~= 51 then l = (o); break; else I = I == l; b = (144 + ((((((N[29][25] (b, b)) == o and b or o) == b and b or b) < b and b or b) < b and o or b) - o)); end; until false; I -= l; b = 71; while true do if not (b <= 60) then if K == 152 then else if b == 122 then I -= l; l = o; b = (- 182 + ((N[29][26] (b + o - o, b, b)) + o + b - b)); continue; else l = o; b = (51 + ((((N[29][22] (b >= o and b or b)) == o and b or o) ~= b and b or b) + b - b)); end; end; else if not (b <= 17) then l = z[B]; break; else I -= l; b = (- 50 + ((N[29][24] ((N[29][24] ((N[29][25] (b + b + b)), o)), o)) - b)); continue; end; end; end; b = 98; repeat if b > 89 then if not (b >= 100) then I -= l; b = - 10 + ((N[29][19] ((N[29][23] (o - o - o + b, (3))))) + b); else I = (I > l); break; end; else l = z[B]; b = (- 54 + (((N[29][22] (b - o)) == b and o or o) + o + o - o)); continue; end; until false; if I then I = (z[B]); end; if K ~= 209 then else if K == 169 then return K; elseif K ~= 209 then return; else if not (not I) then else I = (o); end; end; end; if N[30] == N[15] then else l = z[B]; I -= l; b = (50); while true do if K ~= 209 then elseif b > 6 then if not (b > 50) then l = z[B]; b = (- 88 + ((N[29][25] ((N[29][19] ((N[29][22] (b + o)))) + b, o)) + o)); continue; else if b > 52 then I -= l; b = (52 + (N[29][26] ((N[29][22] ((N[29][25] ((N[29][22] (b)), b)))) + o - o, o))); else h += I; b = (- 1744830436 + ((N[29][28] (b + o - b, (27))) - b + o - b)); end; end; else if b >= 6 then z[B] = P; break; else P += h; b = (- 71 + (((((N[29][23] (o, (b))) < o and o or o) + b <= b and o or b) <= b and o or o) <= b and b or o)); end; end; end; P = u; b = (124); repeat if K ~= 221 then if not (b >= 124) then I = (x); break; else h = f[B]; b = - 4294964885 + (N[29][27] ((N[29][19] ((N[29][27] (b, (10))) - b - b)) - o, (N[29][29] ("<i8", "\x05\x00\x00\x00\x00\x00\x00\x00")))); end; end; until false; end; (P)[h] = I; end; else if not (o >= 80) then P = (nil); h = nil; I = 113; repeat if I == 113 then P = - 54; I = 22 + (N[29][22] ((N[29][22] ((N[29][19] ((N[29][26] ((I ~= I and o or o) + I)))))))); continue; else if I == 28 then h = (0); break; end; end; until false; b = (4503599627370495); l = (nil); I = 32; repeat if not (I <= 9) then if N[32] ~= N[14] then else return; end; if N[49] == N[5] then C = (N[14] + c); else if not (I > 32) then h *= b; I = 3 + ((((N[29][19] (o)) == I and o or o) >= o and o or o) - o + o <= I and I or o); else b = (N[29]); I = (170 + ((N[29][21] (((N[29][25] (o, o, I)) > I and o or o) ~= I and o or o, (N[29][29] (">\i8", "\x00\x00\x00\x00\x00\x00\x00\x1c")))) - o - I)); continue; end; end; else l = 19; break; end; until false; b = (b[l]); d = (nil); I = 121; while true do if I == 4 then d = (N[29]); break; else if I == 121 then l = N[29]; d = 20; l = l[d]; I = (- 28 + (N[29][20] ((N[29][19] ((N[29][24] ((N[29][19] ((N[29][22] (I)) - I)), I, o))))))); continue; end; end; end; if N[39] == N[30] then if not (N[30]) then else return (86 and 163) == N[46]; end; end; if N[43] == N[1] then else X = (nil); C = (nil); I = (55); while true do if I > 42 then local K = (216); if N[27] ~= c then elseif N[41] - N[14] then (N)[36], c = 126, K; a = (131); end; X = (20); d = d[X]; I = 66 + ((N[29][21] (((N[29][19] (o)) ~= I and o or I) >= I and o or o, (27))) + I - o); else if I > 1 and I < 55 then X = (o); I = (- 25 + (N[29][20] ((N[29][26] ((N[29][22] (o + o + I)) >= I and I or I))))); else if I < 42 then C = (z[B]); X = X <= C; break; end; end; end; end; end; if X then X = z[B]; end; if N[14] ~= N[39] then else B, B = N[41], N[41]; end; I = 0; while true do if I > 50 and I < 105 then d = d (X); I = 161 + ((I - I ~= I and o or I) + o - o - I - I); else if I > 95 then d -= X; break; elseif I > 0 and I < 95 then X = z[B]; I = 105 + ((I == o and I or o) - o + o - o - I + I); continue; else if not (I < 50) then else if not (not X) then else X = o; end; I = (174 + (((N[29][21] ((N[29][22] (o + o)), (I))) <= I and o or I) - I - o)); continue; end; end; end; end; I = 30; repeat if I <= 30 then if I == 0 then if N[27] == N[40] then U, B = U, 99; if N[38] then return N[48]; end; end; l = (z[B]); I = (95 + ((N[29][28] ((N[29][23] (o - o >= o and o or o, (I))), (I))) + I == o and I or o)); continue; else l = l (d); I = (73 + (N[29][26] ((N[29][23] ((N[29][24] ((N[29][22] ((N[29][21] (o, (I))))) + o, o)), (I))), I))); end; elseif not (I > 50) then if not (b) then else b = o; end; if N[44] ~= N[40] then else if N[45] ^ 36 then (N)[22] = (- N[39]); return N[32]; end; end; break; else if I == 101 then b = b (l); I = (N[29][20] ((N[29][21] ((N[29][19] ((N[29][20] (I)) - I)), (5))) - o)); else if N[26] == N[40] then else b = b <= l; I = - 1610088398 + (N[29][27] ((N[29][28] ((N[29][20] (I - I + I)) - I, (10))), (19))); end; end; end; until false; if N[27] ~= N[15] then else return; end; I = (34); repeat if N[26] ~= c then else if not (7) then else return 217; end; while N[5] do return N[35]; end; end; if I > 25 and I < 36 then if N[37] ~= N[14] then else if not (N[43]) then else return N[51]; end; while N[30] do U = (- 119); end; end; if not (not b) then else b = (o); end; I = (- 4294967282 + ((N[29][25] ((N[29][26] (o, o, I)) - o - I, o)) + o - I)); continue; elseif I < 34 then if N[14] == N[36] then m, N[27] = N[26], (N[36]); if N[5] then (N)[35] = N[43] > N[5]; return; end; end; l = (z[B]); b += l; I = (- 4294967180 + (N[29][22] ((N[29][20] ((N[29][24] (I <= I and o or I)))) + I < o and o or o))); continue; else if not (I > 34) then else l = z[B]; if N[36] == N[1] then if N[48] then (N)[38], N[51] = N[49], N[35]; end; return c; end; b = (b >= l); break; end; end; until false; if not (b) then else b = z[B]; end; I = (96); while true do if I < 63 then P += h; break; else if I > 18 and I < 96 then h += b; I = (18 + (N[29][19] ((N[29][20] ((N[29][25] (o >= o and I or o, I, o)) + o ~= o and o or o))))); else if I > 63 then if N[26] ~= N[29] then if N[36] == c then while N[36] do N[37], N[49] = 204, N[45]; end; if E then return c; end; else if N[39] == N[22] then if not (- 163 > N[15]) then else N[5] = (N[1]); end; else if not b then b = (o); end; end; end; end; I = (63 + ((((N[29][21] ((N[29][24] (I)), (24))) == I and o or o) - o ~= I and o or o) - o)); end; end; end; end; (z)[B] = P; I = 38; repeat if I <= 38 then P = u; I = (115 + ((N[29][27] ((N[29][23] ((N[29][27] ((N[29][28] (I + o, (N[29][29] ("<i8", "\x1d\x00\x00\x00\x00\x00\x00\x00")))), (0))), (14))), (N[29][29] ("<i8", "\x18\x00\x00\x00\x00\x00\x00\x00")))) - I)); continue; else if not (I > 72) then if N[36] == N[14] then return - (221 - 48); end; if N[29] == N[36] then else b = s; end; break; else h = x[B]; I = (72 + (((N[29][20] ((N[29][21] ((N[29][25] ((N[29][24] (o, o, o)), I)), (4))))) ~= I and I or o) - I)); continue; end; end; until false; (P)[h] = b; else if N[46] ~= N[5] then else if - 100 * c then return N[40]; end; if N[39] then (N)[38], N[38] = 253, E >= d; N[30] = 154 % 93 - N[46]; end; end; if o == 81 then (u)[s[B]] = u[x[B]] / u[f[B]]; else u[s[B]] = (N[31] (u[f[B]], e[B])); end; end; end; else if o < 85 then if not (o < 83) then if o ~= 84 then N[29][f[B]] = u[s[B]]; else l = (s[B]); end; else u[f[B]] = u[x[B]] % k[B]; end; else if o >= 86 then if N[41] == N[14] then return 194; else if o ~= 87 then if not (r) then else if N[37] ~= N[15] then for K, A in r do if not (K >= 1) then else A[1] = A; A[2] = (u[K]); (A)[3] = (2); (r)[K] = nil; end; end; end; end; P = s[B]; return N[27] (u, P + x[B] - 2, P); else P = (Z[f[B]]); (P[1])[P[3]] = (e[B]); end; end; else I %= b; end; end; end; end; end; end; end; B += 1; end; end
        return c
    end
    return G
end
-- VM.mc = bit32.rrotate
-- VM.G = table.move
function VM.g(K, A)
    A[6] = (K.l.yield)
end
-- VM.A = string.char
function VM.R8(K, K, A, G, N, Z)
    A = Z[21] (N)
    K = (76)
    if not (Z[22] ~= Z[1]) then
        if not (Z[26]) then
        else
            G, Z[1] = Z[30], Z[30]
        end
    end
    Z[19] = Z[21] (N * 3)
    return A, K, G
end
function VM.t8(K, A)
    do
        K:X8 (A)
        return - 1
    end
    return nil
end
-- VM.Hc = bit32.band
function VM.M8(K, A, G, N, Z)
    if N == 78 then
        if Z < 233 then
            G = A[48] ()
        else
            G = K:F8 (G, A)
        end
        N = 85
    else
        if not (N ~= 85) then
            return 22037, N, G
        end
    end
    return nil, N, G
end
function VM.zv(K, K, A, G, N)
    (G)[A] = (K[4][N])
end
function VM.M(K, A, G)
    G[1879] = (93 + (K.nc ((K.Ac ((K.lc (K.H[9] - K.H[5], (30))) + K.H[5] + K.H[8])))))
    G[31946] = - 10640735153 + ((K.mc (K.H[9], (3))) + K.H[2] + K.H[8] + K.H[6] + K.H[6] - K.H[4])
    A = - 5485143322 + ((K.Dc ((K.nc ((K.Oc ((K.Ac (K.H[3])), (5))) - K.H[3])), K.H[3])) + K.H[9])
    (G)[7640] = A
    return A
end
function VM.Fv(K, ...)
    return (...)[...]
end
function VM.N8(K, A, G, N, Z)
    local D, e, M
    do
        D, M, N, e = K:i8 (Z, N, M, G, s)
        if D == 9826 then
            continue
        else
            if not (D ~= - 2) then
                return N, - 2, Z, A, e
            end
        end
        D, M, N, e = K:i8 (Z, N, M, G, s)
        if D == 9826 then
            continue
        else
            if not (D ~= - 2) then
                return N, - 2, Z, A, e
            end
        end
        D, M, N, e = K:i8 (Z, N, M, G, s)
        if D == 9826 then
            continue
        else
            if not (D ~= - 2) then
                return N, - 2, Z, A, e
            end
        end
        D, M, N, e = K:i8 (Z, N, M, G, s)
        if D == 9826 then
            continue
        else
            if not (D ~= - 2) then
                return N, - 2, Z, A, e
            end
        end
        D, M, N, e = K:i8 (Z, N, M, G, s)
        if D == 9826 then
            continue
        else
            if not (D ~= - 2) then
                return N, - 2, Z, A, e
            end
        end
    end
    D = (nil)
    e = (97)
    while true do
        if e == 97 then
            D, e, Z = K:R8 (e, D, Z, M, G)
            continue
        else
            for e = 1, M do
                K:g8 (D, e, G)
            end
            break
        end
    end
    for e = 1, #G[19], 3 do
        G[19][e][G[19][e + 1]] = D[G[19][e + 2]]
    end
    if not (not (N)) then
        G[29][12] = (G[4])
        (G[29])[18] = (D)
    end
    A = (nil)
    do
        A = K:L8 (D, G, A)
        if e > 80 and e < 260 then
            if G[53] == N then
                return N, - 1, Z, A
            end
            continue
        elseif e > 260 and e < 440 then
            G[19] = K.q
        elseif e < 350 and e > 170 then
            G[4] = K.q
        else
            if e > 350 then
                (G)[25] = (nil)
            end
        end
        if e > 80 and e < 260 then
            if G[53] == N then
                return N, - 1, Z, A
            end
            continue
        elseif e > 260 and e < 440 then
            G[19] = K.q
        elseif e < 350 and e > 170 then
            G[4] = K.q
        else
            if e > 350 then
                (G)[25] = (nil)
            end
        end
        if e > 80 and e < 260 then
            if G[53] == N then
                return N, - 1, Z, A
            end
            continue
        elseif e > 260 and e < 440 then
            G[19] = K.q
        elseif e < 350 and e > 170 then
            G[4] = K.q
        else
            if e > 350 then
                (G)[25] = (nil)
            end
        end
        if e > 80 and e < 260 then
            if G[53] == N then
                return N, - 1, Z, A
            end
            continue
        elseif e > 260 and e < 440 then
            G[19] = K.q
        elseif e < 350 and e > 170 then
            G[4] = K.q
        else
            if e > 350 then
                (G)[25] = (nil)
            end
        end
    end
    return N, nil, Z, A
end
function VM.Mv(K, A, G)
    G[32411] = 114 + (K.uc ((K.Dc ((K.Tc (((K.nc (G[10280])) > K.H[1] and G[6918] or G[13997]) + G[14464], G[1656], G[31946]))))))
    (G)[9022] = (14 + ((((K.Hc ((K.rc (K.H[2], (G[17825]))) - G[1656])) <= G[28007] and G[1656] or K.H[8]) < G[3219] and G[3219] or G[13997]) == G[10280] and G[8844] or G[10280]))
    A = (- 1904633155 + (((K.Hc ((K.Dc ((K.rc (G[14464], (G[1656]))), G[31946], G[31946])), G[10454])) + A >= G[10716] and G[27523] or G[31867]) + K.H[2]))
    (G)[17708] = A
    return A
end
function VM.b8(K, A, G, N)
    local Z
    if N[15] == N[53] then
        local D = 61
        while true do
            if D == 120 then
                (N)[15] = (N[38])
                break
            else
                if D == 61 then
                    D = (120)
                    while (180 <= 27) ^ N[22] do
                        return - 2, G, N[45]
                    end
                end
            end
        end
    else
        if not (A <= 229) then
            local D = (78)
            repeat
                Z, D, G = K:M8 (N, G, D, A)
                if Z == 22037 then
                    break
                end
            until false
        else
            G = false
        end
    end
    return nil, G
end
function VM.c(K, A, G, N, Z)
    if not (Z <= 21) then
        Z, N = K:b (G, N, A, Z)
    else
        K:F (G, N)
        return N, 26553, Z
    end
    return N, nil, Z
end
-- VM.r = select
function VM.mv(K, K)
    K[37] = function()
        local A = K[12] (F, K[28])
        K[28] = (K[28] + 4)
        return A
    end
    (K)[38] = nil
    (K)[39] = (nil)
    (K)[40] = (nil)
end
function VM.av(F, K, A, G, N)
    local Z
    (G)[41] = (nil)
    (G)[42] = (nil)
    N = 5
    while true do
        Z, N = F:Kv (G, K, A, N)
        if Z == 19105 then
            break
        else
            if not (Z ~= 54730) then
                continue
            end
        end
    end
    (G)[43] = function () local F = G[41] (); if not (F >= G[40]) then else return F - G[30]; end; return F; end
    G[44] = (nil)
    return N
end
function VM.k8(F, F, K, A)
    (F[4])[A] = ({K, (F[47] (K))})
end
-- VM.q = nil
function VM.Dv(F, F, K)
    F = (K[3219])
    return F
end
-- VM.a = bit32.bor
function VM.R(F, K, A, G, N)
    K = (78)
    while true do
        if K < 78 then
            G = F.A
            if not (not N[20959]) then
                K = N[20959]
            else
                K = F:o (N, K)
            end
        elseif K > 79 then
            A[5] = {}
            if not (not N[2661]) then
                K = (N[2661])
            else
                K = F:Q (K, N)
            end
            continue
        elseif K > 48 and K < 79 then
            K = F:i (A, N, K)
        else
            if not (not (K < 85 and K > 78)) then
                F:g (A)
                break
            end
        end
    end
    A[7] = (nil)
    A[8] = nil
    K = (75)
    return G, K
end
function VM.x8(F, K)
    do
        if not (not (A < 73)) then
            K[29][28] = F.Oc
            continue
        end
        (K[29])[25] = F.T
    end
end
function VM.Cv(F, F, K, A)
    A = (20)
    K = #F[19]
    return A, K
end
function VM.N(F, K)
    (K)[13] = F.T
end
-- VM.nc = bit32.countlz
function VM.Q8(F, F, K)
    K = (F[41] () - 77491)
    return K
end
function VM.Ov(F, K, A)
    K = (87550817 + ((F.uc ((F.Ac ((F.Hc (A[28007] + A[13997], A[17668])) - A[31215])))) - F.H[5]))
    (A)[1656] = K
    return K
end
function VM.z(F, F, K)
    F = K[28007]
    return F
end
function VM.b(F, K, A, G, N)
    K[1] = ({})
    A = F.n
    if not G[7640] then
        N = F:M (N, G)
    else
        N = (G[7640])
    end
    return N, A
end
VM):W ()  -- entry call (was inline)

