#!/usr/bin/env python3
"""
Luraph v14.7 5-stage deobfuscation sandbox builder
===================================================
1. AST hooking      : payload extraction + deserializer-tail instrumentation
2. Sandboxed sim    : harness_pre + Roblox runtime (roblox_api/datatypes) + envlog
3. Live decryption  : envlog buffer tracer (constants decrypted at runtime)
4. CFG SSA lifting  : from dumped execution-data IR
5. Polish naming    : constant pool correlation

Usage:
  python3 lraph_sandbox.py <protected.lua> <combined_out.lua>
"""
import os
import re
import sys

HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'harness')
RUNTIME = os.path.join(os.path.dirname(HERE), 'runtime')
HARNESS = HERE

# ---------------------------------------------------------------------------
# 1. AST hooking: instrument the deserializer tail (from instrument.py logic)
# ---------------------------------------------------------------------------

def instrument_ir(src: str):
    """Find the deserializer tail and inject LPH_DUMP with visible locals."""
    m = re.search(
        r'(\w+)\s*=\s*(\w+)\[(0[Xx][0-9A-Fa-f_]+|0[Bb][01_]+|\d+)\]'
        r'\(\s*(\w+)\s*,\s*(\w+)\[(0[Xx][0-9A-Fa-f_]+|0[Bb][01_]+|\d+)\]\s*\)\s*\(',
        src,
    )
    if not m:
        return src, None
    dest = m.group(1)
    start = m.end() - 1
    # bracket-match the interpreter call
    depth, i = 0, start
    while i < len(src):
        c = src[i]
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
            if depth == 0:
                break
        elif c == '"':
            i += 1
            while i < len(src) and src[i] != '"':
                if src[i] == "\\":
                    i += 1
                i += 1
        i += 1
    end = i + 1

    # candidate local names from the 4KB window before the invoke
    window = src[max(0, m.start() - 4000):m.start()]
    idents = re.findall(r"[A-Za-z_]\w*", window)
    keywords = {"and", "break", "do", "else", "elseif", "end", "false",
                "for", "function", "if", "in", "local", "nil", "not", "or",
                "repeat", "return", "then", "true", "until", "while",
                "continue"}
    names, seen = [], set()
    for x in idents:
        if x in keywords or x in seen:
            continue
        seen.add(x)
        names.append(x)
        if len(names) >= 24:
            break

    dump_call = (f"{dest} = LPH_DUMP({', '.join(names)}); "
                 f"local __LPH_DONE = true")
    return src[:start] + dump_call + src[end:], dest


# ---------------------------------------------------------------------------
# 2. Sandboxed simulation: build the combined script
# ---------------------------------------------------------------------------

def build_combined(protected_path, out_path, do_ir=True):
    pre = open(os.path.join(HARNESS, 'harness_pre.lua'),
               encoding='utf-8', errors='replace').read()
    post = open(os.path.join(HARNESS, 'harness_post.lua'),
                encoding='utf-8', errors='replace').read()
    protected = open(protected_path, encoding='utf-8', errors='replace').read()
    roblox_api = open(os.path.join(RUNTIME, 'roblox_api.luau'),
                      encoding='utf-8', errors='replace').read()
    datatypes = open(os.path.join(RUNTIME, 'datatypes.luau'),
                     encoding='utf-8', errors='replace').read()
    unicode_data = open(os.path.join(RUNTIME, 'unicode_data.luau'),
                        encoding='utf-8', errors='replace').read()

    # stage 1: AST hooking — instrument the deserializer tail
    hooked, dest = instrument_ir(protected) if do_ir else (protected, None)

    extra = ''
    # wire __ROBLOX: enums/classes strings + datatypes module + unicode
    extra += '-- === ROBLOX RUNTIME START ===\n'
    extra += 'local __ROBLOX_API = (function()\n' + roblox_api + '\nend)()\n'
    extra += ('local __ROBLOX_DT = (function(...)\n' + datatypes +
              '\nreturn __LPH_DT end)()\n'
              if False else
              'local __ROBLOX_DT_SRC = function() ' + datatypes + ' end\n')
    extra += ('__ROBLOX_WIRE = { enums = __ROBLOX_API.enums, '
              'classes = __ROBLOX_API.classes }\n')
    # datatypes module: loadstring it in the harness env, capture the return
    extra += ('do\n'
              '  local f = R.loadstring(' +
              repr(datatypes) + ', "=datatypes")\n'
              '  if f then setfenv(f, getfenv()) __ROBLOX_WIRE.datatypes = f() end\n'
              'end\n')
    # Roblox globals wiring (AFTER __ROBLOX_WIRE exists)
    extra += '''do
  local CLASSES = __ROBLOX_WIRE.classes or ""
  local proxy_of = {}
  local function mkproxy(name)
    if proxy_of[name] then return proxy_of[name] end
    local p = setmetatable({}, {
      __index = function(_, k)
        if k == "new" then
          return function(...)
            local inst = setmetatable({}, {__index = function() return inst end,
              __tostring = function() return name end})
            return inst
          end
        end
        return mkproxy(name .. "." .. k)
      end,
      __call = function() return mkproxy(name .. "()") end,
      __tostring = function() return name end,
    })
    proxy_of[name] = p
    return p
  end
  env.Instance = mkproxy("Instance")
  env.Enum = setmetatable({}, {__index = function(_, ename)
    return setmetatable({}, {__index = function(_, item)
      return setmetatable({}, {__tostring = function() return ename .. "." .. item end})
    end})
  end})
  env.game = setmetatable({}, {__index = function(_, svc)
    if svc == "GetService" then
      return function(_, s) return mkproxy(s or svc) end
    end
    return mkproxy(svc)
  end})
  env.workspace = mkproxy("Workspace")
  env.script = mkproxy("script")
end
'''
    extra += '-- === ROBLOX RUNTIME END ===\n'
    if os.environ.get('LPH_ENVLOG'):
        envlog = open(os.path.join(RUNTIME, 'envlog.luau'),
                      encoding='utf-8', errors='replace').read()
        extra += '-- === ENVLOG START ===\n'
        extra += ('local _LPH_ENVLOG = (function()\n' + envlog +
                  '\nend)()\n')
        extra += ('if __ROBLOX_WIRE.datatypes then '
                  '__LPH_ENVLOG.dt = __ROBLOX_WIRE.datatypes end\n')
        extra += '-- === ENVLOG END ===\n'

    combined = (
        pre + '\n' + extra +
        '\nlocal function RUN_PROTECTED(...)\n'
        + '-- === PROTECTED SOURCE START ===\n'
        + hooked + '\n-- === PROTECTED SOURCE END ===\nend\n'
        + post
    )
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(combined)
    print(f"combined written: {out_path} ({len(combined)}B, ir_dest={dest})")
    return dest


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    build_combined(sys.argv[1], sys.argv[2], '--no-ir' not in sys.argv)
