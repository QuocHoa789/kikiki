-- Luraph v14.7 FULL semantic decompilation
-- 4448 lifted actions from VM execution trace
-- (execution order, polymorphic re-encodes included)

  [VIP    1] ADDI      Stk[1] = Stk[1] + 231
  [VIP    2] CALL      call Stk[A](...)
  [VIP    3] DT        dT(x,117,3)
  [VIP    4] DT        dT(x,363,4)
  [VIP    5] DT        dT(x,110,5)
  [VIP    6] ADDU      Upv[6] = Upv[6] + 162
  [VIP    7] DT        dT(x,339,7)
  [VIP    8] ADDU      Upv[8] = Upv[8] + 199
  [VIP    9] ADDU      Upv[9] = Upv[9] + 251
  [VIP   10] DT        dT(x,442,10)
  [VIP   11] ADDI      Stk[11] = Stk[11] + 193
  [VIP   12] ADDI      Stk[12] = Stk[12] + 145
  [VIP   13] ADD       Stk[13] = Stk[13] + 508
  [VIP   13] DT        dT(x,508,13)
  [VIP   14] ADDI      Stk[14] = Stk[14] + 161
  [VIP   15] ADDI      Stk[15] = Stk[15] + 111
  [VIP   18] DT        dT(x,105,18)
  [VIP   19] DT        dT(x,137,19)
  [VIP   20] ADDI      Stk[20] = Stk[20] + 250
  [VIP   21] DT        dT(x,92,21)
  [VIP   21] ADDU      Upv[21] = Upv[21] + 43
  [VIP   22] ADDI      Stk[22] = Stk[22] + 254
  [VIP   23] ADDI      Stk[23] = Stk[23] + 207
  [VIP   23] CALL      call Stk[A](...)
  [VIP   24] SETREG    Stk[24] = 11
  [VIP   26] ADDI      Stk[26] = Stk[26] + 234
  [VIP   29] DT        dT(x,409,29)
  [VIP   30] ADDI      Stk[30] = Stk[30] + 254
  [VIP   31] ADD       Stk[31] = Stk[31] + 0
  [VIP   32] ADDI      Stk[32] = Stk[32] + 56
  [VIP   34] ADDI      Stk[34] = Stk[34] + 134
  [VIP   35] ADDI      Stk[35] = Stk[35] + 172
  [VIP   35] CALL      call Stk[A](...)
  [VIP   36] ADDI      Stk[36] = Stk[36] + 123
  [VIP   40] ADDI      Stk[40] = Stk[40] + 78
  [VIP   42] ADDI      Stk[42] = Stk[42] + 92
  [VIP   43] ADDI      Stk[43] = Stk[43] + 22
  [VIP   45] ADDI      Stk[45] = Stk[45] + 215
  [VIP   47] ADDI      Stk[47] = Stk[47] + 160
  [VIP   49] GETTABUP  Stk[49] = env['error in error handling']
  [VIP   49] DT        dT(x,9,49)
  [VIP   50] GETTABUP  Stk[50] = env['bxor']
  [VIP   50] DT        dT(x,47,50)
  [VIP   52] SUBI      Stk[52] = Stk[52] - 16
  [VIP   53] ADDI      Stk[53] = Stk[53] + 147
  [VIP   53] CALL      call Stk[A](...)
  [VIP   54] ADDI      Stk[54] = Stk[54] + 208
  [VIP   56] ADDI      Stk[56] = Stk[56] + 182
  [VIP   57] DT        dT(x,534,57)
  [VIP   58] DT        dT(x,228,58)
  [VIP   60] DT        dT(x,39,60)
  [VIP   61] SETREG    Stk[61] = 8
  [VIP   62] ADDI      Stk[62] = Stk[62] + 47
  [VIP   63] ADD       Stk[63] = Stk[63] + 265
  [VIP   63] DT        dT(x,265,63)
  [VIP   64] ADDI      Stk[64] = Stk[64] + 61
  [VIP   65] ADDI      Stk[65] = Stk[65] + 221
  [VIP   67] CALL      call Stk[A](...)
  [VIP   68] DT        dT(x,664,68)
  [VIP   69] DT        dT(x,445,69)
  [VIP   70] ADDI      Stk[70] = Stk[70] + 81
  [VIP   74] GETTABUP  Stk[74] = env['Luraph']
  [VIP   74] DT        dT(x,7,74)
  [VIP   75] GETTABUP  Stk[75] = env['Luraph']
  [VIP   75] DT        dT(x,7,75)
  [VIP   76] GETTABUP  Stk[76] = env['xpcall']
  [VIP   76] DT        dT(x,40,76)
  [VIP   77] GETTABUP  Stk[77] = env['Luraph']
  [VIP   77] DT        dT(x,7,77)
  [VIP   78] GETTABUP  Stk[78] = env['xpcall']
  [VIP   78] DT        dT(x,40,78)
  [VIP   80] SETREG    Stk[80] = 6
  [VIP   81] ADDI      Stk[81] = Stk[81] + 157
  [VIP   81] CALL      call Stk[A](...)
  [VIP   82] SUBI      Stk[82] = Stk[82] - 28
  [VIP   85] GETTABUP  Stk[85] = env['error in error handling']
  [VIP   85] DT        dT(x,9,85)
  [VIP   86] GETTABUP  Stk[86] = env[K[306]]
  [VIP   86] DT        dT(x,306,86)
  [VIP   88] ADDI      Stk[88] = Stk[88] + 57
  [VIP   89] ADDI      Stk[89] = Stk[89] + 84
  [VIP   90] DT        dT(x,61,90)
  [VIP   90] ADDU      Upv[90] = Upv[90] + 86
  [VIP   91] ADDI      Stk[91] = Stk[91] + 39
  [VIP   92] ADDI      Stk[92] = Stk[92] + 179
  [VIP   94] CALL      call Stk[A](...)
  [VIP   95] DT        dT(x,41,95)
  [VIP   96] SUBI      Stk[96] = Stk[96] - 32
  [VIP   97] ADDI      Stk[97] = Stk[97] + 115
  [VIP   99] ADDI      Stk[99] = Stk[99] + 105
  [VIP  101] GETTABUP  Stk[101] = env[K[81]]
  [VIP  101] DT        dT(x,81,101)
  [VIP  102] GETTABUP  Stk[102] = env[K[85]]
  [VIP  102] DT        dT(x,85,102)
  [VIP  104] SUBI      Stk[104] = Stk[104] - 43
  [VIP  105] SETREG    Stk[105] = 41
  [VIP  105] CALL      call Stk[A](...)
  [VIP  106] ADDI      Stk[106] = Stk[106] + 22
  [VIP  107] DT        dT(x,104,107)
  [VIP  107] ADDU      Upv[107] = Upv[107] + 153
  [VIP  108] SETREG    Stk[108] = 43
  [VIP  109] SETREG    Stk[109] = 45
  [VIP  112] GETTABUP  Stk[112] = env[K[157]]
  [VIP  112] DT        dT(x,157,112)
  [VIP  113] GETTABUP  Stk[113] = env[K[172]]
  [VIP  114] GETTABUP  Stk[114] = env['match']
  [VIP  115] GETTABUP  Stk[115] = env['char']
  [VIP  116] GETTABUP  Stk[116] = env[K[661]]
  [VIP  116] DT        dT(x,661,116)
  [VIP  118] ADDI      Stk[118] = Stk[118] + 68
  [VIP  120] ADDI      Stk[120] = Stk[120] + 140
  [VIP  121] DT        dT(x,222,121)
  [VIP  122] DT        dT(x,133,122)
  [VIP  124] DT        dT(x,239,124)
  [VIP  125] ADDU      Upv[125] = Upv[125] + 59
  [VIP  126] ADDI      Stk[126] = Stk[126] + 102
  [VIP  127] SETREG    Stk[127] = 47
  [VIP  128] ADDI      Stk[128] = Stk[128] + 65
  [VIP  130] SETREG    Stk[130] = 41
  [VIP  131] DT        dT(x,485,131)
  [VIP  134] ADDI      Stk[134] = Stk[134] + 70
  [VIP  137] GETTABUP  Stk[137] = env[K[361]]
  [VIP  137] DT        dT(x,361,137)
  [VIP  138] GETTABUP  Stk[138] = env['getinfo']
  [VIP  138] DT        dT(x,67,138)
  [VIP  140] SETREG    Stk[140] = 30
  [VIP  141] DT        dT(x,172,141)
  [VIP  144] ADDI      Stk[144] = Stk[144] + 151
  [VIP  145] SETREG    Stk[145] = 42
  [VIP  146] LOADN     Stk[146] = 104
  [VIP  146] DT        dT(x,104,146)
  [VIP  147] ADDI      Stk[147] = Stk[147] + 132
  [VIP  148] DT        dT(x,567,148)
  [VIP  150] ADDI      Stk[150] = Stk[150] + 134
  [VIP  151] ADDI      Stk[151] = Stk[151] + 63
  [VIP  152] DT        dT(x,127,152)
  [VIP  153] SETREG2   Upv[153] = 41
  [VIP  154] SETREG    Stk[154] = 15
  [VIP  155] LOADN     Stk[155] = 54
  [VIP  155] DT        dT(x,54,155)
  [VIP  156] SUBI      Stk[156] = Stk[156] - 6
  [VIP  157] SETREG    Stk[157] = 56
  [VIP  158] CALL      call Stk[A](...)
  [VIP  159] ADDI      Stk[159] = Stk[159] + 25
  [VIP  161] ADDI      Stk[161] = Stk[161] + 46
  [VIP  164] GETTABUP  Stk[164] = env['Luraph']
  [VIP  164] DT        dT(x,7,164)
  [VIP  165] GETTABUP  Stk[165] = env[K[128]]
  [VIP  165] DT        dT(x,128,165)
  [VIP  166] GETTABUP  Stk[166] = env[K[337]]
  [VIP  166] DT        dT(x,337,166)
  [VIP  168] ADDI      Stk[168] = Stk[168] + 34
  [VIP  169] SUBI      Stk[169] = Stk[169] - 8
  [VIP  170] CALL      call Stk[A](...)
  [VIP  171] SETREG    Stk[171] = 41
  [VIP  172] ADDI      Stk[172] = Stk[172] + 73
  [VIP  173] SETREG    Stk[173] = 1
  [VIP  175] ADDI      Stk[175] = Stk[175] + 120
  [VIP  176] ADDI      Stk[176] = Stk[176] + 57
  [VIP  177] DT        dT(x,117,177)
  [VIP  181] SUBI      Stk[181] = Stk[181] - 84
  [VIP  182] ADDI      Stk[182] = Stk[182] + 35
  [VIP  183] DT        dT(x,249,183)
  [VIP  183] SETREG2   Upv[183] = 12
  [VIP  184] SETREG    Stk[184] = 14
  [VIP  185] SETTABUP  Stk['string'] = Stk[...]
  [VIP  186] SETREG    Stk[186] = 24
  [VIP  187] SETREG    Stk[187] = 34
  [VIP  187] CALL      call Stk[A](...)
  [VIP  188] SUBI      Stk[188] = Stk[188] - 80
  [VIP  190] CALL      call Stk[A](...)
  [VIP  191] CALL      call Stk[A](...)
  [VIP  192] CALL      call Stk[A](...)
  [VIP  193] SETREG    Stk[193] = 9
  [VIP  196] GETTABUP  Stk[196] = env['Luraph']
  [VIP  196] DT        dT(x,7,196)
  [VIP  197] GETTABUP  Stk[197] = env[K[320]]
  [VIP  197] DT        dT(x,320,197)
  [VIP  199] SETREG    Stk[199] = 62
  [VIP  200] SETREG    Stk[200] = 99
  [VIP  201] SUBI      Stk[201] = Stk[201] - 33
  [VIP  201] CALL      call Stk[A](...)
  [VIP  202] SETREG    Stk[202] = 32
  [VIP  203] LOADN     Stk[203] = 0
  [VIP  204] SETREG    Stk[204] = 96
  [VIP  205] LOADN     Stk[205] = 61
  [VIP  205] DT        dT(x,61,205)
  [VIP  206] ADD       Stk[206] = Stk[206] + 84
  [VIP  206] DT        dT(x,84,206)
  [VIP  207] ADDI      Stk[207] = Stk[207] + 20
  [VIP  208] SETTABUP  Stk['string'] = Stk[...]
  [VIP  209] SETREG    Stk[209] = 92
  [VIP  210] CALL      call Stk[A](...)
  [VIP  211] DT        dT(x,14,211)
  [VIP  212] SUBI      Stk[212] = Stk[212] - 8
  [VIP  214] ADDI      Stk[214] = Stk[214] + 31
  [VIP  220] GETTABUP  Stk[220] = env['Luraph']
  [VIP  220] DT        dT(x,7,220)
  [VIP  221] GETTABUP  Stk[221] = env[K[102]]
  [VIP  221] DT        dT(x,102,221)
  [VIP  223] SETREG    Stk[223] = 22
  [VIP  224] SETREG    Stk[224] = 80
  [VIP  224] CALL      call Stk[A](...)
  [VIP  225] ADDI      Stk[225] = Stk[225] + 17
  [VIP  226] SETTABUP  Stk[215] = Stk[...]
  [VIP  226] DT        dT(x,215,226)
  [VIP  227] ADDI      Stk[227] = Stk[227] + 20
  [VIP  228] ADDI      Stk[228] = Stk[228] + 20
  [VIP  230] ADDI      Stk[230] = Stk[230] + 30
  [VIP  233] SUBI      Stk[233] = Stk[233] - 45
  [VIP  235] GETTABUP  Stk[235] = env['Luraph']
  [VIP  235] DT        dT(x,7,235)
  [VIP  236] GETTABUP  Stk[236] = env[K[286]]
  [VIP  236] DT        dT(x,286,236)
  [VIP  238] SUBI      Stk[238] = Stk[238] - 95
  [VIP  239] SETTABUP  Stk['string'] = Stk[...]
  [VIP  240] SETREG    Stk[240] = 26
  [VIP  241] SETREG    Stk[241] = 91
  [VIP  242] SUBI      Stk[242] = Stk[242] - 86
  [VIP  245] SUBI      Stk[245] = Stk[245] - 7
  [VIP  246] DT        dT(x,405,246)
  [VIP  247] SUBI      Stk[247] = Stk[247] - 43
  [VIP  248] SUBI      Stk[248] = Stk[248] - 77
  [VIP  252] GETTABUP  Stk[252] = env['source']
  [VIP  252] DT        dT(x,51,252)
  [VIP  253] GETTABUP  Stk[253] = env['math']
  [VIP  253] DT        dT(x,70,253)
  [VIP  254] GETTABUP  Stk[254] = env[K[384]]
  [VIP  254] DT        dT(x,384,254)
  [VIP  256] SUBI      Stk[256] = Stk[256] - 31
  [VIP  257] DT        dT(x,200,257)
  [VIP  257] ADDU      Upv[257] = Upv[257] + 27
  [VIP  258] SUBI      Stk[258] = Stk[258] - 105
  [VIP  260] SETREG    Stk[260] = 91
  [VIP  261] ADD       Stk[261] = Stk[261] + 0
  [VIP  262] SUBI      Stk[262] = Stk[262] - 4
  [VIP  268] CALL      call Stk[A](...)
  [VIP  269] SUBI      Stk[269] = Stk[269] - 101
  [VIP  270] SETREG    Stk[270] = 82
  [VIP  271] SETREG    Stk[271] = 70
  [VIP  272] CALL      call Stk[A](...)
  [VIP  273] DT        dT(x,159,273)
  [VIP  274] DT        dT(x,167,274)
  [VIP  275] DT        dT(x,408,275)
  [VIP  276] SUBU      Upv[276] = Upv[276] - 38
  [VIP  278] DT        dT(x,88,278)
  [VIP  279] SETREG    Stk[279] = 64
  [VIP  280] SUBI      Stk[280] = Stk[280] - 98
  [VIP  281] DT        dT(x,508,281)
  [VIP  281] SETREG2   Upv[281] = 106
  [VIP  282] SETREG    Stk[282] = 127
  [VIP  283] SETREG    Stk[283] = 104
  [VIP  283] CALL      call Stk[A](...)
  [VIP  284] SUBI      Stk[284] = Stk[284] - 115
  [VIP  285] SETTABUP  Stk[338] = Stk[...]
  [VIP  285] DT        dT(x,338,285)
  [VIP  286] SUBI      Stk[286] = Stk[286] - 139
  [VIP  290] GETTABUP  Stk[290] = env[K[320]]
  [VIP  290] DT        dT(x,320,290)
  [VIP  291] GETTABUP  Stk[291] = env['Luraph']
  [VIP  291] DT        dT(x,7,291)
  [VIP  292] GETTABUP  Stk[292] = env['Luraph']
  [VIP  292] DT        dT(x,7,292)
  [VIP  293] GETTABUP  Stk[293] = env[K[400]]
  [VIP  293] DT        dT(x,400,293)
  [VIP  295] SUBI      Stk[295] = Stk[295] - 141
  [VIP  296] SETREG    Stk[296] = 120
  [VIP  297] SETREG    Stk[297] = 140
  [VIP    1] ADDI      Stk[1] = Stk[1] + 9
  [VIP    5] GETTABUP  Stk[5] = env[K[91]]
  [VIP    5] DT        dT(x,91,5)
  [VIP    6] GETTABUP  Stk[6] = env[K[650]]
  [VIP    6] DT        dT(x,650,6)
  [VIP    7] GETTABUP  Stk[7] = env['Luraph']
  [VIP    7] DT        dT(x,7,7)
  [VIP    8] GETTABUP  Stk[8] = env['pcall']
  [VIP    8] DT        dT(x,2,8)
  [VIP   10] ADDI      Stk[10] = Stk[10] + 28
  [VIP   11] SETREG    Stk[11] = 1
  [VIP   14] GETTABUP  Stk[14] = env['short_src']
  [VIP   14] DT        dT(x,77,14)
  [VIP   15] GETTABUP  Stk[15] = env['Luraph']
  [VIP   15] DT        dT(x,7,15)
  [VIP   16] GETTABUP  Stk[16] = env[K[123]]
  [VIP   16] DT        dT(x,123,16)
  [VIP   18] ADDI      Stk[18] = Stk[18] + 27
  [VIP   25] ADDI      Stk[25] = Stk[25] + 39
  [VIP   27] SETREG    Stk[27] = 11
  [VIP   28] ADDI      Stk[28] = Stk[28] + 11
  [VIP   31] GETTABUP  Stk[31] = env[K[461]]
  [VIP   31] DT        dT(x,461,31)
  [VIP   32] GETTABUP  Stk[32] = env[K[203]]
  [VIP   33] GETTABUP  Stk[33] = env['byte']
  [VIP   34] GETTABUP  Stk[34] = env['number']
  [VIP   35] GETTABUP  Stk[35] = env[K[123]]
  [VIP   35] DT        dT(x,123,35)
  [VIP   37] SUBI      Stk[37] = Stk[37] - 11
  [VIP   38] SUBI      Stk[38] = Stk[38] - 10
  [VIP   39] SUBI      Stk[39] = Stk[39] - 12
  [VIP   41] GETTABUP  Stk[41] = env['tonumber']
  [VIP   41] DT        dT(x,6,41)
  [VIP   42] GETTABUP  Stk[42] = env[K[98]]
  [VIP   42] DT        dT(x,98,42)
  [VIP   44] SUBI      Stk[44] = Stk[44] - 7
  [VIP   47] CALL      call Stk[A](...)
  [VIP   48] CALL      call Stk[A](...)
  [VIP   49] CALL      call Stk[A](...)
  [VIP   50] CALL      call Stk[A](...)
  [VIP   56] DT        dT(x,293,56)
  [VIP   57] DT        dT(x,122,57)
  [VIP   59] SETLIST2  rD/ZD/wD(...)
  [VIP   60] SETLIST2  rD/ZD/wD(...)
  [VIP   61] SETLIST2  rD/ZD/wD(...)
  [VIP   62] SETLIST2  rD/ZD/wD(...)
  [VIP   63] SETLIST2  rD/ZD/wD(...)
  [VIP   64] ADDI      Stk[64] = Stk[64] + 0
  [VIP   67] SUBI      Stk[67] = Stk[67] - 23
  [VIP   68] SETREG    Stk[68] = 18
  [VIP    1] ADDI      Stk[1] = Stk[1] + 740
  [VIP    2] ADDI      Stk[2] = Stk[2] + 1285
  [VIP    2] CALL      call Stk[A](...)
  [VIP    3] ADDI      Stk[3] = Stk[3] + 562
  [VIP    4] ADDI      Stk[4] = Stk[4] + 18
  [VIP    4] CALL      call Stk[A](...)
  [VIP    5] ADDI      Stk[5] = Stk[5] + 1245
  [VIP    6] CALL      call Stk[A](...)
  [VIP    7] CALL      call Stk[A](...)
  [VIP    8] DT        dT(x,142,8)
  [VIP    9] ADDI      Stk[9] = Stk[9] + 1459
  [VIP   10] GETTABUP  Stk[10] = env['band']
  [VIP   10] ADDU      Upv[10] = Upv[10] + 1626
  [VIP   11] ADDI      Stk[11] = Stk[11] + 1355
  [VIP   12] CALL      call Stk[A](...)
  [VIP   13] DT        dT(x,38,13)
  [VIP   14] ADDI      Stk[14] = Stk[14] + 1600
  [VIP   15] ADD       Stk[15] = Stk[15] + 0
  [VIP   16] ADDI      Stk[16] = Stk[16] + 191
  [VIP   21] CALL      call Stk[A](...)
  [VIP   22] ADDI      Stk[22] = Stk[22] + 605
  [VIP   23] ADDI      Stk[23] = Stk[23] + 462
  [VIP   23] CALL      call Stk[A](...)
  [VIP   24] ADDI      Stk[24] = Stk[24] + 1156
  [VIP   31] DT        dT(x,285,31)
  [VIP   33] DT        dT(x,31,33)
  [VIP   34] ADDI      Stk[34] = Stk[34] + 184
  [VIP   35] CALL      call Stk[A](...)
  [VIP   36] CALL      call Stk[A](...)
  [VIP   37] CALL      call Stk[A](...)
  [VIP   38] CALL      call Stk[A](...)
  [VIP   39] ADDI      Stk[39] = Stk[39] + 344
  [VIP   40] ADDI      Stk[40] = Stk[40] + 349
  [VIP   41] CALL      call Stk[A](...)
  [VIP   43] DT        dT(x,415,43)
  [VIP   44] ADDI      Stk[44] = Stk[44] + 1575
  [VIP   46] ADDI      Stk[46] = Stk[46] + 681
  [VIP   47] DT        dT(x,490,47)
  [VIP   48] ADDI      Stk[48] = Stk[48] + 802
  [VIP   49] CALL      call Stk[A](...)
  [VIP   53] CALL      call Stk[A](...)
  [VIP   55] ADDI      Stk[55] = Stk[55] + 1493
  [VIP   56] DT        dT(x,329,56)
  [VIP   57] ADDI      Stk[57] = Stk[57] + 1674
  [VIP   58] ADD       Stk[58] = Stk[58] + 7
  [VIP   58] DT        dT(x,7,58)
  [VIP   59] ADDI      Stk[59] = Stk[59] + 1239
  [VIP   60] ADDI      Stk[60] = Stk[60] + 51
  [VIP   61] DT        dT(x,333,61)
  [VIP   61] ADDU      Upv[61] = Upv[61] + 1181
  [VIP   62] ADDI      Stk[62] = Stk[62] + 556
  [VIP   63] ADDI      Stk[63] = Stk[63] + 1118
  [VIP   63] CALL      call Stk[A](...)
  [VIP   64] ADDI      Stk[64] = Stk[64] + 329
  [VIP   65] GETTABUP  Stk[65] = env[K[104]]
  [VIP   66] GETTABUP  Stk[66] = env[K[104]]
  [VIP   67] GETTABUP  Stk[67] = env[K[97]]
  [VIP   68] GETTABUP  Stk[68] = env[K[383]]
  [VIP   68] DT        dT(x,383,68)
  [VIP   70] ADDI      Stk[70] = Stk[70] + 1199
  [VIP   71] ADDI      Stk[71] = Stk[71] + 562
  [VIP   72] ADDI      Stk[72] = Stk[72] + 1086
  [VIP   73] DT        dT(x,185,73)
  [VIP   74] ADDI      Stk[74] = Stk[74] + 1472
  [VIP   76] ADDI      Stk[76] = Stk[76] + 1500
  [VIP   76] CALL      call Stk[A](...)
  [VIP   77] ADDI      Stk[77] = Stk[77] + 1049
  [VIP   78] ADDI      Stk[78] = Stk[78] + 301
  [VIP   81] CALL      call Stk[A](...)
  [VIP   83] ADDI      Stk[83] = Stk[83] + 831
  [VIP   94] DT        dT(x,485,94)
  [VIP   95] ADDI      Stk[95] = Stk[95] + 1455
  [VIP   96] DT        dT(x,693,96)
  [VIP   96] ADDU      Upv[96] = Upv[96] + 1305
  [VIP   97] ADDI      Stk[97] = Stk[97] + 679
  [VIP   98] ADDI      Stk[98] = Stk[98] + 1671
  [VIP   99] ADDI      Stk[99] = Stk[99] + 248
  [VIP  100] GETTABUP  Stk[100] = env[K[85]]
  [VIP  101] GETTABUP  Stk[101] = env[K[85]]
  [VIP  102] GETTABUP  Stk[102] = env[K[85]]
  [VIP  103] GETTABUP  Stk[103] = env[K[85]]
  [VIP  104] ADDI      Stk[104] = Stk[104] + 763
  [VIP  105] SETLIST2  rD/ZD/wD(...)
  [VIP  106] DT        dT(x,499,106)
  [VIP  107] ADDI      Stk[107] = Stk[107] + 749
  [VIP  108] ADD       Stk[108] = Stk[108] + 6
  [VIP  108] DT        dT(x,6,108)
  [VIP  109] ADDI      Stk[109] = Stk[109] + 491
  [VIP  110] DT        dT(x,42,110)
  [VIP  111] ADDI      Stk[111] = Stk[111] + 700
  [VIP  112] CALL      call Stk[A](...)
  [VIP  114] DT        dT(x,464,114)
  [VIP  115] ADDI      Stk[115] = Stk[115] + 282
  [VIP  118] GETTABUP  Stk[118] = env[K[89]]
  [VIP  118] DT        dT(x,89,118)
  [VIP  119] GETTABUP  Stk[119] = env[K[304]]
  [VIP  119] DT        dT(x,304,119)
  [VIP  121] ADDI      Stk[121] = Stk[121] + 1702
  [VIP  122] CALL      call Stk[A](...)
  [VIP  123] DT        dT(x,8,123)
  [VIP  124] ADDI      Stk[124] = Stk[124] + 1572
  [VIP  125] DT        dT(x,7,125)
  [VIP  126] CALL      call Stk[A](...)
  [VIP  127] CALL      call Stk[A](...)
  [VIP  128] ADDI      Stk[128] = Stk[128] + 897
  [VIP  129] ADDI      Stk[129] = Stk[129] + 132
  [VIP  136] CALL      call Stk[A](...)
  [VIP  138] DT        dT(x,592,138)
  [VIP  139] ADDI      Stk[139] = Stk[139] + 1342
  [VIP  140] SETLIST2  rD/ZD/wD(...)
  [VIP  142] DT        dT(x,106,142)
  [VIP  143] ADDI      Stk[143] = Stk[143] + 1389
  [VIP  144] DT        dT(x,52,144)
  [VIP  145] ADDI      Stk[145] = Stk[145] + 1405
  [VIP  147] CALL      call Stk[A](...)
  [VIP  148] DT        dT(x,216,148)
  [VIP  149] DT        dT(x,106,149)
  [VIP  150] DT        dT(x,57,150)
  [VIP  151] ADDU      Upv[151] = Upv[151] + 831
  [VIP  152] SETREG    Stk[152] = 48
  [VIP  155] CALL      call Stk[A](...)
  [VIP  156] ADDI      Stk[156] = Stk[156] + 1258
  [VIP  157] DT        dT(x,57,157)
  [VIP  158] ADDI      Stk[158] = Stk[158] + 653
  [VIP  159] ADD       Stk[159] = Stk[159] + 347
  [VIP  159] DT        dT(x,347,159)
  [VIP  160] ADDI      Stk[160] = Stk[160] + 595
  [VIP  161] CALL      call Stk[A](...)
  [VIP  163] DT        dT(x,339,163)
  [VIP  164] ADDI      Stk[164] = Stk[164] + 1421
  [VIP  165] DT        dT(x,36,165)
  [VIP  165] ADDU      Upv[165] = Upv[165] + 550
  [VIP  166] ADDI      Stk[166] = Stk[166] + 567
  [VIP  167] ADDI      Stk[167] = Stk[167] + 1117
  [VIP  168] ADD       Stk[168] = Stk[168] + 0
  [VIP  169] ADDI      Stk[169] = Stk[169] + 239
  [VIP  170] CALL      call Stk[A](...)
  [VIP  171] CALL      call Stk[A](...)
  [VIP  172] CALL      call Stk[A](...)
  [VIP  173] CALL      call Stk[A](...)
  [VIP  174] ADDI      Stk[174] = Stk[174] + 121
  [VIP  175] ADDI      Stk[175] = Stk[175] + 662
  [VIP  180] DT        dT(x,100,180)
  [VIP  181] ADDI      Stk[181] = Stk[181] + 1671
  [VIP  182] ADD       Stk[182] = Stk[182] + 26
  [VIP  182] DT        dT(x,26,182)
  [VIP  183] ADDI      Stk[183] = Stk[183] + 1009
  [VIP  186] ADDI      Stk[186] = Stk[186] + 1250
  [VIP  188] ADD       Stk[188] = Stk[188] + 87
  [VIP  189] ADDI      Stk[189] = Stk[189] + 791
  [VIP  190] DT        dT(x,597,190)
  [VIP  191] ADDI      Stk[191] = Stk[191] + 307
  [VIP  192] ADDI      Stk[192] = Stk[192] + 1026
  [VIP  193] ADDI      Stk[193] = Stk[193] + 1219
  [VIP  194] ADD       Stk[194] = Stk[194] + 47
  [VIP  194] DT        dT(x,47,194)
  [VIP  195] ADDI      Stk[195] = Stk[195] + 890
  [VIP  198] CALL      call Stk[A](...)
  [VIP  200] DT        dT(x,62,200)
  [VIP  201] ADDI      Stk[201] = Stk[201] + 768
  [VIP  202] CALL      call Stk[A](...)
  [VIP  203] GETTABUP  Stk[203] = env[K[85]]
  [VIP  204] DT        dT(x,19,204)
  [VIP  205] ADDI      Stk[205] = Stk[205] + 510
  [VIP  206] ADDI      Stk[206] = Stk[206] + 83
  [VIP  207] ADDI      Stk[207] = Stk[207] + 510
  [VIP  208] ADDI      Stk[208] = Stk[208] + 1038
  [VIP  209] DT        dT(x,19,209)
  [VIP  210] ADDU      Upv[210] = Upv[210] + 1076
  [VIP  211] DT        dT(x,1,211)
  [VIP  211] ADDU      Upv[211] = Upv[211] + 251
  [VIP  212] ADDI      Stk[212] = Stk[212] + 872
  [VIP  213] ADDI      Stk[213] = Stk[213] + 1235
  [VIP  213] CALL      call Stk[A](...)
  [VIP  214] ADDI      Stk[214] = Stk[214] + 1236
  [VIP  217] DT        dT(x,444,217)
  [VIP  218] ADDI      Stk[218] = Stk[218] + 909
  [VIP  219] ADDI      Stk[219] = Stk[219] + 196
  [VIP  220] CALL      call Stk[A](...)
  [VIP  221] DT        dT(x,439,221)
  [VIP  222] ADDI      Stk[222] = Stk[222] + 929
  [VIP  223] ADDI      Stk[223] = Stk[223] + 798
  [VIP  223] CALL      call Stk[A](...)
  [VIP  224] ADDI      Stk[224] = Stk[224] + 2
  [VIP  225] ADD       Stk[225] = Stk[225] + 18
  [VIP  225] DT        dT(x,18,225)
  [VIP  226] ADDI      Stk[226] = Stk[226] + 1114
  [VIP  227] CALL      call Stk[A](...)
  [VIP  228] DT        dT(x,63,228)
  [VIP  229] ADDI      Stk[229] = Stk[229] + 792
  [VIP  233] ADDI      Stk[233] = Stk[233] + 1633
  [VIP  237] CALL      call Stk[A](...)
  [VIP  239] ADDI      Stk[239] = Stk[239] + 1478
  [VIP  240] SETLIST2  rD/ZD/wD(...)
  [VIP  241] SETLIST2  rD/ZD/wD(...)
  [VIP  242] ADDI      Stk[242] = Stk[242] + 521
  [VIP  243] CALL      call Stk[A](...)
  [VIP  245] CALL      call Stk[A](...)
  [VIP  246] SETREG    Stk[246] = 34
  [VIP  249] ADDI      Stk[249] = Stk[249] + 1641
  [VIP  252] DT        dT(x,267,252)
  [VIP  253] ADDI      Stk[253] = Stk[253] + 1230
  [VIP  254] DT        dT(x,252,254)
  [VIP  256] DT        dT(x,631,256)
  [VIP  257] ADDI      Stk[257] = Stk[257] + 1422
  [VIP  258] CALL      call Stk[A](...)
  [VIP  259] GETTABUP  Stk[259] = env[K[84]]
  [VIP  260] DT        dT(x,45,260)
  [VIP  261] ADDI      Stk[261] = Stk[261] + 698
  [VIP  263] DT        dT(x,570,263)
  [VIP  264] ADDI      Stk[264] = Stk[264] + 1156
  [VIP  267] CALL      call Stk[A](...)
  [VIP  269] DT        dT(x,39,269)
  [VIP  270] ADDI      Stk[270] = Stk[270] + 939
  [VIP  271] ADDI      Stk[271] = Stk[271] + 1567
  [VIP  272] ADDI      Stk[272] = Stk[272] + 1594
  [VIP  272] CALL      call Stk[A](...)
  [VIP  273] SUBI      Stk[273] = Stk[273] - 44
  [VIP  274] DT        dT(x,714,274)
  [VIP  274] ADDU      Upv[274] = Upv[274] + 722
  [VIP  275] ADDI      Stk[275] = Stk[275] + 1346
  [VIP  276] CALL      call Stk[A](...)
  [VIP  278] CALL      call Stk[A](...)
  [VIP  279] DT        dT(x,297,279)
  [VIP  280] ADDI      Stk[280] = Stk[280] + 621
  [VIP  282] CALL      call Stk[A](...)
  [VIP  283] CALL      call Stk[A](...)
  [VIP  284] DT        dT(x,111,284)
  [VIP  285] ADDI      Stk[285] = Stk[285] + 171
  [VIP  286] DT        dT(x,114,286)
  [VIP  287] ADDI      Stk[287] = Stk[287] + 1270
  [VIP  288] ADDI      Stk[288] = Stk[288] + 523
  [VIP  289] ADDI      Stk[289] = Stk[289] + 1409
  [VIP  292] CALL      call Stk[A](...)
  [VIP  293] ADDI      Stk[293] = Stk[293] + 760
  [VIP  294] SUBI      Stk[294] = Stk[294] - 23
  [VIP  294] CALL      call Stk[A](...)
  [VIP  295] ADDI      Stk[295] = Stk[295] + 474
  [VIP  296] GETTABUP  Stk[296] = env[K[83]]
  [VIP  297] DT        dT(x,239,297)
  [VIP  298] ADDI      Stk[298] = Stk[298] + 417
  [VIP  299] ADDI      Stk[299] = Stk[299] + 1200
  [VIP  300] GETTABUP  Stk[300] = env[K[104]]
  [VIP  301] GETTABUP  Stk[301] = env[K[104]]
  [VIP  302] GETTABUP  Stk[302] = env[K[97]]
  [VIP  303] GETTABUP  Stk[303] = env[K[292]]
  [VIP  303] DT        dT(x,292,303)
  [VIP  305] ADDI      Stk[305] = Stk[305] + 994
  [VIP  309] CALL      call Stk[A](...)
  [VIP  310] DT        dT(x,300,310)
  [VIP  311] CALL      call Stk[A](...)
  [VIP  312] ADDI      Stk[312] = Stk[312] + 483
  [VIP  313] ADDI      Stk[313] = Stk[313] + 498
  [VIP  313] CALL      call Stk[A](...)
  [VIP  314] ADDI      Stk[314] = Stk[314] + 224
  [VIP  317] GETTABUP  Stk[317] = env[K[650]]
  [VIP  317] DT        dT(x,650,317)
  [VIP  318] GETTABUP  Stk[318] = env[K[432]]
  [VIP  318] DT        dT(x,432,318)
  [VIP  320] ADDI      Stk[320] = Stk[320] + 844
  [VIP  321] CALL      call Stk[A](...)
  [VIP  323] DT        dT(x,88,323)
  [VIP  324] ADDI      Stk[324] = Stk[324] + 532
  [VIP  327] CALL      call Stk[A](...)
  [VIP  328] SUBI      Stk[328] = Stk[328] - 95
  [VIP  329] GETTABUP  Stk[329] = env['setmetatable']
  [VIP  329] ADDU      Upv[329] = Upv[329] + 899
  [VIP  330] ADDI      Stk[330] = Stk[330] + 864
  [VIP  331] SETREG2   Upv[331] = 14
  [VIP  332] ADD       Stk[332] = Stk[332] + 0
  [VIP  333] ADDI      Stk[333] = Stk[333] + 798
  [VIP  334] SUBI      Stk[334] = Stk[334] - 143
  [VIP  335] ADD       Stk[335] = Stk[335] + 18
  [VIP  335] DT        dT(x,18,335)
  [VIP  336] SETREG    Stk[336] = 60
  [VIP  340] ADDI      Stk[340] = Stk[340] + 1130
  [VIP  341] ADD       Stk[341] = Stk[341] + 265
  [VIP  341] DT        dT(x,265,341)
  [VIP  342] ADDI      Stk[342] = Stk[342] + 1167
  [VIP  345] CALL      call Stk[A](...)
  [VIP  347] ADDI      Stk[347] = Stk[347] + 764
  [VIP  351] CALL      call Stk[A](...)
  [VIP  352] ADDI      Stk[352] = Stk[352] + 1536
  [VIP  353] ADDI      Stk[353] = Stk[353] + 278
  [VIP  353] CALL      call Stk[A](...)
  [VIP  354] ADDI      Stk[354] = Stk[354] + 721
  [VIP  355] ADDI      Stk[355] = Stk[355] + 101
  [VIP  355] CALL      call Stk[A](...)
  [VIP  356] ADDI      Stk[356] = Stk[356] + 477
  [VIP  358] SETREG    Stk[358] = 145
  [VIP  362] DT        dT(x,124,362)
  [VIP  363] ADDI      Stk[363] = Stk[363] + 951
  [VIP  367] GETTABUP  Stk[367] = env['function']
  [VIP  367] DT        dT(x,41,367)
  [VIP  368] GETTABUP  Stk[368] = env[K[99]]
  [VIP  368] DT        dT(x,99,368)
  [VIP  369] GETTABUP  Stk[369] = env[K[108]]
  [VIP  369] DT        dT(x,108,369)
  [VIP  371] ADDI      Stk[371] = Stk[371] + 605
  [VIP  374] ADDI      Stk[374] = Stk[374] + 671
  [VIP  375] SETLIST2  rD/ZD/wD(...)
  [VIP  376] DT        dT(x,319,376)
  [VIP  377] ADDI      Stk[377] = Stk[377] + 479
  [VIP  378] ADDI      Stk[378] = Stk[378] + 1236
  [VIP  378] CALL      call Stk[A](...)
  [VIP  379] SETREG    Stk[379] = 59
  [VIP  382] CALL      call Stk[A](...)
  [VIP  383] ADDI      Stk[383] = Stk[383] + 49
  [VIP  384] CALL      call Stk[A](...)
  [VIP  385] DT        dT(x,541,385)
  [VIP  386] ADDI      Stk[386] = Stk[386] + 627
  [VIP  387] ADDI      Stk[387] = Stk[387] + 41
  [VIP  388] DT        dT(x,93,388)
  [VIP  388] ADDU      Upv[388] = Upv[388] + 1247
  [VIP  389] ADDI      Stk[389] = Stk[389] + 1170
  [VIP  390] SETTABUP  Stk['wrap'] = Stk[...]
  [VIP  390] DT        dT(x,76,390)
  [VIP  391] ADDI      Stk[391] = Stk[391] + 356
  [VIP  392] DT        dT(x,41,392)
  [VIP  393] ADDI      Stk[393] = Stk[393] + 463
  [VIP  397] ADDI      Stk[397] = Stk[397] + 961
  [VIP  398] ADDI      Stk[398] = Stk[398] + 1216
  [VIP  400] CALL      call Stk[A](...)
  [VIP  402] ADDI      Stk[402] = Stk[402] + 535
  [VIP  405] GETTABUP  Stk[405] = env['Luraph']
  [VIP  405] DT        dT(x,7,405)
  [VIP  406] GETTABUP  Stk[406] = env[K[189]]
  [VIP  406] DT        dT(x,189,406)
  [VIP  408] ADDI      Stk[408] = Stk[408] + 1319
  [VIP  409] ADDI      Stk[409] = Stk[409] + 141
  [VIP  410] CALL      call Stk[A](...)
  [VIP  411] CALL      call Stk[A](...)
  [VIP  412] CALL      call Stk[A](...)
  [VIP  413] ADDI      Stk[413] = Stk[413] + 430
  [VIP  414] DT        dT(x,125,414)
  [VIP  414] ADDU      Upv[414] = Upv[414] + 1192
  [VIP  415] ADDI      Stk[415] = Stk[415] + 1127
  [VIP  416] ADDI      Stk[416] = Stk[416] + 861
  [VIP  416] CALL      call Stk[A](...)
  [VIP  417] ADDI      Stk[417] = Stk[417] + 1377
  [VIP  418] DT        dT(x,175,418)
  [VIP  419] ADDI      Stk[419] = Stk[419] + 1195
  [VIP  426] GETTABUP  Stk[426] = env[K[80]]
  [VIP  427] DT        dT(x,56,427)
  [VIP  428] SUBI      Stk[428] = Stk[428] - 98
  [VIP  429] DT        dT(x,608,429)
  [VIP  430] ADDI      Stk[430] = Stk[430] + 45
  [VIP  431] ADDI      Stk[431] = Stk[431] + 1005
  [VIP  432] SETREG    Stk[432] = 183
  [VIP  434] DT        dT(x,120,434)
  [VIP  435] ADDI      Stk[435] = Stk[435] + 534
  [VIP  436] DT        dT(x,65,436)
  [VIP  437] ADDI      Stk[437] = Stk[437] + 355
  [VIP  438] DT        dT(x,126,438)
  [VIP  438] ADDU      Upv[438] = Upv[438] + 1119
  [VIP  439] ADDI      Stk[439] = Stk[439] + 456
  [VIP  440] ADDI      Stk[440] = Stk[440] + 619
  [VIP  441] DT        dT(x,239,441)
  [VIP  442] ADDI      Stk[442] = Stk[442] + 1327
  [VIP  443] SETREG    Stk[443] = 97
  [VIP  446] ADDI      Stk[446] = Stk[446] + 1171
  [VIP  447] CALL      call Stk[A](...)
  [VIP  448] CALL      call Stk[A](...)
  [VIP  449] CALL      call Stk[A](...)
  [VIP  450] CALL      call Stk[A](...)
  [VIP  451] CALL      call Stk[A](...)
  [VIP  452] DT        dT(x,144,452)
  [VIP  453] ADDI      Stk[453] = Stk[453] + 1132
  [VIP  456] SUBI      Stk[456] = Stk[456] - 125
  [VIP  457] ADDI      Stk[457] = Stk[457] + 1335
  [VIP  457] CALL      call Stk[A](...)
  [VIP  458] SETREG    Stk[458] = 40
  [VIP  459] DT        dT(x,2,459)
  [VIP  459] ADDU      Upv[459] = Upv[459] + 1292
  [VIP  460] SUBI      Stk[460] = Stk[460] - 86
  [VIP  461] DT        dT(x,403,461)
  [VIP  461] ADDU      Upv[461] = Upv[461] + 653
  [VIP  462] ADDI      Stk[462] = Stk[462] + 384
  [VIP  465] CALL      call Stk[A](...)
  [VIP  467] DT        dT(x,387,467)
  [VIP  468] ADDI      Stk[468] = Stk[468] + 987
  [VIP  469] GETTABUP  Stk[469] = env[K[87]]
  [VIP  475] ADDI      Stk[475] = Stk[475] + 45
  [VIP  476] ADDI      Stk[476] = Stk[476] + 1010
  [VIP  476] CALL      call Stk[A](...)
  [VIP  477] ADDI      Stk[477] = Stk[477] + 552
  [VIP  478] CALL      call Stk[A](...)
  [VIP  480] ADDI      Stk[480] = Stk[480] + 31
  [VIP  481] SETREG    Stk[481] = 166
  [VIP  482] CALL      call Stk[A](...)
  [VIP  484] DT        dT(x,107,484)
  [VIP  485] ADDI      Stk[485] = Stk[485] + 604
  [VIP  486] LOADN     Stk[486] = 0
  [VIP  487] ADDI      Stk[487] = Stk[487] + 88
  [VIP  488] DT        dT(x,290,488)
  [VIP  489] ADDI      Stk[489] = Stk[489] + 825
  [VIP  490] GETTABUP  Stk[490] = env[K[85]]
  [VIP  491] GETTABUP  Stk[491] = env[K[309]]
  [VIP  491] DT        dT(x,309,491)
  [VIP  492] GETTABUP  Stk[492] = env[K[85]]
  [VIP  493] GETTABUP  Stk[493] = env[K[85]]
  [VIP  494] ADDI      Stk[494] = Stk[494] + 394
  [VIP  495] LOADN     Stk[495] = 0
  [VIP  496] ADDI      Stk[496] = Stk[496] + 1220
  [VIP  498] SUBI      Stk[498] = Stk[498] - 13
  [VIP  499] ADD       Stk[499] = Stk[499] + 0
  [VIP  500] ADDI      Stk[500] = Stk[500] + 1231
  [VIP  501] ADDI      Stk[501] = Stk[501] + 1248
  [VIP  501] CALL      call Stk[A](...)
  [VIP  502] SETREG    Stk[502] = 71
  [VIP  503] SETTABUP  Stk['<i8'] = Stk[...]
  [VIP  503] DT        dT(x,54,503)
  [VIP  504] SETREG    Stk[504] = 192
  [VIP  506] CALL      call Stk[A](...)
  [VIP  508] DT        dT(x,50,508)
  [VIP  509] ADDI      Stk[509] = Stk[509] + 811
  [VIP  511] SETREG    Stk[511] = 143
  [VIP  512] ADD       Stk[512] = Stk[512] + 81
  [VIP  513] ADDI      Stk[513] = Stk[513] + 1222
  [VIP  516] DT        dT(x,132,516)
  [VIP  517] ADDI      Stk[517] = Stk[517] + 468
  [VIP  518] ADDI      Stk[518] = Stk[518] + 1130
  [VIP  519] DT        dT(x,96,519)
  [VIP  519] SETREG2   Upv[519] = 181
  [VIP  520] SETREG    Stk[520] = 205
  [VIP  522] GETTABUP  Stk[522] = env['setfenv']
  [VIP  523] ADDI      Stk[523] = Stk[523] + 744
  [VIP  524] SUBI      Stk[524] = Stk[524] - 212
  [VIP  524] CALL      call Stk[A](...)
  [VIP  525] ADDI      Stk[525] = Stk[525] + 435
  [VIP  528] CALL      call Stk[A](...)
  [VIP  530] DT        dT(x,107,530)
  [VIP  531] ADDI      Stk[531] = Stk[531] + 438
  [VIP  532] ADDI      Stk[532] = Stk[532] + 476
  [VIP  535] CALL      call Stk[A](...)
  [VIP  537] DT        dT(x,386,537)
  [VIP  538] ADDI      Stk[538] = Stk[538] + 431
  [VIP  539] CALL      call Stk[A](...)
  [VIP  541] CALL      call Stk[A](...)
  [VIP  543] CALL      call Stk[A](...)
  [VIP  544] SETREG    Stk[544] = 156
  [VIP  548] ADDI      Stk[548] = Stk[548] + 1134
  [VIP  549] DT        dT(x,76,549)
  [VIP  549] ADDU      Upv[549] = Upv[549] + 352
  [VIP  550] SETREG    Stk[550] = 57
  [VIP  551] ADDI      Stk[551] = Stk[551] + 654
  [VIP  552] DT        dT(x,113,552)
  [VIP  553] DT        dT(x,49,553)
  [VIP  554] DT        dT(x,110,554)
  [VIP  555] SUBU      Upv[555] = Upv[555] - 70
  [VIP  558] GETTABUP  Stk[558] = env[K[671]]
  [VIP  558] DT        dT(x,671,558)
  [VIP  559] GETTABUP  Stk[559] = env[K[211]]
  [VIP  559] DT        dT(x,211,559)
  [VIP  561] ADDI      Stk[561] = Stk[561] + 978
  [VIP  562] SETLIST2  rD/ZD/wD(...)
  [VIP  563] SETLIST2  rD/ZD/wD(...)
  [VIP  564] DT        dT(x,16,564)
  [VIP  565] ADDI      Stk[565] = Stk[565] + 722
  [VIP  566] ADDI      Stk[566] = Stk[566] + 837
  [VIP  568] SUBI      Stk[568] = Stk[568] - 17
  [VIP  569] SUBI      Stk[569] = Stk[569] - 255
  [VIP  572] GETTABUP  Stk[572] = env[K[361]]
  [VIP  572] DT        dT(x,361,572)
  [VIP  573] GETTABUP  Stk[573] = env[K[294]]
  [VIP  573] DT        dT(x,294,573)
  [VIP  575] ADDI      Stk[575] = Stk[575] + 440
  [VIP  577] DT        dT(x,464,577)
  [VIP  578] ADDI      Stk[578] = Stk[578] + 157
  [VIP  579] DT        dT(x,36,579)
  [VIP  579] ADDU      Upv[579] = Upv[579] + 889
  [VIP  580] SUBI      Stk[580] = Stk[580] - 140
  [VIP  581] CALL      call Stk[A](...)
  [VIP  583] DT        dT(x,124,583)
  [VIP  584] SUBI      Stk[584] = Stk[584] - 128
  [VIP  585] CALL      call Stk[A](...)
  [VIP  587] CALL      call Stk[A](...)
  [VIP  588] ADDI      Stk[588] = Stk[588] + 490
  [VIP  589] ADDI      Stk[589] = Stk[589] + 943
  [VIP  589] CALL      call Stk[A](...)
  [VIP  590] ADDI      Stk[590] = Stk[590] + 412
  [VIP  593] SETREG    Stk[593] = 70
  [VIP  594] ADDI      Stk[594] = Stk[594] + 761
  [VIP  594] CALL      call Stk[A](...)
  [VIP  595] ADDI      Stk[595] = Stk[595] + 155
  [VIP  599] DT        dT(x,17,599)
  [VIP  600] ADDI      Stk[600] = Stk[600] + 976
  [VIP  601] ADDI      Stk[601] = Stk[601] + 1083
  [VIP  603] CALL      call Stk[A](...)
  [VIP  604] CALL      call Stk[A](...)
  [VIP  606] CALL      call Stk[A](...)
  [VIP  607] CALL      call Stk[A](...)
  [VIP  610] CALL      call Stk[A](...)
  [VIP  611] DT        dT(x,512,611)
  [VIP  612] SUBI      Stk[612] = Stk[612] - 260
  [VIP  615] GETTABUP  Stk[615] = env['tostring']
  [VIP  615] DT        dT(x,59,615)
  [VIP  616] GETTABUP  Stk[616] = env[K[644]]
  [VIP  616] DT        dT(x,644,616)
  [VIP  618] SUBI      Stk[618] = Stk[618] - 124
  [VIP  619] CALL      call Stk[A](...)
  [VIP  621] DT        dT(x,111,621)
  [VIP  622] ADDI      Stk[622] = Stk[622] + 391
  [VIP  624] GETTABUP  Stk[624] = env['setfenv']
  [VIP  625] ADD       Stk[625] = Stk[625] + 1
  [VIP  625] DT        dT(x,1,625)
  [VIP  626] SETREG    Stk[626] = 128
  [VIP  627] ADDI      Stk[627] = Stk[627] + 163
  [VIP  628] CALL      call Stk[A](...)
  [VIP  629] DT        dT(x,222,629)
  [VIP  630] DT        dT(x,559,630)
  [VIP  631] SETREG    Stk[631] = 208
  [VIP  632] SUBI      Stk[632] = Stk[632] - 280
  [VIP  632] CALL      call Stk[A](...)
  [VIP  633] ADDI      Stk[633] = Stk[633] + 947
  [VIP  636] GETTABUP  Stk[636] = env[K[108]]
  [VIP  636] DT        dT(x,108,636)
  [VIP  637] GETTABUP  Stk[637] = env[K[104]]
  [VIP  638] GETTABUP  Stk[638] = env[K[104]]
  [VIP  639] GETTABUP  Stk[639] = env[K[99]]
  [VIP  640] GETTABUP  Stk[640] = env[K[406]]
  [VIP  640] DT        dT(x,406,640)
  [VIP  642] ADDI      Stk[642] = Stk[642] + 1123
  [VIP  643] ADDI      Stk[643] = Stk[643] + 105
  [VIP  644] SETLIST2  rD/ZD/wD(...)
  [VIP  645] CALL      call Stk[A](...)
  [VIP  648] CALL      call Stk[A](...)
  [VIP  650] SETREG    Stk[650] = 121
  [VIP  651] DT        dT(x,690,651)
  [VIP  652] ADDI      Stk[652] = Stk[652] + 933
  [VIP  653] DT        dT(x,107,653)
  [VIP  654] ADDI      Stk[654] = Stk[654] + 81
  [VIP  656] ADDI      Stk[656] = Stk[656] + 296
  [VIP  660] DT        dT(x,363,660)
  [VIP  660] CALL      call Stk[A](...)
  [VIP  662] ADDI      Stk[662] = Stk[662] + 231
  [VIP  663] ADDI      Stk[663] = Stk[663] + 119
  [VIP  665] DT        dT(x,13,665)
  [VIP  669] DT        dT(x,56,669)
  [VIP  670] DT        dT(x,13,670)
  [VIP  671] ADDI      Stk[671] = Stk[671] + 312
  [VIP  672] SETTABUP  Stk[515] = Stk[...]
  [VIP  672] DT        dT(x,515,672)
  [VIP  673] ADDI      Stk[673] = Stk[673] + 291
  [VIP  674] SETLIST2  rD/ZD/wD(...)
  [VIP  675] DT        dT(x,318,675)
  [VIP  676] ADDI      Stk[676] = Stk[676] + 611
  [VIP  678] DT        dT(x,594,678)
  [VIP  680] ADDI      Stk[680] = Stk[680] + 442
  [VIP  682] DT        dT(x,27,682)
  [VIP  683] ADDI      Stk[683] = Stk[683] + 439
  [VIP  686] GETTABUP  Stk[686] = env[K[104]]
  [VIP  686] CALL      call Stk[A](...)
  [VIP  687] ADDI      Stk[687] = Stk[687] + 163
  [VIP  688] SETREG    Stk[688] = 46
  [VIP  689] ADD       Stk[689] = Stk[689] + 104
  [VIP  690] ADDI      Stk[690] = Stk[690] + 113
  [VIP  692] SETLIST2  rD/ZD/wD(...)
  [VIP  694] CALL      call Stk[A](...)
  [VIP  695] SETREG    Stk[695] = 139
  [VIP  708] ADDI      Stk[708] = Stk[708] + 1127
  [VIP  709] DT        dT(x,26,709)
  [VIP  709] ADDU      Upv[709] = Upv[709] + 1150
  [VIP  710] SUBI      Stk[710] = Stk[710] - 354
  [VIP  711] ADDU      Upv[711] = Upv[711] + 560
  [VIP  712] SETREG    Stk[712] = 261
  [VIP  713] CALL      call Stk[A](...)
  [VIP  714] DT        dT(x,124,714)
  [VIP  715] ADDI      Stk[715] = Stk[715] + 24
  [VIP  716] ADD       Stk[716] = Stk[716] + 94
  [VIP  716] DT        dT(x,94,716)
  [VIP  717] ADDI      Stk[717] = Stk[717] + 765
  [VIP  721] GETTABUP  Stk[721] = env[K[86]]
  [VIP  721] DT        dT(x,86,721)
  [VIP  722] GETTABUP  Stk[722] = env[K[90]]
  [VIP  722] DT        dT(x,90,722)
  [VIP  723] GETTABUP  Stk[723] = env[K[618]]
  [VIP  723] DT        dT(x,618,723)
  [VIP  725] ADDI      Stk[725] = Stk[725] + 1012
  [VIP  726] DT        dT(x,4,726)
  [VIP  726] ADDU      Upv[726] = Upv[726] + 1015
  [VIP  727] SUBI      Stk[727] = Stk[727] - 195
  [VIP  733] SETREG    Stk[733] = 336
  [VIP  734] SETTABUP  Stk['gmatch'] = Stk[...]
  [VIP  734] DT        dT(x,5,734)
  [VIP  735] SETREG    Stk[735] = 201
  [VIP  736] DT        dT(x,60,736)
  [VIP  736] ADDU      Upv[736] = Upv[736] + 1031
  [VIP  737] ADDI      Stk[737] = Stk[737] + 404
  [VIP  738] DT        dT(x,482,738)
  [VIP  739] ADDI      Stk[739] = Stk[739] + 548
  [VIP  740] ADD       Stk[740] = Stk[740] + 4
  [VIP  740] CALL      call Stk[A](...)
  [VIP  741] SUBI      Stk[741] = Stk[741] - 115
  [VIP  743] CALL      call Stk[A](...)
  [VIP  744] CALL      call Stk[A](...)
  [VIP  745] DT        dT(x,27,745)
  [VIP  746] ADDI      Stk[746] = Stk[746] + 275
  [VIP  747] ADDI      Stk[747] = Stk[747] + 644
  [VIP  748] ADDI      Stk[748] = Stk[748] + 70
  [VIP  749] ADD       Stk[749] = Stk[749] + 4
  [VIP  749] DT        dT(x,4,749)
  [VIP  750] ADDI      Stk[750] = Stk[750] + 559
  [VIP  754] SETREG    Stk[754] = 72
  [VIP  756] SETLIST2  rD/ZD/wD(...)
  [VIP  757] SETLIST2  rD/ZD/wD(...)
  [VIP  758] CALL      call Stk[A](...)
  [VIP  759] CALL      call Stk[A](...)
  [VIP  761] ADDI      Stk[761] = Stk[761] + 761
  [VIP  762] ADD       Stk[762] = Stk[762] + 103
  [VIP  762] DT        dT(x,103,762)
  [VIP  763] ADDI      Stk[763] = Stk[763] + 103
  [VIP  766] DT        dT(x,707,766)
  [VIP  767] SUBI      Stk[767] = Stk[767] - 91
  [VIP  768] DT        dT(x,238,768)
  [VIP  769] ADDI      Stk[769] = Stk[769] + 23
  [VIP  771] CALL      call Stk[A](...)
  [VIP  776] ADDI      Stk[776] = Stk[776] + 1090
  [VIP  778] ADDI      Stk[778] = Stk[778] + 556
  [VIP  779] CALL      call Stk[A](...)
  [VIP  782] SETREG    Stk[782] = 285
  [VIP  783] DT        dT(x,374,783)
  [VIP  784] ADDI      Stk[784] = Stk[784] + 109
  [VIP  789] CALL      call Stk[A](...)
  [VIP  790] ADDI      Stk[790] = Stk[790] + 435
  [VIP  791] ADDI      Stk[791] = Stk[791] + 882
  [VIP  791] CALL      call Stk[A](...)
  [VIP  792] ADDI      Stk[792] = Stk[792] + 991
  [VIP  793] LOADN     Stk[793] = 74
  [VIP  793] DT        dT(x,74,793)
  [VIP  794] SETREG    Stk[794] = 9
  [VIP  795] SETREG    Stk[795] = 305
  [VIP  796] CALL      call Stk[A](...)
  [VIP  798] CALL      call Stk[A](...)
  [VIP  799] CALL      call Stk[A](...)
  [VIP  801] SETREG    Stk[801] = 206
  [VIP  802] DT        dT(x,595,802)
  [VIP  803] ADDI      Stk[803] = Stk[803] + 775
  [VIP  804] DT        dT(x,75,804)
  [VIP  805] ADDI      Stk[805] = Stk[805] + 103
  [VIP  809] CALL      call Stk[A](...)
  [VIP  810] ADD       Stk[810] = Stk[810] + 84
  [VIP  811] SETREG    Stk[811] = 371
  [VIP  812] ADDI      Stk[812] = Stk[812] + 337
  [VIP  812] CALL      call Stk[A](...)
  [VIP  813] ADDI      Stk[813] = Stk[813] + 422
  [VIP  814] ADDI      Stk[814] = Stk[814] + 38
  [VIP  818] ADDI      Stk[818] = Stk[818] + 7
  [VIP  819] DT        dT(x,223,819)
  [VIP  821] SETLIST2  rD/ZD/wD(...)
  [VIP  825] ADDI      Stk[825] = Stk[825] + 328
  [VIP  826] ADDI      Stk[826] = Stk[826] + 981
  [VIP  828] CALL      call Stk[A](...)
  [VIP  829] CALL      call Stk[A](...)
  [VIP  830] ADDI      Stk[830] = Stk[830] + 812
  [VIP  832] DT        dT(x,64,832)
  [VIP  832] SUBU      Upv[832] = Upv[832] - 122
  [VIP  833] ADDI      Stk[833] = Stk[833] + 109
  [VIP  834] CALL      call Stk[A](...)
  [VIP  835] CALL      call Stk[A](...)
  [VIP  836] CALL      call Stk[A](...)
  [VIP  837] SETREG    Stk[837] = 409
  [VIP  840] GETTABUP  Stk[840] = env[K[650]]
  [VIP  840] DT        dT(x,650,840)
  [VIP  841] GETTABUP  Stk[841] = env[K[492]]
  [VIP  841] DT        dT(x,492,841)
  [VIP  843] ADDI      Stk[843] = Stk[843] + 248
  [VIP  844] CALL      call Stk[A](...)
  [VIP  845] DT        dT(x,353,845)
  [VIP  846] ADDI      Stk[846] = Stk[846] + 268
  [VIP  847] CALL      call Stk[A](...)
  [VIP  848] DT        dT(x,701,848)
  [VIP  849] ADDI      Stk[849] = Stk[849] + 265
  [VIP  851] LOADN     Stk[851] = 104
  [VIP  852] ADDI      Stk[852] = Stk[852] + 577
  [VIP  853] CALL      call Stk[A](...)
  [VIP  855] DT        dT(x,290,855)
  [VIP  856] ADDI      Stk[856] = Stk[856] + 509
  [VIP  857] SETREG    Stk[857] = 402
  [VIP  858] SETREG    Stk[858] = 175
  [VIP  859] DT        dT(x,103,859)
  [VIP  859] ADDU      Upv[859] = Upv[859] + 837
  [VIP  860] ADDI      Stk[860] = Stk[860] + 71
  [VIP  861] ADDI      Stk[861] = Stk[861] + 395
  [VIP  863] ADDI      Stk[863] = Stk[863] + 555
  [VIP  865] DT        dT(x,608,865)
  [VIP  866] ADDI      Stk[866] = Stk[866] + 343
  [VIP  867] ADDI      Stk[867] = Stk[867] + 840
  [VIP  868] GETTABUP  Stk[868] = env[K[85]]
  [VIP  869] GETTABUP  Stk[869] = env[K[85]]
  [VIP  870] GETTABUP  Stk[870] = env[K[85]]
  [VIP  871] GETTABUP  Stk[871] = env[K[85]]
  [VIP  872] SUBI      Stk[872] = Stk[872] - 383
  [VIP  873] DT        dT(x,114,873)
  [VIP  874] DT        dT(x,672,874)
  [VIP  875] DT        dT(x,120,875)
  [VIP  876] ADDU      Upv[876] = Upv[876] + 990
  [VIP  879] GETTABUP  Stk[879] = env[K[170]]
  [VIP  879] DT        dT(x,170,879)
  [VIP  880] GETTABUP  Stk[880] = env[K[514]]
  [VIP  880] DT        dT(x,514,880)
  [VIP  882] ADDI      Stk[882] = Stk[882] + 691
  [VIP  885] GETTABUP  Stk[885] = env['Your Lua environment does not support lo...']
  [VIP  885] DT        dT(x,32,885)
  [VIP  886] GETTABUP  Stk[886] = env[K[493]]
  [VIP  886] DT        dT(x,493,886)
  [VIP  888] ADDI      Stk[888] = Stk[888] + 118
  [VIP  889] GETTABUP  Stk[889] = env[K[85]]
  [VIP  890] GETTABUP  Stk[890] = env[K[85]]
  [VIP  891] GETTABUP  Stk[891] = env[K[85]]
  [VIP  892] GETTABUP  Stk[892] = env[K[85]]
  [VIP  893] ADDI      Stk[893] = Stk[893] + 797
  [VIP  894] LOADN     Stk[894] = 104
  [VIP  895] ADDI      Stk[895] = Stk[895] + 345
  [VIP  898] DT        dT(x,380,898)
  [VIP  900] DT        dT(x,127,900)
  [VIP  901] ADDI      Stk[901] = Stk[901] + 656
  [VIP  902] DT        dT(x,1,902)
  [VIP  902] ADDU      Upv[902] = Upv[902] + 373
  [VIP  903] ADDI      Stk[903] = Stk[903] + 495
  [VIP  904] DT        dT(x,90,904)
  [VIP  904] ADDU      Upv[904] = Upv[904] + 139
  [VIP  905] SUBI      Stk[905] = Stk[905] - 388
  [VIP  907] DT        dT(x,45,907)
  [VIP  908] ADDI      Stk[908] = Stk[908] + 44
  [VIP  909] GETTABUP  Stk[909] = env[K[104]]
  [VIP  910] GETTABUP  Stk[910] = env[K[104]]
  [VIP  911] GETTABUP  Stk[911] = env[K[97]]
  [VIP  912] GETTABUP  Stk[912] = env[K[695]]
  [VIP  912] DT        dT(x,695,912)
  [VIP  914] SETREG    Stk[914] = 167
  [VIP  915] DT        dT(x,323,915)
  [VIP  916] ADDI      Stk[916] = Stk[916] + 72
  [VIP  917] DT        dT(x,7,917)
  [VIP  918] CALL      call Stk[A](...)
  [VIP  919] DT        dT(x,252,919)
  [VIP  920] CALL      call Stk[A](...)
  [VIP  921] CALL      call Stk[A](...)
  [VIP  923] CALL      call Stk[A](...)
  [VIP  924] DT        dT(x,252,924)
  [VIP  925] CALL      call Stk[A](...)
  [VIP  926] CALL      call Stk[A](...)
  [VIP  928] CALL      call Stk[A](...)
  [VIP  929] SETREG    Stk[929] = 253
  [VIP  930] DT        dT(x,59,930)
  [VIP  930] ADDU      Upv[930] = Upv[930] + 52
  [VIP  931] ADDI      Stk[931] = Stk[931] + 692
  [VIP  936] DT        dT(x,57,936)
  [VIP  937] ADDI      Stk[937] = Stk[937] + 759
  [VIP  938] CALL      call Stk[A](...)
  [VIP  940] CALL      call Stk[A](...)
  [VIP  942] ADDI      Stk[942] = Stk[942] + 12
  [VIP  950] SETREG    Stk[950] = 186
  [VIP  951] ADD       Stk[951] = Stk[951] + 77
  [VIP  951] DT        dT(x,77,951)
  [VIP  952] ADDI      Stk[952] = Stk[952] + 921
  [VIP  953] ADD       Stk[953] = Stk[953] + 78
  [VIP  953] CALL      call Stk[A](...)
  [VIP  954] SETREG    Stk[954] = 288
  [VIP  955] CALL      call Stk[A](...)
  [VIP  957] GETTABUP  Stk[957] = env[K[80]]
  [VIP  958] DT        dT(x,56,958)
  [VIP  959] SETREG2   Upv[959] = 331
  [VIP  960] SUBI      Stk[960] = Stk[960] - 245
  [VIP  961] CALL      call Stk[A](...)
  [VIP  963] DT        dT(x,127,963)
  [VIP  964] SETREG    Stk[964] = 287
  [VIP  965] CALL      call Stk[A](...)
  [VIP  966] DT        dT(x,582,966)
  [VIP  967] ADDI      Stk[967] = Stk[967] + 147
  [VIP  968] DT        dT(x,129,968)
  [VIP  969] ADDI      Stk[969] = Stk[969] + 884
  [VIP  970] LOADN     Stk[970] = 93
  [VIP  970] DT        dT(x,93,970)
  [VIP  971] SUBI      Stk[971] = Stk[971] - 453
  [VIP  975] SUBI      Stk[975] = Stk[975] - 265
  [VIP  976] SUBI      Stk[976] = Stk[976] - 146
  [VIP  977] CALL      call Stk[A](...)
  [VIP  978] CALL      call Stk[A](...)
  [VIP  979] DT        dT(x,111,979)
  [VIP  980] ADDI      Stk[980] = Stk[980] + 93
  [VIP  981] DT        dT(x,7,981)
  [VIP  982] SUBI      Stk[982] = Stk[982] - 360
  [VIP  983] SUBI      Stk[983] = Stk[983] - 371
  [VIP  984] DT        dT(x,56,984)
  [VIP  985] ADDU      Upv[985] = Upv[985] + 212
  [VIP  987] DT        dT(x,83,987)
  [VIP  988] SETREG    Stk[988] = 415
  [VIP  989] ADD       Stk[989] = Stk[989] + 4
  [VIP  989] CALL      call Stk[A](...)
  [VIP  990] SETREG    Stk[990] = 239
  [VIP  991] SUBI      Stk[991] = Stk[991] - 115
  [VIP  992] ADDI      Stk[992] = Stk[992] + 769
  [VIP  993] CALL      call Stk[A](...)
  [VIP  995] DT        dT(x,8,995)
  [VIP  996] SUBI      Stk[996] = Stk[996] - 185
  [VIP  997] ADD       Stk[997] = Stk[997] + 714
  [VIP  997] DT        dT(x,714,997)
  [VIP  998] ADDI      Stk[998] = Stk[998] + 665
  [VIP 1001] DT        dT(x,549,1001)
  [VIP 1002] SUBI      Stk[1002] = Stk[1002] - 322
  [VIP 1003] CALL      call Stk[A](...)
  [VIP 1005] DT        dT(x,580,1005)
  [VIP 1006] ADDI      Stk[1006] = Stk[1006] + 526
  [VIP 1007] DT        dT(x,26,1007)
  [VIP 1007] ADDU      Upv[1007] = Upv[1007] + 527
  [VIP 1008] SUBI      Stk[1008] = Stk[1008] - 366
  [VIP 1012] DT        dT(x,7,1012)
  [VIP 1013] SETREG    Stk[1013] = 124
  [VIP 1014] LOADN     Stk[1014] = 125
  [VIP 1014] DT        dT(x,125,1014)
  [VIP 1015] SUBI      Stk[1015] = Stk[1015] - 202
  [VIP 1016] DT        dT(x,56,1016)
  [VIP 1017] CALL      call Stk[A](...)
  [VIP 1018] CALL      call Stk[A](...)
  [VIP 1019] ADDI      Stk[1019] = Stk[1019] + 768
  [VIP 1020] DT        dT(x,53,1020)
  [VIP 1020] SUBU      Upv[1020] = Upv[1020] - 259
  [VIP 1021] SUBI      Stk[1021] = Stk[1021] - 164
  [VIP 1022] SETREG    Stk[1022] = 222
  [VIP 1022] CALL      call Stk[A](...)
  [VIP 1023] ADDI      Stk[1023] = Stk[1023] + 657
  [VIP 1024] SETREG    Stk[1024] = 498
  [VIP 1024] CALL      call Stk[A](...)
  [VIP 1025] SETREG    Stk[1025] = 55
  [VIP 1026] DT        dT(x,105,1026)
  [VIP 1027] DT        dT(x,271,1027)
  [VIP 1028] DT        dT(x,686,1028)
  [VIP 1029] ADDI      Stk[1029] = Stk[1029] + 84
  [VIP 1036] DT        dT(x,39,1036)
  [VIP 1037] ADDI      Stk[1037] = Stk[1037] + 579
  [VIP 1038] SUBI      Stk[1038] = Stk[1038] - 448
  [VIP 1041] DT        dT(x,280,1041)
  [VIP 1043] SUBI      Stk[1043] = Stk[1043] - 518
  [VIP 1044] ADD       Stk[1044] = Stk[1044] + 90
  [VIP 1044] DT        dT(x,90,1044)
  [VIP 1045] SETREG    Stk[1045] = 160
  [VIP 1047] CALL      call Stk[A](...)
  [VIP 1049] ADDI      Stk[1049] = Stk[1049] + 427
  [VIP 1050] CALL      call Stk[A](...)
  [VIP 1051] SETLIST2  rD/ZD/wD(...)
  [VIP 1052] CALL      call Stk[A](...)
  [VIP 1053] SUBI      Stk[1053] = Stk[1053] - 452
  [VIP 1055] DT        dT(x,38,1055)
  [VIP 1056] SUBI      Stk[1056] = Stk[1056] - 87
  [VIP 1057] CALL      call Stk[A](...)
  [VIP 1058] DT        dT(x,628,1058)
  [VIP 1059] ADDI      Stk[1059] = Stk[1059] + 526
  [VIP 1062] CALL      call Stk[A](...)
  [VIP 1065] SETREG    Stk[1065] = 504
  [VIP 1068] CALL      call Stk[A](...)
  [VIP 1070] SETREG    Stk[1070] = 513
  [VIP 1071] CALL      call Stk[A](...)
  [VIP 1073] SETREG    Stk[1073] = 446
  [VIP 1074] DT        dT(x,118,1074)
  [VIP 1074] SETREG2   Upv[1074] = 224
  [VIP 1075] SETREG    Stk[1075] = 531
  [VIP 1076] SETLIST2  rD/ZD/wD(...)
  [VIP 1077] DT        dT(x,105,1077)
  [VIP 1078] SETREG    Stk[1078] = 352
  [VIP 1079] CALL      call Stk[A](...)
  [VIP 1080] CALL      call Stk[A](...)
  [VIP 1081] CALL      call Stk[A](...)
  [VIP 1082] SETREG    Stk[1082] = 417
  [VIP 1083] DT        dT(x,200,1083)
  [VIP 1083] ADDU      Upv[1083] = Upv[1083] + 660
  [VIP 1084] SUBI      Stk[1084] = Stk[1084] - 46
  [VIP 1085] ADDI      Stk[1085] = Stk[1085] + 113
  [VIP 1086] DT        dT(x,7,1086)
  [VIP 1087] DT        dT(x,556,1087)
  [VIP 1088] DT        dT(x,56,1088)
  [VIP 1089] ADDU      Upv[1089] = Upv[1089] + 178
  [VIP 1090] ADDI      Stk[1090] = Stk[1090] + 524
  [VIP 1091] ADDI      Stk[1091] = Stk[1091] + 738
  [VIP 1092] ADD       Stk[1092] = Stk[1092] + 37
  [VIP 1092] DT        dT(x,37,1092)
  [VIP 1093] SETREG    Stk[1093] = 151
  [VIP 1094] SUBI      Stk[1094] = Stk[1094] - 280
  [VIP 1099] SUBI      Stk[1099] = Stk[1099] - 238
  [VIP 1100] SUBI      Stk[1100] = Stk[1100] - 112
  [VIP 1101] CALL      call Stk[A](...)
  [VIP 1102] CALL      call Stk[A](...)
  [VIP 1103] CALL      call Stk[A](...)
  [VIP 1104] CALL      call Stk[A](...)
  [VIP 1105] CALL      call Stk[A](...)
  [VIP 1107] CALL      call Stk[A](...)
  [VIP 1108] SETREG    Stk[1108] = 109
  [VIP 1109] CALL      call Stk[A](...)
  [VIP 1110] DT        dT(x,49,1110)
  [VIP 1111] SUBI      Stk[1111] = Stk[1111] - 210
  [VIP 1112] DT        dT(x,42,1112)
  [VIP 1113] ADDI      Stk[1113] = Stk[1113] + 444
  [VIP 1114] SETREG2   Upv[1114] = 498
  [VIP 1115] ADD       Stk[1115] = Stk[1115] + 403
  [VIP 1115] DT        dT(x,403,1115)
  [VIP 1116] ADDI      Stk[1116] = Stk[1116] + 280
  [VIP 1118] DT        dT(x,318,1118)
  [VIP 1120] GETTABUP  Stk[1120] = env[K[80]]
  [VIP 1121] DT        dT(x,56,1121)
  [VIP 1122] ADDI      Stk[1122] = Stk[1122] + 18
  [VIP 1123] ADD       Stk[1123] = Stk[1123] + 29
  [VIP 1123] DT        dT(x,29,1123)
  [VIP 1124] SUBI      Stk[1124] = Stk[1124] - 126
  [VIP 1125] ADD       Stk[1125] = Stk[1125] + 28
  [VIP 1125] DT        dT(x,28,1125)
  [VIP 1126] SUBI      Stk[1126] = Stk[1126] - 266
  [VIP 1127] ADDI      Stk[1127] = Stk[1127] + 467
  [VIP 1129] DT        dT(x,167,1129)
  [VIP 1130] SUBI      Stk[1130] = Stk[1130] - 161
  [VIP 1133] SUBI      Stk[1133] = Stk[1133] - 181
  [VIP 1136] GETTABUP  Stk[1136] = env[K[104]]
  [VIP 1136] CALL      call Stk[A](...)
  [VIP 1137] SUBI      Stk[1137] = Stk[1137] - 449
  [VIP 1138] ADDI      Stk[1138] = Stk[1138] + 225
  [VIP 1139] DT        dT(x,562,1139)
  [VIP 1139] SUBU      Upv[1139] = Upv[1139] - 468
  [VIP 1140] ADDI      Stk[1140] = Stk[1140] + 491
  [VIP 1141] SUBI      Stk[1141] = Stk[1141] - 485
  [VIP 1142] ADD       Stk[1142] = Stk[1142] + 93
  [VIP 1142] DT        dT(x,93,1142)
  [VIP 1143] SUBI      Stk[1143] = Stk[1143] - 271
  [VIP 1144] DT        dT(x,222,1144)
  [VIP 1145] ADDI      Stk[1145] = Stk[1145] + 310
  [VIP 1146] SETREG    Stk[1146] = 371
  [VIP 1147] SUBI      Stk[1147] = Stk[1147] - 342
  [VIP 1148] SETREG    Stk[1148] = 1
  [VIP 1148] CALL      call Stk[A](...)
  [VIP 1149] SETREG    Stk[1149] = 561
  [VIP 1150] SETREG    Stk[1150] = 523
  [VIP 1150] CALL      call Stk[A](...)
  [VIP 1151] SUBI      Stk[1151] = Stk[1151] - 159
  [VIP 1152] DT        dT(x,59,1152)
  [VIP 1152] SETREG2   Upv[1152] = 158
  [VIP 1153] ADDI      Stk[1153] = Stk[1153] + 708
  [VIP 1158] ADDI      Stk[1158] = Stk[1158] + 128
  [VIP 1164] ADDI      Stk[1164] = Stk[1164] + 641
  [VIP 1165] CALL      call Stk[A](...)
  [VIP 1172] CALL      call Stk[A](...)
  [VIP 1174] CALL      call Stk[A](...)
  [VIP 1175] SETREG    Stk[1175] = 280
  [VIP 1176] SETREG    Stk[1176] = 293
  [VIP 1176] CALL      call Stk[A](...)
  [VIP 1177] SUBI      Stk[1177] = Stk[1177] - 514
  [VIP 1178] CALL      call Stk[A](...)
  [VIP 1180] SETREG    Stk[1180] = 5
  [VIP 1181] ADDI      Stk[1181] = Stk[1181] + 291
  [VIP 1185] SUBI      Stk[1185] = Stk[1185] - 418
  [VIP 1186] SETLIST2  rD/ZD/wD(...)
  [VIP 1187] DT        dT(x,401,1187)
  [VIP 1188] SUBI      Stk[1188] = Stk[1188] - 332
  [VIP 1190] DT        dT(x,38,1190)
  [VIP 1191] SUBI      Stk[1191] = Stk[1191] - 456
  [VIP 1192] ADDI      Stk[1192] = Stk[1192] + 437
  [VIP 1193] DT        dT(x,334,1193)
  [VIP 1193] ADDU      Upv[1193] = Upv[1193] + 286
  [VIP 1194] SETREG    Stk[1194] = 152
  [VIP 1197] ADDI      Stk[1197] = Stk[1197] + 31
  [VIP 1198] SETREG    Stk[1198] = 555
  [VIP 1201] DT        dT(x,444,1201)
  [VIP 1203] SUBI      Stk[1203] = Stk[1203] - 212
  [VIP 1204] ADDI      Stk[1204] = Stk[1204] + 5
  [VIP 1204] CALL      call Stk[A](...)
  [VIP 1205] SETREG    Stk[1205] = 264
  [VIP 1208] DT        dT(x,134,1208)
  [VIP 1209] SUBI      Stk[1209] = Stk[1209] - 110
  [VIP 1210] SUBI      Stk[1210] = Stk[1210] - 7
  [VIP 1210] CALL      call Stk[A](...)
  [VIP 1211] ADDI      Stk[1211] = Stk[1211] + 215
  [VIP 1214] CALL      call Stk[A](...)
  [VIP 1218] ADDI      Stk[1218] = Stk[1218] + 342
  [VIP 1222] GETTABUP  Stk[1222] = env[K[205]]
  [VIP 1222] CALL      call Stk[A](...)
  [VIP 1224] ADDI      Stk[1224] = Stk[1224] + 354
  [VIP 1225] SUBI      Stk[1225] = Stk[1225] - 424
  [VIP 1227] DT        dT(x,185,1227)
  [VIP 1228] SUBI      Stk[1228] = Stk[1228] - 436
  [VIP 1229] DT        dT(x,124,1229)
  [VIP 1230] SUBI      Stk[1230] = Stk[1230] - 157
  [VIP 1231] CALL      call Stk[A](...)
  [VIP 1234] DT        dT(x,404,1234)
  [VIP 1235] SUBI      Stk[1235] = Stk[1235] - 372
  [VIP 1236] CALL      call Stk[A](...)
  [VIP 1238] SETREG    Stk[1238] = 242
  [VIP 1239] LOADN     Stk[1239] = 2
  [VIP 1239] DT        dT(x,2,1239)
  [VIP 1240] ADDI      Stk[1240] = Stk[1240] + 505
  [VIP 1241] DT        dT(x,171,1241)
  [VIP 1242] SETREG    Stk[1242] = 299
  [VIP 1243] DT        dT(x,125,1243)
  [VIP 1243] SUBU      Upv[1243] = Upv[1243] - 230
  [VIP 1244] ADDI      Stk[1244] = Stk[1244] + 250
  [VIP 1245] DT        dT(x,385,1245)
  [VIP 1245] ADDU      Upv[1245] = Upv[1245] + 340
  [VIP 1246] ADDI      Stk[1246] = Stk[1246] + 618
  [VIP 1250] SUBI      Stk[1250] = Stk[1250] - 62
  [VIP 1251] ADDI      Stk[1251] = Stk[1251] + 191
  [VIP 1252] SETREG    Stk[1252] = 588
  [VIP 1252] CALL      call Stk[A](...)
  [VIP 1253] ADDI      Stk[1253] = Stk[1253] + 283
  [VIP 1256] ADDI      Stk[1256] = Stk[1256] + 97
  [VIP 1259] CALL      call Stk[A](...)
  [VIP 1261] ADDI      Stk[1261] = Stk[1261] + 266
  [VIP 1264] SETREG    Stk[1264] = 14
  [VIP 1265] SETREG    Stk[1265] = 115
  [VIP 1266] SETREG    Stk[1266] = 415
  [VIP 1266] CALL      call Stk[A](...)
  [VIP 1267] SUBI      Stk[1267] = Stk[1267] - 521
  [VIP 1268] LOADN     Stk[1268] = 0
  [VIP 1269] ADDI      Stk[1269] = Stk[1269] + 293
  [VIP 1270] DT        dT(x,22,1270)
  [VIP 1270] ADDU      Upv[1270] = Upv[1270] + 97
  [VIP 1271] ADDI      Stk[1271] = Stk[1271] + 597
  [VIP 1273] CALL      call Stk[A](...)
  [VIP 1275] SUBI      Stk[1275] = Stk[1275] - 304
  [VIP 1276] LOADN     Stk[1276] = 1
  [VIP 1276] DT        dT(x,1,1276)
  [VIP 1277] SUBI      Stk[1277] = Stk[1277] - 169
  [VIP 1278] SUBI      Stk[1278] = Stk[1278] - 13
  [VIP 1278] CALL      call Stk[A](...)
  [VIP 1279] SETREG    Stk[1279] = 24
  [VIP 1280] CALL      call Stk[A](...)
  [VIP 1281] CALL      call Stk[A](...)
  [VIP 1282] CALL      call Stk[A](...)
  [VIP 1283] CALL      call Stk[A](...)
  [VIP 1284] SUBI      Stk[1284] = Stk[1284] - 458
  [VIP 1285] CALL      call Stk[A](...)
  [VIP 1286] SETREG    Stk[1286] = 511
  [VIP 1287] SUBI      Stk[1287] = Stk[1287] - 154
  [VIP 1288] ADDI      Stk[1288] = Stk[1288] + 204
  [VIP 1288] CALL      call Stk[A](...)
  [VIP 1289] ADDI      Stk[1289] = Stk[1289] + 255
  [VIP 1290] DT        dT(x,656,1290)
  [VIP 1291] DT        dT(x,111,1291)
  [VIP 1292] ADDI      Stk[1292] = Stk[1292] + 22
  [VIP 1293] DT        dT(x,309,1293)
  [VIP 1293] SETREG2   Upv[1293] = 273
  [VIP 1294] SETREG    Stk[1294] = 39
  [VIP 1295] CALL      call Stk[A](...)
  [VIP 1296] SETLIST2  rD/ZD/wD(...)
  [VIP 1297] CALL      call Stk[A](...)
  [VIP 1298] SETREG    Stk[1298] = 219
  [VIP 1299] SETREG    Stk[1299] = 568
  [VIP 1300] ADDU      Upv[1300] = Upv[1300] + 317
  [VIP 1303] GETTABUP  Stk[1303] = env[K[632]]
  [VIP 1303] DT        dT(x,632,1303)
  [VIP 1304] GETTABUP  Stk[1304] = env[K[566]]
  [VIP 1304] DT        dT(x,566,1304)
  [VIP 1306] SUBI      Stk[1306] = Stk[1306] - 14
  [VIP 1307] ADD       Stk[1307] = Stk[1307] + 15
  [VIP 1307] DT        dT(x,15,1307)
  [VIP 1308] ADDI      Stk[1308] = Stk[1308] + 398
  [VIP 1309] ADDI      Stk[1309] = Stk[1309] + 255
  [VIP 1310] ADDI      Stk[1310] = Stk[1310] + 59
  [VIP 1314] SUBI      Stk[1314] = Stk[1314] - 604
  [VIP 1315] DT        dT(x,118,1315)
  [VIP 1315] SETREG2   Upv[1315] = 413
  [VIP 1316] SETREG    Stk[1316] = 358
  [VIP 1317] CALL      call Stk[A](...)
  [VIP 1319] ADDI      Stk[1319] = Stk[1319] + 285
  [VIP 1320] ADDI      Stk[1320] = Stk[1320] + 352
  [VIP 1321] ADDI      Stk[1321] = Stk[1321] + 134
  [VIP 1328] CALL      call Stk[A](...)
  [VIP 1330] DT        dT(x,245,1330)
  [VIP 1331] ADDI      Stk[1331] = Stk[1331] + 124
  [VIP 1333] DT        dT(x,87,1333)
  [VIP 1334] ADDI      Stk[1334] = Stk[1334] + 198
  [VIP 1337] DT        dT(x,578,1337)
  [VIP 1337] SUBU      Upv[1337] = Upv[1337] - 31
  [VIP 1338] SUBI      Stk[1338] = Stk[1338] - 244
  [VIP 1339] DT        dT(x,690,1339)
  [VIP 1340] SUBI      Stk[1340] = Stk[1340] - 291
  [VIP 1342] CALL      call Stk[A](...)
  [VIP 1343] DT        dT(x,534,1343)
  [VIP 1344] DT        dT(x,424,1344)
  [VIP 1345] DT        dT(x,100,1345)
  [VIP 1346] ADDU      Upv[1346] = Upv[1346] + 214
  [VIP 1350] CALL      call Stk[A](...)
  [VIP 1352] CALL      call Stk[A](...)
  [VIP 1353] SETREG    Stk[1353] = 270
  [VIP 1354] DT        dT(x,387,1354)
  [VIP 1355] ADDI      Stk[1355] = Stk[1355] + 419
  [VIP 1356] SETREG    Stk[1356] = 500
  [VIP 1356] CALL      call Stk[A](...)
  [VIP 1357] ADDI      Stk[1357] = Stk[1357] + 251
  [VIP 1358] SUBI      Stk[1358] = Stk[1358] - 58
  [VIP 1359] ADDI      Stk[1359] = Stk[1359] + 456
  [VIP 1360] DT        dT(x,555,1360)
  [VIP 1361] SUBI      Stk[1361] = Stk[1361] - 622
  [VIP 1362] GETTABUP  Stk[1362] = env['band']
  [VIP 1362] ADDU      Upv[1362] = Upv[1362] + 149
  [VIP 1363] SUBI      Stk[1363] = Stk[1363] - 42
  [VIP 1364] DT        dT(x,634,1364)
  [VIP 1365] SUBI      Stk[1365] = Stk[1365] - 677
  [VIP 1366] SUBI      Stk[1366] = Stk[1366] - 353
  [VIP 1367] ADDI      Stk[1367] = Stk[1367] + 11
  [VIP 1368] LOADN     Stk[1368] = 22
  [VIP 1368] DT        dT(x,22,1368)
  [VIP 1369] SUBI      Stk[1369] = Stk[1369] - 231
  [VIP 1372] GETTABUP  Stk[1372] = env[K[147]]
  [VIP 1372] DT        dT(x,147,1372)
  [VIP 1373] GETTABUP  Stk[1373] = env[K[104]]
  [VIP 1374] GETTABUP  Stk[1374] = env[K[104]]
  [VIP 1375] GETTABUP  Stk[1375] = env[K[97]]
  [VIP 1376] GETTABUP  Stk[1376] = env[K[472]]
  [VIP 1376] DT        dT(x,472,1376)
  [VIP 1378] SETREG    Stk[1378] = 77
  [VIP 1381] GETTABUP  Stk[1381] = env[K[198]]
  [VIP 1381] DT        dT(x,198,1381)
  [VIP 1382] GETTABUP  Stk[1382] = env[K[104]]
  [VIP 1383] GETTABUP  Stk[1383] = env[K[104]]
  [VIP 1384] GETTABUP  Stk[1384] = env[K[98]]
  [VIP 1385] GETTABUP  Stk[1385] = env[K[250]]
  [VIP 1385] DT        dT(x,250,1385)
  [VIP 1386] GETTABUP  Stk[1386] = env[K[104]]
  [VIP 1387] GETTABUP  Stk[1387] = env[K[104]]
  [VIP 1388] GETTABUP  Stk[1388] = env[K[100]]
  [VIP 1389] GETTABUP  Stk[1389] = env[K[154]]
  [VIP 1389] DT        dT(x,154,1389)
  [VIP 1391] ADDI      Stk[1391] = Stk[1391] + 446
  [VIP 1394] DT        dT(x,260,1394)
  [VIP 1396] ADDI      Stk[1396] = Stk[1396] + 403
  [VIP 1397] DT        dT(x,515,1397)
  [VIP 1397] ADDU      Upv[1397] = Upv[1397] + 124
  [VIP 1398] SUBI      Stk[1398] = Stk[1398] - 328
  [VIP 1399] CALL      call Stk[A](...)
  [VIP 1400] DT        dT(x,222,1400)
  [VIP 1401] SUBI      Stk[1401] = Stk[1401] - 500
  [VIP 1402] LOADN     Stk[1402] = 36
  [VIP 1402] DT        dT(x,36,1402)
  [VIP 1403] SUBI      Stk[1403] = Stk[1403] - 609
  [VIP 1407] CALL      call Stk[A](...)
  [VIP 1408] CALL      call Stk[A](...)
  [VIP 1410] CALL      call Stk[A](...)
  [VIP 1411] CALL      call Stk[A](...)
  [VIP 1412] ADDI      Stk[1412] = Stk[1412] + 186
  [VIP 1413] GETTABUP  Stk[1413] = env[K[228]]
  [VIP 1413] SUBI      Stk[1413] = Stk[1413] - 228
  [VIP 1414] SETREG    Stk[1414] = 104
  [VIP 1416] ADDI      Stk[1416] = Stk[1416] + 88
  [VIP 1417] ADDI      Stk[1417] = Stk[1417] + 154
  [VIP 1417] CALL      call Stk[A](...)
  [VIP 1418] SETREG    Stk[1418] = 11
  [VIP 1419] SETTABUP  Stk['string'] = Stk[...]
  [VIP 1420] SUBI      Stk[1420] = Stk[1420] - 430
  [VIP 1421] SETTABUP  Stk[89] = Stk[...]
  [VIP 1421] DT        dT(x,89,1421)
  [VIP 1422] SETREG    Stk[1422] = 107
  [VIP 1426] ADDI      Stk[1426] = Stk[1426] + 126
  [VIP 1427] ADDI      Stk[1427] = Stk[1427] + 452
  [VIP 1428] SUBI      Stk[1428] = Stk[1428] - 405
  [VIP 1428] CALL      call Stk[A](...)
  [VIP 1429] SETREG    Stk[1429] = 189
  [VIP 1430] DT        dT(x,440,1430)
  [VIP 1431] SETREG    Stk[1431] = 64
  [VIP 1433] CALL      call Stk[A](...)
  [VIP 1434] CALL      call Stk[A](...)
  [VIP 1435] DT        dT(x,663,1435)
  [VIP 1436] SUBI      Stk[1436] = Stk[1436] - 448
  [VIP 1437] SETREG    Stk[1437] = 643
  [VIP 1441] CALL      call Stk[A](...)
  [VIP 1442] SETREG    Stk[1442] = 424
  [VIP 1448] SETREG    Stk[1448] = 485
  [VIP 1449] ADDI      Stk[1449] = Stk[1449] + 101
  [VIP 1449] CALL      call Stk[A](...)
  [VIP 1450] SETREG    Stk[1450] = 83
  [VIP 1454] DT        dT(x,442,1454)
  [VIP 1455] ADDI      Stk[1455] = Stk[1455] + 95
  [VIP 1456] ADD       Stk[1456] = Stk[1456] + 4
  [VIP 1456] CALL      call Stk[A](...)
  [VIP 1457] SETREG    Stk[1457] = 210
  [VIP 1462] SETREG    Stk[1462] = 246
  [VIP 1463] SUBI      Stk[1463] = Stk[1463] - 110
  [VIP 1464] SUBI      Stk[1464] = Stk[1464] - 211
  [VIP 1465] CALL      call Stk[A](...)
  [VIP 1468] SUBI      Stk[1468] = Stk[1468] - 690
  [VIP 1469] SETTABUP  Stk['lrotate'] = Stk[...]
  [VIP 1469] DT        dT(x,73,1469)
  [VIP 1470] SETREG    Stk[1470] = 95
  [VIP 1471] SETREG2   Upv[1471] = 169
  [VIP 1472] SUBI      Stk[1472] = Stk[1472] - 141
  [VIP 1476] SETREG    Stk[1476] = 496
  [VIP 1477] CALL      call Stk[A](...)
  [VIP 1478] DT        dT(x,175,1478)
  [VIP 1479] SETREG    Stk[1479] = 735
  [VIP 1480] ADD       Stk[1480] = Stk[1480] + 67
  [VIP 1480] DT        dT(x,67,1480)
  [VIP 1481] SETREG    Stk[1481] = 387
  [VIP 1482] SUBI      Stk[1482] = Stk[1482] - 513
  [VIP 1483] SETREG    Stk[1483] = 257
  [VIP 1485] DT        dT(x,567,1485)
  [VIP 1486] ADDI      Stk[1486] = Stk[1486] + 257
  [VIP 1490] CALL      call Stk[A](...)
  [VIP 1491] CALL      call Stk[A](...)
  [VIP 1492] SETREG    Stk[1492] = 487
  [VIP 1493] SUBI      Stk[1493] = Stk[1493] - 346
  [VIP 1493] CALL      call Stk[A](...)
  [VIP 1494] SETREG    Stk[1494] = 673
  [VIP 1495] CALL      call Stk[A](...)
  [VIP 1497] CALL      call Stk[A](...)
  [VIP 1498] CALL      call Stk[A](...)
  [VIP 1499] SETREG    Stk[1499] = 275
  [VIP 1503] DT        dT(x,65,1503)
  [VIP 1504] ADDI      Stk[1504] = Stk[1504] + 269
  [VIP 1507] CALL      call Stk[A](...)
  [VIP 1509] SUBI      Stk[1509] = Stk[1509] - 366
  [VIP 1510] LOADN     Stk[1510] = 77
  [VIP 1511] SUBI      Stk[1511] = Stk[1511] - 366
  [VIP 1514] CALL      call Stk[A](...)
  [VIP 1516] DT        dT(x,49,1516)
  [VIP 1517] SUBI      Stk[1517] = Stk[1517] - 62
  [VIP 1521] SETREG    Stk[1521] = 386
  [VIP 1522] SETREG    Stk[1522] = 683
  [VIP 1523] CALL      call Stk[A](...)
  [VIP 1525] CALL      call Stk[A](...)
  [VIP 1527] SETREG    Stk[1527] = 391
  [VIP 1530] CALL      call Stk[A](...)
  [VIP 1532] SUBI      Stk[1532] = Stk[1532] - 173
  [VIP 1533] SUBI      Stk[1533] = Stk[1533] - 282
  [VIP 1533] CALL      call Stk[A](...)
  [VIP 1534] SUBI      Stk[1534] = Stk[1534] - 357
  [VIP 1535] ADD       Stk[1535] = Stk[1535] + 68
  [VIP 1535] DT        dT(x,68,1535)
  [VIP 1536] SETREG    Stk[1536] = 725
  [VIP 1539] SUBI      Stk[1539] = Stk[1539] - 69
  [VIP 1540] ADD       Stk[1540] = Stk[1540] + 0
  [VIP 1541] SUBI      Stk[1541] = Stk[1541] - 350
  [VIP 1542] SETREG    Stk[1542] = 249
  [VIP 1543] ADD       Stk[1543] = Stk[1543] + 18
  [VIP 1543] DT        dT(x,18,1543)
  [VIP 1544] SETREG    Stk[1544] = 363
  [VIP 1545] SETLIST2  rD/ZD/wD(...)
  [VIP 1546] SETREG    Stk[1546] = 324
  [VIP 1547] SETREG    Stk[1547] = 593
  [VIP 1547] CALL      call Stk[A](...)
  [VIP 1548] ADDI      Stk[1548] = Stk[1548] + 72
  [VIP 1549] DT        dT(x,409,1549)
  [VIP 1550] ADDI      Stk[1550] = Stk[1550] + 193
  [VIP 1551] SETREG    Stk[1551] = 212
  [VIP 1551] CALL      call Stk[A](...)
  [VIP 1552] SUBI      Stk[1552] = Stk[1552] - 95
  [VIP 1557] ADDI      Stk[1557] = Stk[1557] + 249
  [VIP 1558] DT        dT(x,34,1558)
  [VIP 1558] ADDU      Upv[1558] = Upv[1558] + 201
  [VIP 1559] SETREG    Stk[1559] = 174
  [VIP 1560] SETREG    Stk[1560] = 129
  [VIP 1561] LOADN     Stk[1561] = 0
  [VIP 1562] SUBI      Stk[1562] = Stk[1562] - 517
  [VIP 1564] SUBI      Stk[1564] = Stk[1564] - 582
  [VIP 1565] CALL      call Stk[A](...)
  [VIP 1566] CALL      call Stk[A](...)
  [VIP 1567] CALL      call Stk[A](...)
  [VIP 1568] CALL      call Stk[A](...)
  [VIP 1569] CALL      call Stk[A](...)
  [VIP 1570] CALL      call Stk[A](...)
  [VIP 1571] ADDI      Stk[1571] = Stk[1571] + 298
  [VIP 1572] SETREG    Stk[1572] = 377
  [VIP 1572] CALL      call Stk[A](...)
  [VIP 1573] SUBI      Stk[1573] = Stk[1573] - 235
  [VIP 1575] SETREG    Stk[1575] = 70
  [VIP 1576] SUBI      Stk[1576] = Stk[1576] - 539
  [VIP 1577] SETREG    Stk[1577] = 75
  [VIP 1577] CALL      call Stk[A](...)
  [VIP 1578] SETREG    Stk[1578] = 595
  [VIP 1579] ADD       Stk[1579] = Stk[1579] + 104
  [VIP 1580] SUBI      Stk[1580] = Stk[1580] - 613
  [VIP 1581] SUBI      Stk[1581] = Stk[1581] - 287
  [VIP 1582] DT        dT(x,518,1582)
  [VIP 1583] SUBI      Stk[1583] = Stk[1583] - 469
  [VIP 1584] CALL      call Stk[A](...)
  [VIP 1585] ADDI      Stk[1585] = Stk[1585] + 19
  [VIP 1586] DT        dT(x,58,1586)
  [VIP 1586] ADDU      Upv[1586] = Upv[1586] + 72
  [VIP 1587] SUBI      Stk[1587] = Stk[1587] - 323
  [VIP 1588] DT        dT(x,67,1588)
  [VIP 1588] SUBU      Upv[1588] = Upv[1588] - 619
  [VIP 1589] ADDI      Stk[1589] = Stk[1589] + 71
  [VIP 1590] CALL      call Stk[A](...)
  [VIP 1591] DT        dT(x,13,1591)
  [VIP 1592] SUBI      Stk[1592] = Stk[1592] - 736
  [VIP 1593] DT        dT(x,43,1593)
  [VIP 1593] SUBU      Upv[1593] = Upv[1593] - 471
  [VIP 1594] SETREG    Stk[1594] = 695
  [VIP 1598] SETREG    Stk[1598] = 786
  [VIP 1600] CALL      call Stk[A](...)
  [VIP 1601] CALL      call Stk[A](...)
  [VIP 1603] CALL      call Stk[A](...)
  [VIP 1604] SUBI      Stk[1604] = Stk[1604] - 688
  [VIP 1605] LOADN     Stk[1605] = 81
  [VIP 1606] SUBI      Stk[1606] = Stk[1606] - 169
  [VIP 1607] SETTABUP  Stk[118] = Stk[...]
  [VIP 1607] DT        dT(x,118,1607)
  [VIP 1608] SUBI      Stk[1608] = Stk[1608] - 319
  [VIP 1614] SETREG    Stk[1614] = 509
  [VIP 1615] SUBI      Stk[1615] = Stk[1615] - 199
  [VIP 1615] CALL      call Stk[A](...)
  [VIP 1616] SETREG    Stk[1616] = 481
  [VIP 1617] SETREG    Stk[1617] = 475
  [VIP 1618] LOADN     Stk[1618] = 0
  [VIP 1619] SETREG    Stk[1619] = 654
  [VIP 1620] SETREG    Stk[1620] = 456
  [VIP 1621] SETREG    Stk[1621] = 544
  [VIP 1622] DT        dT(x,322,1622)
  [VIP 1623] SUBI      Stk[1623] = Stk[1623] - 337
  [VIP 1624] DT        dT(x,530,1624)
  [VIP 1626] GETTABUP  Stk[1626] = env['setfenv']
  [VIP 1627] SUBI      Stk[1627] = Stk[1627] - 645
  [VIP 1628] ADD       Stk[1628] = Stk[1628] + 78
  [VIP 1628] CALL      call Stk[A](...)
  [VIP 1629] SUBI      Stk[1629] = Stk[1629] - 539
  [VIP 1631] ADDI      Stk[1631] = Stk[1631] + 235
  [VIP 1632] CALL      call Stk[A](...)
  [VIP 1633] CALL      call Stk[A](...)
  [VIP 1635] SUBI      Stk[1635] = Stk[1635] - 54
  [VIP 1636] SUBI      Stk[1636] = Stk[1636] - 754
  [VIP 1642] ADDI      Stk[1642] = Stk[1642] + 202
  [VIP 1643] CALL      call Stk[A](...)
  [VIP 1646] CALL      call Stk[A](...)
  [VIP 1648] SUBI      Stk[1648] = Stk[1648] - 532
  [VIP 1649] CALL      call Stk[A](...)
  [VIP 1656] CALL      call Stk[A](...)
  [VIP 1658] SETREG    Stk[1658] = 650
  [VIP 1659] SETTABUP  Stk[112] = Stk[...]
  [VIP 1659] DT        dT(x,112,1659)
  [VIP 1660] SUBI      Stk[1660] = Stk[1660] - 757
  [VIP 1661] SETREG    Stk[1661] = 214
  [VIP 1662] SETTABUP  Stk['band'] = Stk[...]
  [VIP 1662] CALL      call Stk[A](...)
  [VIP 1663] SETREG    Stk[1663] = 439
  [VIP 1669] SUBI      Stk[1669] = Stk[1669] - 383
  [VIP 1670] SETLIST2  rD/ZD/wD(...)
  [VIP 1671] DT        dT(x,687,1671)
  [VIP 1672] SUBI      Stk[1672] = Stk[1672] - 816
  [VIP 1673] SUBI      Stk[1673] = Stk[1673] - 90
  [VIP 1676] CALL      call Stk[A](...)
  [VIP 1678] DT        dT(x,116,1678)
  [VIP 1679] SETREG    Stk[1679] = 739
  [VIP 1680] SUBI      Stk[1680] = Stk[1680] - 393
  [VIP 1681] CALL      call Stk[A](...)
  [VIP 1682] SUBI      Stk[1682] = Stk[1682] - 582
  [VIP 1683] DT        dT(x,27,1683)
  [VIP 1684] SUBI      Stk[1684] = Stk[1684] - 138
  [VIP 1685] DT        dT(x,108,1685)
  [VIP 1687] GETTABUP  Stk[1687] = env[K[85]]
  [VIP 1688] GETTABUP  Stk[1688] = env[K[309]]
  [VIP 1688] DT        dT(x,309,1688)
  [VIP 1689] GETTABUP  Stk[1689] = env[K[85]]
  [VIP 1690] SETREG    Stk[1690] = 99
  [VIP 1691] GETTABUP  Stk[1691] = env[K[309]]
  [VIP 1691] DT        dT(x,309,1691)
  [VIP 1692] GETTABUP  Stk[1692] = env[K[85]]
  [VIP 1693] GETTABUP  Stk[1693] = env[K[85]]
  [VIP 1694] GETTABUP  Stk[1694] = env[K[309]]
  [VIP 1694] DT        dT(x,309,1694)
  [VIP 1695] GETTABUP  Stk[1695] = env[K[85]]
  [VIP 1696] ADDI      Stk[1696] = Stk[1696] + 181
  [VIP 1697] LOADN     Stk[1697] = 10
  [VIP 1697] DT        dT(x,10,1697)
  [VIP 1698] SUBI      Stk[1698] = Stk[1698] - 679
  [VIP 1699] DT        dT(x,506,1699)
  [VIP 1700] DT        dT(x,56,1700)
  [VIP 1701] CALL      call Stk[A](...)
  [VIP 1702] CALL      call Stk[A](...)
  [VIP 1703] SUBI      Stk[1703] = Stk[1703] - 424
  [VIP 1705] DT        dT(x,63,1705)
  [VIP 1706] SUBI      Stk[1706] = Stk[1706] - 160
  [VIP 1707] ADDI      Stk[1707] = Stk[1707] + 140
  [VIP 1715] SETREG    Stk[1715] = 566
  [VIP 1716] SETREG    Stk[1716] = 569
  [VIP 1717] SETREG    Stk[1717] = 690
  [VIP 1720] CALL      call Stk[A](...)
  [VIP 1721] SUBI      Stk[1721] = Stk[1721] - 375
  [VIP 1724] GETTABUP  Stk[1724] = env[K[86]]
  [VIP 1724] DT        dT(x,86,1724)
  [VIP 1725] GETTABUP  Stk[1725] = env[K[588]]
  [VIP 1725] DT        dT(x,588,1725)
  [VIP 1727] SUBI      Stk[1727] = Stk[1727] - 24
  [VIP 1728] SETTABUP  Stk['band'] = Stk[...]
  [VIP 1728] CALL      call Stk[A](...)
  [VIP 1729] SETREG    Stk[1729] = 333
  [VIP 1730] ADD       Stk[1730] = Stk[1730] + 69
  [VIP 1730] DT        dT(x,69,1730)
  [VIP 1731] SETREG    Stk[1731] = 708
  [VIP 1733] CALL      call Stk[A](...)
  [VIP 1734] DT        dT(x,137,1734)
  [VIP 1735] SUBI      Stk[1735] = Stk[1735] - 315
  [VIP 1736] CALL      call Stk[A](...)
  [VIP 1737] SUBI      Stk[1737] = Stk[1737] - 421
  [VIP 1740] DT        dT(x,497,1740)
  [VIP 1741] SUBI      Stk[1741] = Stk[1741] - 273
  [VIP 1742] SETTABUP  Stk[96] = Stk[...]
  [VIP 1742] DT        dT(x,96,1742)
  [VIP 1743] SETREG    Stk[1743] = 195
  [VIP 1744] SETTABUP  Stk[338] = Stk[...]
  [VIP 1744] DT        dT(x,338,1744)
  [VIP 1745] SUBI      Stk[1745] = Stk[1745] - 204
  [VIP 1746] GETTABUP  Stk[1746] = env[K[157]]
  [VIP 1746] SUBI      Stk[1746] = Stk[1746] - 157
  [VIP 1747] SUBI      Stk[1747] = Stk[1747] - 78
  [VIP 1748] GETTABUP  Stk[1748] = env['find']
  [VIP 1748] SETREG    Stk[1748] = 16
  [VIP 1749] SETREG    Stk[1749] = 78
  [VIP 1750] SUBI      Stk[1750] = Stk[1750] - 204
  [VIP 1750] CALL      call Stk[A](...)
  [VIP 1751] SETREG    Stk[1751] = 298
  [VIP 1752] SETLIST2  rD/ZD/wD(...)
  [VIP 1753] CALL      call Stk[A](...)
  [VIP 1754] CALL      call Stk[A](...)
  [VIP 1755] CALL      call Stk[A](...)
  [VIP 1756] CALL      call Stk[A](...)
  [VIP 1757] CALL      call Stk[A](...)
  [VIP 1758] CALL      call Stk[A](...)
  [VIP 1759] SETREG    Stk[1759] = 737
  [VIP 1760] LOADN     Stk[1760] = 126
  [VIP 1760] DT        dT(x,126,1760)
  [VIP 1761] SETREG    Stk[1761] = 342
  [VIP 1764] CALL      call Stk[A](...)
  [VIP 1765] SUBI      Stk[1765] = Stk[1765] - 334
  [VIP 1766] DT        dT(x,49,1766)
  [VIP 1767] ADDI      Stk[1767] = Stk[1767] + 7
  [VIP 1768] SETTABUP  Stk['bor'] = Stk[...]
  [VIP 1768] DT        dT(x,26,1768)
  [VIP 1769] SETREG    Stk[1769] = 652
  [VIP 1770] SETLIST2  rD/ZD/wD(...)
  [VIP 1771] SUBI      Stk[1771] = Stk[1771] - 303
  [VIP 1772] DT        dT(x,94,1772)
  [VIP 1772] SETREG2   Upv[1772] = 164
  [VIP 1773] SUBI      Stk[1773] = Stk[1773] - 680
  [VIP 1774] SUBI      Stk[1774] = Stk[1774] - 228
  [VIP 1775] SETTABUP  Stk['bit32'] = Stk[...]
  [VIP 1775] DT        dT(x,1,1775)
  [VIP 1776] SETREG    Stk[1776] = 430
  [VIP 1778] CALL      call Stk[A](...)
  [VIP 1783] SUBI      Stk[1783] = Stk[1783] - 586
  [VIP 1786] DT        dT(x,415,1786)
  [VIP 1787] SETREG    Stk[1787] = 739
  [VIP 1788] CALL      call Stk[A](...)
  [VIP 1789] CALL      call Stk[A](...)
  [VIP 1792] SETREG    Stk[1792] = 477
  [VIP 1793] SETREG    Stk[1793] = 354
  [VIP 1793] CALL      call Stk[A](...)
  [VIP 1794] SETREG    Stk[1794] = 580
  [VIP 1797] DT        dT(x,706,1797)
  [VIP 1799] SUBI      Stk[1799] = Stk[1799] - 335
  [VIP 1802] CALL      call Stk[A](...)
  [VIP 1804] DT        dT(x,541,1804)
  [VIP 1805] SETREG    Stk[1805] = 415
  [VIP 1806] SUBI      Stk[1806] = Stk[1806] - 85
  [VIP 1807] SUBI      Stk[1807] = Stk[1807] - 817
  [VIP 1809] GETTABUP  Stk[1809] = env[K[682]]
  [VIP 1809] DT        dT(x,682,1809)
  [VIP 1810] GETTABUP  Stk[1810] = env[K[104]]
  [VIP 1811] GETTABUP  Stk[1811] = env[K[104]]
  [VIP 1812] GETTABUP  Stk[1812] = env[K[100]]
  [VIP 1813] GETTABUP  Stk[1813] = env['type']
  [VIP 1813] DT        dT(x,20,1813)
  [VIP 1815] SETREG    Stk[1815] = 44
  [VIP 1819] GETTABUP  Stk[1819] = env['Luraph']
  [VIP 1819] DT        dT(x,7,1819)
  [VIP 1820] GETTABUP  Stk[1820] = env[K[89]]
  [VIP 1820] DT        dT(x,89,1820)
  [VIP 1821] GETTABUP  Stk[1821] = env[K[669]]
  [VIP 1821] DT        dT(x,669,1821)
  [VIP 1823] SETREG    Stk[1823] = 435
  [VIP 1825] CALL      call Stk[A](...)
  [VIP 1826] CALL      call Stk[A](...)
  [VIP 1829] SETREG    Stk[1829] = 584
  [VIP 1830] DT        dT(x,19,1830)
  [VIP 1831] DT        dT(x,56,1831)
  [VIP 1832] CALL      call Stk[A](...)
  [VIP 1833] CALL      call Stk[A](...)
  [VIP 1834] CALL      call Stk[A](...)
  [VIP 1835] SETREG    Stk[1835] = 398
  [VIP 1836] DT        dT(x,594,1836)
  [VIP 1837] SUBI      Stk[1837] = Stk[1837] - 291
  [VIP 1838] SUBI      Stk[1838] = Stk[1838] - 321
  [VIP 1841] GETTABUP  Stk[1841] = env[K[89]]
  [VIP 1841] DT        dT(x,89,1841)
  [VIP 1842] GETTABUP  Stk[1842] = env[K[317]]
  [VIP 1842] DT        dT(x,317,1842)
  [VIP 1844] SETREG    Stk[1844] = 712
  [VIP 1846] DT        dT(x,157,1846)
  [VIP 1847] SETREG    Stk[1847] = 792
  [VIP 1851] SUBI      Stk[1851] = Stk[1851] - 429
  [VIP 1853] SUBI      Stk[1853] = Stk[1853] - 157
  [VIP 1854] GETTABUP  Stk[1854] = env[K[104]]
  [VIP 1855] GETTABUP  Stk[1855] = env[K[104]]
  [VIP 1856] GETTABUP  Stk[1856] = env[K[99]]
  [VIP 1857] GETTABUP  Stk[1857] = env[K[220]]
  [VIP 1857] DT        dT(x,220,1857)
  [VIP 1859] SETREG    Stk[1859] = 502
  [VIP 1860] DT        dT(x,93,1860)
  [VIP 1860] SETREG2   Upv[1860] = 735
  [VIP 1861] SUBI      Stk[1861] = Stk[1861] - 553
  [VIP 1862] CALL      call Stk[A](...)
  [VIP 1863] DT        dT(x,106,1863)
  [VIP 1864] SUBI      Stk[1864] = Stk[1864] - 713
  [VIP 1865] SETTABUP  Stk['rep'] = Stk[...]
  [VIP 1865] DT        dT(x,58,1865)
  [VIP 1866] SUBI      Stk[1866] = Stk[1866] - 810
  [VIP 1867] SETTABUP  Stk['string'] = Stk[...]
  [VIP 1868] SETREG    Stk[1868] = 905
  [VIP 1869] SUBI      Stk[1869] = Stk[1869] - 919
  [VIP 1870] DT        dT(x,275,1870)
  [VIP 1871] DT        dT(x,180,1871)
  [VIP 1872] DT        dT(x,31,1872)
  [VIP 1873] SUBU      Upv[1873] = Upv[1873] - 455
  [VIP 1876] DT        dT(x,388,1876)
  [VIP 1877] SUBI      Stk[1877] = Stk[1877] - 763
  [VIP 1879] SUBI      Stk[1879] = Stk[1879] - 459
  [VIP 1882] GETTABUP  Stk[1882] = env[K[567]]
  [VIP 1882] DT        dT(x,567,1882)
  [VIP 1883] GETTABUP  Stk[1883] = env[K[104]]
  [VIP 1884] GETTABUP  Stk[1884] = env[K[104]]
  [VIP 1885] GETTABUP  Stk[1885] = env[K[97]]
  [VIP 1886] GETTABUP  Stk[1886] = env[K[396]]
  [VIP 1886] DT        dT(x,396,1886)
  [VIP 1888] SUBI      Stk[1888] = Stk[1888] - 823
  [VIP 1889] SETTABUP  Stk[84] = Stk[...]
  [VIP 1890] SUBI      Stk[1890] = Stk[1890] - 121
  [VIP 1891] DT        dT(x,50,1891)
  [VIP 1892] SUBI      Stk[1892] = Stk[1892] - 316
  [VIP    1] ADDI      Stk[1] = Stk[1] + 4
  [VIP    6] SETREG    Stk[6] = 2
  [VIP    1] ADDI      Stk[1] = Stk[1] + 17
  [VIP    2] ADDI      Stk[2] = Stk[2] + 9
  [VIP    6] ADDI      Stk[6] = Stk[6] + 80
  [VIP    7] SETREG    Stk[7] = 2
  [VIP    9] CALL      call Stk[A](...)
  [VIP   10] CALL      call Stk[A](...)
  [VIP   11] ADDI      Stk[11] = Stk[11] + 103
  [VIP   14] GETTABUP  Stk[14] = env[K[348]]
  [VIP   14] DT        dT(x,348,14)
  [VIP   15] GETTABUP  Stk[15] = env['<i8']
  [VIP   15] DT        dT(x,54,15)
  [VIP   16] GETTABUP  Stk[16] = env['format']
  [VIP   16] DT        dT(x,35,16)
  [VIP   18] ADDI      Stk[18] = Stk[18] + 76
  [VIP   19] ADDI      Stk[19] = Stk[19] + 86
  [VIP   25] GETTABUP  Stk[25] = env['running']
  [VIP   25] DT        dT(x,24,25)
  [VIP   26] GETTABUP  Stk[26] = env['Luraph']
  [VIP   26] DT        dT(x,7,26)
  [VIP   27] GETTABUP  Stk[27] = env['tostring']
  [VIP   27] DT        dT(x,59,27)
  [VIP   29] ADDI      Stk[29] = Stk[29] + 54
  [VIP   30] DT        dT(x,113,30)
  [VIP   32] ADDI      Stk[32] = Stk[32] + 71
  [VIP   33] ADDI      Stk[33] = Stk[33] + 70
  [VIP   33] CALL      call Stk[A](...)
  [VIP   34] SUBI      Stk[34] = Stk[34] - 5
  [VIP   38] GETTABUP  Stk[38] = env[K[90]]
  [VIP   38] DT        dT(x,90,38)
  [VIP   39] GETTABUP  Stk[39] = env['short_src']
  [VIP   39] DT        dT(x,77,39)
  [VIP   40] GETTABUP  Stk[40] = env[K[376]]
  [VIP   40] DT        dT(x,376,40)
  [VIP   41] GETTABUP  Stk[41] = env['traceback']
  [VIP   41] DT        dT(x,34,41)
  [VIP   43] ADDI      Stk[43] = Stk[43] + 32
  [VIP   54] ADDI      Stk[54] = Stk[54] + 59
  [VIP   57] GETTABUP  Stk[57] = env[K[213]]
  [VIP   57] DT        dT(x,213,57)
  [VIP   59] GETTABUP  Stk[59] = env[K[84]]
  [VIP   63] GETTABUP  Stk[63] = env[' ']
  [VIP   64] GETTABUP  Stk[64] = env['debug']
  [VIP   65] GETTABUP  Stk[65] = env['source']
  [VIP   65] DT        dT(x,51,65)
  [VIP   67] SETREG    Stk[67] = 7
  [VIP   68] DT        dT(x,111,68)
  [VIP   72] SETREG    Stk[72] = 1
  [VIP   74] DT        dT(x,290,74)
  [VIP   75] SETREG    Stk[75] = 1
  [VIP   76] CALL      call Stk[A](...)
  [VIP   83] SUBI      Stk[83] = Stk[83] - 40
  [VIP   84] SETREG    Stk[84] = 32
  [VIP   84] CALL      call Stk[A](...)
  [VIP   85] ADDI      Stk[85] = Stk[85] + 19
  [VIP   86] SETREG    Stk[86] = 34
  [VIP   94] SETREG    Stk[94] = 19
  [VIP   95] SETTABUP  Stk['tonumber'] = Stk[...]
  [VIP   95] CALL      call Stk[A](...)
  [VIP   96] SETREG    Stk[96] = 6
  [VIP   99] GETTABUP  Stk[99] = env['Luraph']
  [VIP   99] DT        dT(x,7,99)
  [VIP  100] GETTABUP  Stk[100] = env['Your Lua environment does not support lo...']
  [VIP  100] DT        dT(x,32,100)
  [VIP  102] SUBI      Stk[102] = Stk[102] - 30
  [VIP  103] SUBI      Stk[103] = Stk[103] - 49
  [VIP  104] SETREG    Stk[104] = 22
  [VIP  105] ADDI      Stk[105] = Stk[105] + 11
  [VIP  109] GETTABUP  Stk[109] = env['traceback']
  [VIP  109] DT        dT(x,34,109)
  [VIP  110] GETTABUP  Stk[110] = env[K[118]]
  [VIP  110] DT        dT(x,118,110)
  [VIP  111] GETTABUP  Stk[111] = env[K[221]]
  [VIP  111] DT        dT(x,221,111)
  [VIP  113] SUBI      Stk[113] = Stk[113] - 11
  [VIP  114] SUBI      Stk[114] = Stk[114] - 18
  [VIP  115] DT        dT(x,532,115)
  [VIP  116] SUBI      Stk[116] = Stk[116] - 13
  [VIP  118] SUBI      Stk[118] = Stk[118] - 33
  [VIP    1] ADDI      Stk[1] = Stk[1] + 6
  [VIP    3] CALL      call Stk[A](...)
  [VIP    4] CALL      call Stk[A](...)
  [VIP    5] DT        dT(x,116,5)
  [VIP    6] ADDI      Stk[6] = Stk[6] + 52
  [VIP    7] ADDI      Stk[7] = Stk[7] + 25
  [VIP    8] ADDI      Stk[8] = Stk[8] + 14
  [VIP    9] ADDI      Stk[9] = Stk[9] + 24
  [VIP   12] GETTABUP  Stk[12] = env['Luraph']
  [VIP   12] DT        dT(x,7,12)
  [VIP   13] GETTABUP  Stk[13] = env['gmatch']
  [VIP   13] DT        dT(x,5,13)
  [VIP   15] ADDI      Stk[15] = Stk[15] + 3
  [VIP   16] ADDI      Stk[16] = Stk[16] + 36
  [VIP   20] DT        dT(x,418,20)
  [VIP   22] ADDI      Stk[22] = Stk[22] + 36
  [VIP   27] GETTABUP  Stk[27] = env['short_src']
  [VIP   27] DT        dT(x,77,27)
  [VIP   28] GETTABUP  Stk[28] = env['rawset']
  [VIP   28] DT        dT(x,10,28)
  [VIP   29] GETTABUP  Stk[29] = env['Luraph']
  [VIP   29] DT        dT(x,7,29)
  [VIP   30] GETTABUP  Stk[30] = env[K[122]]
  [VIP   30] DT        dT(x,122,30)
  [VIP   32] SETREG    Stk[32] = 8
  [VIP   33] SETREG    Stk[33] = 9
  [VIP   36] GETTABUP  Stk[36] = env[K[609]]
  [VIP   36] DT        dT(x,609,36)
  [VIP   37] GETTABUP  Stk[37] = env['next']
  [VIP   38] GETTABUP  Stk[38] = env['next']
  [VIP   39] GETTABUP  Stk[39] = env['rawset']
  [VIP   40] GETTABUP  Stk[40] = env['nparams']
  [VIP   40] DT        dT(x,56,40)
  [VIP   42] SETREG    Stk[42] = 1
  [VIP   51] SETREG    Stk[51] = 16
  [VIP   55] GETTABUP  Stk[55] = env[K[606]]
  [VIP   55] DT        dT(x,606,55)
  [VIP   56] GETTABUP  Stk[56] = env['rawget']
  [VIP   56] DT        dT(x,30,56)
  [VIP   58] SUBI      Stk[58] = Stk[58] - 16
  [VIP   59] LOADN     Stk[59] = 81
  [VIP   59] DT        dT(x,81,59)
  [VIP   60] SETREG    Stk[60] = 6
  [VIP    1] ADDI      Stk[1] = Stk[1] + 32
  [VIP    4] GETTABUP  Stk[4] = env[K[81]]
  [VIP    4] DT        dT(x,81,4)
  [VIP    5] GETTABUP  Stk[5] = env[K[92]]
  [VIP    5] DT        dT(x,92,5)
  [VIP    7] ADDI      Stk[7] = Stk[7] + 25
  [VIP   10] GETTABUP  Stk[10] = env[K[207]]
  [VIP   10] DT        dT(x,207,10)
  [VIP   11] GETTABUP  Stk[11] = env['debug']
  [VIP   12] GETTABUP  Stk[12] = env['debug']
  [VIP   13] GETTABUP  Stk[13] = env['Luraph']
  [VIP   14] GETTABUP  Stk[14] = env[K[278]]
  [VIP   14] DT        dT(x,278,14)
  [VIP   16] ADDI      Stk[16] = Stk[16] + 18
  [VIP   17] DT        dT(x,502,17)
  [VIP   21] ADDI      Stk[21] = Stk[21] + 0
  [VIP   23] GETTABUP  Stk[23] = env['running']
  [VIP   23] DT        dT(x,24,23)
  [VIP   24] GETTABUP  Stk[24] = env[K[487]]
  [VIP   24] DT        dT(x,487,24)
  [VIP   26] ADDI      Stk[26] = Stk[26] + 0
  [VIP   27] SETREG    Stk[27] = 7
  [VIP   29] GETTABUP  Stk[29] = env['bit32']
  [VIP   32] SETREG    Stk[32] = 16
  [VIP   33] SUBI      Stk[33] = Stk[33] - 13
  [VIP   34] SETREG    Stk[34] = 1
  [VIP   35] ADDI      Stk[35] = Stk[35] + 0
  [VIP   39] GETTABUP  Stk[39] = env['Luraph']
  [VIP   39] DT        dT(x,7,39)
  [VIP   40] GETTABUP  Stk[40] = env['<i8']
  [VIP   40] DT        dT(x,54,40)
  [VIP   41] GETTABUP  Stk[41] = env[K[278]]
  [VIP   41] DT        dT(x,278,41)
  [VIP   43] SUBI      Stk[43] = Stk[43] - 16
  [VIP    1] ADDI      Stk[1] = Stk[1] + 37
  [VIP    2] ADDI      Stk[2] = Stk[2] + 21
  [VIP    6] GETTABUP  Stk[6] = env['linedefined']
  [VIP    6] DT        dT(x,68,6)
  [VIP    7] GETTABUP  Stk[7] = env['linedefined']
  [VIP    7] DT        dT(x,68,7)
  [VIP    8] GETTABUP  Stk[8] = env[K[101]]
  [VIP    8] DT        dT(x,101,8)
  [VIP    9] GETTABUP  Stk[9] = env[K[81]]
  [VIP    9] DT        dT(x,81,9)
  [VIP   10] GETTABUP  Stk[10] = env['char']
  [VIP   10] DT        dT(x,18,10)
  [VIP   12] ADDI      Stk[12] = Stk[12] + 2
  [VIP   13] ADDI      Stk[13] = Stk[13] + 10
  [VIP   13] CALL      call Stk[A](...)
  [VIP   14] ADDI      Stk[14] = Stk[14] + 16
  [VIP   17] GETTABUP  Stk[17] = env[K[678]]
  [VIP   17] DT        dT(x,678,17)
  [VIP   18] GETTABUP  Stk[18] = env[K[227]]
  [VIP   19] GETTABUP  Stk[19] = env['number']
  [VIP   20] GETTABUP  Stk[20] = env['Luraph']
  [VIP   21] GETTABUP  Stk[21] = env['linedefined']
  [VIP   21] DT        dT(x,68,21)
  [VIP   23] SUBI      Stk[23] = Stk[23] - 11
  [VIP   24] ADDI      Stk[24] = Stk[24] + 7
  [VIP   24] CALL      call Stk[A](...)
  [VIP   25] ADDI      Stk[25] = Stk[25] + 15
  [VIP   26] DT        dT(x,388,26)
  [VIP   30] SETREG    Stk[30] = 1
  [VIP   31] ADDI      Stk[31] = Stk[31] + 1
  [VIP   32] ADDI      Stk[32] = Stk[32] + 4
  [VIP   37] SETREG    Stk[37] = 2
  [VIP   39] DT        dT(x,353,39)
  [VIP   40] SUBI      Stk[40] = Stk[40] - 17
  [VIP   41] SUBI      Stk[41] = Stk[41] - 16
  [VIP    1] ADDI      Stk[1] = Stk[1] + 53
  [VIP    2] DT        dT(x,150,2)
  [VIP    3] GETTABUP  Stk[3] = env['pcall']
  [VIP    4] ADDI      Stk[4] = Stk[4] + 116
  [VIP    7] GETTABUP  Stk[7] = env['Luraph']
  [VIP    7] DT        dT(x,7,7)
  [VIP    8] GETTABUP  Stk[8] = env[K[146]]
  [VIP    8] DT        dT(x,146,8)
  [VIP   10] ADDI      Stk[10] = Stk[10] + 137
  [VIP   11] ADDI      Stk[11] = Stk[11] + 33
  [VIP   12] DT        dT(x,62,12)
  [VIP   13] DT        dT(x,52,13)
  [VIP   14] DT        dT(x,105,14)
  [VIP   15] ADDI      Stk[15] = Stk[15] + 51
  [VIP   17] DT        dT(x,579,17)
  [VIP   17] ADDU      Upv[17] = Upv[17] + 97
  [VIP   18] ADDI      Stk[18] = Stk[18] + 29
  [VIP   19] ADDI      Stk[19] = Stk[19] + 104
  [VIP   19] CALL      call Stk[A](...)
  [VIP   20] ADDI      Stk[20] = Stk[20] + 22
  [VIP   21] DT        dT(x,45,21)
  [VIP   22] ADDU      Upv[22] = Upv[22] + 157
  [VIP   25] GETTABUP  Stk[25] = env[K[90]]
  [VIP   25] DT        dT(x,90,25)
  [VIP   26] GETTABUP  Stk[26] = env['yield']
  [VIP   26] DT        dT(x,72,26)
  [VIP   28] ADDI      Stk[28] = Stk[28] + 63
  [VIP   30] ADDI      Stk[30] = Stk[30] + 7
  [VIP   33] GETTABUP  Stk[33] = env['<i8']
  [VIP   33] DT        dT(x,54,33)
  [VIP   34] GETTABUP  Stk[34] = env['isvararg']
  [VIP   34] DT        dT(x,23,34)
  [VIP   36] ADDI      Stk[36] = Stk[36] + 28
  [VIP   37] ADDI      Stk[37] = Stk[37] + 86
  [VIP   38] ADD       Stk[38] = Stk[38] + 82
  [VIP   38] DT        dT(x,82,38)
  [VIP   39] ADDI      Stk[39] = Stk[39] + 110
  [VIP   40] GETTABUP  Stk[40] = env[K[112]]
  [VIP   40] ADDI      Stk[40] = Stk[40] + 112
  [VIP   41] ADDI      Stk[41] = Stk[41] + 72
  [VIP   42] ADDI      Stk[42] = Stk[42] + 21
  [VIP   43] GETTABUP  Stk[43] = env['next']
  [VIP   44] ADDI      Stk[44] = Stk[44] + 79
  [VIP   45] DT        dT(x,477,45)
  [VIP   46] DT        dT(x,684,46)
  [VIP   47] SUBI      Stk[47] = Stk[47] - 10
  [VIP   48] SETREG    Stk[48] = 1
  [VIP   49] SUBI      Stk[49] = Stk[49] - 19
  [VIP   50] SETTABUP  Stk[135] = Stk[...]
  [VIP   50] DT        dT(x,135,50)
  [VIP   51] ADDI      Stk[51] = Stk[51] + 70
  [VIP   52] ADDI      Stk[52] = Stk[52] + 54
  [VIP   53] SETTABUP  Stk['error in error handling'] = Stk[...]
  [VIP   53] DT        dT(x,9,53)
  [VIP   54] ADDI      Stk[54] = Stk[54] + 65
  [VIP   55] ADDI      Stk[55] = Stk[55] + 110
  [VIP   58] GETTABUP  Stk[58] = env[K[361]]
  [VIP   58] DT        dT(x,361,58)
  [VIP   59] GETTABUP  Stk[59] = env['Luraph']
  [VIP   59] DT        dT(x,7,59)
  [VIP   60] GETTABUP  Stk[60] = env[K[109]]
  [VIP   60] DT        dT(x,109,60)
  [VIP   62] SETREG    Stk[62] = 15
  [VIP   64] ADDI      Stk[64] = Stk[64] + 109
  [VIP   65] DT        dT(x,82,65)
  [VIP   65] SUBU      Upv[65] = Upv[65] - 13
  [VIP   66] SUBI      Stk[66] = Stk[66] - 15
  [VIP   67] ADDU      Upv[67] = Upv[67] + 56
  [VIP   70] GETTABUP  Stk[70] = env['char']
  [VIP   70] DT        dT(x,18,70)
  [VIP   71] GETTABUP  Stk[71] = env[K[306]]
  [VIP   71] DT        dT(x,306,71)
  [VIP   73] ADDI      Stk[73] = Stk[73] + 72
  [VIP   74] ADD       Stk[74] = Stk[74] + 0
  [VIP   75] ADDI      Stk[75] = Stk[75] + 106
  [VIP   77] CALL      call Stk[A](...)
  [VIP   78] CALL      call Stk[A](...)
  [VIP   79] DT        dT(x,231,79)
  [VIP   80] SETREG    Stk[80] = 37
  [VIP   86] DT        dT(x,667,86)
  [VIP   87] ADDI      Stk[87] = Stk[87] + 72
  [VIP   88] DT        dT(x,119,88)
  [VIP   91] ADDI      Stk[91] = Stk[91] + 67
  [VIP   93] DT        dT(x,56,93)
  [VIP   95] DT        dT(x,252,95)
  [VIP   99] SETREG    Stk[99] = 37
  [VIP  101] ADDI      Stk[101] = Stk[101] + 62
  [VIP  103] GETTABUP  Stk[103] = env['Luraph']
  [VIP  103] DT        dT(x,7,103)
  [VIP  104] GETTABUP  Stk[104] = env[K[101]]
  [VIP  104] DT        dT(x,101,104)
  [VIP  106] SUBI      Stk[106] = Stk[106] - 7
  [VIP  107] DT        dT(x,141,107)
  [VIP  108] DT        dT(x,56,108)
  [VIP  110] DT        dT(x,56,110)
  [VIP  111] ADDU      Upv[111] = Upv[111] + 52
  [VIP  112] DT        dT(x,71,112)
  [VIP  113] ADDI      Stk[113] = Stk[113] + 10
  [VIP  114] SETREG    Stk[114] = 55
  [VIP  115] CALL      call Stk[A](...)
  [VIP  116] CALL      call Stk[A](...)
  [VIP  117] CALL      call Stk[A](...)
  [VIP  118] CALL      call Stk[A](...)
  [VIP  119] SETREG    Stk[119] = 11
  [VIP  120] SETREG    Stk[120] = 4
  [VIP  121] SUBI      Stk[121] = Stk[121] - 20
  [VIP  122] GETTABUP  Stk[122] = env['gmatch']
  [VIP  124] ADDI      Stk[124] = Stk[124] + 5
  [VIP  126] CALL      call Stk[A](...)
  [VIP  127] DT        dT(x,581,127)
  [VIP  128] SETREG    Stk[128] = 36
  [VIP  129] SUBI      Stk[129] = Stk[129] - 62
  [VIP  133] GETTABUP  Stk[133] = env['math']
  [VIP  133] DT        dT(x,70,133)
  [VIP  134] GETTABUP  Stk[134] = env['create']
  [VIP  134] DT        dT(x,60,134)
  [VIP  135] GETTABUP  Stk[135] = env['match']
  [VIP  135] DT        dT(x,25,135)
  [VIP  137] SUBI      Stk[137] = Stk[137] - 64
  [VIP  141] GETTABUP  Stk[141] = env['Luraph']
  [VIP  141] DT        dT(x,7,141)
  [VIP  142] GETTABUP  Stk[142] = env['linedefined']
  [VIP  142] DT        dT(x,68,142)
  [VIP  143] GETTABUP  Stk[143] = env[K[400]]
  [VIP  143] DT        dT(x,400,143)
  [VIP  145] ADDI      Stk[145] = Stk[145] + 9
  [VIP  146] SETREG    Stk[146] = 18
  [VIP  146] CALL      call Stk[A](...)
  [VIP  147] ADDI      Stk[147] = Stk[147] + 4
  [VIP  148] DT        dT(x,135,148)
  [VIP  148] SETREG2   Upv[148] = 49
  [VIP  149] SETREG    Stk[149] = 10
  [VIP  150] DT        dT(x,709,150)
  [VIP  150] SETREG2   Upv[150] = 48
  [VIP  151] SETREG    Stk[151] = 41
  [VIP  152] SUBI      Stk[152] = Stk[152] - 41
  [VIP  154] ADDI      Stk[154] = Stk[154] + 25
  [VIP  155] CALL      call Stk[A](...)
  [VIP  156] DT        dT(x,185,156)
  [VIP  157] DT        dT(x,187,157)
  [VIP  158] SETREG    Stk[158] = 20
  [VIP  159] SETREG    Stk[159] = 22
  [VIP  161] GETTABUP  Stk[161] = env['pcall']
  [VIP  162] SUBI      Stk[162] = Stk[162] - 42
  [VIP  163] SUBI      Stk[163] = Stk[163] - 26
  [VIP  164] SETTABUP  Stk['string'] = Stk[...]
  [VIP  165] SETREG    Stk[165] = 28
  [VIP  168] GETTABUP  Stk[168] = env[K[89]]
  [VIP  168] DT        dT(x,89,168)
  [VIP  169] GETTABUP  Stk[169] = env['traceback']
  [VIP  169] DT        dT(x,34,169)
  [VIP  171] SETREG    Stk[171] = 75
  [VIP  172] SUBI      Stk[172] = Stk[172] - 44
  [VIP  172] CALL      call Stk[A](...)
  [VIP  173] SUBI      Stk[173] = Stk[173] - 49
  [VIP  176] GETTABUP  Stk[176] = env[K[89]]
  [VIP  176] DT        dT(x,89,176)
  [VIP  177] GETTABUP  Stk[177] = env['bor']
  [VIP  177] DT        dT(x,26,177)
  [VIP  179] SETREG    Stk[179] = 87
  [VIP  180] LOADN     Stk[180] = 0
  [VIP  181] SUBI      Stk[181] = Stk[181] - 61
  [VIP  182] SETREG    Stk[182] = 80
  [VIP    1] ADDI      Stk[1] = Stk[1] + 267
  [VIP    2] GETTABUP  Stk[2] = env['number']
  [VIP    4] CALL      call Stk[A](...)
  [VIP    6] GETTABUP  Stk[6] = env['number']
  [VIP    7] GETTABUP  Stk[7] = env[K[419]]
  [VIP    7] DT        dT(x,419,7)
  [VIP    8] GETTABUP  Stk[8] = env[K[565]]
  [VIP    8] DT        dT(x,565,8)
  [VIP    9] ADDI      Stk[9] = Stk[9] + 111
  [VIP   10] GETTABUP  Stk[10] = env[K[683]]
  [VIP   10] DT        dT(x,683,10)
  [VIP   11] GETTABUP  Stk[11] = env['number']
  [VIP   12] CALL      call Stk[A](...)
  [VIP   13] GETTABUP  Stk[13] = env['number']
  [VIP   14] GETTABUP  Stk[14] = env[K[181]]
  [VIP   14] DT        dT(x,181,14)
  [VIP   15] GETTABUP  Stk[15] = env[K[622]]
  [VIP   15] DT        dT(x,622,15)
  [VIP   16] GETTABUP  Stk[16] = env[K[351]]
  [VIP   16] DT        dT(x,351,16)
  [VIP   17] ADDI      Stk[17] = Stk[17] + 25
  [VIP   20] GETTABUP  Stk[20] = env['linedefined']
  [VIP   20] DT        dT(x,68,20)
  [VIP   21] GETTABUP  Stk[21] = env['linedefined']
  [VIP   21] DT        dT(x,68,21)
  [VIP   22] GETTABUP  Stk[22] = env[K[342]]
  [VIP   22] DT        dT(x,342,22)
  [VIP   24] ADDI      Stk[24] = Stk[24] + 245
  [VIP   25] GETTABUP  Stk[25] = env[K[314]]
  [VIP   25] DT        dT(x,314,25)
  [VIP   26] GETTABUP  Stk[26] = env[K[476]]
  [VIP   26] DT        dT(x,476,26)
  [VIP   27] GETTABUP  Stk[27] = env[K[474]]
  [VIP   27] DT        dT(x,474,27)
  [VIP   28] ADDI      Stk[28] = Stk[28] + 245
  [VIP   31] GETTABUP  Stk[31] = env['linedefined']
  [VIP   31] DT        dT(x,68,31)
  [VIP   32] GETTABUP  Stk[32] = env[K[448]]
  [VIP   32] DT        dT(x,448,32)
  [VIP   34] ADDI      Stk[34] = Stk[34] + 98
  [VIP   35] GETTABUP  Stk[35] = env['number']
  [VIP   36] GETTABUP  Stk[36] = env[K[336]]
  [VIP   36] DT        dT(x,336,36)
  [VIP   37] GETTABUP  Stk[37] = env[K[399]]
  [VIP   37] DT        dT(x,399,37)
  [VIP   38] ADDI      Stk[38] = Stk[38] + 55
  [VIP   39] GETTABUP  Stk[39] = env['number']
  [VIP   40] CALL      call Stk[A](...)
  [VIP   41] GETTABUP  Stk[41] = env['number']
  [VIP   42] ADDI      Stk[42] = Stk[42] + 21
  [VIP   43] CALL      call Stk[A](...)
  [VIP   44] GETTABUP  Stk[44] = env['number']
  [VIP   45] CALL      call Stk[A](...)
  [VIP   46] CALL      call Stk[A](...)
  [VIP   47] GETTABUP  Stk[47] = env['number']
  [VIP   48] CALL      call Stk[A](...)
  [VIP   49] GETTABUP  Stk[49] = env['number']
  [VIP   50] ADDI      Stk[50] = Stk[50] + 123
  [VIP   51] GETTABUP  Stk[51] = env[K[643]]
  [VIP   51] DT        dT(x,643,51)
  [VIP   52] CALL      call Stk[A](...)
  [VIP   53] GETTABUP  Stk[53] = env['number']
  [VIP   54] CALL      call Stk[A](...)
  [VIP   55] ADDI      Stk[55] = Stk[55] + 95
  [VIP   59] GETTABUP  Stk[59] = env[K[81]]
  [VIP   59] DT        dT(x,81,59)
  [VIP   60] GETTABUP  Stk[60] = env['Luraph']
  [VIP   60] DT        dT(x,7,60)
  [VIP   61] GETTABUP  Stk[61] = env[K[552]]
  [VIP   61] DT        dT(x,552,61)
  [VIP   63] ADDI      Stk[63] = Stk[63] + 171
  [VIP   64] GETTABUP  Stk[64] = env[K[459]]
  [VIP   64] DT        dT(x,459,64)
  [VIP   65] GETTABUP  Stk[65] = env[K[486]]
  [VIP   65] DT        dT(x,486,65)
  [VIP   66] GETTABUP  Stk[66] = env[K[510]]
  [VIP   66] DT        dT(x,510,66)
  [VIP   69] GETTABUP  Stk[69] = env[K[496]]
  [VIP   69] DT        dT(x,496,69)
  [VIP   71] CALL      call Stk[A](...)
  [VIP   72] ADDI      Stk[72] = Stk[72] + 146
  [VIP   73] GETTABUP  Stk[73] = env[K[165]]
  [VIP   73] DT        dT(x,165,73)
  [VIP   74] GETTABUP  Stk[74] = env[K[568]]
  [VIP   74] DT        dT(x,568,74)
  [VIP   75] GETTABUP  Stk[75] = env[K[380]]
  [VIP   75] DT        dT(x,380,75)
  [VIP   76] GETTABUP  Stk[76] = env[K[267]]
  [VIP   76] DT        dT(x,267,76)
  [VIP   77] CALL      call Stk[A](...)
  [VIP   78] GETTABUP  Stk[78] = env['number']
  [VIP   79] GETTABUP  Stk[79] = env[K[621]]
  [VIP   79] DT        dT(x,621,79)
  [VIP   81] CALL      call Stk[A](...)
  [VIP   83] ADDI      Stk[83] = Stk[83] + 6
  [VIP   84] GETTABUP  Stk[84] = env['number']
  [VIP   85] GETTABUP  Stk[85] = env[K[519]]
  [VIP   85] DT        dT(x,519,85)
  [VIP   86] GETTABUP  Stk[86] = env[K[665]]
  [VIP   86] DT        dT(x,665,86)
  [VIP   87] CALL      call Stk[A](...)
  [VIP   88] ADDI      Stk[88] = Stk[88] + 186
  [VIP   89] SETREG    Stk[89] = 28
  [VIP   90] GETTABUP  Stk[90] = env['number']
  [VIP   91] GETTABUP  Stk[91] = env[K[498]]
  [VIP   91] DT        dT(x,498,91)
  [VIP   92] CALL      call Stk[A](...)
  [VIP   93] SUBI      Stk[93] = Stk[93] - 5
  [VIP   94] ADDI      Stk[94] = Stk[94] + 12
  [VIP   95] GETTABUP  Stk[95] = env['number']
  [VIP   98] GETTABUP  Stk[98] = env[K[425]]
  [VIP   98] DT        dT(x,425,98)
  [VIP  100] DT        dT(x,297,100)
  [VIP  102] GETTABUP  Stk[102] = env['number']
  [VIP  103] CALL      call Stk[A](...)
  [VIP  104] CALL      call Stk[A](...)
  [VIP  105] SETREG    Stk[105] = 1
  [VIP  106] ADDI      Stk[106] = Stk[106] + 35
  [VIP  110] GETTABUP  Stk[110] = env['gmatch']
  [VIP  110] DT        dT(x,5,110)
  [VIP  111] GETTABUP  Stk[111] = env['linedefined']
  [VIP  111] DT        dT(x,68,111)
  [VIP  112] GETTABUP  Stk[112] = env[K[214]]
  [VIP  112] DT        dT(x,214,112)
  [VIP  114] ADDI      Stk[114] = Stk[114] + 139
  [VIP  117] GETTABUP  Stk[117] = env['linedefined']
  [VIP  117] DT        dT(x,68,117)
  [VIP  118] GETTABUP  Stk[118] = env[' ']
  [VIP  118] DT        dT(x,21,118)
  [VIP  120] SETREG    Stk[120] = 24
  [VIP  121] ADDI      Stk[121] = Stk[121] + 89
  [VIP  124] GETTABUP  Stk[124] = env[K[115]]
  [VIP  124] DT        dT(x,115,124)
  [VIP  125] GETTABUP  Stk[125] = env[K[651]]
  [VIP  125] DT        dT(x,651,125)
  [VIP  127] ADDI      Stk[127] = Stk[127] + 92
  [VIP  128] GETTABUP  Stk[128] = env['number']
  [VIP  129] GETTABUP  Stk[129] = env[K[444]]
  [VIP  129] DT        dT(x,444,129)
  [VIP  130] CALL      call Stk[A](...)
  [VIP  131] GETTABUP  Stk[131] = env['number']
  [VIP  132] ADDI      Stk[132] = Stk[132] + 117
  [VIP  133] GETTABUP  Stk[133] = env['number']
  [VIP  136] GETTABUP  Stk[136] = env[K[301]]
  [VIP  136] DT        dT(x,301,136)
  [VIP  138] GETTABUP  Stk[138] = env[K[600]]
  [VIP  138] DT        dT(x,600,138)
  [VIP  139] GETTABUP  Stk[139] = env[K[377]]
  [VIP  139] DT        dT(x,377,139)
  [VIP  140] GETTABUP  Stk[140] = env[K[172]]
  [VIP  140] DT        dT(x,172,140)
  [VIP  141] ADDI      Stk[141] = Stk[141] + 33
  [VIP  144] GETTABUP  Stk[144] = env[K[83]]
  [VIP  144] DT        dT(x,83,144)
  [VIP  145] GETTABUP  Stk[145] = env['isvararg']
  [VIP  146] GETTABUP  Stk[146] = env['isvararg']
  [VIP  147] GETTABUP  Stk[147] = env['loadstring']
  [VIP  148] GETTABUP  Stk[148] = env[K[342]]
  [VIP  148] DT        dT(x,342,148)
  [VIP  150] ADDI      Stk[150] = Stk[150] + 83
  [VIP  151] ADDI      Stk[151] = Stk[151] + 74
  [VIP  152] CALL      call Stk[A](...)
  [VIP  153] CALL      call Stk[A](...)
  [VIP  154] GETTABUP  Stk[154] = env['number']
  [VIP  155] ADDI      Stk[155] = Stk[155] + 36
  [VIP  159] GETTABUP  Stk[159] = env[K[115]]
  [VIP  159] DT        dT(x,115,159)
  [VIP  160] GETTABUP  Stk[160] = env[K[448]]
  [VIP  160] DT        dT(x,448,160)
  [VIP  161] GETTABUP  Stk[161] = env[K[115]]
  [VIP  161] DT        dT(x,115,161)
  [VIP  162] GETTABUP  Stk[162] = env[K[660]]
  [VIP  162] DT        dT(x,660,162)
  [VIP  164] ADDI      Stk[164] = Stk[164] + 115
  [VIP  165] SUBI      Stk[165] = Stk[165] - 51
  [VIP  169] CALL      call Stk[A](...)
  [VIP  170] GETTABUP  Stk[170] = env['number']
  [VIP  171] GETTABUP  Stk[171] = env[K[311]]
  [VIP  171] DT        dT(x,311,171)
  [VIP  172] GETTABUP  Stk[172] = env[K[360]]
  [VIP  172] DT        dT(x,360,172)
  [VIP  173] ADDI      Stk[173] = Stk[173] + 32
  [VIP  174] SETREG    Stk[174] = 55
  [VIP  175] GETTABUP  Stk[175] = env[K[688]]
  [VIP  175] DT        dT(x,688,175)
  [VIP  176] CALL      call Stk[A](...)
  [VIP  177] GETTABUP  Stk[177] = env['number']
  [VIP  178] GETTABUP  Stk[178] = env[K[280]]
  [VIP  178] DT        dT(x,280,178)
  [VIP  179] SUBI      Stk[179] = Stk[179] - 15
  [VIP  180] GETTABUP  Stk[180] = env[K[369]]
  [VIP  180] DT        dT(x,369,180)
  [VIP  181] CALL      call Stk[A](...)
  [VIP  182] GETTABUP  Stk[182] = env['number']
  [VIP  183] GETTABUP  Stk[183] = env[K[603]]
  [VIP  183] DT        dT(x,603,183)
  [VIP  184] GETTABUP  Stk[184] = env[K[553]]
  [VIP  184] DT        dT(x,553,184)
  [VIP  185] GETTABUP  Stk[185] = env[K[160]]
  [VIP  185] DT        dT(x,160,185)
  [VIP  186] GETTABUP  Stk[186] = env[K[143]]
  [VIP  186] DT        dT(x,143,186)
  [VIP  187] CALL      call Stk[A](...)
  [VIP  188] CALL      call Stk[A](...)
  [VIP  189] GETTABUP  Stk[189] = env['number']
  [VIP  190] CALL      call Stk[A](...)
  [VIP  191] SETREG    Stk[191] = 94
  [VIP  192] CALL      call Stk[A](...)
  [VIP  193] GETTABUP  Stk[193] = env['number']
  [VIP  194] GETTABUP  Stk[194] = env[K[554]]
  [VIP  194] DT        dT(x,554,194)
  [VIP  195] GETTABUP  Stk[195] = env[K[243]]
  [VIP  195] DT        dT(x,243,195)
  [VIP  196] GETTABUP  Stk[196] = env[K[392]]
  [VIP  196] DT        dT(x,392,196)
  [VIP  197] SUBI      Stk[197] = Stk[197] - 18
  [VIP  200] GETTABUP  Stk[200] = env[K[91]]
  [VIP  200] DT        dT(x,91,200)
  [VIP  201] GETTABUP  Stk[201] = env[K[115]]
  [VIP  201] DT        dT(x,115,201)
  [VIP  202] GETTABUP  Stk[202] = env[K[104]]
  [VIP  202] DT        dT(x,104,202)
  [VIP  204] SUBI      Stk[204] = Stk[204] - 53
  [VIP  206] GETTABUP  Stk[206] = env[K[169]]
  [VIP  206] DT        dT(x,169,206)
  [VIP  207] CALL      call Stk[A](...)
  [VIP  208] CALL      call Stk[A](...)
  [VIP  209] ADDI      Stk[209] = Stk[209] + 0
  [VIP  210] SUBI      Stk[210] = Stk[210] - 89
  [VIP  214] GETTABUP  Stk[214] = env[K[91]]
  [VIP  214] DT        dT(x,91,214)
  [VIP  215] GETTABUP  Stk[215] = env['Luraph']
  [VIP  215] DT        dT(x,7,215)
  [VIP  216] GETTABUP  Stk[216] = env['bit32']
  [VIP  216] DT        dT(x,1,216)
  [VIP  218] SETREG    Stk[218] = 50
  [VIP  219] SUBI      Stk[219] = Stk[219] - 64
  [VIP  220] GETTABUP  Stk[220] = env['number']
  [VIP  221] CALL      call Stk[A](...)
  [VIP  222] GETTABUP  Stk[222] = env['number']
  [VIP  223] GETTABUP  Stk[223] = env[K[436]]
  [VIP  223] DT        dT(x,436,223)
  [VIP  224] CALL      call Stk[A](...)
  [VIP  225] SETREG    Stk[225] = 34
  [VIP  228] GETTABUP  Stk[228] = env['gmatch']
  [VIP  228] DT        dT(x,5,228)
  [VIP  229] GETTABUP  Stk[229] = env['pcall']
  [VIP  229] DT        dT(x,2,229)
  [VIP  231] SETREG    Stk[231] = 38
  [VIP  232] ADDI      Stk[232] = Stk[232] + 11
  [VIP  233] ADDI      Stk[233] = Stk[233] + 5
  [VIP  234] SETREG    Stk[234] = 17
  [VIP  235] GETTABUP  Stk[235] = env[K[711]]
  [VIP  235] DT        dT(x,711,235)
  [VIP  236] GETTABUP  Stk[236] = env[K[244]]
  [VIP  236] DT        dT(x,244,236)
  [VIP  237] GETTABUP  Stk[237] = env[K[205]]
  [VIP  237] DT        dT(x,205,237)
  [VIP  238] SETREG    Stk[238] = 105
  [VIP  240] GETTABUP  Stk[240] = env[K[115]]
  [VIP  240] DT        dT(x,115,240)
  [VIP  241] GETTABUP  Stk[241] = env[K[545]]
  [VIP  241] DT        dT(x,545,241)
  [VIP  243] SUBI      Stk[243] = Stk[243] - 116
  [VIP  246] GETTABUP  Stk[246] = env['Luraph']
  [VIP  246] DT        dT(x,7,246)
  [VIP  247] GETTABUP  Stk[247] = env[K[138]]
  [VIP  247] DT        dT(x,138,247)
  [VIP  249] SUBI      Stk[249] = Stk[249] - 84
  [VIP  250] GETTABUP  Stk[250] = env[K[193]]
  [VIP  250] DT        dT(x,193,250)
  [VIP  251] GETTABUP  Stk[251] = env['setmetatable']
  [VIP  251] DT        dT(x,79,251)
  [VIP  252] GETTABUP  Stk[252] = env[K[246]]
  [VIP  252] DT        dT(x,246,252)
  [VIP  253] SETREG    Stk[253] = 9
  [VIP  254] GETTABUP  Stk[254] = env[K[379]]
  [VIP  254] DT        dT(x,379,254)
  [VIP  255] GETTABUP  Stk[255] = env[K[295]]
  [VIP  255] DT        dT(x,295,255)
  [VIP  256] GETTABUP  Stk[256] = env[K[615]]
  [VIP  256] DT        dT(x,615,256)
  [VIP  257] GETTABUP  Stk[257] = env[K[505]]
  [VIP  257] DT        dT(x,505,257)
  [VIP  258] GETTABUP  Stk[258] = env[K[576]]
  [VIP  258] DT        dT(x,576,258)
  [VIP  259] ADDI      Stk[259] = Stk[259] + 0
  [VIP  260] CALL      call Stk[A](...)
  [VIP  261] GETTABUP  Stk[261] = env['number']
  [VIP  262] GETTABUP  Stk[262] = env[K[516]]
  [VIP  262] DT        dT(x,516,262)
  [VIP  263] GETTABUP  Stk[263] = env[K[370]]
  [VIP  263] DT        dT(x,370,263)
  [VIP  264] GETTABUP  Stk[264] = env[K[282]]
  [VIP  264] DT        dT(x,282,264)
  [VIP  265] GETTABUP  Stk[265] = env[K[357]]
  [VIP  265] DT        dT(x,357,265)
  [VIP  266] GETTABUP  Stk[266] = env[K[624]]
  [VIP  266] DT        dT(x,624,266)
  [VIP  267] SETLIST2  rD/ZD/wD(...)
  [VIP  268] SETREG    Stk[268] = 101
  [VIP  269] SUBI      Stk[269] = Stk[269] - 38
  [VIP  270] GETTABUP  Stk[270] = env[K[393]]
  [VIP  270] DT        dT(x,393,270)
  [VIP  271] GETTABUP  Stk[271] = env[K[531]]
  [VIP  271] DT        dT(x,531,271)
  [VIP  272] GETTABUP  Stk[272] = env[K[689]]
  [VIP  272] DT        dT(x,689,272)
  [VIP  273] SETREG    Stk[273] = 72
  [VIP  274] SUBI      Stk[274] = Stk[274] - 77
  [VIP  275] GETTABUP  Stk[275] = env['number']
  [VIP  276] GETTABUP  Stk[276] = env[K[382]]
  [VIP  276] DT        dT(x,382,276)
  [VIP  277] GETTABUP  Stk[277] = env[K[699]]
  [VIP  277] DT        dT(x,699,277)
  [VIP  278] CALL      call Stk[A](...)
  [VIP  279] SUBI      Stk[279] = Stk[279] - 47
  [VIP  280] GETTABUP  Stk[280] = env['number']
  [VIP  282] CALL      call Stk[A](...)
  [VIP  284] CALL      call Stk[A](...)
  [VIP  285] SETREG    Stk[285] = 83
  [VIP    1] ADDI      Stk[1] = Stk[1] + 88
  [VIP    2] DT        dT(x,185,2)
  [VIP    3] ADDI      Stk[3] = Stk[3] + 76
  [VIP    7] GETTABUP  Stk[7] = env[K[104]]
  [VIP    7] DT        dT(x,104,7)
  [VIP    8] GETTABUP  Stk[8] = env[K[109]]
  [VIP    8] DT        dT(x,109,8)
  [VIP    9] GETTABUP  Stk[9] = env[K[101]]
  [VIP    9] DT        dT(x,101,9)
  [VIP   10] GETTABUP  Stk[10] = env[K[376]]
  [VIP   10] DT        dT(x,376,10)
  [VIP   12] ADDI      Stk[12] = Stk[12] + 70
  [VIP   13] ADDI      Stk[13] = Stk[13] + 39
  [VIP   14] ADDI      Stk[14] = Stk[14] + 28
  [VIP   15] DT        dT(x,291,15)
  [VIP   16] ADDI      Stk[16] = Stk[16] + 37
  [VIP   17] ADDI      Stk[17] = Stk[17] + 11
  [VIP   18] ADDI      Stk[18] = Stk[18] + 45
  [VIP   19] ADD       Stk[19] = Stk[19] + 15
  [VIP   20] SUBI      Stk[20] = Stk[20] - 6
  [VIP   21] ADDI      Stk[21] = Stk[21] + 69
  [VIP   22] ADDI      Stk[22] = Stk[22] + 29
  [VIP   23] ADDI      Stk[23] = Stk[23] + 26
  [VIP   25] GETTABUP  Stk[25] = env['lastlinedefined']
  [VIP   25] DT        dT(x,11,25)
  [VIP   26] GETTABUP  Stk[26] = env[K[86]]
  [VIP   26] DT        dT(x,86,26)
  [VIP   28] ADDI      Stk[28] = Stk[28] + 52
  [VIP   29] DT        dT(x,186,29)
  [VIP   30] SUBI      Stk[30] = Stk[30] - 12
  [VIP   32] CALL      call Stk[A](...)
  [VIP   33] CALL      call Stk[A](...)
  [VIP   34] SETREG    Stk[34] = 17
  [VIP   35] DT        dT(x,106,35)
  [VIP   37] ADDI      Stk[37] = Stk[37] + 32
  [VIP   39] DT        dT(x,65,39)
  [VIP   42] ADDI      Stk[42] = Stk[42] + 37
  [VIP   47] SETREG    Stk[47] = 20
  [VIP   48] ADDI      Stk[48] = Stk[48] + 31
  [VIP   48] CALL      call Stk[A](...)
  [VIP   49] ADDI      Stk[49] = Stk[49] + 1
  [VIP   50] ADDI      Stk[50] = Stk[50] + 37
  [VIP   51] ADDI      Stk[51] = Stk[51] + 20
  [VIP   53] SETREG    Stk[53] = 3
  [VIP   54] GETTABUP  Stk[54] = env['next']
  [VIP   55] GETTABUP  Stk[55] = env['next']
  [VIP   56] GETTABUP  Stk[56] = env['rawset']
  [VIP   57] GETTABUP  Stk[57] = env['nparams']
  [VIP   57] DT        dT(x,56,57)
  [VIP   59] SETREG    Stk[59] = 1
  [VIP   62] SUBI      Stk[62] = Stk[62] - 11
  [VIP   66] GETTABUP  Stk[66] = env['tonumber']
  [VIP   66] DT        dT(x,6,66)
  [VIP   67] GETTABUP  Stk[67] = env['linedefined']
  [VIP   67] DT        dT(x,68,67)
  [VIP   69] SETREG    Stk[69] = 12
  [VIP   70] LOADN     Stk[70] = 347
  [VIP   70] DT        dT(x,347,70)
  [VIP   71] SUBI      Stk[71] = Stk[71] - 12
  [VIP   75] GETTABUP  Stk[75] = env['typeof']
  [VIP   75] DT        dT(x,3,75)
  [VIP   76] GETTABUP  Stk[76] = env['nparams']
  [VIP   76] DT        dT(x,56,76)
  [VIP   77] GETTABUP  Stk[77] = env[K[98]]
  [VIP   77] DT        dT(x,98,77)
  [VIP   79] SETREG    Stk[79] = 37
  [VIP   80] SETREG    Stk[80] = 23
  [VIP   81] SUBI      Stk[81] = Stk[81] - 34
  [VIP   81] CALL      call Stk[A](...)
  [VIP   82] SETREG    Stk[82] = 13
  [VIP   85] GETTABUP  Stk[85] = env['next']
  [VIP   85] CALL      call Stk[A](...)
  [VIP   86] SETREG    Stk[86] = 18
  [VIP   87] SETREG    Stk[87] = 16
  [VIP   88] DT        dT(x,439,88)
  [VIP   89] SUBI      Stk[89] = Stk[89] - 20
  [VIP   90] SETREG    Stk[90] = 30
  [VIP   93] GETTABUP  Stk[93] = env['Luraph']
  [VIP   93] DT        dT(x,7,93)
  [VIP   94] GETTABUP  Stk[94] = env[K[118]]
  [VIP   94] DT        dT(x,118,94)
  [VIP   96] SETREG    Stk[96] = 21
  [VIP    1] ADDI      Stk[1] = Stk[1] + 62
  [VIP    2] ADDI      Stk[2] = Stk[2] + 71
  [VIP    3] ADDI      Stk[3] = Stk[3] + 96
  [VIP    9] ADDI      Stk[9] = Stk[9] + 41
  [VIP   13] GETTABUP  Stk[13] = env['gmatch']
  [VIP   13] DT        dT(x,5,13)
  [VIP   14] GETTABUP  Stk[14] = env['Luraph']
  [VIP   14] DT        dT(x,7,14)
  [VIP   15] GETTABUP  Stk[15] = env['tonumber']
  [VIP   15] DT        dT(x,6,15)
  [VIP   17] ADDI      Stk[17] = Stk[17] + 2
  [VIP   18] ADDI      Stk[18] = Stk[18] + 21
  [VIP   19] SETREG    Stk[19] = 9
  [VIP   20] ADD       Stk[20] = Stk[20] + 0
  [VIP   21] SETREG    Stk[21] = 1
  [VIP   24] GETTABUP  Stk[24] = env['nparams']
  [VIP   24] DT        dT(x,56,24)
  [VIP   25] GETTABUP  Stk[25] = env['Luraph']
  [VIP   25] DT        dT(x,7,25)
  [VIP   26] GETTABUP  Stk[26] = env['source']
  [VIP   26] DT        dT(x,51,26)
  [VIP   27] GETTABUP  Stk[27] = env['close']
  [VIP   27] DT        dT(x,55,27)
  [VIP   29] ADDI      Stk[29] = Stk[29] + 52
  [VIP   30] ADDI      Stk[30] = Stk[30] + 11
  [VIP   31] ADDI      Stk[31] = Stk[31] + 43
  [VIP   32] GETTABUP  Stk[32] = env['gmatch']
  [VIP   32] ADDU      Upv[32] = Upv[32] + 50
  [VIP   33] ADDI      Stk[33] = Stk[33] + 39
  [VIP   36] GETTABUP  Stk[36] = env[K[101]]
  [VIP   36] DT        dT(x,101,36)
  [VIP   37] GETTABUP  Stk[37] = env[K[269]]
  [VIP   37] DT        dT(x,269,37)
  [VIP   39] ADDI      Stk[39] = Stk[39] + 21
  [VIP   40] DT        dT(x,52,40)
  [VIP   41] ADDI      Stk[41] = Stk[41] + 21
  [VIP   45] GETTABUP  Stk[45] = env['Luraph']
  [VIP   45] DT        dT(x,7,45)
  [VIP   46] GETTABUP  Stk[46] = env['xpcall']
  [VIP   46] DT        dT(x,40,46)
  [VIP   47] GETTABUP  Stk[47] = env[K[90]]
  [VIP   47] DT        dT(x,90,47)
  [VIP   48] GETTABUP  Stk[48] = env[K[89]]
  [VIP   48] DT        dT(x,89,48)
  [VIP   50] SETREG    Stk[50] = 4
  [VIP   61] ADD       Stk[61] = Stk[61] + 18
  [VIP   62] SETREG    Stk[62] = 2
  [VIP   63] SUBI      Stk[63] = Stk[63] - 30
  [VIP   65] DT        dT(x,144,65)
  [VIP   66] DT        dT(x,424,66)
  [VIP   67] DT        dT(x,100,67)
  [VIP   68] SETREG2   Upv[68] = 18
  [VIP   71] CALL      call Stk[A](...)
  [VIP   72] SETREG    Stk[72] = 29
  [VIP   73] ADDI      Stk[73] = Stk[73] + 13
  [VIP   74] SUBI      Stk[74] = Stk[74] - 6
  [VIP   77] GETTABUP  Stk[77] = env['gmatch']
  [VIP   77] DT        dT(x,5,77)
  [VIP   78] GETTABUP  Stk[78] = env['format']
  [VIP   78] DT        dT(x,35,78)
  [VIP   80] ADDI      Stk[80] = Stk[80] + 14
  [VIP   81] SUBI      Stk[81] = Stk[81] - 13
  [VIP   82] SETREG    Stk[82] = 30
  [VIP   86] SETREG    Stk[86] = 18
  [VIP   88] CALL      call Stk[A](...)
  [VIP   93] SUBI      Stk[93] = Stk[93] - 13
  [VIP   94] SETREG    Stk[94] = 21
  [VIP   97] GETTABUP  Stk[97] = env[K[119]]
  [VIP   97] DT        dT(x,119,97)
  [VIP   98] SUBI      Stk[98] = Stk[98] - 36
  [VIP   99] SETREG    Stk[99] = 17
  [VIP  100] DT        dT(x,105,100)
  [VIP  101] GETTABUP  Stk[101] = env['char']
  [VIP  102] GETTABUP  Stk[102] = env['char']
  [VIP  103] GETTABUP  Stk[103] = env['lastlinedefined']
  [VIP  104] GETTABUP  Stk[104] = env[K[97]]
  [VIP  104] DT        dT(x,97,104)
  [VIP  106] SETREG    Stk[106] = 31
  [VIP    1] ADDI      Stk[1] = Stk[1] + 30
  [VIP    2] DT        dT(x,56,2)
  [VIP    3] ADDU      Upv[3] = Upv[3] + 42
  [VIP    4] ADDI      Stk[4] = Stk[4] + 28
  [VIP    8] GETTABUP  Stk[8] = env[K[81]]
  [VIP    8] DT        dT(x,81,8)
  [VIP    9] GETTABUP  Stk[9] = env['short_src']
  [VIP    9] DT        dT(x,77,9)
  [VIP   10] GETTABUP  Stk[10] = env['gmatch']
  [VIP   10] DT        dT(x,5,10)
  [VIP   12] ADDI      Stk[12] = Stk[12] + 6
  [VIP   13] DT        dT(x,77,13)
  [VIP   16] DT        dT(x,56,16)
  [VIP   18] SETREG    Stk[18] = 1
  [VIP   19] ADDI      Stk[19] = Stk[19] + 34
  [VIP   21] ADDI      Stk[21] = Stk[21] + 24
  [VIP   22] ADDI      Stk[22] = Stk[22] + 25
  [VIP   27] GETTABUP  Stk[27] = env['Luraph']
  [VIP   27] DT        dT(x,7,27)
  [VIP   28] GETTABUP  Stk[28] = env['Luraph']
  [VIP   28] DT        dT(x,7,28)
  [VIP   29] GETTABUP  Stk[29] = env[K[112]]
  [VIP   29] DT        dT(x,112,29)
  [VIP   31] ADDI      Stk[31] = Stk[31] + 8
  [VIP   32] SETREG    Stk[32] = 4
  [VIP   35] GETTABUP  Stk[35] = env[K[89]]
  [VIP   35] DT        dT(x,89,35)
  [VIP   36] GETTABUP  Stk[36] = env['linedefined']
  [VIP   36] DT        dT(x,68,36)
  [VIP   38] SETREG    Stk[38] = 12
  [VIP   39] SUBI      Stk[39] = Stk[39] - 18
  [VIP   40] SETLIST2  rD/ZD/wD(...)
  [VIP   45] SETREG    Stk[45] = 3
  [VIP   46] LOADN     Stk[46] = 0
  [VIP   47] SETREG    Stk[47] = 21
  [VIP   50] GETTABUP  Stk[50] = env[' --[[%s]] return setfenv(function(...) r...']
  [VIP   50] DT        dT(x,44,50)
  [VIP   51] GETTABUP  Stk[51] = env['pcall']
  [VIP   51] DT        dT(x,2,51)
  [VIP   53] SUBI      Stk[53] = Stk[53] - 15
  [VIP   54] ADDI      Stk[54] = Stk[54] + 0
  [VIP   56] GETTABUP  Stk[56] = env[K[558]]
  [VIP   56] DT        dT(x,558,56)
  [VIP   58] GETTABUP  Stk[58] = env[K[199]]
  [VIP   62] GETTABUP  Stk[62] = env['rawset']
  [VIP   63] GETTABUP  Stk[63] = env['tonumber']
  [VIP   64] GETTABUP  Stk[64] = env[K[112]]
  [VIP   64] DT        dT(x,112,64)
  [VIP   66] ADDI      Stk[66] = Stk[66] + 0
  [VIP   67] SETREG    Stk[67] = 23
  [VIP    1] ADDI      Stk[1] = Stk[1] + 70
  [VIP    5] GETTABUP  Stk[5] = env['Luraph']
  [VIP    5] DT        dT(x,7,5)
  [VIP    6] GETTABUP  Stk[6] = env['C']
  [VIP    6] DT        dT(x,29,6)
  [VIP    8] ADDI      Stk[8] = Stk[8] + 40
  [VIP    9] ADD       Stk[9] = Stk[9] + 91
  [VIP    9] DT        dT(x,91,9)
  [VIP   10] ADDI      Stk[10] = Stk[10] + 66
  [VIP   11] ADDI      Stk[11] = Stk[11] + 85
  [VIP   12] ADD       Stk[12] = Stk[12] + 247
  [VIP   12] DT        dT(x,247,12)
  [VIP   13] ADDI      Stk[13] = Stk[13] + 22
  [VIP   16] GETTABUP  Stk[16] = env['lastlinedefined']
  [VIP   16] DT        dT(x,11,16)
  [VIP   17] GETTABUP  Stk[17] = env[K[97]]
  [VIP   17] DT        dT(x,97,17)
  [VIP   19] ADDI      Stk[19] = Stk[19] + 12
  [VIP   20] DT        dT(x,610,20)
  [VIP   21] SETREG    Stk[21] = 10
  [VIP   22] DT        dT(x,247,22)
  [VIP   22] ADDU      Upv[22] = Upv[22] + 16
  [VIP   23] ADDI      Stk[23] = Stk[23] + 68
  [VIP   25] ADDI      Stk[25] = Stk[25] + 62
  [VIP   28] GETTABUP  Stk[28] = env['Luraph']
  [VIP   28] DT        dT(x,7,28)
  [VIP   29] GETTABUP  Stk[29] = env[K[94]]
  [VIP   29] DT        dT(x,94,29)
  [VIP   31] ADDI      Stk[31] = Stk[31] + 32
  [VIP   35] ADDI      Stk[35] = Stk[35] + 72
  [VIP   37] ADDI      Stk[37] = Stk[37] + 38
  [VIP   38] SETREG    Stk[38] = 2
  [VIP   39] SUBI      Stk[39] = Stk[39] - 14
  [VIP   42] GETTABUP  Stk[42] = env['Luraph']
  [VIP   42] DT        dT(x,7,42)
  [VIP   43] GETTABUP  Stk[43] = env[K[103]]
  [VIP   43] DT        dT(x,103,43)
  [VIP   45] ADDI      Stk[45] = Stk[45] + 2
  [VIP   46] ADDI      Stk[46] = Stk[46] + 29
  [VIP   47] SUBU      Upv[47] = Upv[47] - 9
  [VIP   48] SUBI      Stk[48] = Stk[48] - 11
  [VIP   51] DT        dT(x,417,51)
  [VIP   51] CALL      call Stk[A](...)
  [VIP   52] SETREG    Stk[52] = 10
  [VIP   53] ADDI      Stk[53] = Stk[53] + 25
  [VIP   57] GETTABUP  Stk[57] = env['Luraph']
  [VIP   57] DT        dT(x,7,57)
  [VIP   58] GETTABUP  Stk[58] = env['char']
  [VIP   58] DT        dT(x,18,58)
  [VIP   59] GETTABUP  Stk[59] = env['xpcall']
  [VIP   59] DT        dT(x,40,59)
  [VIP   60] GETTABUP  Stk[60] = env[K[122]]
  [VIP   60] DT        dT(x,122,60)
  [VIP   61] GETTABUP  Stk[61] = env['coroutine']
  [VIP   61] DT        dT(x,37,61)
  [VIP   63] SUBI      Stk[63] = Stk[63] - 17
  [VIP   64] LOADN     Stk[64] = 0
  [VIP   65] ADDI      Stk[65] = Stk[65] + 41
  [VIP   66] SUBI      Stk[66] = Stk[66] - 27
  [VIP   67] CALL      call Stk[A](...)
  [VIP   68] DT        dT(x,157,68)
  [VIP   69] DT        dT(x,313,69)
  [VIP   70] DT        dT(x,439,70)
  [VIP   71] SUBI      Stk[71] = Stk[71] - 6
  [VIP   73] CALL      call Stk[A](...)
  [VIP   74] CALL      call Stk[A](...)
  [VIP   75] SUBI      Stk[75] = Stk[75] - 9
  [VIP   76] SETREG    Stk[76] = 13
  [VIP   78] SETREG    Stk[78] = 38
  [VIP   79] SETREG    Stk[79] = 19
  [VIP   80] GETTABUP  Stk[80] = env['byte']
  [VIP   81] GETTABUP  Stk[81] = env['byte']
  [VIP   82] GETTABUP  Stk[82] = env['slnaf']
  [VIP   83] GETTABUP  Stk[83] = env['coroutine']
  [VIP   83] DT        dT(x,37,83)
  [VIP   85] ADDI      Stk[85] = Stk[85] + 10
  [VIP   86] SETTABUP  Stk['byte'] = Stk[...]
  [VIP   87] ADDI      Stk[87] = Stk[87] + 28
  [VIP   91] SETREG    Stk[91] = 1
  [VIP   93] SETREG    Stk[93] = 38
  [VIP   94] DT        dT(x,145,94)
  [VIP   94] SETREG2   Upv[94] = 21
  [VIP   95] SETREG    Stk[95] = 8
  [VIP   96] SUBI      Stk[96] = Stk[96] - 43
  [VIP   99] GETTABUP  Stk[99] = env['tonumber']
  [VIP   99] DT        dT(x,6,99)
  [VIP  100] GETTABUP  Stk[100] = env['rrotate']
  [VIP  100] DT        dT(x,43,100)
  [VIP  102] SUBI      Stk[102] = Stk[102] - 17
  [VIP  103] DT        dT(x,561,103)
  [VIP  104] SUBI      Stk[104] = Stk[104] - 25
  [VIP  105] SETREG    Stk[105] = 1
  [VIP  106] SETREG    Stk[106] = 24
  [VIP  107] SETREG    Stk[107] = 45
  [VIP  115] SUBI      Stk[115] = Stk[115] - 11
  [VIP  116] SUBI      Stk[116] = Stk[116] - 14
  [VIP    1] ADDI      Stk[1] = Stk[1] + 55
  [VIP    2] DT        dT(x,291,2)
  [VIP    3] DT        dT(x,88,3)
  [VIP    4] ADDU      Upv[4] = Upv[4] + 19
  [VIP    5] ADDI      Stk[5] = Stk[5] + 24
  [VIP    8] GETTABUP  Stk[8] = env[K[90]]
  [VIP    8] DT        dT(x,90,8)
  [VIP    9] GETTABUP  Stk[9] = env['status']
  [VIP    9] DT        dT(x,61,9)
  [VIP   11] ADDI      Stk[11] = Stk[11] + 30
  [VIP   15] GETTABUP  Stk[15] = env[' --[[%s]] return setfenv(function(...) r...']
  [VIP   15] DT        dT(x,44,15)
  [VIP   16] GETTABUP  Stk[16] = env['source']
  [VIP   16] DT        dT(x,51,16)
  [VIP   17] GETTABUP  Stk[17] = env['lastlinedefined']
  [VIP   17] DT        dT(x,11,17)
  [VIP   18] GETTABUP  Stk[18] = env['match']
  [VIP   18] DT        dT(x,25,18)
  [VIP   20] ADDI      Stk[20] = Stk[20] + 53
  [VIP   23] ADDI      Stk[23] = Stk[23] + 62
  [VIP   24] ADD       Stk[24] = Stk[24] + 0
  [VIP   25] ADDI      Stk[25] = Stk[25] + 57
  [VIP   27] SUBI      Stk[27] = Stk[27] - 4
  [VIP   28] ADDI      Stk[28] = Stk[28] + 39
  [VIP   29] ADDI      Stk[29] = Stk[29] + 14
  [VIP   32] GETTABUP  Stk[32] = env[K[296]]
  [VIP   32] DT        dT(x,296,32)
  [VIP   33] GETTABUP  Stk[33] = env['type']
  [VIP   34] GETTABUP  Stk[34] = env['byte']
  [VIP   35] GETTABUP  Stk[35] = env['number']
  [VIP   36] GETTABUP  Stk[36] = env[K[121]]
  [VIP   36] DT        dT(x,121,36)
  [VIP   38] ADDI      Stk[38] = Stk[38] + 16
  [VIP   39] SETREG    Stk[39] = 5
  [VIP   40] DT        dT(x,34,40)
  [VIP   40] ADDU      Upv[40] = Upv[40] + 22
  [VIP   41] SUBI      Stk[41] = Stk[41] - 20
  [VIP   43] SUBI      Stk[43] = Stk[43] - 20
  [VIP   47] GETTABUP  Stk[47] = env['tonumber']
  [VIP   47] DT        dT(x,6,47)
  [VIP   48] GETTABUP  Stk[48] = env[K[101]]
  [VIP   48] DT        dT(x,101,48)
  [VIP   49] GETTABUP  Stk[49] = env['tonumber']
  [VIP   49] DT        dT(x,6,49)
  [VIP   50] GETTABUP  Stk[50] = env['tonumber']
  [VIP   50] DT        dT(x,6,50)
  [VIP   51] GETTABUP  Stk[51] = env[K[89]]
  [VIP   51] DT        dT(x,89,51)
  [VIP   53] SETREG    Stk[53] = 4
  [VIP   54] SETREG    Stk[54] = 11
  [VIP   55] GETTABUP  Stk[55] = env['loadstring']
  [VIP   55] SUBI      Stk[55] = Stk[55] - 17
  [VIP   56] ADDI      Stk[56] = Stk[56] + 32
  [VIP   58] CALL      call Stk[A](...)
  [VIP   59] CALL      call Stk[A](...)
  [VIP   61] DT        dT(x,38,61)
  [VIP   62] SETREG    Stk[62] = 27
  [VIP   63] SETTABUP  Stk['coroutine'] = Stk[...]
  [VIP   63] DT        dT(x,37,63)
  [VIP   64] ADDI      Stk[64] = Stk[64] + 23
  [VIP   66] DT        dT(x,42,66)
  [VIP   67] SUBI      Stk[67] = Stk[67] - 28
  [VIP   70] GETTABUP  Stk[70] = env['xpcall']
  [VIP   70] DT        dT(x,40,70)
  [VIP   71] GETTABUP  Stk[71] = env['nparams']
  [VIP   71] DT        dT(x,56,71)
  [VIP   73] SETREG    Stk[73] = 1
  [VIP   82] SUBI      Stk[82] = Stk[82] - 18
  [VIP   84] DT        dT(x,114,84)
  [VIP   85] SETREG    Stk[85] = 39
  [VIP   88] SUBI      Stk[88] = Stk[88] - 35
  [VIP   89] ADDI      Stk[89] = Stk[89] + 2
  [VIP   90] LOADN     Stk[90] = 9
  [VIP   90] CALL      call Stk[A](...)
  [VIP   91] SETREG    Stk[91] = 25
  [VIP   93] SUBI      Stk[93] = Stk[93] - 11
  [VIP    1] ADDI      Stk[1] = Stk[1] + 28
  [VIP    5] DT        dT(x,99,5)
  [VIP    6] ADDI      Stk[6] = Stk[6] + 0
  [VIP    7] ADDI      Stk[7] = Stk[7] + 130
  [VIP    9] ADDI      Stk[9] = Stk[9] + 65
  [VIP   10] ADDU      Upv[10] = Upv[10] + 32
  [VIP   11] ADDI      Stk[11] = Stk[11] + 76
  [VIP   14] GETTABUP  Stk[14] = env[K[90]]
  [VIP   14] DT        dT(x,90,14)
  [VIP   15] GETTABUP  Stk[15] = env['nparams']
  [VIP   15] DT        dT(x,56,15)
  [VIP   17] SETREG    Stk[17] = 1
  [VIP   21] ADDI      Stk[21] = Stk[21] + 144
  [VIP   22] ADDI      Stk[22] = Stk[22] + 80
  [VIP   25] GETTABUP  Stk[25] = env['concat']
  [VIP   25] DT        dT(x,64,25)
  [VIP   26] GETTABUP  Stk[26] = env[K[82]]
  [VIP   26] DT        dT(x,82,26)
  [VIP   28] ADDI      Stk[28] = Stk[28] + 21
  [VIP   29] SETREG    Stk[29] = 9
  [VIP   30] ADDI      Stk[30] = Stk[30] + 58
  [VIP   31] ADDI      Stk[31] = Stk[31] + 49
  [VIP   34] ADDI      Stk[34] = Stk[34] + 33
  [VIP   38] ADDI      Stk[38] = Stk[38] + 63
  [VIP   39] ADDI      Stk[39] = Stk[39] + 94
  [VIP   39] CALL      call Stk[A](...)
  [VIP   40] ADDI      Stk[40] = Stk[40] + 15
  [VIP   44] CALL      call Stk[A](...)
  [VIP   45] DT        dT(x,690,45)
  [VIP   46] ADDI      Stk[46] = Stk[46] + 87
  [VIP   47] DT        dT(x,482,47)
  [VIP   49] ADDI      Stk[49] = Stk[49] + 20
  [VIP   50] SETTABUP  Stk['number'] = Stk[...]
  [VIP   50] CALL      call Stk[A](...)
  [VIP   51] ADDI      Stk[51] = Stk[51] + 31
  [VIP   53] CALL      call Stk[A](...)
  [VIP   54] CALL      call Stk[A](...)
  [VIP   55] ADDI      Stk[55] = Stk[55] + 15
  [VIP   56] ADDI      Stk[56] = Stk[56] + 64
  [VIP   57] ADD       Stk[57] = Stk[57] + 51
  [VIP   57] DT        dT(x,51,57)
  [VIP   58] ADDI      Stk[58] = Stk[58] + 0
  [VIP   59] SETREG    Stk[59] = 11
  [VIP   63] GETTABUP  Stk[63] = env['Luraph']
  [VIP   63] DT        dT(x,7,63)
  [VIP   64] GETTABUP  Stk[64] = env[K[89]]
  [VIP   64] DT        dT(x,89,64)
  [VIP   65] GETTABUP  Stk[65] = env[K[333]]
  [VIP   65] DT        dT(x,333,65)
  [VIP   67] ADDI      Stk[67] = Stk[67] + 57
  [VIP   68] ADDU      Upv[68] = Upv[68] + 3
  [VIP   69] SUBI      Stk[69] = Stk[69] - 29
  [VIP   70] SETREG    Stk[70] = 22
  [VIP   71] ADDI      Stk[71] = Stk[71] + 36
  [VIP   72] CALL      call Stk[A](...)
  [VIP   73] DT        dT(x,440,73)
  [VIP   74] SUBI      Stk[74] = Stk[74] - 5
  [VIP   75] ADD       Stk[75] = Stk[75] + 0
  [VIP   76] ADDI      Stk[76] = Stk[76] + 20
  [VIP   80] SETREG    Stk[80] = 21
  [VIP   82] ADDI      Stk[82] = Stk[82] + 14
  [VIP   83] SUBI      Stk[83] = Stk[83] - 37
  [VIP   84] DT        dT(x,45,84)
  [VIP   85] DT        dT(x,672,85)
  [VIP   86] DT        dT(x,87,86)
  [VIP   87] SUBU      Upv[87] = Upv[87] - 13
  [VIP   88] SETREG    Stk[88] = 34
  [VIP   92] GETTABUP  Stk[92] = env[' ']
  [VIP   92] DT        dT(x,21,92)
  [VIP   93] GETTABUP  Stk[93] = env['traceback']
  [VIP   93] DT        dT(x,34,93)
  [VIP   94] GETTABUP  Stk[94] = env[K[670]]
  [VIP   94] DT        dT(x,670,94)
  [VIP   96] SUBI      Stk[96] = Stk[96] - 45
  [VIP   99] DT        dT(x,287,99)
  [VIP  100] SETREG    Stk[100] = 6
  [VIP  101] ADDI      Stk[101] = Stk[101] + 25
  [VIP  102] ADDI      Stk[102] = Stk[102] + 44
  [VIP  104] GETTABUP  Stk[104] = env['Luraph']
  [VIP  104] DT        dT(x,7,104)
  [VIP  105] GETTABUP  Stk[105] = env[K[128]]
  [VIP  105] DT        dT(x,128,105)
  [VIP  107] SETREG    Stk[107] = 28
  [VIP  110] GETTABUP  Stk[110] = env[K[173]]
  [VIP  110] DT        dT(x,173,110)
  [VIP  112] GETTABUP  Stk[112] = env['wrap']
  [VIP  116] GETTABUP  Stk[116] = env['running']
  [VIP  117] GETTABUP  Stk[117] = env['loadstring']
  [VIP  118] GETTABUP  Stk[118] = env['tostring']
  [VIP  118] DT        dT(x,59,118)
  [VIP  120] SUBI      Stk[120] = Stk[120] - 37
  [VIP  121] CALL      call Stk[A](...)
  [VIP  123] SETREG    Stk[123] = 9
  [VIP  125] SETTABUP  Stk[94] = Stk[...]
  [VIP  125] DT        dT(x,94,125)
  [VIP  126] SETREG    Stk[126] = 30
  [VIP  129] GETTABUP  Stk[129] = env['linedefined']
  [VIP  129] DT        dT(x,68,129)
  [VIP  130] GETTABUP  Stk[130] = env['pcall']
  [VIP  130] DT        dT(x,2,130)
  [VIP  132] SETREG    Stk[132] = 38
  [VIP  133] SETREG    Stk[133] = 59
  [VIP  134] SUBI      Stk[134] = Stk[134] - 34
  [VIP  134] CALL      call Stk[A](...)
  [VIP  135] SETREG    Stk[135] = 17
  [VIP  136] DT        dT(x,43,136)
  [VIP  136] SUBU      Upv[136] = Upv[136] - 4
  [VIP  137] SETREG    Stk[137] = 7
  [VIP  141] GETTABUP  Stk[141] = env['xpcall']
  [VIP  141] DT        dT(x,40,141)
  [VIP  142] GETTABUP  Stk[142] = env['short_src']
  [VIP  142] DT        dT(x,77,142)
  [VIP  143] GETTABUP  Stk[143] = env['Luraph']
  [VIP  143] DT        dT(x,7,143)
  [VIP  144] GETTABUP  Stk[144] = env['next']
  [VIP  144] DT        dT(x,15,144)
  [VIP  146] SETREG    Stk[146] = 56
  [VIP  150] GETTABUP  Stk[150] = env['Luraph']
  [VIP  150] DT        dT(x,7,150)
  [VIP  151] GETTABUP  Stk[151] = env[K[221]]
  [VIP  151] DT        dT(x,221,151)
  [VIP  152] GETTABUP  Stk[152] = env[K[400]]
  [VIP  152] DT        dT(x,400,152)
  [VIP  154] ADDI      Stk[154] = Stk[154] + 0
  [VIP  165] SETREG    Stk[165] = 67
  [VIP  172] DT        dT(x,339,172)
  [VIP  173] SUBI      Stk[173] = Stk[173] - 40
  [VIP    1] ADDI      Stk[1] = Stk[1] + 27
  [VIP    2] ADDU      Upv[2] = Upv[2] + 191
  [VIP    3] ADDI      Stk[3] = Stk[3] + 243
  [VIP    4] ADDI      Stk[4] = Stk[4] + 192
  [VIP    5] ADDI      Stk[5] = Stk[5] + 14
  [VIP    5] CALL      call Stk[A](...)
  [VIP    6] ADDI      Stk[6] = Stk[6] + 12
  [VIP    8] GETTABUP  Stk[8] = env['error in error handling']
  [VIP    9] GETTABUP  Stk[9] = env['rawset']
  [VIP   10] ADDI      Stk[10] = Stk[10] + 11
  [VIP   14] GETTABUP  Stk[14] = env[K[95]]
  [VIP   14] DT        dT(x,95,14)
  [VIP   15] GETTABUP  Stk[15] = env[K[126]]
  [VIP   15] DT        dT(x,126,15)
  [VIP   16] GETTABUP  Stk[16] = env[K[92]]
  [VIP   16] DT        dT(x,92,16)
  [VIP   18] ADDI      Stk[18] = Stk[18] + 14
  [VIP   19] ADDI      Stk[19] = Stk[19] + 29
  [VIP   21] ADDI      Stk[21] = Stk[21] + 27
  [VIP   22] ADDI      Stk[22] = Stk[22] + 173
  [VIP   24] GETTABUP  Stk[24] = env['gmatch']
  [VIP   25] ADDI      Stk[25] = Stk[25] + 190
  [VIP   26] ADDI      Stk[26] = Stk[26] + 22
  [VIP   26] CALL      call Stk[A](...)
  [VIP   27] SETREG    Stk[27] = 4
  [VIP   28] ADDI      Stk[28] = Stk[28] + 115
  [VIP   30] CALL      call Stk[A](...)
  [VIP   31] CALL      call Stk[A](...)
  [VIP   32] ADDI      Stk[32] = Stk[32] + 92
  [VIP   33] SETREG2   Upv[33] = 1
  [VIP   34] ADDI      Stk[34] = Stk[34] + 4
  [VIP   35] ADDI      Stk[35] = Stk[35] + 190
  [VIP   36] ADDI      Stk[36] = Stk[36] + 171
  [VIP   39] ADDI      Stk[39] = Stk[39] + 94
  [VIP   41] GETTABUP  Stk[41] = env['band']
  [VIP   42] ADDI      Stk[42] = Stk[42] + 123
  [VIP   43] ADDI      Stk[43] = Stk[43] + 198
  [VIP   44] DT        dT(x,11,44)
  [VIP   46] DT        dT(x,11,46)
  [VIP   48] ADDU      Upv[48] = Upv[48] + 26
  [VIP   49] ADDI      Stk[49] = Stk[49] + 27
  [VIP   52] GETTABUP  Stk[52] = env['bor']
  [VIP   52] DT        dT(x,26,52)
  [VIP   53] GETTABUP  Stk[53] = env[K[343]]
  [VIP   53] DT        dT(x,343,53)
  [VIP   55] ADDI      Stk[55] = Stk[55] + 98
  [VIP   56] GETTABUP  Stk[56] = env['lastlinedefined']
  [VIP   64] SUBI      Stk[64] = Stk[64] - 29
  [VIP   68] ADDI      Stk[68] = Stk[68] + 19
  [VIP   69] DT        dT(x,393,69)
  [VIP   70] DT        dT(x,11,70)
  [VIP   73] DT        dT(x,56,73)
  [VIP   74] ADDU      Upv[74] = Upv[74] + 77
  [VIP   75] ADD       Stk[75] = Stk[75] + 0
  [VIP   76] SETREG    Stk[76] = 36
  [VIP   79] GETTABUP  Stk[79] = env['nparams']
  [VIP   79] DT        dT(x,56,79)
  [VIP   80] GETTABUP  Stk[80] = env['source']
  [VIP   80] DT        dT(x,51,80)
  [VIP   81] GETTABUP  Stk[81] = env[K[125]]
  [VIP   81] DT        dT(x,125,81)
  [VIP   83] SUBI      Stk[83] = Stk[83] - 40
  [VIP   87] ADDI      Stk[87] = Stk[87] + 126
  [VIP   90] GETTABUP  Stk[90] = env['gmatch']
  [VIP   91] ADDI      Stk[91] = Stk[91] + 60
  [VIP   92] DT        dT(x,24,92)
  [VIP   98] ADDI      Stk[98] = Stk[98] + 61
  [VIP  101] ADDI      Stk[101] = Stk[101] + 104
  [VIP  102] SETREG    Stk[102] = 49
  [VIP  103] CALL      call Stk[A](...)
  [VIP  104] SETREG    Stk[104] = 48
  [VIP  105] DT        dT(x,56,105)
  [VIP  106] DT        dT(x,56,106)
  [VIP  107] GETTABUP  Stk[107] = env['mQxEXg']
  [VIP  108] ADDI      Stk[108] = Stk[108] + 87
  [VIP  109] SETTABUP  Stk['string'] = Stk[...]
  [VIP  110] ADDI      Stk[110] = Stk[110] + 28
  [VIP  112] SETREG    Stk[112] = 48
  [VIP  115] DT        dT(x,56,115)
  [VIP  116] DT        dT(x,56,116)
  [VIP  117] SETREG    Stk[117] = 27
  [VIP  120] GETTABUP  Stk[120] = env['Luraph']
  [VIP  120] DT        dT(x,7,120)
  [VIP  121] GETTABUP  Stk[121] = env['Luraph']
  [VIP  121] DT        dT(x,7,121)
  [VIP  122] GETTABUP  Stk[122] = env[K[652]]
  [VIP  122] DT        dT(x,652,122)
  [VIP  124] ADDI      Stk[124] = Stk[124] + 52
  [VIP  125] SUBI      Stk[125] = Stk[125] - 24
  [VIP  125] CALL      call Stk[A](...)
  [VIP  126] SUBI      Stk[126] = Stk[126] - 16
  [VIP  130] SETREG    Stk[130] = 22
  [VIP  133] SUBI      Stk[133] = Stk[133] - 59
  [VIP  135] GETTABUP  Stk[135] = env['rawset']
  [VIP  138] SETREG    Stk[138] = 6
  [VIP  139] ADDI      Stk[139] = Stk[139] + 23
  [VIP  143] SETREG    Stk[143] = 64
  [VIP  147] GETTABUP  Stk[147] = env[K[89]]
  [VIP  147] DT        dT(x,89,147)
  [VIP  148] GETTABUP  Stk[148] = env[K[264]]
  [VIP  148] DT        dT(x,264,148)
  [VIP  149] GETTABUP  Stk[149] = env[K[112]]
  [VIP  149] DT        dT(x,112,149)
  [VIP  151] SETREG    Stk[151] = 39
  [VIP  152] ADDI      Stk[152] = Stk[152] + 17
  [VIP  153] SUBI      Stk[153] = Stk[153] - 41
  [VIP  154] SETREG    Stk[154] = 25
  [VIP  154] CALL      call Stk[A](...)
  [VIP  155] SUBI      Stk[155] = Stk[155] - 3
  [VIP  156] GETTABUP  Stk[156] = env['gmatch']
  [VIP  158] GETTABUP  Stk[158] = env['tonumber']
  [VIP  158] SETREG2   Upv[158] = 68
  [VIP  159] ADDI      Stk[159] = Stk[159] + 55
  [VIP  160] ADDI      Stk[160] = Stk[160] + 73
  [VIP  162] SUBI      Stk[162] = Stk[162] - 45
  [VIP  165] SETREG    Stk[165] = 48
  [VIP  168] DT        dT(x,24,168)
  [VIP  169] SUBI      Stk[169] = Stk[169] - 8
  [VIP  172] GETTABUP  Stk[172] = env[K[101]]
  [VIP  172] DT        dT(x,101,172)
  [VIP  173] GETTABUP  Stk[173] = env[' ']
  [VIP  173] DT        dT(x,21,173)
  [VIP  174] GETTABUP  Stk[174] = env['lastlinedefined']
  [VIP  174] DT        dT(x,11,174)
  [VIP  176] SETREG    Stk[176] = 3
  [VIP  179] SETREG    Stk[179] = 48
  [VIP  181] GETTABUP  Stk[181] = env['Luraph']
  [VIP  183] GETTABUP  Stk[183] = env['Luraph']
  [VIP  188] SUBI      Stk[188] = Stk[188] - 58
  [VIP  190] DT        dT(x,11,190)
  [VIP  192] DT        dT(x,56,192)
  [VIP  193] ADDU      Upv[193] = Upv[193] + 22
  [VIP  194] GETTABUP  Stk[194] = env['error in error handling']
  [VIP  195] ADDI      Stk[195] = Stk[195] + 10
  [VIP  196] SETREG    Stk[196] = 10
  [VIP  199] GETTABUP  Stk[199] = env[K[584]]
  [VIP  199] DT        dT(x,584,199)
  [VIP  200] GETTABUP  Stk[200] = env[K[159]]
  [VIP  201] GETTABUP  Stk[201] = env['running']
  [VIP  202] GETTABUP  Stk[202] = env['loadstring']
  [VIP  203] GETTABUP  Stk[203] = env[K[557]]
  [VIP  203] DT        dT(x,557,203)
  [VIP  205] SUBI      Stk[205] = Stk[205] - 97
  [VIP  206] LOADN     Stk[206] = 56
  [VIP  206] DT        dT(x,56,206)
  [VIP  207] SETREG    Stk[207] = 34
  [VIP  210] GETTABUP  Stk[210] = env['linedefined']
  [VIP  210] DT        dT(x,68,210)
  [VIP  211] GETTABUP  Stk[211] = env[K[693]]
  [VIP  211] DT        dT(x,693,211)
  [VIP  213] SUBI      Stk[213] = Stk[213] - 87
  [VIP  214] ADDI      Stk[214] = Stk[214] + 3
  [VIP  215] SUBI      Stk[215] = Stk[215] - 27
  [VIP  216] LOADN     Stk[216] = 0
  [VIP  217] SETREG    Stk[217] = 98
  [VIP  221] GETTABUP  Stk[221] = env['linedefined']
  [VIP  221] DT        dT(x,68,221)
  [VIP  222] GETTABUP  Stk[222] = env['linedefined']
  [VIP  222] DT        dT(x,68,222)
  [VIP  223] GETTABUP  Stk[223] = env[K[593]]
  [VIP  223] DT        dT(x,593,223)
  [VIP  225] SUBI      Stk[225] = Stk[225] - 86
  [VIP  229] GETTABUP  Stk[229] = env[K[95]]
  [VIP  229] DT        dT(x,95,229)
  [VIP  230] GETTABUP  Stk[230] = env['Luraph']
  [VIP  230] DT        dT(x,7,230)
  [VIP  231] GETTABUP  Stk[231] = env[K[90]]
  [VIP  231] DT        dT(x,90,231)
  [VIP  233] SETREG    Stk[233] = 104
  [VIP  237] GETTABUP  Stk[237] = env['source']
  [VIP  237] DT        dT(x,51,237)
  [VIP  238] GETTABUP  Stk[238] = env[K[306]]
  [VIP  238] DT        dT(x,306,238)
  [VIP  239] GETTABUP  Stk[239] = env[K[131]]
  [VIP  239] DT        dT(x,131,239)
  [VIP  241] SUBI      Stk[241] = Stk[241] - 86
  [VIP  242] ADDI      Stk[242] = Stk[242] + 0
  [VIP  245] DT        dT(x,24,245)
  [VIP  246] SETREG    Stk[246] = 91
  [VIP  249] GETTABUP  Stk[249] = env['error in error handling']
  [VIP  250] SUBI      Stk[250] = Stk[250] - 57
  [VIP    1] ADDI      Stk[1] = Stk[1] + 53
  [VIP    2] ADDI      Stk[2] = Stk[2] + 90
  [VIP    2] CALL      call Stk[A](...)
  [VIP    3] ADDI      Stk[3] = Stk[3] + 49
  [VIP    4] ADD       Stk[4] = Stk[4] + 340
  [VIP    4] DT        dT(x,340,4)
  [VIP    5] ADDI      Stk[5] = Stk[5] + 148
  [VIP    8] GETTABUP  Stk[8] = env['Luraph']
  [VIP    8] DT        dT(x,7,8)
  [VIP    9] GETTABUP  Stk[9] = env['create']
  [VIP    9] DT        dT(x,60,9)
  [VIP   11] ADDI      Stk[11] = Stk[11] + 77
  [VIP   12] DT        dT(x,485,12)
  [VIP   14] DT        dT(x,7,14)
  [VIP   15] ADDI      Stk[15] = Stk[15] + 54
  [VIP   18] GETTABUP  Stk[18] = env['typeof']
  [VIP   18] DT        dT(x,3,18)
  [VIP   19] GETTABUP  Stk[19] = env['Luraph']
  [VIP   19] DT        dT(x,7,19)
  [VIP   20] GETTABUP  Stk[20] = env[K[359]]
  [VIP   20] DT        dT(x,359,20)
  [VIP   22] ADDI      Stk[22] = Stk[22] + 177
  [VIP   25] GETTABUP  Stk[25] = env['Luraph']
  [VIP   25] DT        dT(x,7,25)
  [VIP   26] GETTABUP  Stk[26] = env['resume']
  [VIP   26] DT        dT(x,22,26)
  [VIP   28] ADDI      Stk[28] = Stk[28] + 31
  [VIP   30] CALL      call Stk[A](...)
  [VIP   32] ADDI      Stk[32] = Stk[32] + 141
  [VIP   33] ADDI      Stk[33] = Stk[33] + 30
  [VIP   36] GETTABUP  Stk[36] = env['Luraph']
  [VIP   36] DT        dT(x,7,36)
  [VIP   37] GETTABUP  Stk[37] = env[K[545]]
  [VIP   37] DT        dT(x,545,37)
  [VIP   39] ADDI      Stk[39] = Stk[39] + 88
  [VIP   40] ADDI      Stk[40] = Stk[40] + 154
  [VIP   41] ADDI      Stk[41] = Stk[41] + 41
  [VIP   43] DT        dT(x,408,43)
  [VIP   44] SETREG    Stk[44] = 1
  [VIP   46] CALL      call Stk[A](...)
  [VIP   49] ADDI      Stk[49] = Stk[49] + 0
  [VIP   52] ADDI      Stk[52] = Stk[52] + 90
  [VIP   53] SUBI      Stk[53] = Stk[53] - 25
  [VIP   54] ADDI      Stk[54] = Stk[54] + 72
  [VIP   55] ADDI      Stk[55] = Stk[55] + 18
  [VIP   56] DT        dT(x,117,56)
  [VIP   57] DT        dT(x,206,57)
  [VIP   58] DT        dT(x,52,58)
  [VIP   59] ADDU      Upv[59] = Upv[59] + 31
  [VIP   60] SUBI      Stk[60] = Stk[60] - 20
  [VIP   61] SETREG    Stk[61] = 22
  [VIP   62] ADDI      Stk[62] = Stk[62] + 27
  [VIP   63] ADDI      Stk[63] = Stk[63] + 109
  [VIP   65] DT        dT(x,252,65)
  [VIP   68] DT        dT(x,442,68)
  [VIP   69] ADDI      Stk[69] = Stk[69] + 3
  [VIP   72] SETREG    Stk[72] = 1
  [VIP   73] SETREG    Stk[73] = 1
  [VIP   76] GETTABUP  Stk[76] = env['Luraph']
  [VIP   76] DT        dT(x,7,76)
  [VIP   77] GETTABUP  Stk[77] = env[K[316]]
  [VIP   77] DT        dT(x,316,77)
  [VIP   79] ADDI      Stk[79] = Stk[79] + 77
  [VIP   80] ADDI      Stk[80] = Stk[80] + 23
  [VIP   81] ADDI      Stk[81] = Stk[81] + 50
  [VIP   85] GETTABUP  Stk[85] = env[K[95]]
  [VIP   85] DT        dT(x,95,85)
  [VIP   86] GETTABUP  Stk[86] = env['error in error handling']
  [VIP   86] DT        dT(x,9,86)
  [VIP   88] SETREG    Stk[88] = 11
  [VIP   89] ADDI      Stk[89] = Stk[89] + 93
  [VIP   90] SETREG    Stk[90] = 41
  [VIP   91] SETREG    Stk[91] = 15
  [VIP   92] ADDI      Stk[92] = Stk[92] + 83
  [VIP   93] ADDI      Stk[93] = Stk[93] + 18
  [VIP   94] DT        dT(x,587,94)
  [VIP   94] SUBU      Upv[94] = Upv[94] - 4
  [VIP   95] ADDI      Stk[95] = Stk[95] + 79
  [VIP   96] DT        dT(x,52,96)
  [VIP   98] CALL      call Stk[A](...)
  [VIP  101] SETREG    Stk[101] = 1
  [VIP  102] ADDI      Stk[102] = Stk[102] + 49
  [VIP  102] CALL      call Stk[A](...)
  [VIP  103] SUBI      Stk[103] = Stk[103] - 23
  [VIP  107] GETTABUP  Stk[107] = env['short_src']
  [VIP  107] DT        dT(x,77,107)
  [VIP  108] GETTABUP  Stk[108] = env[K[118]]
  [VIP  108] DT        dT(x,118,108)
  [VIP  109] GETTABUP  Stk[109] = env[K[632]]
  [VIP  109] DT        dT(x,632,109)
  [VIP  111] ADDI      Stk[111] = Stk[111] + 37
  [VIP  115] GETTABUP  Stk[115] = env['Luraph']
  [VIP  115] DT        dT(x,7,115)
  [VIP  116] GETTABUP  Stk[116] = env['<i8']
  [VIP  116] DT        dT(x,54,116)
  [VIP  117] GETTABUP  Stk[117] = env['typeof']
  [VIP  117] DT        dT(x,3,117)
  [VIP  118] GETTABUP  Stk[118] = env[K[400]]
  [VIP  118] DT        dT(x,400,118)
  [VIP  120] ADDI      Stk[120] = Stk[120] + 34
  [VIP  123] GETTABUP  Stk[123] = env['short_src']
  [VIP  123] DT        dT(x,77,123)
  [VIP  124] GETTABUP  Stk[124] = env[K[199]]
  [VIP  124] DT        dT(x,199,124)
  [VIP  126] ADDI      Stk[126] = Stk[126] + 24
  [VIP  127] SETREG    Stk[127] = 5
  [VIP  129] DT        dT(x,14,129)
  [VIP  130] SETREG    Stk[130] = 1
  [VIP  131] SETREG    Stk[131] = 55
  [VIP  136] SETREG    Stk[136] = 61
  [VIP  140] ADDI      Stk[140] = Stk[140] + 0
  [VIP  142] SUBI      Stk[142] = Stk[142] - 53
  [VIP  146] CALL      call Stk[A](...)
  [VIP  148] SETREG    Stk[148] = 42
  [VIP  149] SETREG    Stk[149] = 1
  [VIP  149] CALL      call Stk[A](...)
  [VIP  150] SETREG    Stk[150] = 53
  [VIP  151] SUBI      Stk[151] = Stk[151] - 15
  [VIP  152] SUBI      Stk[152] = Stk[152] - 73
  [VIP  152] CALL      call Stk[A](...)
  [VIP  153] SETREG    Stk[153] = 60
  [VIP  154] SETREG    Stk[154] = 44
  [VIP  155] SUBI      Stk[155] = Stk[155] - 54
  [VIP  155] CALL      call Stk[A](...)
  [VIP  156] SETREG    Stk[156] = 32
  [VIP  161] SETREG    Stk[161] = 41
  [VIP  162] SUBI      Stk[162] = Stk[162] - 32
  [VIP  167] CALL      call Stk[A](...)
  [VIP  172] SUBI      Stk[172] = Stk[172] - 82
  [VIP  173] SUBI      Stk[173] = Stk[173] - 53
  [VIP  174] SETREG    Stk[174] = 33
  [VIP  175] SUBI      Stk[175] = Stk[175] - 13
  [VIP  178] GETTABUP  Stk[178] = env['xpcall']
  [VIP  178] DT        dT(x,40,178)
  [VIP  179] GETTABUP  Stk[179] = env[K[338]]
  [VIP  179] DT        dT(x,338,179)
  [VIP  181] SUBI      Stk[181] = Stk[181] - 88
  [VIP  182] SUBI      Stk[182] = Stk[182] - 40
  [VIP  184] GETTABUP  Stk[184] = env[K[460]]
  [VIP  184] DT        dT(x,460,184)
  [VIP  186] GETTABUP  Stk[186] = env[K[113]]
  [VIP  190] GETTABUP  Stk[190] = env[' ']
  [VIP  191] GETTABUP  Stk[191] = env['loadstring']
  [VIP  192] GETTABUP  Stk[192] = env['wrap']
  [VIP  192] DT        dT(x,76,192)
  [VIP  194] SETREG    Stk[194] = 95
  [VIP  196] GETTABUP  Stk[196] = env['running']
  [VIP  196] DT        dT(x,24,196)
  [VIP  197] GETTABUP  Stk[197] = env['lastlinedefined']
  [VIP  197] DT        dT(x,11,197)
  [VIP  199] SETREG    Stk[199] = 3
  [VIP  200] LOADN     Stk[200] = 0
  [VIP  201] SUBI      Stk[201] = Stk[201] - 20
  [VIP    1] ADDI      Stk[1] = Stk[1] + 53
  [VIP    3] ADDI      Stk[3] = Stk[3] + 2
  [VIP    4] ADD       Stk[4] = Stk[4] + 0
  [VIP    5] ADDI      Stk[5] = Stk[5] + 48
  [VIP    6] ADDI      Stk[6] = Stk[6] + 57
  [VIP    9] CALL      call Stk[A](...)
  [VIP   10] DT        dT(x,196,10)
  [VIP   11] DT        dT(x,339,11)
  [VIP   12] DT        dT(x,646,12)
  [VIP   13] SETREG2   Upv[13] = 5
  [VIP   14] GETTABUP  Stk[14] = env['bit32']
  [VIP   14] SETREG    Stk[14] = 1
  [VIP   15] ADDI      Stk[15] = Stk[15] + 1
  [VIP   17] ADDI      Stk[17] = Stk[17] + 38
  [VIP   21] ADDI      Stk[21] = Stk[21] + 9
  [VIP   30] ADDI      Stk[30] = Stk[30] + 13
  [VIP   33] GETTABUP  Stk[33] = env[K[274]]
  [VIP   33] DT        dT(x,274,33)
  [VIP   35] GETTABUP  Stk[35] = env[K[93]]
  [VIP   39] GETTABUP  Stk[39] = env['loadstring']
  [VIP   40] GETTABUP  Stk[40] = env['rawset']
  [VIP   41] GETTABUP  Stk[41] = env['xpcall']
  [VIP   41] DT        dT(x,40,41)
  [VIP   43] SETREG    Stk[43] = 6
  [VIP   44] SETREG    Stk[44] = 5
  [VIP   48] GETTABUP  Stk[48] = env['Luraph']
  [VIP   48] DT        dT(x,7,48)
  [VIP   49] GETTABUP  Stk[49] = env[K[89]]
  [VIP   49] DT        dT(x,89,49)
  [VIP   50] GETTABUP  Stk[50] = env[K[199]]
  [VIP   50] DT        dT(x,199,50)
  [VIP   51] GETTABUP  Stk[51] = env['concat']
  [VIP   51] DT        dT(x,64,51)
  [VIP   53] SETREG    Stk[53] = 20
  [VIP   54] SETREG    Stk[54] = 17
  [VIP   55] SUBI      Stk[55] = Stk[55] - 11
  [VIP   59] GETTABUP  Stk[59] = env[' --[[%s]] return setfenv(function(...) r...']
  [VIP   59] DT        dT(x,44,59)
  [VIP   60] GETTABUP  Stk[60] = env['Luraph']
  [VIP   60] DT        dT(x,7,60)
  [VIP   61] GETTABUP  Stk[61] = env['lrotate']
  [VIP   61] DT        dT(x,73,61)
  [VIP   63] ADDI      Stk[63] = Stk[63] + 6
  [VIP   66] GETTABUP  Stk[66] = env['Luraph']
  [VIP   66] DT        dT(x,7,66)
  [VIP   67] GETTABUP  Stk[67] = env['lastlinedefined']
  [VIP   67] DT        dT(x,11,67)
  [VIP   69] SETREG    Stk[69] = 3
  [VIP   70] SETREG    Stk[70] = 21
  [VIP    1] ADDI      Stk[1] = Stk[1] + 32
  [VIP    2] ADDI      Stk[2] = Stk[2] + 74
  [VIP    3] ADDI      Stk[3] = Stk[3] + 91
  [VIP    7] ADDI      Stk[7] = Stk[7] + 0
  [VIP   10] DT        dT(x,51,10)
  [VIP   15] ADDI      Stk[15] = Stk[15] + 72
  [VIP   20] DT        dT(x,54,20)
  [VIP   22] SETREG    Stk[22] = 2
  [VIP   27] GETTABUP  Stk[27] = env['typeof']
  [VIP   27] DT        dT(x,3,27)
  [VIP   28] GETTABUP  Stk[28] = env['running']
  [VIP   28] DT        dT(x,24,28)
  [VIP   29] GETTABUP  Stk[29] = env['nparams']
  [VIP   29] DT        dT(x,56,29)
  [VIP   30] GETTABUP  Stk[30] = env['traceback']
  [VIP   30] DT        dT(x,34,30)
  [VIP   32] ADDI      Stk[32] = Stk[32] + 43
  [VIP   34] SUBI      Stk[34] = Stk[34] - 12
  [VIP   38] GETTABUP  Stk[38] = env['Luraph']
  [VIP   38] DT        dT(x,7,38)
  [VIP   39] GETTABUP  Stk[39] = env['Luraph']
  [VIP   39] DT        dT(x,7,39)
  [VIP   40] GETTABUP  Stk[40] = env['Luraph']
  [VIP   40] DT        dT(x,7,40)
  [VIP   41] GETTABUP  Stk[41] = env[K[109]]
  [VIP   41] DT        dT(x,109,41)
  [VIP   43] SETREG    Stk[43] = 15
  [VIP   48] GETTABUP  Stk[48] = env['lastlinedefined']
  [VIP   48] DT        dT(x,11,48)
  [VIP   49] GETTABUP  Stk[49] = env['typeof']
  [VIP   49] DT        dT(x,3,49)
  [VIP   50] GETTABUP  Stk[50] = env['nparams']
  [VIP   50] DT        dT(x,56,50)
  [VIP   51] GETTABUP  Stk[51] = env['running']
  [VIP   51] DT        dT(x,24,51)
  [VIP   52] GETTABUP  Stk[52] = env[K[115]]
  [VIP   52] DT        dT(x,115,52)
  [VIP   53] GETTABUP  Stk[53] = env['nparams']
  [VIP   53] DT        dT(x,56,53)
  [VIP   55] SETREG    Stk[55] = 1
  [VIP   57] DT        dT(x,89,57)
  [VIP   59] ADDI      Stk[59] = Stk[59] + 41
  [VIP   63] DT        dT(x,24,63)
  [VIP   70] DT        dT(x,11,70)
  [VIP   75] ADDI      Stk[75] = Stk[75] + 9
  [VIP   76] SUBI      Stk[76] = Stk[76] - 17
  [VIP   78] GETTABUP  Stk[78] = env[K[228]]
  [VIP   78] DT        dT(x,228,78)
  [VIP   79] GETTABUP  Stk[79] = env['slnaf']
  [VIP   80] GETTABUP  Stk[80] = env['slnaf']
  [VIP   81] GETTABUP  Stk[81] = env['error in error handling']
  [VIP   82] GETTABUP  Stk[82] = env['number']
  [VIP   82] DT        dT(x,12,82)
  [VIP   84] SUBI      Stk[84] = Stk[84] - 29
  [VIP   85] SUBI      Stk[85] = Stk[85] - 42
  [VIP   90] DT        dT(x,122,90)
  [VIP   94] SUBI      Stk[94] = Stk[94] - 9
  [VIP   97] GETTABUP  Stk[97] = env['Luraph']
  [VIP   97] DT        dT(x,7,97)
  [VIP   98] GETTABUP  Stk[98] = env['lastlinedefined']
  [VIP   98] DT        dT(x,11,98)
  [VIP  100] SETREG    Stk[100] = 3
  [VIP  101] SETREG    Stk[101] = 34
  [VIP    1] ADDI      Stk[1] = Stk[1] + 48
  [VIP    3] DT        dT(x,7,3)
  [VIP    4] DT        dT(x,556,4)
  [VIP    5] DT        dT(x,56,5)
  [VIP    6] ADDI      Stk[6] = Stk[6] + 183
  [VIP    7] ADDI      Stk[7] = Stk[7] + 139
  [VIP    8] ADDI      Stk[8] = Stk[8] + 147
  [VIP    9] SETTABUP  Stk['string'] = Stk[...]
  [VIP   10] ADDI      Stk[10] = Stk[10] + 13
  [VIP   19] ADDI      Stk[19] = Stk[19] + 167
  [VIP   23] ADDI      Stk[23] = Stk[23] + 128
  [VIP   25] ADDI      Stk[25] = Stk[25] + 111
  [VIP   27] DT        dT(x,56,27)
  [VIP   28] ADDU      Upv[28] = Upv[28] + 108
  [VIP   29] ADDI      Stk[29] = Stk[29] + 161
  [VIP   36] ADDI      Stk[36] = Stk[36] + 99
  [VIP   40] ADD       Stk[40] = Stk[40] + 15
  [VIP   41] ADDI      Stk[41] = Stk[41] + 14
  [VIP   45] GETTABUP  Stk[45] = env[' ']
  [VIP   45] DT        dT(x,21,45)
  [VIP   46] GETTABUP  Stk[46] = env['short_src']
  [VIP   46] DT        dT(x,77,46)
  [VIP   47] GETTABUP  Stk[47] = env[K[240]]
  [VIP   47] DT        dT(x,240,47)
  [VIP   49] ADDI      Stk[49] = Stk[49] + 126
  [VIP   50] DT        dT(x,56,50)
  [VIP   53] DT        dT(x,56,53)
  [VIP   54] ADDU      Upv[54] = Upv[54] + 90
  [VIP   55] ADDI      Stk[55] = Stk[55] + 55
  [VIP   56] ADDI      Stk[56] = Stk[56] + 60
  [VIP   65] ADDI      Stk[65] = Stk[65] + 30
  [VIP   69] GETTABUP  Stk[69] = env['Luraph']
  [VIP   69] DT        dT(x,7,69)
  [VIP   70] GETTABUP  Stk[70] = env[K[525]]
  [VIP   70] DT        dT(x,525,70)
  [VIP   72] ADDI      Stk[72] = Stk[72] + 125
  [VIP   76] ADDI      Stk[76] = Stk[76] + 93
  [VIP   82] SUBI      Stk[82] = Stk[82] - 26
  [VIP   83] ADDI      Stk[83] = Stk[83] + 51
  [VIP   87] GETTABUP  Stk[87] = env['Luraph']
  [VIP   87] DT        dT(x,7,87)
  [VIP   88] GETTABUP  Stk[88] = env[K[125]]
  [VIP   88] DT        dT(x,125,88)
  [VIP   89] GETTABUP  Stk[89] = env['tonumber']
  [VIP   89] DT        dT(x,6,89)
  [VIP   91] SETREG    Stk[91] = 19
  [VIP   92] DT        dT(x,7,92)
  [VIP   93] DT        dT(x,556,93)
  [VIP   94] DT        dT(x,56,94)
  [VIP   95] SETREG2   Upv[95] = 8
  [VIP   96] SUBI      Stk[96] = Stk[96] - 13
  [VIP  100] SETREG    Stk[100] = 8
  [VIP  103] SETREG    Stk[103] = 36
  [VIP  104] ADDI      Stk[104] = Stk[104] + 81
  [VIP  107] GETTABUP  Stk[107] = env[' ']
  [VIP  107] DT        dT(x,21,107)
  [VIP  108] GETTABUP  Stk[108] = env['yield']
  [VIP  108] DT        dT(x,72,108)
  [VIP  110] SUBI      Stk[110] = Stk[110] - 19
  [VIP  113] GETTABUP  Stk[113] = env[K[125]]
  [VIP  113] DT        dT(x,125,113)
  [VIP  114] GETTABUP  Stk[114] = env['short_src']
  [VIP  114] DT        dT(x,77,114)
  [VIP  116] SETREG    Stk[116] = 10
  [VIP  119] GETTABUP  Stk[119] = env[' ']
  [VIP  119] DT        dT(x,21,119)
  [VIP  120] GETTABUP  Stk[120] = env[K[348]]
  [VIP  120] DT        dT(x,348,120)
  [VIP  122] SETREG    Stk[122] = 58
  [VIP  130] ADDI      Stk[130] = Stk[130] + 49
  [VIP  134] SUBI      Stk[134] = Stk[134] - 38
  [VIP  135] SETREG    Stk[135] = 6
  [VIP  136] SETREG    Stk[136] = 66
  [VIP  137] ADD       Stk[137] = Stk[137] + 0
  [VIP  138] ADDI      Stk[138] = Stk[138] + 58
  [VIP  141] GETTABUP  Stk[141] = env['error in error handling']
  [VIP  141] DT        dT(x,9,141)
  [VIP  142] GETTABUP  Stk[142] = env[K[602]]
  [VIP  142] DT        dT(x,602,142)
  [VIP  144] SUBI      Stk[144] = Stk[144] - 22
  [VIP  145] LOADN     Stk[145] = 0
  [VIP  146] SUBI      Stk[146] = Stk[146] - 70
  [VIP  148] GETTABUP  Stk[148] = env['Luraph']
  [VIP  148] DT        dT(x,7,148)
  [VIP  149] GETTABUP  Stk[149] = env[K[494]]
  [VIP  149] DT        dT(x,494,149)
  [VIP  151] ADDI      Stk[151] = Stk[151] + 9
  [VIP  154] SETREG    Stk[154] = 72
  [VIP  155] ADDI      Stk[155] = Stk[155] + 11
  [VIP  157] GETTABUP  Stk[157] = env['Luraph']
  [VIP  157] DT        dT(x,7,157)
  [VIP  158] GETTABUP  Stk[158] = env[K[520]]
  [VIP  158] DT        dT(x,520,158)
  [VIP  160] SUBI      Stk[160] = Stk[160] - 60
  [VIP  162] DT        dT(x,56,162)
  [VIP  165] SETREG    Stk[165] = 25
  [VIP  166] SUBI      Stk[166] = Stk[166] - 62
  [VIP  169] SETREG    Stk[169] = 72
  [VIP  175] SUBI      Stk[175] = Stk[175] - 45
  [VIP  176] SUBU      Upv[176] = Upv[176] - 41
  [VIP  179] SETREG    Stk[179] = 36
  [VIP  185] SETREG    Stk[185] = 29
  [VIP  186] SUBI      Stk[186] = Stk[186] - 10
  [VIP  187] SUBI      Stk[187] = Stk[187] - 49
  [VIP  189] SETREG    Stk[189] = 28
  [VIP  190] SETREG    Stk[190] = 41
  [VIP  193] GETTABUP  Stk[193] = env['xpcall']
  [VIP  193] DT        dT(x,40,193)
  [VIP  194] GETTABUP  Stk[194] = env['nparams']
  [VIP  194] DT        dT(x,56,194)
  [VIP  196] SETREG    Stk[196] = 1
  [VIP  197] SUBI      Stk[197] = Stk[197] - 10
  [VIP  198] LOADN     Stk[198] = 0
  [VIP  199] SETREG    Stk[199] = 82
  [VIP    1] ADDI      Stk[1] = Stk[1] + 95
  [VIP    2] ADDI      Stk[2] = Stk[2] + 53
  [VIP    4] LOADN     Stk[4] = 5
  [VIP    5] ADDI      Stk[5] = Stk[5] + 77
  [VIP    6] GETTABUP  Stk[6] = env['find']
  [VIP    7] GETTABUP  Stk[7] = env['find']
  [VIP    8] GETTABUP  Stk[8] = env['rawset']
  [VIP    9] GETTABUP  Stk[9] = env['wrap']
  [VIP    9] DT        dT(x,76,9)
  [VIP   11] ADDI      Stk[11] = Stk[11] + 84
  [VIP   12] GETTABUP  Stk[12] = env[K[163]]
  [VIP   13] GETTABUP  Stk[13] = env[K[97]]
  [VIP   20] ADDI      Stk[20] = Stk[20] + 72
  [VIP   21] GETTABUP  Stk[21] = env[K[113]]
  [VIP   27] GETTABUP  Stk[27] = env[K[172]]
  [VIP   31] ADDI      Stk[31] = Stk[31] + 68
  [VIP   34] DT        dT(x,543,34)
  [VIP   34] CALL      call Stk[A](...)
  [VIP   35] ADDI      Stk[35] = Stk[35] + 19
  [VIP   36] ADDI      Stk[36] = Stk[36] + 3
  [VIP   38] SETREG    Stk[38] = 11
  [VIP   39] SETREG    Stk[39] = 1
  [VIP   40] DT        dT(x,712,40)
  [VIP   42] ADDI      Stk[42] = Stk[42] + 12
  [VIP   45] GETTABUP  Stk[45] = env['type']
  [VIP   45] DT        dT(x,20,45)
  [VIP   46] GETTABUP  Stk[46] = env[K[97]]
  [VIP   46] DT        dT(x,97,46)
  [VIP   47] GETTABUP  Stk[47] = env['next']
  [VIP   47] DT        dT(x,15,47)
  [VIP   48] GETTABUP  Stk[48] = env[K[89]]
  [VIP   48] DT        dT(x,89,48)
  [VIP   49] GETTABUP  Stk[49] = env['running']
  [VIP   49] DT        dT(x,24,49)
  [VIP   50] GETTABUP  Stk[50] = env['bxor']
  [VIP   50] DT        dT(x,47,50)
  [VIP   52] SUBI      Stk[52] = Stk[52] - 16
  [VIP   53] DT        dT(x,271,53)
  [VIP   54] ADDI      Stk[54] = Stk[54] + 14
  [VIP   55] ADDI      Stk[55] = Stk[55] + 14
  [VIP   56] SUBI      Stk[56] = Stk[56] - 25
  [VIP   59] GETTABUP  Stk[59] = env['<i8']
  [VIP   59] DT        dT(x,54,59)
  [VIP   60] GETTABUP  Stk[60] = env['<i8']
  [VIP   60] DT        dT(x,54,60)
  [VIP   61] GETTABUP  Stk[61] = env['namewhat']
  [VIP   61] DT        dT(x,48,61)
  [VIP   63] ADDI      Stk[63] = Stk[63] + 15
  [VIP   64] GETTABUP  Stk[64] = env['pcall']
  [VIP   65] GETTABUP  Stk[65] = env['band']
  [VIP   67] GETTABUP  Stk[67] = env['typeof']
  [VIP   68] ADDI      Stk[68] = Stk[68] + 29
  [VIP   69] ADDI      Stk[69] = Stk[69] + 15
  [VIP   72] GETTABUP  Stk[72] = env['Luraph']
  [VIP   72] DT        dT(x,7,72)
  [VIP   73] GETTABUP  Stk[73] = env[K[577]]
  [VIP   73] DT        dT(x,577,73)
  [VIP   75] ADDI      Stk[75] = Stk[75] + 15
  [VIP   76] DT        dT(x,56,76)
  [VIP   77] SETREG    Stk[77] = 3
  [VIP   78] SUBI      Stk[78] = Stk[78] - 3
  [VIP   79] GETTABUP  Stk[79] = env['pcall']
  [VIP   81] GETTABUP  Stk[81] = env['gmatch']
  [VIP   82] SETREG    Stk[82] = 20
  [VIP   83] DT        dT(x,7,83)
  [VIP   84] SETREG    Stk[84] = 2
  [VIP   87] GETTABUP  Stk[87] = env[K[101]]
  [VIP   87] DT        dT(x,101,87)
  [VIP   88] GETTABUP  Stk[88] = env['<i8']
  [VIP   88] DT        dT(x,54,88)
  [VIP   90] SETREG    Stk[90] = 5
  [VIP   91] SETTABUP  Stk['find'] = Stk[...]
  [VIP   92] ADDI      Stk[92] = Stk[92] + 6
  [VIP   93] SETREG    Stk[93] = 3
  [VIP   94] SUBI      Stk[94] = Stk[94] - 17
  [VIP   96] SUBI      Stk[96] = Stk[96] - 33
  [VIP   97] SETREG    Stk[97] = 42
  [VIP   98] SUBI      Stk[98] = Stk[98] - 42
  [VIP   99] SUBI      Stk[99] = Stk[99] - 47
  [VIP    1] ADDI      Stk[1] = Stk[1] + 57
  [VIP    4] DT        dT(x,56,4)
  [VIP    6] ADDI      Stk[6] = Stk[6] + 23
  [VIP    7] ADDI      Stk[7] = Stk[7] + 24
  [VIP   10] DT        dT(x,10,10)
  [VIP   12] ADDI      Stk[12] = Stk[12] + 57
  [VIP   16] GETTABUP  Stk[16] = env['math']
  [VIP   16] DT        dT(x,70,16)
  [VIP   17] GETTABUP  Stk[17] = env['math']
  [VIP   17] DT        dT(x,70,17)
  [VIP   18] GETTABUP  Stk[18] = env['traceback']
  [VIP   18] DT        dT(x,34,18)
  [VIP   19] GETTABUP  Stk[19] = env['xpcall']
  [VIP   19] DT        dT(x,40,19)
  [VIP   21] SETREG    Stk[21] = 6
  [VIP   24] GETTABUP  Stk[24] = env['xpcall']
  [VIP   24] DT        dT(x,40,24)
  [VIP   25] GETTABUP  Stk[25] = env['coroutine']
  [VIP   25] DT        dT(x,37,25)
  [VIP   27] ADDI      Stk[27] = Stk[27] + 19
  [VIP   28] SUBI      Stk[28] = Stk[28] - 7
  [VIP   30] SETREG    Stk[30] = 12
  [VIP   31] SETREG    Stk[31] = 1
  [VIP   34] GETTABUP  Stk[34] = env[K[259]]
  [VIP   34] DT        dT(x,259,34)
  [VIP   35] GETTABUP  Stk[35] = env[K[240]]
  [VIP   36] GETTABUP  Stk[36] = env['loadstring']
  [VIP   37] GETTABUP  Stk[37] = env['rawset']
  [VIP   38] GETTABUP  Stk[38] = env['getfenv']
  [VIP   38] DT        dT(x,33,38)
  [VIP   40] ADDI      Stk[40] = Stk[40] + 0
  [VIP   41] DT        dT(x,89,41)
  [VIP   45] DT        dT(x,23,45)
  [VIP   46] SUBI      Stk[46] = Stk[46] - 19
  [VIP   48] DT        dT(x,645,48)
  [VIP   51] ADDI      Stk[51] = Stk[51] + 0
  [VIP   52] DT        dT(x,92,52)
  [VIP   56] DT        dT(x,667,56)
  [VIP   58] SETREG    Stk[58] = 7
  [VIP   59] ADDI      Stk[59] = Stk[59] + 0
  [VIP   63] GETTABUP  Stk[63] = env['xpcall']
  [VIP   63] DT        dT(x,40,63)
  [VIP   64] GETTABUP  Stk[64] = env[' ']
  [VIP   64] DT        dT(x,21,64)
  [VIP   65] GETTABUP  Stk[65] = env['Luraph']
  [VIP   65] DT        dT(x,7,65)
  [VIP   66] GETTABUP  Stk[66] = env['xpcall']
  [VIP   66] DT        dT(x,40,66)
  [VIP   67] GETTABUP  Stk[67] = env['getinfo']
  [VIP   67] DT        dT(x,67,67)
  [VIP   69] SETREG    Stk[69] = 30
  [VIP   70] DT        dT(x,71,70)
  [VIP   74] DT        dT(x,122,74)
  [VIP    1] ADDI      Stk[1] = Stk[1] + 77
  [VIP    2] ADDI      Stk[2] = Stk[2] + 50
  [VIP    5] GETTABUP  Stk[5] = env['source']
  [VIP    5] DT        dT(x,51,5)
  [VIP    6] GETTABUP  Stk[6] = env[K[122]]
  [VIP    6] DT        dT(x,122,6)
  [VIP    7] GETTABUP  Stk[7] = env[K[95]]
  [VIP    7] DT        dT(x,95,7)
  [VIP    9] ADDI      Stk[9] = Stk[9] + 0
  [VIP   10] GETTABUP  Stk[10] = env['gmatch']
  [VIP   11] GETTABUP  Stk[11] = env['Luraph']
  [VIP   13] ADDI      Stk[13] = Stk[13] + 89
  [VIP   17] GETTABUP  Stk[17] = env['bxor']
  [VIP   17] DT        dT(x,47,17)
  [VIP   18] GETTABUP  Stk[18] = env['xpcall']
  [VIP   18] DT        dT(x,40,18)
  [VIP   19] GETTABUP  Stk[19] = env[K[89]]
  [VIP   19] DT        dT(x,89,19)
  [VIP   20] GETTABUP  Stk[20] = env[K[85]]
  [VIP   20] DT        dT(x,85,20)
  [VIP   22] ADDI      Stk[22] = Stk[22] + 39
  [VIP   24] DT        dT(x,56,24)
  [VIP   27] DT        dT(x,56,27)
  [VIP   28] ADDI      Stk[28] = Stk[28] + 36
  [VIP   31] GETTABUP  Stk[31] = env[K[467]]
  [VIP   31] DT        dT(x,467,31)
  [VIP   32] GETTABUP  Stk[32] = env['char']
  [VIP   33] GETTABUP  Stk[33] = env['char']
  [VIP   34] GETTABUP  Stk[34] = env['slnaf']
  [VIP   35] GETTABUP  Stk[35] = env['wrap']
  [VIP   35] DT        dT(x,76,35)
  [VIP   37] ADDI      Stk[37] = Stk[37] + 70
  [VIP   38] SETREG    Stk[38] = 13
  [VIP   39] DT        dT(x,56,39)
  [VIP   40] CALL      call Stk[A](...)
  [VIP   41] ADDI      Stk[41] = Stk[41] + 69
  [VIP   42] SUBI      Stk[42] = Stk[42] - 4
  [VIP   45] GETTABUP  Stk[45] = env[K[81]]
  [VIP   45] DT        dT(x,81,45)
  [VIP   46] GETTABUP  Stk[46] = env['traceback']
  [VIP   46] DT        dT(x,34,46)
  [VIP   47] GETTABUP  Stk[47] = env[K[101]]
  [VIP   47] DT        dT(x,101,47)
  [VIP   48] GETTABUP  Stk[48] = env['bor']
  [VIP   48] DT        dT(x,26,48)
  [VIP   50] ADDI      Stk[50] = Stk[50] + 37
  [VIP   51] ADDI      Stk[51] = Stk[51] + 35
  [VIP   51] CALL      call Stk[A](...)
  [VIP   52] SUBI      Stk[52] = Stk[52] - 15
  [VIP   56] GETTABUP  Stk[56] = env[' --[[%s]] return setfenv(function(...) r...']
  [VIP   56] DT        dT(x,44,56)
  [VIP   57] GETTABUP  Stk[57] = env[K[98]]
  [VIP   57] DT        dT(x,98,57)
  [VIP   58] GETTABUP  Stk[58] = env['<i8']
  [VIP   58] DT        dT(x,54,58)
  [VIP   59] GETTABUP  Stk[59] = env['rep']
  [VIP   59] DT        dT(x,58,59)
  [VIP   61] ADDI      Stk[61] = Stk[61] + 9
  [VIP   62] CALL      call Stk[A](...)
  [VIP   63] ADDI      Stk[63] = Stk[63] + 47
  [VIP   64] SUBI      Stk[64] = Stk[64] - 23
  [VIP   65] SUBI      Stk[65] = Stk[65] - 23
  [VIP   68] DT        dT(x,7,68)
  [VIP   69] CALL      call Stk[A](...)
  [VIP   70] ADDI      Stk[70] = Stk[70] + 36
  [VIP   71] DT        dT(x,56,71)
  [VIP   72] DT        dT(x,7,72)
  [VIP   73] ADDI      Stk[73] = Stk[73] + 13
  [VIP   74] SETREG    Stk[74] = 28
  [VIP   75] GETTABUP  Stk[75] = env['tonumber']
  [VIP   77] SUBI      Stk[77] = Stk[77] - 27
  [VIP   77] CALL      call Stk[A](...)
  [VIP   78] ADDI      Stk[78] = Stk[78] + 30
  [VIP   82] SETREG    Stk[82] = 22
  [VIP   83] DT        dT(x,97,83)
  [VIP   86] SUBI      Stk[86] = Stk[86] - 13
  [VIP   87] SETREG    Stk[87] = 2
  [VIP   88] DT        dT(x,64,88)
  [VIP   90] DT        dT(x,367,90)
  [VIP   94] DT        dT(x,118,94)
  [VIP   95] SUBI      Stk[95] = Stk[95] - 13
  [VIP   97] DT        dT(x,92,97)
  [VIP   99] SUBI      Stk[99] = Stk[99] - 25
  [VIP  100] DT        dT(x,7,100)
  [VIP  103] CALL      call Stk[A](...)
  [VIP  108] ADDI      Stk[108] = Stk[108] + 4
  [VIP  109] SETREG    Stk[109] = 1
  [VIP  109] CALL      call Stk[A](...)
  [VIP  110] SUBI      Stk[110] = Stk[110] - 11
  [VIP  111] SETTABUP  Stk['Luraph'] = Stk[...]
  [VIP  112] SUBI      Stk[112] = Stk[112] - 47
  [VIP  115] GETTABUP  Stk[115] = env['source']
  [VIP  115] DT        dT(x,51,115)
  [VIP  116] GETTABUP  Stk[116] = env['wrap']
  [VIP  116] DT        dT(x,76,116)
  [VIP  118] SUBI      Stk[118] = Stk[118] - 23
  [VIP    1] ADDI      Stk[1] = Stk[1] + 320
  [VIP    4] ADDI      Stk[4] = Stk[4] + 173
  [VIP    6] GETTABUP  Stk[6] = env[K[95]]
  [VIP    6] DT        dT(x,95,6)
  [VIP    7] GETTABUP  Stk[7] = env[K[103]]
  [VIP    7] DT        dT(x,103,7)
  [VIP    9] ADDI      Stk[9] = Stk[9] + 38
  [VIP   17] GETTABUP  Stk[17] = env['gmatch']
  [VIP   18] GETTABUP  Stk[18] = env['tonumber']
  [VIP   22] ADDI      Stk[22] = Stk[22] + 72
  [VIP   23] ADDI      Stk[23] = Stk[23] + 210
  [VIP   24] ADDI      Stk[24] = Stk[24] + 148
  [VIP   27] GETTABUP  Stk[27] = env[K[104]]
  [VIP   27] DT        dT(x,104,27)
  [VIP   28] GETTABUP  Stk[28] = env['<i8']
  [VIP   28] DT        dT(x,54,28)
  [VIP   29] GETTABUP  Stk[29] = env[K[501]]
  [VIP   29] DT        dT(x,501,29)
  [VIP   31] ADDI      Stk[31] = Stk[31] + 307
  [VIP   33] ADDI      Stk[33] = Stk[33] + 55
  [VIP   34] GETTABUP  Stk[34] = env['pcall']
  [VIP   35] GETTABUP  Stk[35] = env['band']
  [VIP   37] CALL      call Stk[A](...)
  [VIP   38] DT        dT(x,119,38)
  [VIP   39] ADDI      Stk[39] = Stk[39] + 49
  [VIP   42] CALL      call Stk[A](...)
  [VIP   44] ADDI      Stk[44] = Stk[44] + 124
  [VIP   45] ADDI      Stk[45] = Stk[45] + 28
  [VIP   46] ADD       Stk[46] = Stk[46] + 30
  [VIP   47] ADDI      Stk[47] = Stk[47] + 278
  [VIP   49] ADDI      Stk[49] = Stk[49] + 9
  [VIP   50] ADD       Stk[50] = Stk[50] + 0
  [VIP   51] ADDI      Stk[51] = Stk[51] + 214
  [VIP   52] ADDI      Stk[52] = Stk[52] + 324
  [VIP   53] GETTABUP  Stk[53] = env['rawget']
  [VIP   54] GETTABUP  Stk[54] = env['rawget']
  [VIP   55] GETTABUP  Stk[55] = env['match']
  [VIP   56] GETTABUP  Stk[56] = env[K[397]]
  [VIP   56] DT        dT(x,397,56)
  [VIP   58] ADDI      Stk[58] = Stk[58] + 177
  [VIP   59] SETREG    Stk[59] = 24
  [VIP   63] GETTABUP  Stk[63] = env[K[447]]
  [VIP   63] DT        dT(x,447,63)
  [VIP   64] GETTABUP  Stk[64] = env['rawget']
  [VIP   65] GETTABUP  Stk[65] = env['rawget']
  [VIP   66] GETTABUP  Stk[66] = env['running']
  [VIP   67] GETTABUP  Stk[67] = env[K[483]]
  [VIP   67] DT        dT(x,483,67)
  [VIP   68] GETTABUP  Stk[68] = env['rawget']
  [VIP   69] GETTABUP  Stk[69] = env['rawget']
  [VIP   70] GETTABUP  Stk[70] = env['isvararg']
  [VIP   71] GETTABUP  Stk[71] = env[K[82]]
  [VIP   71] DT        dT(x,82,71)
  [VIP   73] SUBI      Stk[73] = Stk[73] - 24
  [VIP   74] ADD       Stk[74] = Stk[74] + 94
  [VIP   74] DT        dT(x,94,74)
  [VIP   75] ADDI      Stk[75] = Stk[75] + 107
  [VIP   76] ADDI      Stk[76] = Stk[76] + 38
  [VIP   77] DT        dT(x,239,77)
  [VIP   78] CALL      call Stk[A](...)
  [VIP   81] ADDI      Stk[81] = Stk[81] + 79
  [VIP   84] ADDI      Stk[84] = Stk[84] + 282
  [VIP   85] DT        dT(x,530,85)
  [VIP   86] SUBI      Stk[86] = Stk[86] - 41
  [VIP   87] DT        dT(x,693,87)
  [VIP   87] ADDU      Upv[87] = Upv[87] + 225
  [VIP   88] ADDI      Stk[88] = Stk[88] + 95
  [VIP   89] ADDI      Stk[89] = Stk[89] + 259
  [VIP   91] GETTABUP  Stk[91] = env['lastlinedefined']
  [VIP   91] DT        dT(x,11,91)
  [VIP   92] GETTABUP  Stk[92] = env[K[343]]
  [VIP   92] DT        dT(x,343,92)
  [VIP   94] ADDI      Stk[94] = Stk[94] + 59
  [VIP   95] ADD       Stk[95] = Stk[95] + 0
  [VIP   96] ADDI      Stk[96] = Stk[96] + 15
  [VIP   97] DT        dT(x,73,97)
  [VIP   97] ADDU      Upv[97] = Upv[97] + 155
  [VIP   98] ADDI      Stk[98] = Stk[98] + 170
  [VIP   99] DT        dT(x,19,99)
  [VIP  100] ADD       Stk[100] = Stk[100] + 6
  [VIP  101] ADDI      Stk[101] = Stk[101] + 266
  [VIP  108] ADDI      Stk[108] = Stk[108] + 0
  [VIP  111] ADDI      Stk[111] = Stk[111] + 188
  [VIP  112] ADDI      Stk[112] = Stk[112] + 273
  [VIP  113] SETREG    Stk[113] = 39
  [VIP  114] ADDI      Stk[114] = Stk[114] + 179
  [VIP  117] GETTABUP  Stk[117] = env[K[104]]
  [VIP  117] DT        dT(x,104,117)
  [VIP  118] GETTABUP  Stk[118] = env[K[327]]
  [VIP  118] DT        dT(x,327,118)
  [VIP  120] ADDI      Stk[120] = Stk[120] + 100
  [VIP  125] ADDI      Stk[125] = Stk[125] + 265
  [VIP  126] ADDI      Stk[126] = Stk[126] + 144
  [VIP  127] CALL      call Stk[A](...)
  [VIP  128] CALL      call Stk[A](...)
  [VIP  129] CALL      call Stk[A](...)
  [VIP  130] CALL      call Stk[A](...)
  [VIP  131] DT        dT(x,623,131)
  [VIP  132] SETREG    Stk[132] = 58
  [VIP  136] GETTABUP  Stk[136] = env['getinfo']
  [VIP  136] DT        dT(x,67,136)
  [VIP  137] GETTABUP  Stk[137] = env[K[102]]
  [VIP  137] DT        dT(x,102,137)
  [VIP  138] GETTABUP  Stk[138] = env[K[81]]
  [VIP  138] DT        dT(x,81,138)
  [VIP  139] GETTABUP  Stk[139] = env[K[139]]
  [VIP  139] DT        dT(x,139,139)
  [VIP  141] ADDI      Stk[141] = Stk[141] + 57
  [VIP  144] SUBI      Stk[144] = Stk[144] - 50
  [VIP  147] GETTABUP  Stk[147] = env[K[115]]
  [VIP  147] DT        dT(x,115,147)
  [VIP  148] GETTABUP  Stk[148] = env[K[395]]
  [VIP  148] DT        dT(x,395,148)
  [VIP  150] ADDI      Stk[150] = Stk[150] + 128
  [VIP  153] SETREG    Stk[153] = 33
  [VIP  154] SETREG    Stk[154] = 76
  [VIP  155] DT        dT(x,141,155)
  [VIP  156] GETTABUP  Stk[156] = env['Luraph']
  [VIP  157] SUBI      Stk[157] = Stk[157] - 69
  [VIP  158] ADDI      Stk[158] = Stk[158] + 42
  [VIP  159] ADDI      Stk[159] = Stk[159] + 211
  [VIP  159] CALL      call Stk[A](...)
  [VIP  160] SETREG    Stk[160] = 22
  [VIP  161] CALL      call Stk[A](...)
  [VIP  168] ADDI      Stk[168] = Stk[168] + 151
  [VIP  170] DT        dT(x,142,170)
  [VIP  171] SETREG    Stk[171] = 58
  [VIP  172] ADDI      Stk[172] = Stk[172] + 94
  [VIP  173] DT        dT(x,129,173)
  [VIP  177] SETREG    Stk[177] = 31
  [VIP  178] DT        dT(x,45,178)
  [VIP  179] SETREG    Stk[179] = 58
  [VIP  180] ADDI      Stk[180] = Stk[180] + 77
  [VIP  183] SETREG    Stk[183] = 89
  [VIP  184] SETTABUP  Stk['debug'] = Stk[...]
  [VIP  185] SETREG    Stk[185] = 1
  [VIP  188] GETTABUP  Stk[188] = env['typeof']
  [VIP  188] DT        dT(x,3,188)
  [VIP  189] GETTABUP  Stk[189] = env[K[95]]
  [VIP  189] DT        dT(x,95,189)
  [VIP  191] SETREG    Stk[191] = 9
  [VIP  192] ADDI      Stk[192] = Stk[192] + 150
  [VIP  193] DT        dT(x,63,193)
  [VIP  194] SETREG2   Upv[194] = 94
  [VIP  195] SETREG    Stk[195] = 94
  [VIP  195] CALL      call Stk[A](...)
  [VIP  196] ADDI      Stk[196] = Stk[196] + 20
  [VIP  197] ADD       Stk[197] = Stk[197] + 73
  [VIP  197] DT        dT(x,73,197)
  [VIP  198] SUBI      Stk[198] = Stk[198] - 86
  [VIP  199] SETREG    Stk[199] = 59
  [VIP  200] ADDI      Stk[200] = Stk[200] + 80
  [VIP  201] DT        dT(x,497,201)
  [VIP  204] ADDI      Stk[204] = Stk[204] + 33
  [VIP  207] CALL      call Stk[A](...)
  [VIP  208] DT        dT(x,31,208)
  [VIP  209] DT        dT(x,637,209)
  [VIP  210] SUBI      Stk[210] = Stk[210] - 18
  [VIP  213] CALL      call Stk[A](...)
  [VIP  214] SETLIST2  rD/ZD/wD(...)
  [VIP  216] SETREG    Stk[216] = 94
  [VIP  217] LOADN     Stk[217] = 2
  [VIP  218] ADDI      Stk[218] = Stk[218] + 38
  [VIP  219] ADDI      Stk[219] = Stk[219] + 73
  [VIP  219] CALL      call Stk[A](...)
  [VIP  220] ADDI      Stk[220] = Stk[220] + 84
  [VIP  221] DT        dT(x,528,221)
  [VIP  222] DT        dT(x,88,222)
  [VIP  223] ADDU      Upv[223] = Upv[223] + 143
  [VIP  224] SETREG    Stk[224] = 86
  [VIP  228] GETTABUP  Stk[228] = env['math']
  [VIP  228] DT        dT(x,70,228)
  [VIP  229] GETTABUP  Stk[229] = env['Luraph']
  [VIP  229] DT        dT(x,7,229)
  [VIP  230] GETTABUP  Stk[230] = env[K[333]]
  [VIP  230] DT        dT(x,333,230)
  [VIP  231] GETTABUP  Stk[231] = env[K[452]]
  [VIP  231] DT        dT(x,452,231)
  [VIP  233] ADDI      Stk[233] = Stk[233] + 57
  [VIP  236] ADDI      Stk[236] = Stk[236] + 18
  [VIP  236] CALL      call Stk[A](...)
  [VIP  237] SUBI      Stk[237] = Stk[237] - 66
  [VIP  238] CALL      call Stk[A](...)
  [VIP  241] ADDI      Stk[241] = Stk[241] + 99
  [VIP  246] ADDI      Stk[246] = Stk[246] + 88
  [VIP  248] SUBI      Stk[248] = Stk[248] - 54
  [VIP  248] CALL      call Stk[A](...)
  [VIP  249] SUBI      Stk[249] = Stk[249] - 39
  [VIP  251] LOADN     Stk[251] = 4
  [VIP  252] SUBI      Stk[252] = Stk[252] - 102
  [VIP  253] DT        dT(x,94,253)
  [VIP  253] SETREG2   Upv[253] = 58
  [VIP  254] ADDI      Stk[254] = Stk[254] + 51
  [VIP  255] ADDI      Stk[255] = Stk[255] + 111
  [VIP  255] CALL      call Stk[A](...)
  [VIP  256] ADDI      Stk[256] = Stk[256] + 32
  [VIP  257] SUBI      Stk[257] = Stk[257] - 116
  [VIP  260] GETTABUP  Stk[260] = env['linedefined']
  [VIP  260] DT        dT(x,68,260)
  [VIP  261] GETTABUP  Stk[261] = env[K[681]]
  [VIP  261] DT        dT(x,681,261)
  [VIP  263] ADDI      Stk[263] = Stk[263] + 0
  [VIP  264] DT        dT(x,72,264)
  [VIP  264] SETREG2   Upv[264] = 96
  [VIP  265] SETREG    Stk[265] = 44
  [VIP  266] SUBI      Stk[266] = Stk[266] - 86
  [VIP  267] ADD       Stk[267] = Stk[267] + 9
  [VIP  268] ADDI      Stk[268] = Stk[268] + 32
  [VIP  269] SETTABUP  Stk['gmatch'] = Stk[...]
  [VIP  269] DT        dT(x,5,269)
  [VIP  270] SETREG    Stk[270] = 98
  [VIP  274] GETTABUP  Stk[274] = env['gmatch']
  [VIP  274] DT        dT(x,5,274)
  [VIP  275] GETTABUP  Stk[275] = env['bor']
  [VIP  275] DT        dT(x,26,275)
  [VIP  276] GETTABUP  Stk[276] = env[K[140]]
  [VIP  276] DT        dT(x,140,276)
  [VIP  278] ADDI      Stk[278] = Stk[278] + 8
  [VIP  279] SUBI      Stk[279] = Stk[279] - 32
  [VIP  279] CALL      call Stk[A](...)
  [VIP  280] SUBI      Stk[280] = Stk[280] - 81
  [VIP  281] ADD       Stk[281] = Stk[281] + 3
  [VIP  282] ADDI      Stk[282] = Stk[282] + 34
  [VIP  283] DT        dT(x,239,283)
  [VIP  284] ADDU      Upv[284] = Upv[284] + 15
  [VIP  285] SETREG    Stk[285] = 88
  [VIP  285] CALL      call Stk[A](...)
  [VIP  286] SETREG    Stk[286] = 23
  [VIP  287] ADDI      Stk[287] = Stk[287] + 106
  [VIP  287] CALL      call Stk[A](...)
  [VIP  288] SETREG    Stk[288] = 113
  [VIP  289] ADD       Stk[289] = Stk[289] + 7
  [VIP  290] SETREG    Stk[290] = 81
  [VIP  291] ADD       Stk[291] = Stk[291] + 0
  [VIP  292] ADDI      Stk[292] = Stk[292] + 49
  [VIP  293] SETREG    Stk[293] = 144
  [VIP  294] SETREG    Stk[294] = 101
  [VIP  297] GETTABUP  Stk[297] = env[K[120]]
  [VIP  297] DT        dT(x,120,297)
  [VIP  298] SETREG    Stk[298] = 45
  [VIP  299] SETREG    Stk[299] = 84
  [VIP  300] SETREG    Stk[300] = 132
  [VIP  303] ADDI      Stk[303] = Stk[303] + 30
  [VIP  304] ADDI      Stk[304] = Stk[304] + 76
  [VIP  305] SUBI      Stk[305] = Stk[305] - 120
  [VIP  306] ADDI      Stk[306] = Stk[306] + 0
  [VIP  309] GETTABUP  Stk[309] = env[' --[[%s]] return setfenv(function(...) r...']
  [VIP  309] DT        dT(x,44,309)
  [VIP  310] GETTABUP  Stk[310] = env[K[261]]
  [VIP  310] DT        dT(x,261,310)
  [VIP  312] SUBI      Stk[312] = Stk[312] - 9
  [VIP  313] DT        dT(x,36,313)
  [VIP  313] ADDU      Upv[313] = Upv[313] + 78
  [VIP  314] SUBI      Stk[314] = Stk[314] - 118
  [VIP  315] SUBI      Stk[315] = Stk[315] - 31
  [VIP  315] CALL      call Stk[A](...)
  [VIP  316] SETREG    Stk[316] = 154
  [VIP  319] ADDI      Stk[319] = Stk[319] + 70
  [VIP  321] SETREG    Stk[321] = 58
  [VIP  323] CALL      call Stk[A](...)
  [VIP  324] CALL      call Stk[A](...)
  [VIP  325] SETREG    Stk[325] = 126
  [VIP  326] DT        dT(x,563,326)
  [VIP  327] SETREG    Stk[327] = 52
  [VIP  328] SUBI      Stk[328] = Stk[328] - 14
  [VIP  328] CALL      call Stk[A](...)
  [VIP  329] SETREG    Stk[329] = 51
  [VIP  331] DT        dT(x,512,331)
  [VIP  332] DT        dT(x,310,332)
  [VIP  333] SUBI      Stk[333] = Stk[333] - 51
  [VIP  334] ADDI      Stk[334] = Stk[334] + 32
  [VIP  338] ADDI      Stk[338] = Stk[338] + 18
  [VIP  339] SETTABUP  Stk['yield'] = Stk[...]
  [VIP  339] DT        dT(x,72,339)
  [VIP  340] SUBI      Stk[340] = Stk[340] - 117
  [VIP  341] SETREG    Stk[341] = 4
  [VIP  342] SUBI      Stk[342] = Stk[342] - 93
  [VIP  345] GETTABUP  Stk[345] = env['Luraph']
  [VIP  345] DT        dT(x,7,345)
  [VIP  346] GETTABUP  Stk[346] = env[K[176]]
  [VIP  346] DT        dT(x,176,346)
  [VIP  348] SETREG    Stk[348] = 158
  [VIP  352] GETTABUP  Stk[352] = env[K[122]]
  [VIP  352] DT        dT(x,122,352)
  [VIP  353] GETTABUP  Stk[353] = env['bor']
  [VIP  353] DT        dT(x,26,353)
  [VIP  354] GETTABUP  Stk[354] = env[K[402]]
  [VIP  354] DT        dT(x,402,354)
  [VIP  356] SUBI      Stk[356] = Stk[356] - 29
  [VIP  366] SUBI      Stk[366] = Stk[366] - 67
  [VIP  367] SUBI      Stk[367] = Stk[367] - 143
  [VIP  370] ADDI      Stk[370] = Stk[370] + 8
  [VIP  371] SUBI      Stk[371] = Stk[371] - 72
  [VIP  371] CALL      call Stk[A](...)
  [VIP  372] SUBI      Stk[372] = Stk[372] - 131
  [VIP  376] SUBI      Stk[376] = Stk[376] - 47
  [VIP  377] GETTABUP  Stk[377] = env['error in error handling']
  [VIP  378] SUBI      Stk[378] = Stk[378] - 6
  [VIP  379] SETREG    Stk[379] = 58
  [VIP  380] SUBI      Stk[380] = Stk[380] - 86
  [VIP  383] GETTABUP  Stk[383] = env['gmatch']
  [VIP  384] GETTABUP  Stk[384] = env['tonumber']
  [VIP  385] SUBI      Stk[385] = Stk[385] - 181
  [VIP  387] GETTABUP  Stk[387] = env['typeof']
  [VIP  388] DT        dT(x,117,388)
  [VIP  389] SETREG    Stk[389] = 75
  [VIP  390] SETREG    Stk[390] = 94
  [VIP  391] SUBI      Stk[391] = Stk[391] - 92
  [VIP  392] LOADN     Stk[392] = 36
  [VIP  392] DT        dT(x,36,392)
  [VIP  393] SETREG    Stk[393] = 157
  [VIP  394] SETREG    Stk[394] = 191
  [VIP  394] CALL      call Stk[A](...)
  [VIP  395] SETREG    Stk[395] = 120
  [VIP    1] ADDI      Stk[1] = Stk[1] + 32
  [VIP    2] ADDI      Stk[2] = Stk[2] + 39
  [VIP    6] GETTABUP  Stk[6] = env['<i8']
  [VIP    6] DT        dT(x,54,6)
  [VIP    7] GETTABUP  Stk[7] = env[K[90]]
  [VIP    7] DT        dT(x,90,7)
  [VIP    8] GETTABUP  Stk[8] = env['<i8']
  [VIP    8] DT        dT(x,54,8)
  [VIP    9] GETTABUP  Stk[9] = env['next']
  [VIP    9] DT        dT(x,15,9)
  [VIP   11] ADDI      Stk[11] = Stk[11] + 45
  [VIP   12] ADDI      Stk[12] = Stk[12] + 50
  [VIP   12] CALL      call Stk[A](...)
  [VIP   13] ADDI      Stk[13] = Stk[13] + 26
  [VIP   16] GETTABUP  Stk[16] = env[K[458]]
  [VIP   16] DT        dT(x,458,16)
  [VIP   17] GETTABUP  Stk[17] = env['next']
  [VIP   18] GETTABUP  Stk[18] = env['next']
  [VIP   19] GETTABUP  Stk[19] = env['mQxEXg']
  [VIP   20] GETTABUP  Stk[20] = env['error in error handling']
  [VIP   20] DT        dT(x,9,20)
  [VIP   22] SETREG    Stk[22] = 11
  [VIP   26] ADDI      Stk[26] = Stk[26] + 37
  [VIP   27] SETREG    Stk[27] = 2
  [VIP   28] DT        dT(x,468,28)
  [VIP   31] SETREG    Stk[31] = 1
  [VIP   32] SETREG    Stk[32] = 1
  [VIP   32] CALL      call Stk[A](...)
  [VIP   33] ADDI      Stk[33] = Stk[33] + 5
  [VIP   35] CALL      call Stk[A](...)
  [VIP   37] DT        dT(x,686,37)
  [VIP   38] SETREG    Stk[38] = 1
  [VIP   39] SUBI      Stk[39] = Stk[39] - 13
  [VIP   40] SUBI      Stk[40] = Stk[40] - 13
  [VIP   41] SUBI      Stk[41] = Stk[41] - 19
  [VIP   45] GETTABUP  Stk[45] = env['traceback']
  [VIP   45] DT        dT(x,34,45)
  [VIP   46] GETTABUP  Stk[46] = env[K[109]]
  [VIP   46] DT        dT(x,109,46)
  [VIP   47] GETTABUP  Stk[47] = env['isvararg']
  [VIP   47] DT        dT(x,23,47)
  [VIP   49] ADDI      Stk[49] = Stk[49] + 15
  [VIP   52] GETTABUP  Stk[52] = env['running']
  [VIP   52] DT        dT(x,24,52)
  [VIP   53] GETTABUP  Stk[53] = env['<i8']
  [VIP   53] DT        dT(x,54,53)
  [VIP   54] GETTABUP  Stk[54] = env[K[97]]
  [VIP   54] DT        dT(x,97,54)
  [VIP   56] SUBI      Stk[56] = Stk[56] - 25
  [VIP   61] ADDI      Stk[61] = Stk[61] + 2
  [VIP   62] SUBI      Stk[62] = Stk[62] - 22
  [VIP   63] SUBI      Stk[63] = Stk[63] - 14
  [VIP   65] SETREG    Stk[65] = 13
  [VIP    1] ADDI      Stk[1] = Stk[1] + 27
  [VIP    6] DT        dT(x,191,6)
  [VIP    9] ADDI      Stk[9] = Stk[9] + 63
  [VIP   12] GETTABUP  Stk[12] = env['xpcall']
  [VIP   12] DT        dT(x,40,12)
  [VIP   13] GETTABUP  Stk[13] = env[K[86]]
  [VIP   13] DT        dT(x,86,13)
  [VIP   14] GETTABUP  Stk[14] = env['nparams']
  [VIP   14] DT        dT(x,56,14)
  [VIP   16] SETREG    Stk[16] = 1
  [VIP   17] ADDI      Stk[17] = Stk[17] + 0
  [VIP   22] GETTABUP  Stk[22] = env[K[89]]
  [VIP   22] DT        dT(x,89,22)
  [VIP   23] GETTABUP  Stk[23] = env['typeof']
  [VIP   23] DT        dT(x,3,23)
  [VIP   24] GETTABUP  Stk[24] = env['lastlinedefined']
  [VIP   24] DT        dT(x,11,24)
  [VIP   25] GETTABUP  Stk[25] = env['Luraph']
  [VIP   25] DT        dT(x,7,25)
  [VIP   26] GETTABUP  Stk[26] = env['isvararg']
  [VIP   26] DT        dT(x,23,26)
  [VIP   28] ADDI      Stk[28] = Stk[28] + 36
  [VIP   29] ADDI      Stk[29] = Stk[29] + 28
  [VIP   30] ADDI      Stk[30] = Stk[30] + 1
  [VIP   31] ADDI      Stk[31] = Stk[31] + 1
  [VIP   32] SUBI      Stk[32] = Stk[32] - 2
  [VIP   35] GETTABUP  Stk[35] = env[K[662]]
  [VIP   35] DT        dT(x,662,35)
  [VIP   37] GETTABUP  Stk[37] = env[K[243]]
  [VIP   41] GETTABUP  Stk[41] = env['loadstring']
  [VIP   42] GETTABUP  Stk[42] = env['rawset']
  [VIP   43] GETTABUP  Stk[43] = env['isvararg']
  [VIP   43] DT        dT(x,23,43)
  [VIP   45] SETREG    Stk[45] = 16
  [VIP   50] ADDI      Stk[50] = Stk[50] + 23
  [VIP   55] ADDI      Stk[55] = Stk[55] + 17
  [VIP   56] SUBI      Stk[56] = Stk[56] - 27
  [VIP   60] GETTABUP  Stk[60] = env['Luraph']
  [VIP   60] DT        dT(x,7,60)
  [VIP   61] GETTABUP  Stk[61] = env['Luraph']
  [VIP   61] DT        dT(x,7,61)
  [VIP   62] GETTABUP  Stk[62] = env['bit32']
  [VIP   62] DT        dT(x,1,62)
  [VIP   64] SUBI      Stk[64] = Stk[64] - 14
  [VIP   65] SETLIST2  rD/ZD/wD(...)
  [VIP   72] SUBI      Stk[72] = Stk[72] - 27
  [VIP   74] SETREG    Stk[74] = 9
  [VIP    1] ADDI      Stk[1] = Stk[1] + 38
  [VIP    3] DT        dT(x,31,3)
  [VIP    5] ADDI      Stk[5] = Stk[5] + 32
  [VIP    8] GETTABUP  Stk[8] = env['math']
  [VIP    8] DT        dT(x,70,8)
  [VIP    9] GETTABUP  Stk[9] = env['lastlinedefined']
  [VIP    9] DT        dT(x,11,9)
  [VIP   10] GETTABUP  Stk[10] = env[K[109]]
  [VIP   10] DT        dT(x,109,10)
  [VIP   12] ADDI      Stk[12] = Stk[12] + 3
  [VIP   13] CALL      call Stk[A](...)
  [VIP   15] ADDI      Stk[15] = Stk[15] + 25
  [VIP   16] ADDI      Stk[16] = Stk[16] + 4
  [VIP   18] CALL      call Stk[A](...)
  [VIP   20] ADDI      Stk[20] = Stk[20] + 41
  [VIP   22] GETTABUP  Stk[22] = env[K[620]]
  [VIP   22] DT        dT(x,620,22)
  [VIP   23] GETTABUP  Stk[23] = env['C']
  [VIP   24] GETTABUP  Stk[24] = env['loadstring']
  [VIP   25] GETTABUP  Stk[25] = env['slnaf']
  [VIP   26] GETTABUP  Stk[26] = env['rawset']
  [VIP   26] DT        dT(x,10,26)
  [VIP   28] SUBI      Stk[28] = Stk[28] - 12
  [VIP   29] ADDI      Stk[29] = Stk[29] + 21
  [VIP   30] DT        dT(x,55,30)
  [VIP   30] ADDU      Upv[30] = Upv[30] + 7
  [VIP   31] SETREG    Stk[31] = 1
  [VIP   34] GETTABUP  Stk[34] = env['Luraph']
  [VIP   34] DT        dT(x,7,34)
  [VIP   35] GETTABUP  Stk[35] = env['status']
  [VIP   35] DT        dT(x,61,35)
  [VIP   37] ADDI      Stk[37] = Stk[37] + 4
  [VIP   38] SETTABUP  Stk[348] = Stk[...]
  [VIP   38] DT        dT(x,348,38)
  [VIP   39] SETREG    Stk[39] = 12
  [VIP   40] SETREG    Stk[40] = 5
  [VIP   41] SUBI      Stk[41] = Stk[41] - 9
  [VIP   47] CALL      call Stk[A](...)
  [VIP   48] DT        dT(x,83,48)
  [VIP   50] SUBI      Stk[50] = Stk[50] - 13
  [VIP   53] GETTABUP  Stk[53] = env['Luraph']
  [VIP   53] DT        dT(x,7,53)
  [VIP   54] GETTABUP  Stk[54] = env['xpcall']
  [VIP   54] DT        dT(x,40,54)
  [VIP   55] GETTABUP  Stk[55] = env['Luraph']
  [VIP   55] DT        dT(x,7,55)
  [VIP   56] GETTABUP  Stk[56] = env['coroutine']
  [VIP   56] DT        dT(x,37,56)
  [VIP   58] SUBI      Stk[58] = Stk[58] - 12
  [VIP   62] SUBI      Stk[62] = Stk[62] - 4
  [VIP   63] SETREG    Stk[63] = 28
  [VIP    1] ADDI      Stk[1] = Stk[1] + 5
  [VIP    4] CALL      call Stk[A](...)
  [VIP    7] SETREG    Stk[7] = 2
  [VIP    1] ADDI      Stk[1] = Stk[1] + 63
  [VIP    5] ADDI      Stk[5] = Stk[5] + 29
  [VIP    8] GETTABUP  Stk[8] = env['Luraph']
  [VIP    8] DT        dT(x,7,8)
  [VIP    9] GETTABUP  Stk[9] = env['nparams']
  [VIP    9] DT        dT(x,56,9)
  [VIP   11] SETREG    Stk[11] = 1
  [VIP   12] ADDI      Stk[12] = Stk[12] + 64
  [VIP   16] GETTABUP  Stk[16] = env['short_src']
  [VIP   16] DT        dT(x,77,16)
  [VIP   17] GETTABUP  Stk[17] = env['Luraph']
  [VIP   17] DT        dT(x,7,17)
  [VIP   18] GETTABUP  Stk[18] = env[K[81]]
  [VIP   18] DT        dT(x,81,18)
  [VIP   19] GETTABUP  Stk[19] = env['<i8']
  [VIP   19] DT        dT(x,54,19)
  [VIP   20] GETTABUP  Stk[20] = env[K[170]]
  [VIP   20] DT        dT(x,170,20)
  [VIP   22] ADDI      Stk[22] = Stk[22] + 62
  [VIP   23] ADDI      Stk[23] = Stk[23] + 14
  [VIP   24] SETREG    Stk[24] = 5
  [VIP   25] ADD       Stk[25] = Stk[25] + 0
  [VIP   26] SETREG    Stk[26] = 11
  [VIP   33] ADDI      Stk[33] = Stk[33] + 1
  [VIP   34] ADDI      Stk[34] = Stk[34] + 12
  [VIP   37] ADDI      Stk[37] = Stk[37] + 20
  [VIP   46] SUBI      Stk[46] = Stk[46] - 10
  [VIP   47] ADDI      Stk[47] = Stk[47] + 16
  [VIP   49] CALL      call Stk[A](...)
  [VIP   51] DT        dT(x,582,51)
  [VIP   52] DT        dT(x,117,52)
  [VIP   54] DT        dT(x,39,54)
  [VIP   55] SETREG2   Upv[55] = 24
  [VIP   57] SETREG    Stk[57] = 24
  [VIP   60] GETTABUP  Stk[60] = env['<i8']
  [VIP   60] DT        dT(x,54,60)
  [VIP   61] GETTABUP  Stk[61] = env[K[487]]
  [VIP   61] DT        dT(x,487,61)
  [VIP   63] SETREG    Stk[63] = 26
  [VIP   64] SETREG    Stk[64] = 23
  [VIP   65] SETREG    Stk[65] = 12
  [VIP   67] SETREG    Stk[67] = 24
  [VIP   70] GETTABUP  Stk[70] = env[K[456]]
  [VIP   70] DT        dT(x,456,70)
  [VIP   71] GETTABUP  Stk[71] = env['char']
  [VIP   72] GETTABUP  Stk[72] = env['char']
  [VIP   73] GETTABUP  Stk[73] = env['lastlinedefined']
  [VIP   74] GETTABUP  Stk[74] = env[K[103]]
  [VIP   74] DT        dT(x,103,74)
  [VIP   76] SUBI      Stk[76] = Stk[76] - 29
  [VIP   79] GETTABUP  Stk[79] = env['Luraph']
  [VIP   79] DT        dT(x,7,79)
  [VIP   80] GETTABUP  Stk[80] = env[K[102]]
  [VIP   80] DT        dT(x,102,80)
  [VIP   82] SETREG    Stk[82] = 22
  [VIP   83] DT        dT(x,340,83)
  [VIP   83] SUBU      Upv[83] = Upv[83] - 28
  [VIP   84] SUBI      Stk[84] = Stk[84] - 19
  [VIP   85] SUBI      Stk[85] = Stk[85] - 18
  [VIP    1] ADDI      Stk[1] = Stk[1] + 33
  [VIP    5] GETTABUP  Stk[5] = env[K[347]]
  [VIP    5] DT        dT(x,347,5)
  [VIP    6] GETTABUP  Stk[6] = env[K[89]]
  [VIP    6] DT        dT(x,89,6)
  [VIP    7] GETTABUP  Stk[7] = env[K[670]]
  [VIP    7] DT        dT(x,670,7)
  [VIP    9] ADDI      Stk[9] = Stk[9] + 42
  [VIP   10] ADD       Stk[10] = Stk[10] + 7
  [VIP   10] DT        dT(x,7,10)
  [VIP   11] ADDI      Stk[11] = Stk[11] + 12
  [VIP   13] ADDI      Stk[13] = Stk[13] + 6
  [VIP   16] GETTABUP  Stk[16] = env['nparams']
  [VIP   16] DT        dT(x,56,16)
  [VIP   17] GETTABUP  Stk[17] = env[K[349]]
  [VIP   17] DT        dT(x,349,17)
  [VIP   19] ADDI      Stk[19] = Stk[19] + 16
  [VIP   21] CALL      call Stk[A](...)
  [VIP   22] DT        dT(x,24,22)
  [VIP   23] SETREG    Stk[23] = 9
  [VIP   24] ADDI      Stk[24] = Stk[24] + 13
  [VIP   25] ADD       Stk[25] = Stk[25] + 7
  [VIP   25] DT        dT(x,7,25)
  [VIP   26] ADDI      Stk[26] = Stk[26] + 43
  [VIP   27] GETTABUP  Stk[27] = env['gmatch']
  [VIP   28] SETTABUP  Stk['Luraph'] = Stk[...]
  [VIP   28] DT        dT(x,7,28)
  [VIP   29] ADDI      Stk[29] = Stk[29] + 47
  [VIP   34] SETREG    Stk[34] = 9
  [VIP   35] ADDI      Stk[35] = Stk[35] + 18
  [VIP   36] SETREG    Stk[36] = 9
  [VIP   37] ADDI      Stk[37] = Stk[37] + 51
  [VIP   39] GETTABUP  Stk[39] = env['<i8']
  [VIP   39] DT        dT(x,54,39)
  [VIP   40] GETTABUP  Stk[40] = env[K[487]]
  [VIP   40] DT        dT(x,487,40)
  [VIP   42] SUBI      Stk[42] = Stk[42] - 16
  [VIP   45] GETTABUP  Stk[45] = env['what']
  [VIP   45] DT        dT(x,75,45)
  [VIP   46] GETTABUP  Stk[46] = env['loadstring']
  [VIP   47] GETTABUP  Stk[47] = env['loadstring']
  [VIP   48] GETTABUP  Stk[48] = env['number']
  [VIP   49] GETTABUP  Stk[49] = env[K[170]]
  [VIP   49] DT        dT(x,170,49)
  [VIP   51] ADDI      Stk[51] = Stk[51] + 33
  [VIP   53] ADDI      Stk[53] = Stk[53] + 25
  [VIP   54] ADDI      Stk[54] = Stk[54] + 1
  [VIP   55] ADDI      Stk[55] = Stk[55] + 6
  [VIP   58] GETTABUP  Stk[58] = env['math']
  [VIP   58] DT        dT(x,70,58)
  [VIP   59] GETTABUP  Stk[59] = env['rawget']
  [VIP   59] DT        dT(x,30,59)
  [VIP   61] SUBI      Stk[61] = Stk[61] - 19
  [VIP   64] GETTABUP  Stk[64] = env['xpcall']
  [VIP   64] DT        dT(x,40,64)
  [VIP   65] GETTABUP  Stk[65] = env[K[611]]
  [VIP   65] DT        dT(x,611,65)
  [VIP   66] GETTABUP  Stk[66] = env[' ']
  [VIP   66] DT        dT(x,21,66)
  [VIP   68] SETREG    Stk[68] = 24
  [VIP   69] SETREG    Stk[69] = 1
  [VIP   70] ADDI      Stk[70] = Stk[70] + 2
  [VIP   71] ADD       Stk[71] = Stk[71] + 7
  [VIP   71] DT        dT(x,7,71)
  [VIP   72] ADDI      Stk[72] = Stk[72] + 17
  [VIP   73] GETTABUP  Stk[73] = env['gmatch']
  [VIP   74] GETTABUP  Stk[74] = env[K[188]]
  [VIP   75] ADD       Stk[75] = Stk[75] + 6
  [VIP   76] SUBI      Stk[76] = Stk[76] - 8
  [VIP   77] SETREG    Stk[77] = 11
  [VIP   78] SETREG    Stk[78] = 13
  [VIP   80] CALL      call Stk[A](...)
  [VIP   82] CALL      call Stk[A](...)
  [VIP   83] DT        dT(x,24,83)
  [VIP   84] SUBI      Stk[84] = Stk[84] - 14
  [VIP   86] DT        dT(x,56,86)
  [VIP   87] DT        dT(x,7,87)
  [VIP   88] SUBI      Stk[88] = Stk[88] - 18
  [VIP   89] SETREG    Stk[89] = 32
  [VIP   90] SUBI      Stk[90] = Stk[90] - 36
  [VIP    1] ADDI      Stk[1] = Stk[1] + 27
  [VIP    4] GETTABUP  Stk[4] = env['error in error handling']
  [VIP    4] DT        dT(x,9,4)
  [VIP    5] GETTABUP  Stk[5] = env['slnaf']
  [VIP    6] GETTABUP  Stk[6] = env['slnaf']
  [VIP    7] GETTABUP  Stk[7] = env['Luraph']
  [VIP    8] GETTABUP  Stk[8] = env['type']
  [VIP    8] DT        dT(x,20,8)
  [VIP   10] ADDI      Stk[10] = Stk[10] + 2
  [VIP   12] SETREG    Stk[12] = 1
  [VIP   14] GETTABUP  Stk[14] = env[' ']
  [VIP   14] DT        dT(x,21,14)
  [VIP   15] CALL      call Stk[A](...)
  [VIP   16] CALL      call Stk[A](...)
  [VIP   17] DT        dT(x,10,17)
  [VIP   18] DT        dT(x,6,18)
  [VIP   29] ADDI      Stk[29] = Stk[29] + 0
  [VIP   30] ADDI      Stk[30] = Stk[30] + 0
  [VIP   35] GETTABUP  Stk[35] = env['debug']
  [VIP   35] DT        dT(x,14,35)
  [VIP   36] GETTABUP  Stk[36] = env['byte']
  [VIP   36] DT        dT(x,19,36)
  [VIP   37] GETTABUP  Stk[37] = env['char']
  [VIP   37] DT        dT(x,18,37)
  [VIP   38] GETTABUP  Stk[38] = env['gmatch']
  [VIP   38] DT        dT(x,5,38)
  [VIP   39] GETTABUP  Stk[39] = env['bit32']
  [VIP   39] DT        dT(x,1,39)
  [VIP   42] SETREG    Stk[42] = 11
