; Luraph v14.7 pseudo-Lua listing (static)
; 114 constants, 218 instructions

; -- constants --
  K[0] = "string"
  K[1] = "bit32"
  K[2] = "pcall"
  K[3] = "typeof"
  K[4] = "band"
  K[5] = "gmatch"
  K[6] = "tonumber"
  K[7] = "Luraph"
  K[8] = "mQxEXg"
  K[9] = "error in error handling"
  K[10] = "rawset"
  K[11] = "lastlinedefined"
  K[12] = "number"
  K[13] = <8B binary>
  K[14] = "slnaf"
  K[15] = "debug"
  K[16] = "next"
  K[17] = "find"
  K[18] = "loadstring"
  K[19] = "char"
  K[20] = "byte"
  K[21] = "type"
  K[22] = " "
  K[23] = "resume"
  K[24] = "
				 .@%(/*,.......      ...,,*/(#%&@@.
			 (*   ,/(#%%&..."
  K[25] = "isvararg"
  K[26] = "running"
  K[27] = "match"
  K[28] = "bor"
  K[29] = ":(%d+)[:
]"
  K[30] = "table"
  K[31] = "boolean"
  K[32] = "C"
  K[33] = "rawget"
  K[34] = "currentline"
  K[35] = "Your Lua environment does not support load or loadstring,..."
  K[36] = "getfenv"
  K[37] = "traceback"
  K[38] = "format"
  K[39] = "The debug library is required on Luau platforms. Please o..."
  K[40] = "coroutine"
  K[41] = "=[C]"
  K[42] = "info"
  K[43] = "xpcall"
  K[44] = "function"
  K[45] = "assert"
  K[46] = "rrotate"
  K[47] = " --[[%s]] return setfenv(function(...) return %s(...) end..."
  K[48] = "unpack"
  K[49] = "select"
  K[50] = "bxor"
  K[51] = "namewhat"
  K[52] = "insert"
  K[53] = "error"
  K[54] = "source"
  K[55] = "f"
  K[56] = "getmetatable"
  K[57] = "<i8"
  K[58] = "close"
  K[59] = "nparams"
  K[60] = "gsub"
  K[61] = "rep"
  K[62] = "tostring"
  K[63] = "create"
  K[64] = "status"
  K[65] = "isyieldable"
  K[66] = "countlz"
  K[67] = "concat"
  K[68] = "'setfenv' cannot change environment of given object"
  K[69] = "__index"
  K[70] = "getinfo"
  K[71] = "linedefined"
  K[72] = "[C]"
  K[73] = "math"
  K[74] = "sub"
  K[75] = "yield"
  K[76] = "lrotate"
  K[77] = "pack"
  K[78] = "what"
  K[79] = "wrap"
  K[80] = "short_src"
  K[81] = "setfenv"
  K[82] = "setmetatable"
  K[83] = <5B binary>
  K[84] = <2B binary>
  K[85] = <5B binary>
  K[86] = <4B binary>
  K[87] = <32B binary>
  K[88] = <21B binary>
  K[89] = <14B binary>
  K[90] = <36B binary>
  K[91] = <3B binary>
  K[92] = <36B binary>
  K[93] = <41B binary>
  K[94] = <2B binary>
  K[95] = <5B binary>
  K[96] = <5B binary>
  K[97] = <3B binary>
  K[98] = <2B binary>
  K[99] = <1B binary>
  K[100] = <4B binary>
  K[101] = <5B binary>
  K[102] = <3B binary>
  K[103] = <6B binary>
  K[104] = <5B binary>
  K[105] = <7B binary>
  K[106] = <5B binary>
  K[107] = <1B binary>
  K[108] = <73B binary>
  K[109] = <9B binary>
  K[110] = <12B binary>
  K[111] = <15B binary>
  K[112] = <6B binary>
  K[113] = <42B binary>

; -- code --
  [   0] OP 256    c3(r11) c5(r8) SETL(r12) SETL(r0) LOAD(r11) SETL(r1) LOAD(r8)
  [   1] OP 305    SETT(r3) SETT(r11) ADD(r7) ADD(r15) c5(r20) c6(r24)
  [   2] OP 286    c6(r13) c6(r15)
  [   3] OP 1293   
  [   4] OP 1837   
  [   5] OP 3616   ADD(r20) c3(r14) c6(r10)
  [   6] OP 271    
  [   7] OP 285    ADD(r24) c5(r3) c6(r19) ADD(r21)
  [   8] OP 306    
  [   9] OP 1427   GETG(r28)
  [  10] OP 268    
  [  11] OP 1310   
  [  12] OP 1727   
  [  13] OP 1165   
  [  14] OP 1265   
  [  15] OP 15199  SETT(r7) ADD(r29)
  [  16] OP 381    c6(r18) c6(r14) c5(r9) c5(r22)
  [  17] OP 534    
  [  18] OP 8946   
  [  19] OP 1539   
  [  20] OP 14072  ADD(r31) c5(r31) SETL(r14) SETT(r4) SETL(r18)
  [  21] OP 502    c6(r12) LOAD(r11) SETT(r24)
  [  22] OP 1636   LOAD(r29) LOAD(r28) c6(r6)
  [  23] OP 569    ADD(r6)
  [  24] OP 857    
  [  25] OP 382    
  [  26] OP 1359   
  [  27] OP 24940  
  [  28] OP 1023   SETT(r12) GETG(r12) LOAD(r21)
  [  29] OP 1806   c5(r15)
  [  30] OP 297    c3(r20) SETT(r2) c6(r20)
  [  31] OP 11945  
  [  32] OP 1789   
  [  33] OP 390    
  [  34] OP 303    
  [  35] OP 382    
  [  36] OP 287    SETL(r13) LOAD(r13) SETL(r26)
  [  37] OP 282    SETT(r7)
  [  38] OP 19912  SETL(r22)
  [  39] OP 2583   
  [  40] OP 322    GETG(r7) SETL(r16)
  [  41] OP 322    c3(r3)
  [  42] OP 456    
  [  43] OP 1618   
  [  44] OP 266    c3(r5) LOAD(r18)
  [  45] OP 1299   
  [  46] OP 1015   
  [  47] OP 312    GETG(r0) c6(r26) GETG(r24)
  [  48] OP 380    
  [  49] OP 1522   
  [  50] OP 1823   
  [  51] OP 436    ADD(r18)
  [  52] OP 13177  
  [  53] OP 410    c3(r16)
  [  54] OP 411    
  [  55] OP 262    
  [  56] OP 20135  SETT(r19)
  [  57] OP 712    c5(r1) c6(r4) c6(r7) ADD(r14) GETG(r14) SETT(r27)
  [  58] OP 262    
  [  59] OP 13217  SETT(r15) c3(r15)
  [  60] OP 269    ADD(r19) SETT(r19) GETG(r15)
  [  61] OP 30668  SETT(r8) SETL(r7) c3(r4) c5(r18)
  [  62] OP 9004   LOAD(r24)
  [  63] OP 280    
  [  64] OP 1198   
  [  65] OP 367    
  [  66] OP 3198   
  [  67] OP 1269   ADD(r28) c5(r13) c5(r12) ADD(r13) SETL(r1) LOAD(r19)
  [  68] OP 1367   
  [  69] OP 983    
  [  70] OP 278    
  [  71] OP 1065   c3(r29)
  [  72] OP 1368   
  [  73] OP 327    LOAD(r2)
  [  74] OP 1765   
  [  75] OP 9593   c5(r4) c6(r14)
  [  76] OP 504    
  [  77] OP 305    
  [  78] OP 29669  
  [  79] OP 1518   GETG(r14) GETG(r29) ADD(r3)
  [  80] OP 5266   ADD(r24) ADD(r30)
  [  81] OP 1358   
  [  82] OP 1738   
  [  83] OP 1164   LOAD(r23) c5(r21) SETT(r13)
  [  84] OP 1141   SETT(r8) c3(r12)
  [  85] OP 341    LOAD(r3)
  [  86] OP 300    
  [  87] OP 315    
  [  88] OP 330    SETT(r16)
  [  89] OP 19794  
  [  90] OP 290    
  [  91] OP 418    c5(r14)
  [  92] OP 400    
  [  93] OP 26672  GETG(r24)
  [  94] OP 266    GETG(r29)
  [  95] OP 293    
  [  96] OP 496    GETG(r15)
  [  97] OP 283    
  [  98] OP 271    c5(r9)
  [  99] OP 297    
  [ 100] OP 418    
  [ 101] OP 791    c6(r12)
  [ 102] OP 448    c6(r23) SETL(r14)
  [ 103] OP 991    
  [ 104] OP 383    
  [ 105] OP 280    
  [ 106] OP 1091   
  [ 107] OP 1006   GETG(r20) GETG(r31)
  [ 108] OP 338    
  [ 109] OP 12927  
  [ 110] OP 1777   
  [ 111] OP 1573   SETT(r9)
  [ 112] OP 25376  c3(r7)
  [ 113] OP 1202   
  [ 114] OP 1287   c3(r23) c5(r24)
  [ 115] OP 1067   SETT(r18) c5(r25)
  [ 116] OP 259    LOAD(r13) LOAD(r24) SETL(r22) SETT(r15) LOAD(r30)
  [ 117] OP 329    
  [ 118] OP 2047   LOAD(r15) ADD(r22) GETG(r20)
  [ 119] OP 36682  
  [ 120] OP 324    
  [ 121] OP 298    SETL(r29)
  [ 122] OP 472    ADD(r12)
  [ 123] OP 328    
  [ 124] OP 1625   
  [ 125] OP 1292   c5(r11)
  [ 126] OP 25857  
  [ 127] OP 9797   
  [ 128] OP 2469   
  [ 129] OP 403    SETT(r9) GETG(r10)
  [ 130] OP 350    
  [ 131] OP 1703   
  [ 132] OP 1775   
  [ 133] OP 265    SETT(r1) c3(r17) c5(r10) SETL(r29)
  [ 134] OP 1704   
  [ 135] OP 524    
  [ 136] OP 430    SETL(r15)
  [ 137] OP 15330  LOAD(r25) c5(r16) c5(r5)
  [ 138] OP 424    
  [ 139] OP 394    LOAD(r12)
  [ 140] OP 3722   
  [ 141] OP 359    
  [ 142] OP 264    
  [ 143] OP 1737   ADD(r7)
  [ 144] OP 347    
  [ 145] OP 4401   
  [ 146] OP 384    
  [ 147] OP 451    
  [ 148] OP 645    
  [ 149] OP 274    
  [ 150] OP 318    c3(r21)
  [ 151] OP 11231  
  [ 152] OP 304    c5(r23)
  [ 153] OP 9368   
  [ 154] OP 494    SETT(r5)
  [ 155] OP 600    LOAD(r16)
  [ 156] OP 1716   ADD(r15) c3(r27) GETG(r22)
  [ 157] OP 24946  
  [ 158] OP 729    
  [ 159] OP 414    ADD(r23)
  [ 160] OP 302    c6(r11)
  [ 161] OP 279    SETL(r23)
  [ 162] OP 510    SETL(r11) SETL(r13)
  [ 163] OP 435    c3(r6) c6(r10) c5(r17)
  [ 164] OP 260    
  [ 165] OP 27966  
  [ 166] OP 32016  
  [ 167] OP 29184  
  [ 168] OP 397    
  [ 169] OP 826    
  [ 170] OP 263    SETL(r23)
  [ 171] OP 314    c5(r7) c3(r4)
  [ 172] OP 6888   
  [ 173] OP 455    c6(r15) ADD(r27) LOAD(r20) LOAD(r6)
  [ 174] OP 551    
  [ 175] OP 23567  c5(r16)
  [ 176] OP 11623  
  [ 177] OP 270    
  [ 178] OP 487    c3(r3) ADD(r14)
  [ 179] OP 4057   c5(r0) SETT(r0) GETG(r1)
  [ 180] OP 50980  
  [ 181] OP 935    ADD(r0)
  [ 182] OP 59212  ADD(r0) ADD(r0)
  [ 183] OP 388    
  [ 184] OP 9281   
  [ 185] OP 19953  GETG(r9) SETL(r12) GETG(r1)
  [ 186] OP 19113  c3(r8) c5(r9) SETT(r1) GETG(r9) ADD(r4)
  [ 187] OP 1993   c5(r9) c6(r2)
  [ 188] OP 49439  
  [ 189] OP 3215   SETT(r9)
  [ 190] OP 14977  SETL(r6) c5(r3)
  [ 191] OP 7591   
  [ 192] OP 1436   SETT(r3)
  [ 193] OP 3809   
  [ 194] OP 5543   
  [ 195] OP 11172  c3(r0) SETL(r0) SETL(r0) LOAD(r0)
  [ 196] OP 1673   c3(r0)
  [ 197] OP 59156  
  [ 198] OP 703    SETL(r0)
  [ 199] OP 1225   c3(r0)
  [ 200] OP 415    SETT(r0)
  [ 201] OP 51551  
  [ 202] OP 1161   ADD(r0) SETL(r0)
  [ 203] OP 993    ADD(r0)
  [ 204] OP 1729   
  [ 205] OP 468    c3(r0)
  [ 206] OP 959    
  [ 207] OP 703    
  [ 208] OP 33097  
  [ 209] OP 26900  
  [ 210] OP 481    
  [ 211] OP 487    
  [ 212] OP 951    c5(r0) SETT(r0) SETL(r0) SETL(r0) ADD(r1) SETT(r2)
  [ 213] OP 2009   c6(r0) ADD(r0)
  [ 214] OP 1473   
  [ 215] OP 2949   
  [ 216] OP 969    ADD(r0) c3(r0) c3(r14)
  [ 217] OP 9395   
