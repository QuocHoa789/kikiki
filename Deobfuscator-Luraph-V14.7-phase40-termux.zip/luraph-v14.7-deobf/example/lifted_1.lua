-- Luraph v14.7 LIFTED pseudo-Lua (semantic reconstruction)
-- from VM execution trace + constant pool correlation

  [  1] OP 256    | ADDI      Stk[l] = l + 27
  [  2] OP 305    | (op 305: classes V=5 q=5 K=5 e=0 g=7)
  [  3] OP 286    | (op 286: classes V=5 q=5 K=5 e=9 g=0)
  [  4] OP 1293   | GETTABUP  Stk[l] = env['error in error handling']
  [  5] OP 1837   | GETTABUP  Stk[l] = env['slnaf']
  [  6] OP 3616   | GETTABUP  Stk[l] = env['slnaf']
  [  7] OP 271    | GETTABUP  Stk[l] = env['Luraph']
  [  8] OP 285    | GETTABUP  Stk[l] = env['type']
  [  9] OP 306    | (op 306: classes V=5 q=5 K=5 e=5 g=14)
  [ 10] OP 1427   | ADDI      Stk[l] = l + 2
  [ 11] OP 268    | (op 268: classes V=5 q=5 K=5 e=250 g=60)
  [ 12] OP 1310   | SETREG    Stk[l] = 1
  [ 13] OP 1727   | (op 1727: classes V=5 q=5 K=5 e=0 g=0)
  [ 14] OP 1165   | GETTABUP  Stk[l] = env[' ']
  [ 15] OP 1265   | CALL      hD(...)
  [ 16] OP 15199  | CALL      hD(...)
  [ 17] OP 381    | (op 381: classes V=5 q=0 K=5 e=10 g=241)
  [ 18] OP 534    | (op 534: classes V=5 q=0 K=5 e=6 g=0)
  [ 19] OP 8946   | (op 8946: classes V=5 q=5 K=5 e=3 g=2)
  [ 20] OP 1539   | (op 1539: classes V=5 q=5 K=5 e=0 g=1)
  [ 21] OP 14072  | (op 14072: classes V=5 q=5 K=5 e=81 g=244)
  [ 22] OP 502    | (op 502: classes V=5 q=5 K=5 e=58 g=136)
  [ 23] OP 1636   | (op 1636: classes V=5 q=5 K=5 e=54 g=86)
  [ 24] OP 569    | (op 569: classes V=5 q=5 K=5 e=68 g=189)
  [ 25] OP 857    | (op 857: classes V=5 q=5 K=5 e=163 g=27)
  [ 26] OP 382    | (op 382: classes V=5 q=5 K=5 e=14 g=36)
  [ 27] OP 1359   | (op 1359: classes V=5 q=5 K=5 e=14 g=205)
  [ 28] OP 24940  | (op 24940: classes V=5 q=5 K=5 e=0 g=0)
  [ 29] OP 1023   | ADDI      Stk[l] = l + 0
  [ 30] OP 1806   | ADDI      Stk[l] = l + 0
  [ 31] OP 297    | (op 297: classes V=5 q=5 K=5 e=19 g=0)
  [ 32] OP 11945  | (op 11945: classes V=5 q=5 K=5 e=0 g=16)
  [ 33] OP 1789   | (op 1789: classes V=5 q=5 K=5 e=0 g=17)
  [ 34] OP 390    | (op 390: classes V=5 q=5 K=5 e=0 g=18)
  [ 35] OP 303    | GETTABUP  Stk[l] = env['debug']
  [ 36] OP 382    | GETTABUP  Stk[l] = env['byte']
  [ 37] OP 287    | GETTABUP  Stk[l] = env['char']
  [ 38] OP 282    | GETTABUP  Stk[l] = env['gmatch']
  [ 39] OP 19912  | GETTABUP  Stk[l] = env['bit32']
  [ 40] OP 2583   | (op 2583: classes V=5 q=5 K=5 e=15 g=22)
  [ 41] OP 322    | (op 322: classes V=5 q=5 K=5 e=215 g=150)
  [ 42] OP 322    | SETREG    Stk[l] = 11
  [ 43] OP 456    | (op 456: classes V=5 q=5 K=5 e=13 g=0)
  [ 44] OP 1618   | (op 1618: classes V=5 q=5 K=5 e=0 g=12)
  [ 45] OP 266    | GETTABUP  Stk[l] = env['what']
  [ 46] OP 1299   | GETTABUP  Stk[l] = env['loadstring']
  [ 47] OP 1015   | GETTABUP  Stk[l] = env['loadstring']
  [ 48] OP 312    | GETTABUP  Stk[l] = env['number']
  [ 49] OP 380    | GETTABUP  Stk[l] = env['K[170]']
  [ 50] OP 1522   | (op 1522: classes V=5 q=5 K=5 e=9 g=18)
  [ 51] OP 1823   | ADDI      Stk[l] = l + 33
  [ 52] OP 436    | (op 436: classes V=5 q=5 K=5 e=3 g=4)
  [ 53] OP 13177  | ADDI      Stk[l] = l + 25
  [ 54] OP 410    | ADDI      Stk[l] = l + 1
  [ 55] OP 411    | ADDI      Stk[l] = l + 6
  [ 56] OP 262    | (op 262: classes V=5 q=5 K=5 e=23 g=0)
  [ 57] OP 20135  | (op 20135: classes V=5 q=5 K=5 e=0 g=21)
  [ 58] OP 712    | GETTABUP  Stk[l] = env['math']
  [ 59] OP 262    | GETTABUP  Stk[l] = env['rawget']
  [ 60] OP 13217  | (op 13217: classes V=5 q=5 K=5 e=19 g=26)
  [ 61] OP 269    | SUBI      Stk[l] = l - 19
  [ 62] OP 30668  | (op 30668: classes V=5 q=5 K=5 e=0 g=20)
  [ 63] OP 9004   | (op 9004: classes V=5 q=5 K=5 e=23 g=0)
  [ 64] OP 280    | GETTABUP  Stk[l] = env['xpcall']
  [ 65] OP 1198   | GETTABUP  Stk[l] = env['K[611]']
  [ 66] OP 367    | GETTABUP  Stk[l] = env[' ']
  [ 67] OP 3198   | (op 3198: classes V=5 q=5 K=5 e=19 g=26)
  [ 68] OP 1269   | SETREG    Stk[l] = 24
  [ 69] OP 1367   | SETREG    Stk[l] = 1
  [ 70] OP 983    | ADDI      Stk[l] = l + 2
  [ 71] OP 278    | ADD       Stk[l] = l + 7
  [ 72] OP 1065   | ADDI      Stk[l] = l + 17
  [ 73] OP 1368   | GETTABUP  Stk[l] = env['gmatch']
  [ 74] OP 327    | GETTABUP  Stk[l] = env['K[188]']
  [ 75] OP 1765   | ADD       Stk[l] = l + 6
  [ 76] OP 9593   | SUBI      Stk[l] = l - 8
  [ 77] OP 504    | SETREG    Stk[l] = 11
  [ 78] OP 305    | SETREG    Stk[l] = 13
  [ 79] OP 29669  | (op 29669: classes V=5 q=5 K=5 e=5 g=7)
  [ 80] OP 1518   | CALL      hD(...)
  [ 81] OP 5266   | (op 5266: classes V=5 q=5 K=5 e=6 g=7)
  [ 82] OP 1358   | CALL      hD(...)
  [ 83] OP 1738   | (op 1738: classes V=5 q=0 K=5 e=24 g=3)
  [ 84] OP 1164   | SUBI      Stk[l] = l - 14
  [ 85] OP 1141   | (op 1141: classes V=5 q=5 K=5 e=2 g=0)
  [ 86] OP 341    | (op 341: classes V=5 q=0 K=5 e=56 g=0)
  [ 87] OP 300    | (op 300: classes V=5 q=0 K=5 e=7 g=0)
  [ 88] OP 315    | SUBI      Stk[l] = l - 18
  [ 89] OP 330    | SETREG    Stk[l] = 32
  [ 90] OP 19794  | SUBI      Stk[l] = l - 36
  [ 91] OP 290    | GETTABUP  Stk[l] = env['lastlinedefined']
  [ 92] OP 418    | GETTABUP  Stk[l] = env['K[343]']
  [ 93] OP 400    | (op 400: classes V=5 q=5 K=5 e=32 g=39)
  [ 94] OP 26672  | ADDI      Stk[l] = l + 59
  [ 95] OP 266    | ADD       Stk[l] = l + 0
  [ 96] OP 293    | ADDI      Stk[l] = l + 15
  [ 97] OP 496    | (op 496: classes V=5 q=0 K=1 e=73 g=155)
  [ 98] OP 283    | ADDI      Stk[l] = l + 170
  [ 99] OP 271    | (op 271: classes V=5 q=0 K=5 e=19 g=0)
  [100] OP 297    | ADD       Stk[l] = l + 6
  [101] OP 418    | ADDI      Stk[l] = l + 266
  [102] OP 791    | (op 791: classes V=5 q=5 K=5 e=0 g=19)
  [103] OP 448    | (op 448: classes V=5 q=5 K=5 e=13 g=20)
  [104] OP 991    | (op 991: classes V=5 q=5 K=5 e=14 g=21)
  [105] OP 383    | (op 383: classes V=5 q=5 K=5 e=0 g=0)
  [106] OP 280    | (op 280: classes V=5 q=5 K=5 e=0 g=19)
  [107] OP 1091   | (op 1091: classes V=5 q=5 K=5 e=14 g=20)
  [108] OP 1006   | ADDI      Stk[l] = l + 0
  [109] OP 338    | (op 338: classes V=5 q=5 K=5 e=12 g=21)
  [110] OP 12927  | (op 12927: classes V=5 q=5 K=5 e=0 g=0)
  [111] OP 1777   | ADDI      Stk[l] = l + 188
  [112] OP 1573   | ADDI      Stk[l] = l + 273
  [113] OP 25376  | SETREG    Stk[l] = 39
  [114] OP 1202   | ADDI      Stk[l] = l + 179
  [115] OP 1287   | (op 1287: classes V=5 q=5 K=5 e=0 g=33)
  [116] OP 1067   | (op 1067: classes V=5 q=5 K=5 e=36 g=0)
  [117] OP 259    | GETTABUP  Stk[l] = env['K[104]']
  [118] OP 329    | GETTABUP  Stk[l] = env['K[327]']
  [119] OP 2047   | (op 2047: classes V=5 q=5 K=5 e=32 g=39)
  [120] OP 324    | ADDI      Stk[l] = l + 100
  [121] OP 298    | (op 298: classes V=5 q=5 K=5 e=0 g=19)
  [122] OP 472    | (op 472: classes V=5 q=5 K=5 e=10 g=20)
  [123] OP 328    | (op 328: classes V=5 q=5 K=5 e=13 g=21)
  [124] OP 1625   | (op 1625: classes V=5 q=5 K=5 e=0 g=0)
  [125] OP 1292   | ADDI      Stk[l] = l + 265
  [126] OP 25857  | ADDI      Stk[l] = l + 144
  [127] OP 9797   | CALL      hD(...)
  [128] OP 2469   | CALL      hD(...)
  [129] OP 403    | CALL      hD(...)
  [130] OP 350    | CALL      hD(...)
  [131] OP 1703   | (op 1703: classes V=5 q=0 K=5 e=623 g=0)
  [132] OP 1775   | SETREG    Stk[l] = 58
  [133] OP 265    | (op 265: classes V=5 q=5 K=5 e=0 g=34)
  [134] OP 1704   | (op 1704: classes V=5 q=5 K=5 e=0 g=33)
  [135] OP 524    | (op 524: classes V=5 q=5 K=5 e=36 g=0)
  [136] OP 430    | GETTABUP  Stk[l] = env['getinfo']
  [137] OP 15330  | GETTABUP  Stk[l] = env['K[102]']
  [138] OP 424    | GETTABUP  Stk[l] = env['K[81]']
  [139] OP 394    | GETTABUP  Stk[l] = env['K[139]']
  [140] OP 3722   | (op 3722: classes V=5 q=5 K=5 e=32 g=39)
  [141] OP 359    | ADDI      Stk[l] = l + 57
  [142] OP 264    | (op 264: classes V=5 q=5 K=5 e=0 g=1)
  [143] OP 1737   | (op 1737: classes V=5 q=5 K=5 e=0 g=0)
  [144] OP 347    | SUBI      Stk[l] = l - 50
  [145] OP 4401   | (op 4401: classes V=5 q=5 K=5 e=36 g=0)
  [146] OP 384    | (op 384: classes V=5 q=5 K=5 e=0 g=35)
  [147] OP 451    | GETTABUP  Stk[l] = env['K[115]']
  [148] OP 645    | GETTABUP  Stk[l] = env['K[395]']
  [149] OP 274    | (op 274: classes V=5 q=5 K=5 e=32 g=39)
  [150] OP 318    | ADDI      Stk[l] = l + 128
  [151] OP 11231  | (op 11231: classes V=5 q=5 K=5 e=0 g=1)
  [152] OP 304    | (op 304: classes V=5 q=5 K=5 e=0 g=0)
  [153] OP 9368   | SETREG    Stk[l] = 33
  [154] OP 494    | SETREG    Stk[l] = 76
  [155] OP 600    | (op 600: classes V=5 q=0 K=5 e=141 g=0)
  [156] OP 1716   | GETTABUP  Stk[l] = env['Luraph']
  [157] OP 24946  | SUBI      Stk[l] = l - 69
  [158] OP 729    | ADDI      Stk[l] = l + 42
  [159] OP 414    | ADDI      Stk[l] = l + 211 ; CALL      hD(...)
  [160] OP 302    | SETREG    Stk[l] = 22
  [161] OP 279    | CALL      hD(...)
  [162] OP 510    | (op 510: classes V=5 q=5 K=5 e=16 g=9)
  [163] OP 435    | (op 435: classes V=5 q=5 K=5 e=82 g=5)
  [164] OP 260    | (op 260: classes V=5 q=5 K=5 e=41 g=224)
  [165] OP 27966  | (op 27966: classes V=5 q=5 K=5 e=9 g=4)
  [166] OP 32016  | (op 32016: classes V=5 q=5 K=5 e=139 g=6)
  [167] OP 29184  | (op 29184: classes V=5 q=5 K=5 e=127 g=130)
  [168] OP 397    | ADDI      Stk[l] = l + 151
  [169] OP 826    | (op 826: classes V=5 q=5 K=5 e=9 g=2)
  [170] OP 263    | (op 263: classes V=5 q=0 K=5 e=142 g=0)
  [171] OP 314    | SETREG    Stk[l] = 58
  [172] OP 6888   | ADDI      Stk[l] = l + 94
  [173] OP 455    | (op 455: classes V=5 q=0 K=5 e=129 g=0)
  [174] OP 551    | (op 551: classes V=5 q=5 K=5 e=0 g=15)
  [175] OP 23567  | (op 23567: classes V=5 q=5 K=5 e=2 g=16)
  [176] OP 11623  | (op 11623: classes V=5 q=5 K=5 e=3 g=17)
  [177] OP 270    | SETREG    Stk[l] = 31
  [178] OP 487    | (op 487: classes V=5 q=0 K=5 e=45 g=0)
  [179] OP 9395   | SETREG    Stk[l] = 58
  [180] OP ?      | ADDI      Stk[l] = l + 77
  [181] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [182] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [183] OP ?      | SETREG    Stk[l] = 89
  [184] OP ?      | SETTABUP  Stk[debug] = ...
  [185] OP ?      | SETREG    Stk[l] = 1
  [186] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=33)
  [187] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=0)
  [188] OP ?      | GETTABUP  Stk[l] = env['typeof']
  [189] OP ?      | GETTABUP  Stk[l] = env['K[95]']
  [190] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=39)
  [191] OP ?      | SETREG    Stk[l] = 9
  [192] OP ?      | ADDI      Stk[l] = l + 150
  [193] OP ?      | (op ?: classes V=5 q=0 K=5 e=63 g=0)
  [194] OP ?      | SETREG2   v[l] = 94
  [195] OP ?      | SETREG    Stk[l] = 94 ; CALL      hD(...)
  [196] OP ?      | ADDI      Stk[l] = l + 20
  [197] OP ?      | ADD       Stk[l] = l + 73
  [198] OP ?      | SUBI      Stk[l] = l - 86
  [199] OP ?      | SETREG    Stk[l] = 59
  [200] OP ?      | ADDI      Stk[l] = l + 80
  [201] OP ?      | (op ?: classes V=5 q=0 K=5 e=497 g=0)
  [202] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=9)
  [203] OP ?      | (op ?: classes V=5 q=5 K=5 e=1 g=10)
  [204] OP ?      | ADDI      Stk[l] = l + 33
  [205] OP ?      | (op ?: classes V=5 q=5 K=5 e=9 g=4)
  [206] OP ?      | (op ?: classes V=5 q=5 K=5 e=9 g=7)
  [207] OP ?      | CALL      hD(...)
  [208] OP ?      | (op ?: classes V=5 q=0 K=5 e=31 g=0)
  [209] OP ?      | (op ?: classes V=5 q=0 K=5 e=637 g=0)
  [210] OP ?      | SUBI      Stk[l] = l - 18
  [211] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=14)
  [212] OP ?      | (op ?: classes V=5 q=5 K=5 e=1 g=15)
  [213] OP ?      | CALL      hD(...)
  [214] OP ?      | (op ?: classes V=5 q=5 K=2 e=17 g=4)
  [215] OP ?      | (op ?: classes V=5 q=5 K=5 e=4 g=14)
  [216] OP ?      | SETREG    Stk[l] = 94
  [217] OP ?      | LOADN     Stk[l] = 2
  [218] OP ?      | ADDI      Stk[l] = l + 38
  [219] OP ?      | ADDI      Stk[l] = l + 73 ; CALL      hD(...)
  [220] OP ?      | ADDI      Stk[l] = l + 84
  [221] OP ?      | (op ?: classes V=5 q=0 K=5 e=528 g=0)
  [222] OP ?      | (op ?: classes V=5 q=0 K=5 e=88 g=0)
  [223] OP ?      | (op ?: classes V=5 q=5 K=1 e=11 g=143)
  [224] OP ?      | SETREG    Stk[l] = 86
  [225] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=34)
  [226] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=0)
  [227] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=33)
  [228] OP ?      | GETTABUP  Stk[l] = env['math']
  [229] OP ?      | GETTABUP  Stk[l] = env['Luraph']
  [230] OP ?      | GETTABUP  Stk[l] = env['K[333]']
  [231] OP ?      | GETTABUP  Stk[l] = env['K[452]']
  [232] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=39)
  [233] OP ?      | ADDI      Stk[l] = l + 57
  [234] OP ?      | (op ?: classes V=5 q=5 K=5 e=11 g=19)
  [235] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=19)
  [236] OP ?      | ADDI      Stk[l] = l + 18 ; CALL      hD(...)
  [237] OP ?      | SUBI      Stk[l] = l - 66
  [238] OP ?      | CALL      hD(...)
  [239] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=9)
  [240] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=9)
  [241] OP ?      | ADDI      Stk[l] = l + 99
  [242] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=19)
  [243] OP ?      | (op ?: classes V=5 q=5 K=5 e=7 g=20)
  [244] OP ?      | (op ?: classes V=5 q=5 K=5 e=9 g=21)
  [245] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [246] OP ?      | ADDI      Stk[l] = l + 88
  [247] OP ?      | (op ?: classes V=5 q=5 K=5 e=341 g=408)
  [248] OP ?      | SUBI      Stk[l] = l - 54 ; CALL      hD(...)
  [249] OP ?      | SUBI      Stk[l] = l - 39
  [250] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [251] OP ?      | LOADN     Stk[l] = 4
  [252] OP ?      | SUBI      Stk[l] = l - 102
  [253] OP ?      | SETREG2   v[l] = 58
  [254] OP ?      | ADDI      Stk[l] = l + 51
  [255] OP ?      | ADDI      Stk[l] = l + 111 ; CALL      hD(...)
  [256] OP ?      | ADDI      Stk[l] = l + 32
  [257] OP ?      | SUBI      Stk[l] = l - 116
  [258] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=35)
  [259] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=0)
  [260] OP ?      | GETTABUP  Stk[l] = env['linedefined']
  [261] OP ?      | GETTABUP  Stk[l] = env['K[681]']
  [262] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=39)
  [263] OP ?      | ADDI      Stk[l] = l + 0
  [264] OP ?      | SETREG2   v[l] = 96
  [265] OP ?      | SETREG    Stk[l] = 44
  [266] OP ?      | SUBI      Stk[l] = l - 86
  [267] OP ?      | ADD       Stk[l] = l + 9
  [268] OP ?      | ADDI      Stk[l] = l + 32
  [269] OP ?      | SETTABUP  Stk[gmatch] = ...
  [270] OP ?      | SETREG    Stk[l] = 98
  [271] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=35)
  [272] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=33)
  [273] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=0)
  [274] OP ?      | GETTABUP  Stk[l] = env['gmatch']
  [275] OP ?      | GETTABUP  Stk[l] = env['bor']
  [276] OP ?      | GETTABUP  Stk[l] = env['K[140]']
  [277] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=39)
  [278] OP ?      | ADDI      Stk[l] = l + 8
  [279] OP ?      | SUBI      Stk[l] = l - 32 ; CALL      hD(...)
  [280] OP ?      | SUBI      Stk[l] = l - 81
  [281] OP ?      | ADD       Stk[l] = l + 3
  [282] OP ?      | ADDI      Stk[l] = l + 34
  [283] OP ?      | (op ?: classes V=5 q=0 K=5 e=239 g=0)
  [284] OP ?      | (op ?: classes V=5 q=5 K=1 e=15 g=15)
  [285] OP ?      | SETREG    Stk[l] = 88 ; CALL      hD(...)
  [286] OP ?      | SETREG    Stk[l] = 23
  [287] OP ?      | ADDI      Stk[l] = l + 106 ; CALL      hD(...)
  [288] OP ?      | SETREG    Stk[l] = 113
  [289] OP ?      | ADD       Stk[l] = l + 7
  [290] OP ?      | SETREG    Stk[l] = 81
  [291] OP ?      | ADD       Stk[l] = l + 0
  [292] OP ?      | ADDI      Stk[l] = l + 49
  [293] OP ?      | SETREG    Stk[l] = 144
  [294] OP ?      | SETREG    Stk[l] = 101
  [295] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=25)
  [296] OP ?      | (op ?: classes V=5 q=5 K=5 e=26 g=0)
  [297] OP ?      | GETTABUP  Stk[l] = env['K[120]']
  [298] OP ?      | SETREG    Stk[l] = 45
  [299] OP ?      | SETREG    Stk[l] = 84
  [300] OP ?      | SETREG    Stk[l] = 132
  [301] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=1)
  [302] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [303] OP ?      | ADDI      Stk[l] = l + 30
  [304] OP ?      | ADDI      Stk[l] = l + 76
  [305] OP ?      | SUBI      Stk[l] = l - 120
  [306] OP ?      | ADDI      Stk[l] = l + 0
  [307] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=0)
  [308] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=33)
  [309] OP ?      | GETTABUP  Stk[l] = env[' --[[%s]] return setfenv(function(...) r']
  [310] OP ?      | GETTABUP  Stk[l] = env['K[261]']
  [311] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=39)
  [312] OP ?      | SUBI      Stk[l] = l - 9
  [313] OP ?      | (op ?: classes V=5 q=0 K=1 e=36 g=78)
  [314] OP ?      | SUBI      Stk[l] = l - 118
  [315] OP ?      | SUBI      Stk[l] = l - 31 ; CALL      hD(...)
  [316] OP ?      | SETREG    Stk[l] = 154
  [317] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=1)
  [318] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [319] OP ?      | ADDI      Stk[l] = l + 70
  [320] OP ?      | (op ?: classes V=5 q=5 K=5 e=10 g=6)
  [321] OP ?      | SETREG    Stk[l] = 58
  [322] OP ?      | (op ?: classes V=5 q=5 K=5 e=1 g=0)
  [323] OP ?      | CALL      hD(...)
  [324] OP ?      | CALL      hD(...)
  [325] OP ?      | SETREG    Stk[l] = 126
  [326] OP ?      | (op ?: classes V=5 q=0 K=5 e=563 g=0)
  [327] OP ?      | SETREG    Stk[l] = 52
  [328] OP ?      | SUBI      Stk[l] = l - 14 ; CALL      hD(...)
  [329] OP ?      | SETREG    Stk[l] = 51
  [330] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [331] OP ?      | (op ?: classes V=5 q=0 K=5 e=512 g=0)
  [332] OP ?      | (op ?: classes V=5 q=0 K=5 e=310 g=0)
  [333] OP ?      | SUBI      Stk[l] = l - 51
  [334] OP ?      | ADDI      Stk[l] = l + 32
  [335] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=19)
  [336] OP ?      | (op ?: classes V=5 q=5 K=5 e=9 g=20)
  [337] OP ?      | (op ?: classes V=5 q=5 K=5 e=4 g=21)
  [338] OP ?      | ADDI      Stk[l] = l + 18
  [339] OP ?      | SETTABUP  Stk[yield] = ...
  [340] OP ?      | SUBI      Stk[l] = l - 117
  [341] OP ?      | SETREG    Stk[l] = 4
  [342] OP ?      | SUBI      Stk[l] = l - 93
  [343] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=35)
  [344] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=0)
  [345] OP ?      | GETTABUP  Stk[l] = env['Luraph']
  [346] OP ?      | GETTABUP  Stk[l] = env['K[176]']
  [347] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=39)
  [348] OP ?      | SETREG    Stk[l] = 158
  [349] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=0)
  [350] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=33)
  [351] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=35)
  [352] OP ?      | GETTABUP  Stk[l] = env['K[122]']
  [353] OP ?      | GETTABUP  Stk[l] = env['bor']
  [354] OP ?      | GETTABUP  Stk[l] = env['K[402]']
  [355] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=39)
  [356] OP ?      | SUBI      Stk[l] = l - 29
  [357] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [358] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=19)
  [359] OP ?      | (op ?: classes V=5 q=5 K=5 e=150 g=20)
  [360] OP ?      | (op ?: classes V=5 q=5 K=5 e=118 g=217)
  [361] OP ?      | (op ?: classes V=5 q=5 K=5 e=11 g=246)
  [362] OP ?      | (op ?: classes V=5 q=5 K=5 e=247 g=174)
  [363] OP ?      | (op ?: classes V=5 q=5 K=5 e=197 g=100)
  [364] OP ?      | (op ?: classes V=5 q=5 K=5 e=10 g=21)
  [365] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [366] OP ?      | SUBI      Stk[l] = l - 67
  [367] OP ?      | SUBI      Stk[l] = l - 143
  [368] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=1)
  [369] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [370] OP ?      | ADDI      Stk[l] = l + 8
  [371] OP ?      | SUBI      Stk[l] = l - 72 ; CALL      hD(...)
  [372] OP ?      | SUBI      Stk[l] = l - 131
  [373] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=15)
  [374] OP ?      | (op ?: classes V=5 q=5 K=5 e=3 g=16)
  [375] OP ?      | (op ?: classes V=5 q=5 K=5 e=7 g=17)
  [376] OP ?      | SUBI      Stk[l] = l - 47
  [377] OP ?      | GETTABUP  Stk[l] = env['error in error handling']
  [378] OP ?      | SUBI      Stk[l] = l - 6
  [379] OP ?      | SETREG    Stk[l] = 58
  [380] OP ?      | SUBI      Stk[l] = l - 86
  [381] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=9)
  [382] OP ?      | (op ?: classes V=5 q=5 K=5 e=1 g=10)
  [383] OP ?      | GETTABUP  Stk[l] = env['gmatch']
  [384] OP ?      | GETTABUP  Stk[l] = env['tonumber']
  [385] OP ?      | SUBI      Stk[l] = l - 181
  [386] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [387] OP ?      | GETTABUP  Stk[l] = env['typeof']
  [388] OP ?      | (op ?: classes V=5 q=0 K=5 e=117 g=0)
  [389] OP ?      | SETREG    Stk[l] = 75
  [390] OP ?      | SETREG    Stk[l] = 94
  [391] OP ?      | SUBI      Stk[l] = l - 92
  [392] OP ?      | LOADN     Stk[l] = 36
  [393] OP ?      | SETREG    Stk[l] = 157
  [394] OP ?      | SETREG    Stk[l] = 191 ; CALL      hD(...)
  [395] OP ?      | SETREG    Stk[l] = 120
  [396] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [397] OP ?      | ADDI      Stk[l] = l + 961
  [398] OP ?      | ADDI      Stk[l] = l + 1216
  [399] OP ?      | (op ?: classes V=5 q=5 K=5 e=82 g=81)
  [400] OP ?      | CALL      hD(...)
  [401] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=80)
  [402] OP ?      | ADDI      Stk[l] = l + 535
  [403] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [404] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=109)
  [405] OP ?      | GETTABUP  Stk[l] = env['Luraph']
  [406] OP ?      | GETTABUP  Stk[l] = env['K[189]']
  [407] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [408] OP ?      | ADDI      Stk[l] = l + 1319
  [409] OP ?      | ADDI      Stk[l] = l + 141
  [410] OP ?      | CALL      hD(...)
  [411] OP ?      | CALL      hD(...)
  [412] OP ?      | CALL      hD(...)
  [413] OP ?      | ADDI      Stk[l] = l + 430
  [414] OP ?      | (op ?: classes V=5 q=0 K=1 e=125 g=1192)
  [415] OP ?      | ADDI      Stk[l] = l + 1127
  [416] OP ?      | ADDI      Stk[l] = l + 861 ; CALL      hD(...)
  [417] OP ?      | ADDI      Stk[l] = l + 1377
  [418] OP ?      | (op ?: classes V=5 q=0 K=5 e=175 g=0)
  [419] OP ?      | ADDI      Stk[l] = l + 1195
  [420] OP ?      | (op ?: classes V=5 q=5 K=5 e=510 g=183)
  [421] OP ?      | (op ?: classes V=5 q=5 K=5 e=55 g=459)
  [422] OP ?      | (op ?: classes V=5 q=5 K=5 e=13 g=66)
  [423] OP ?      | (op ?: classes V=5 q=5 K=5 e=145 g=151)
  [424] OP ?      | (op ?: classes V=5 q=5 K=5 e=416 g=478)
  [425] OP ?      | (op ?: classes V=5 q=5 K=5 e=80 g=0)
  [426] OP ?      | GETTABUP  Stk[l] = env['K[80]']
  [427] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [428] OP ?      | SUBI      Stk[l] = l - 98
  [429] OP ?      | (op ?: classes V=5 q=0 K=5 e=608 g=0)
  [430] OP ?      | ADDI      Stk[l] = l + 45
  [431] OP ?      | ADDI      Stk[l] = l + 1005
  [432] OP ?      | SETREG    Stk[l] = 183
  [433] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [434] OP ?      | (op ?: classes V=5 q=0 K=5 e=120 g=0)
  [435] OP ?      | ADDI      Stk[l] = l + 534
  [436] OP ?      | (op ?: classes V=5 q=0 K=5 e=65 g=205)
  [437] OP ?      | ADDI      Stk[l] = l + 355
  [438] OP ?      | (op ?: classes V=5 q=0 K=1 e=126 g=1119)
  [439] OP ?      | ADDI      Stk[l] = l + 456
  [440] OP ?      | ADDI      Stk[l] = l + 619
  [441] OP ?      | (op ?: classes V=5 q=0 K=5 e=239 g=0)
  [442] OP ?      | ADDI      Stk[l] = l + 1327
  [443] OP ?      | SETREG    Stk[l] = 97
  [444] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=1)
  [445] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [446] OP ?      | ADDI      Stk[l] = l + 1171
  [447] OP ?      | CALL      hD(...)
  [448] OP ?      | CALL      hD(...)
  [449] OP ?      | CALL      hD(...)
  [450] OP ?      | CALL      hD(...)
  [451] OP ?      | CALL      hD(...)
  [452] OP ?      | (op ?: classes V=5 q=0 K=5 e=144 g=0)
  [453] OP ?      | ADDI      Stk[l] = l + 1132
  [454] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=2)
  [455] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [456] OP ?      | SUBI      Stk[l] = l - 125
  [457] OP ?      | ADDI      Stk[l] = l + 1335 ; CALL      hD(...)
  [458] OP ?      | SETREG    Stk[l] = 40
  [459] OP ?      | (op ?: classes V=5 q=0 K=1 e=2 g=1292)
  [460] OP ?      | SUBI      Stk[l] = l - 86
  [461] OP ?      | (op ?: classes V=5 q=0 K=1 e=403 g=653)
  [462] OP ?      | ADDI      Stk[l] = l + 384
  [463] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [464] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=72)
  [465] OP ?      | CALL      hD(...)
  [466] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [467] OP ?      | (op ?: classes V=5 q=0 K=5 e=387 g=0)
  [468] OP ?      | ADDI      Stk[l] = l + 987
  [469] OP ?      | GETTABUP  Stk[l] = env['K[87]']
  [470] OP ?      | (op ?: classes V=5 q=5 K=5 e=11 g=88)
  [471] OP ?      | (op ?: classes V=5 q=5 K=5 e=78 g=89)
  [472] OP ?      | (op ?: classes V=5 q=5 K=5 e=88 g=0)
  [473] OP ?      | (op ?: classes V=5 q=5 K=5 e=67 g=87)
  [474] OP ?      | (op ?: classes V=5 q=5 K=5 e=87 g=78)
  [475] OP ?      | ADDI      Stk[l] = l + 45
  [476] OP ?      | ADDI      Stk[l] = l + 1010 ; CALL      hD(...)
  [477] OP ?      | ADDI      Stk[l] = l + 552
  [478] OP ?      | CALL      hD(...)
  [479] OP ?      | (op ?: classes V=5 q=5 K=5 e=82 g=81)
  [480] OP ?      | ADDI      Stk[l] = l + 31
  [481] OP ?      | SETREG    Stk[l] = 166
  [482] OP ?      | CALL      hD(...)
  [483] OP ?      | (op ?: classes V=5 q=5 K=5 e=44 g=38)
  [484] OP ?      | (op ?: classes V=5 q=0 K=5 e=107 g=0)
  [485] OP ?      | ADDI      Stk[l] = l + 604
  [486] OP ?      | LOADN     Stk[l] = 0
  [487] OP ?      | ADDI      Stk[l] = l + 88
  [488] OP ?      | (op ?: classes V=5 q=0 K=5 e=290 g=0)
  [489] OP ?      | ADDI      Stk[l] = l + 825
  [490] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [491] OP ?      | GETTABUP  Stk[l] = env['K[309]']
  [492] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [493] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [494] OP ?      | ADDI      Stk[l] = l + 394
  [495] OP ?      | LOADN     Stk[l] = 0
  [496] OP ?      | ADDI      Stk[l] = l + 1220
  [497] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [498] OP ?      | SUBI      Stk[l] = l - 13
  [499] OP ?      | ADD       Stk[l] = l + 0
  [500] OP ?      | ADDI      Stk[l] = l + 1231
  [501] OP ?      | ADDI      Stk[l] = l + 1248 ; CALL      hD(...)
  [502] OP ?      | SETREG    Stk[l] = 71
  [503] OP ?      | SETTABUP  Stk[<i8] = ...
  [504] OP ?      | SETREG    Stk[l] = 192
  [505] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=72)
  [506] OP ?      | CALL      hD(...)
  [507] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [508] OP ?      | (op ?: classes V=5 q=0 K=5 e=50 g=0)
  [509] OP ?      | ADDI      Stk[l] = l + 811
  [510] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [511] OP ?      | SETREG    Stk[l] = 143
  [512] OP ?      | ADD       Stk[l] = l + 81
  [513] OP ?      | ADDI      Stk[l] = l + 1222
  [514] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [515] OP ?      | (op ?: classes V=5 q=5 K=5 e=44 g=70)
  [516] OP ?      | (op ?: classes V=5 q=0 K=5 e=132 g=0)
  [517] OP ?      | ADDI      Stk[l] = l + 468
  [518] OP ?      | ADDI      Stk[l] = l + 1130
  [519] OP ?      | SETREG2   v[l] = 181
  [520] OP ?      | SETREG    Stk[l] = 205
  [521] OP ?      | (op ?: classes V=5 q=5 K=5 e=43 g=87)
  [522] OP ?      | GETTABUP  Stk[l] = env['setfenv']
  [523] OP ?      | ADDI      Stk[l] = l + 744
  [524] OP ?      | SUBI      Stk[l] = l - 212 ; CALL      hD(...)
  [525] OP ?      | ADDI      Stk[l] = l + 435
  [526] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [527] OP ?      | (op ?: classes V=5 q=5 K=5 e=12 g=72)
  [528] OP ?      | CALL      hD(...)
  [529] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [530] OP ?      | (op ?: classes V=5 q=0 K=5 e=107 g=0)
  [531] OP ?      | ADDI      Stk[l] = l + 438
  [532] OP ?      | ADDI      Stk[l] = l + 476
  [533] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [534] OP ?      | (op ?: classes V=5 q=5 K=5 e=26 g=22)
  [535] OP ?      | CALL      hD(...)
  [536] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [537] OP ?      | (op ?: classes V=5 q=0 K=5 e=386 g=0)
  [538] OP ?      | ADDI      Stk[l] = l + 431
  [539] OP ?      | CALL      hD(...)
  [540] OP ?      | (op ?: classes V=5 q=5 K=5 e=12 g=5)
  [541] OP ?      | CALL      hD(...)
  [542] OP ?      | (op ?: classes V=5 q=5 K=5 e=12 g=5)
  [543] OP ?      | CALL      hD(...)
  [544] OP ?      | SETREG    Stk[l] = 156
  [545] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [546] OP ?      | (op ?: classes V=5 q=5 K=5 e=20 g=74)
  [547] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [548] OP ?      | ADDI      Stk[l] = l + 1134
  [549] OP ?      | (op ?: classes V=5 q=0 K=1 e=76 g=352)
  [550] OP ?      | SETREG    Stk[l] = 57
  [551] OP ?      | ADDI      Stk[l] = l + 654
  [552] OP ?      | (op ?: classes V=5 q=0 K=5 e=113 g=0)
  [553] OP ?      | (op ?: classes V=5 q=0 K=5 e=49 g=0)
  [554] OP ?      | (op ?: classes V=5 q=0 K=5 e=110 g=0)
  [555] OP ?      | (op ?: classes V=5 q=5 K=4 e=89 g=70)
  [556] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [557] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=108)
  [558] OP ?      | GETTABUP  Stk[l] = env['K[671]']
  [559] OP ?      | GETTABUP  Stk[l] = env['K[211]']
  [560] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [561] OP ?      | ADDI      Stk[l] = l + 978
  [562] OP ?      | (op ?: classes V=5 q=5 K=2 e=62 g=9)
  [563] OP ?      | (op ?: classes V=5 q=5 K=2 e=63 g=16)
  [564] OP ?      | (op ?: classes V=5 q=0 K=5 e=16 g=0)
  [565] OP ?      | ADDI      Stk[l] = l + 722
  [566] OP ?      | ADDI      Stk[l] = l + 837
  [567] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [568] OP ?      | SUBI      Stk[l] = l - 17
  [569] OP ?      | SUBI      Stk[l] = l - 255
  [570] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [571] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=107)
  [572] OP ?      | GETTABUP  Stk[l] = env['K[361]']
  [573] OP ?      | GETTABUP  Stk[l] = env['K[294]']
  [574] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [575] OP ?      | ADDI      Stk[l] = l + 440
  [576] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [577] OP ?      | (op ?: classes V=5 q=0 K=5 e=464 g=0)
  [578] OP ?      | ADDI      Stk[l] = l + 157
  [579] OP ?      | (op ?: classes V=5 q=0 K=1 e=36 g=889)
  [580] OP ?      | SUBI      Stk[l] = l - 140
  [581] OP ?      | CALL      hD(...)
  [582] OP ?      | (op ?: classes V=5 q=5 K=5 e=28 g=18)
  [583] OP ?      | (op ?: classes V=5 q=0 K=5 e=124 g=0)
  [584] OP ?      | SUBI      Stk[l] = l - 128
  [585] OP ?      | CALL      hD(...)
  [586] OP ?      | (op ?: classes V=5 q=5 K=5 e=39 g=38)
  [587] OP ?      | CALL      hD(...)
  [588] OP ?      | ADDI      Stk[l] = l + 490
  [589] OP ?      | ADDI      Stk[l] = l + 943 ; CALL      hD(...)
  [590] OP ?      | ADDI      Stk[l] = l + 412
  [591] OP ?      | (op ?: classes V=5 q=5 K=5 e=45 g=84)
  [592] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [593] OP ?      | SETREG    Stk[l] = 70
  [594] OP ?      | ADDI      Stk[l] = l + 761 ; CALL      hD(...)
  [595] OP ?      | ADDI      Stk[l] = l + 155
  [596] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [597] OP ?      | (op ?: classes V=5 q=5 K=5 e=15 g=74)
  [598] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [599] OP ?      | (op ?: classes V=5 q=0 K=5 e=17 g=0)
  [600] OP ?      | ADDI      Stk[l] = l + 976
  [601] OP ?      | ADDI      Stk[l] = l + 1083
  [602] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [603] OP ?      | CALL      hD(...)
  [604] OP ?      | CALL      hD(...)
  [605] OP ?      | (op ?: classes V=5 q=5 K=5 e=47 g=48)
  [606] OP ?      | CALL      hD(...)
  [607] OP ?      | CALL      hD(...)
  [608] OP ?      | (op ?: classes V=5 q=5 K=5 e=47 g=48)
  [609] OP ?      | (op ?: classes V=5 q=5 K=5 e=48 g=0)
  [610] OP ?      | CALL      hD(...)
  [611] OP ?      | (op ?: classes V=5 q=0 K=5 e=512 g=0)
  [612] OP ?      | SUBI      Stk[l] = l - 260
  [613] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [614] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=109)
  [615] OP ?      | GETTABUP  Stk[l] = env['tostring']
  [616] OP ?      | GETTABUP  Stk[l] = env['K[644]']
  [617] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [618] OP ?      | SUBI      Stk[l] = l - 124
  [619] OP ?      | CALL      hD(...)
  [620] OP ?      | (op ?: classes V=5 q=5 K=5 e=19 g=5)
  [621] OP ?      | (op ?: classes V=5 q=0 K=5 e=111 g=0)
  [622] OP ?      | ADDI      Stk[l] = l + 391
  [623] OP ?      | (op ?: classes V=5 q=5 K=5 e=87 g=79)
  [624] OP ?      | GETTABUP  Stk[l] = env['setfenv']
  [625] OP ?      | ADD       Stk[l] = l + 1
  [626] OP ?      | SETREG    Stk[l] = 128
  [627] OP ?      | ADDI      Stk[l] = l + 163
  [628] OP ?      | CALL      hD(...)
  [629] OP ?      | (op ?: classes V=5 q=0 K=5 e=222 g=0)
  [630] OP ?      | (op ?: classes V=5 q=0 K=5 e=559 g=0)
  [631] OP ?      | SETREG    Stk[l] = 208
  [632] OP ?      | SUBI      Stk[l] = l - 280 ; CALL      hD(...)
  [633] OP ?      | ADDI      Stk[l] = l + 947
  [634] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [635] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=99)
  [636] OP ?      | GETTABUP  Stk[l] = env['K[108]']
  [637] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [638] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [639] OP ?      | GETTABUP  Stk[l] = env['K[99]']
  [640] OP ?      | GETTABUP  Stk[l] = env['K[406]']
  [641] OP ?      | (op ?: classes V=5 q=5 K=5 e=96 g=105)
  [642] OP ?      | ADDI      Stk[l] = l + 1123
  [643] OP ?      | ADDI      Stk[l] = l + 105
  [644] OP ?      | (op ?: classes V=5 q=5 K=2 e=85 g=25)
  [645] OP ?      | CALL      hD(...)
  [646] OP ?      | (op ?: classes V=5 q=5 K=5 e=152 g=66)
  [647] OP ?      | (op ?: classes V=5 q=5 K=5 e=87 g=77)
  [648] OP ?      | CALL      hD(...)
  [649] OP ?      | (op ?: classes V=5 q=5 K=5 e=18 g=140)
  [650] OP ?      | SETREG    Stk[l] = 121
  [651] OP ?      | (op ?: classes V=5 q=0 K=5 e=690 g=0)
  [652] OP ?      | ADDI      Stk[l] = l + 933
  [653] OP ?      | (op ?: classes V=5 q=0 K=5 e=107 g=0)
  [654] OP ?      | ADDI      Stk[l] = l + 81
  [655] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [656] OP ?      | ADDI      Stk[l] = l + 296
  [657] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=97)
  [658] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [659] OP ?      | (op ?: classes V=5 q=5 K=5 e=27 g=127)
  [660] OP ?      | CALL      hD(...)
  [661] OP ?      | (op ?: classes V=5 q=5 K=5 e=148 g=167)
  [662] OP ?      | ADDI      Stk[l] = l + 231
  [663] OP ?      | ADDI      Stk[l] = l + 119
  [664] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=82)
  [665] OP ?      | (op ?: classes V=5 q=0 K=5 e=13 g=0)
  [666] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [667] OP ?      | (op ?: classes V=5 q=5 K=5 e=84 g=84)
  [668] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [669] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [670] OP ?      | (op ?: classes V=5 q=0 K=5 e=13 g=0)
  [671] OP ?      | ADDI      Stk[l] = l + 312
  [672] OP ?      | SETTABUP  Stk[515] = ...
  [673] OP ?      | ADDI      Stk[l] = l + 291
  [674] OP ?      | (op ?: classes V=5 q=5 K=2 e=61 g=12)
  [675] OP ?      | (op ?: classes V=5 q=0 K=5 e=318 g=0)
  [676] OP ?      | ADDI      Stk[l] = l + 611
  [677] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [678] OP ?      | (op ?: classes V=5 q=0 K=5 e=594 g=149)
  [679] OP ?      | (op ?: classes V=5 q=5 K=5 e=154 g=199)
  [680] OP ?      | ADDI      Stk[l] = l + 442
  [681] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [682] OP ?      | (op ?: classes V=5 q=0 K=5 e=27 g=0)
  [683] OP ?      | ADDI      Stk[l] = l + 439
  [684] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=97)
  [685] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [686] OP ?      | GETTABUP  Stk[l] = env['K[104]'] ; CALL      hD(...)
  [687] OP ?      | ADDI      Stk[l] = l + 163
  [688] OP ?      | SETREG    Stk[l] = 46
  [689] OP ?      | ADD       Stk[l] = l + 104
  [690] OP ?      | ADDI      Stk[l] = l + 113
  [691] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [692] OP ?      | (op ?: classes V=5 q=5 K=2 e=78 g=17)
  [693] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [694] OP ?      | CALL      hD(...)
  [695] OP ?      | SETREG    Stk[l] = 139
  [696] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [697] OP ?      | (op ?: classes V=5 q=5 K=5 e=13 g=74)
  [698] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [699] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [700] OP ?      | (op ?: classes V=5 q=5 K=5 e=14 g=74)
  [701] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [702] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [703] OP ?      | (op ?: classes V=5 q=5 K=5 e=42 g=74)
  [704] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [705] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [706] OP ?      | (op ?: classes V=5 q=5 K=5 e=27 g=74)
  [707] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [708] OP ?      | ADDI      Stk[l] = l + 1127
  [709] OP ?      | (op ?: classes V=5 q=0 K=1 e=26 g=1150)
  [710] OP ?      | SUBI      Stk[l] = l - 354
  [711] OP ?      | (op ?: classes V=5 q=5 K=1 e=85 g=560)
  [712] OP ?      | SETREG    Stk[l] = 261
  [713] OP ?      | CALL      hD(...)
  [714] OP ?      | (op ?: classes V=5 q=0 K=5 e=124 g=0)
  [715] OP ?      | ADDI      Stk[l] = l + 24
  [716] OP ?      | ADD       Stk[l] = l + 94
  [717] OP ?      | ADDI      Stk[l] = l + 765
  [718] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=107)
  [719] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=108)
  [720] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [721] OP ?      | GETTABUP  Stk[l] = env['K[86]']
  [722] OP ?      | GETTABUP  Stk[l] = env['K[90]']
  [723] OP ?      | GETTABUP  Stk[l] = env['K[618]']
  [724] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [725] OP ?      | ADDI      Stk[l] = l + 1012
  [726] OP ?      | (op ?: classes V=5 q=0 K=1 e=4 g=1015)
  [727] OP ?      | SUBI      Stk[l] = l - 195
  [728] OP ?      | (op ?: classes V=5 q=5 K=5 e=14 g=87)
  [729] OP ?      | (op ?: classes V=5 q=5 K=5 e=91 g=88)
  [730] OP ?      | (op ?: classes V=5 q=5 K=5 e=79 g=89)
  [731] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [732] OP ?      | (op ?: classes V=5 q=5 K=5 e=14 g=87)
  [733] OP ?      | SETREG    Stk[l] = 336
  [734] OP ?      | SETTABUP  Stk[gmatch] = ...
  [735] OP ?      | SETREG    Stk[l] = 201
  [736] OP ?      | (op ?: classes V=5 q=0 K=1 e=60 g=1031)
  [737] OP ?      | ADDI      Stk[l] = l + 404
  [738] OP ?      | (op ?: classes V=5 q=0 K=5 e=482 g=0)
  [739] OP ?      | ADDI      Stk[l] = l + 548
  [740] OP ?      | ADD       Stk[l] = l + 4 ; CALL      hD(...)
  [741] OP ?      | SUBI      Stk[l] = l - 115
  [742] OP ?      | (op ?: classes V=5 q=5 K=5 e=1 g=0)
  [743] OP ?      | CALL      hD(...)
  [744] OP ?      | CALL      hD(...)
  [745] OP ?      | (op ?: classes V=5 q=0 K=5 e=27 g=0)
  [746] OP ?      | ADDI      Stk[l] = l + 275
  [747] OP ?      | ADDI      Stk[l] = l + 644
  [748] OP ?      | ADDI      Stk[l] = l + 70
  [749] OP ?      | ADD       Stk[l] = l + 4
  [750] OP ?      | ADDI      Stk[l] = l + 559
  [751] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [752] OP ?      | (op ?: classes V=5 q=5 K=5 e=30 g=74)
  [753] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [754] OP ?      | SETREG    Stk[l] = 72
  [755] OP ?      | (op ?: classes V=5 q=5 K=5 e=139 g=158)
  [756] OP ?      | (op ?: classes V=5 q=5 K=2 e=52 g=26)
  [757] OP ?      | (op ?: classes V=5 q=5 K=2 e=53 g=11)
  [758] OP ?      | CALL      hD(...)
  [759] OP ?      | CALL      hD(...)
  [760] OP ?      | (op ?: classes V=5 q=5 K=5 e=56 g=0)
  [761] OP ?      | ADDI      Stk[l] = l + 761
  [762] OP ?      | ADD       Stk[l] = l + 103
  [763] OP ?      | ADDI      Stk[l] = l + 103
  [764] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [765] OP ?      | (op ?: classes V=5 q=5 K=5 e=2 g=74)
  [766] OP ?      | (op ?: classes V=5 q=0 K=5 e=707 g=0)
  [767] OP ?      | SUBI      Stk[l] = l - 91
  [768] OP ?      | (op ?: classes V=5 q=0 K=5 e=238 g=0)
  [769] OP ?      | ADDI      Stk[l] = l + 23
  [770] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=82)
  [771] OP ?      | CALL      hD(...)
  [772] OP ?      | (op ?: classes V=5 q=5 K=5 e=30 g=84)
  [773] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [774] OP ?      | (op ?: classes V=5 q=5 K=5 e=2 g=84)
  [775] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [776] OP ?      | ADDI      Stk[l] = l + 1090
  [777] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=4)
  [778] OP ?      | ADDI      Stk[l] = l + 556
  [779] OP ?      | CALL      hD(...)
  [780] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [781] OP ?      | (op ?: classes V=5 q=5 K=5 e=70 g=0)
  [782] OP ?      | SETREG    Stk[l] = 285
  [783] OP ?      | (op ?: classes V=5 q=0 K=5 e=374 g=0)
  [784] OP ?      | ADDI      Stk[l] = l + 109
  [785] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=423)
  [786] OP ?      | (op ?: classes V=5 q=5 K=5 e=201 g=99)
  [787] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [788] OP ?      | (op ?: classes V=5 q=5 K=5 e=11 g=74)
  [789] OP ?      | CALL      hD(...)
  [790] OP ?      | ADDI      Stk[l] = l + 435
  [791] OP ?      | ADDI      Stk[l] = l + 882 ; CALL      hD(...)
  [792] OP ?      | ADDI      Stk[l] = l + 991
  [793] OP ?      | LOADN     Stk[l] = 74
  [794] OP ?      | SETREG    Stk[l] = 9
  [795] OP ?      | SETREG    Stk[l] = 305
  [796] OP ?      | CALL      hD(...)
  [797] OP ?      | (op ?: classes V=5 q=5 K=5 e=85 g=5)
  [798] OP ?      | CALL      hD(...)
  [799] OP ?      | CALL      hD(...)
  [800] OP ?      | (op ?: classes V=5 q=5 K=5 e=5 g=83)
  [801] OP ?      | SETREG    Stk[l] = 206
  [802] OP ?      | (op ?: classes V=5 q=0 K=5 e=595 g=0)
  [803] OP ?      | ADDI      Stk[l] = l + 775
  [804] OP ?      | (op ?: classes V=5 q=0 K=5 e=75 g=0)
  [805] OP ?      | ADDI      Stk[l] = l + 103
  [806] OP ?      | (op ?: classes V=5 q=5 K=5 e=30 g=83)
  [807] OP ?      | (op ?: classes V=5 q=5 K=5 e=78 g=84)
  [808] OP ?      | (op ?: classes V=5 q=5 K=5 e=83 g=0)
  [809] OP ?      | CALL      hD(...)
  [810] OP ?      | ADD       Stk[l] = l + 84
  [811] OP ?      | SETREG    Stk[l] = 371
  [812] OP ?      | ADDI      Stk[l] = l + 337 ; CALL      hD(...)
  [813] OP ?      | ADDI      Stk[l] = l + 422
  [814] OP ?      | ADDI      Stk[l] = l + 38
  [815] OP ?      | (op ?: classes V=5 q=5 K=5 e=14 g=87)
  [816] OP ?      | (op ?: classes V=5 q=5 K=5 e=83 g=88)
  [817] OP ?      | (op ?: classes V=5 q=5 K=5 e=79 g=89)
  [818] OP ?      | ADDI      Stk[l] = l + 7
  [819] OP ?      | (op ?: classes V=5 q=0 K=5 e=223 g=0)
  [820] OP ?      | (op ?: classes V=5 q=5 K=5 e=54 g=80)
  [821] OP ?      | (op ?: classes V=5 q=5 K=2 e=81 g=8)
  [822] OP ?      | (op ?: classes V=5 q=5 K=5 e=80 g=0)
  [823] OP ?      | (op ?: classes V=5 q=5 K=5 e=80 g=75)
  [824] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=80)
  [825] OP ?      | ADDI      Stk[l] = l + 328
  [826] OP ?      | ADDI      Stk[l] = l + 981
  [827] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=83)
  [828] OP ?      | CALL      hD(...)
  [829] OP ?      | CALL      hD(...)
  [830] OP ?      | ADDI      Stk[l] = l + 812
  [831] OP ?      | (op ?: classes V=5 q=5 K=5 e=87 g=86)
  [832] OP ?      | (op ?: classes V=5 q=0 K=4 e=64 g=122)
  [833] OP ?      | ADDI      Stk[l] = l + 109
  [834] OP ?      | CALL      hD(...)
  [835] OP ?      | CALL      hD(...)
  [836] OP ?      | CALL      hD(...)
  [837] OP ?      | SETREG    Stk[l] = 409
  [838] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=107)
  [839] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [840] OP ?      | GETTABUP  Stk[l] = env['K[650]']
  [841] OP ?      | GETTABUP  Stk[l] = env['K[492]']
  [842] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [843] OP ?      | ADDI      Stk[l] = l + 248
  [844] OP ?      | CALL      hD(...)
  [845] OP ?      | (op ?: classes V=5 q=0 K=5 e=353 g=0)
  [846] OP ?      | ADDI      Stk[l] = l + 268
  [847] OP ?      | CALL      hD(...)
  [848] OP ?      | (op ?: classes V=5 q=0 K=5 e=701 g=0)
  [849] OP ?      | ADDI      Stk[l] = l + 265
  [850] OP ?      | (op ?: classes V=5 q=5 K=5 e=170 g=379)
  [851] OP ?      | LOADN     Stk[l] = 104
  [852] OP ?      | ADDI      Stk[l] = l + 577
  [853] OP ?      | CALL      hD(...)
  [854] OP ?      | (op ?: classes V=5 q=5 K=5 e=19 g=5)
  [855] OP ?      | (op ?: classes V=5 q=0 K=5 e=290 g=0)
  [856] OP ?      | ADDI      Stk[l] = l + 509
  [857] OP ?      | SETREG    Stk[l] = 402
  [858] OP ?      | SETREG    Stk[l] = 175
  [859] OP ?      | (op ?: classes V=5 q=0 K=1 e=103 g=837)
  [860] OP ?      | ADDI      Stk[l] = l + 71
  [861] OP ?      | ADDI      Stk[l] = l + 395
  [862] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=79)
  [863] OP ?      | ADDI      Stk[l] = l + 555
  [864] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [865] OP ?      | (op ?: classes V=5 q=0 K=5 e=608 g=0)
  [866] OP ?      | ADDI      Stk[l] = l + 343
  [867] OP ?      | ADDI      Stk[l] = l + 840
  [868] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [869] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [870] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [871] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [872] OP ?      | SUBI      Stk[l] = l - 383
  [873] OP ?      | (op ?: classes V=5 q=0 K=5 e=114 g=0)
  [874] OP ?      | (op ?: classes V=5 q=0 K=5 e=672 g=0)
  [875] OP ?      | (op ?: classes V=5 q=0 K=5 e=120 g=0)
  [876] OP ?      | (op ?: classes V=5 q=5 K=1 e=78 g=990)
  [877] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [878] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=108)
  [879] OP ?      | GETTABUP  Stk[l] = env['K[170]']
  [880] OP ?      | GETTABUP  Stk[l] = env['K[514]']
  [881] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [882] OP ?      | ADDI      Stk[l] = l + 691
  [883] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=108)
  [884] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [885] OP ?      | GETTABUP  Stk[l] = env['Your Lua environment does not support lo']
  [886] OP ?      | GETTABUP  Stk[l] = env['K[493]']
  [887] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [888] OP ?      | ADDI      Stk[l] = l + 118
  [889] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [890] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [891] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [892] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [893] OP ?      | ADDI      Stk[l] = l + 797
  [894] OP ?      | LOADN     Stk[l] = 104
  [895] OP ?      | ADDI      Stk[l] = l + 345
  [896] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [897] OP ?      | (op ?: classes V=5 q=5 K=5 e=7 g=72)
  [898] OP ?      | (op ?: classes V=5 q=0 K=5 e=380 g=0)
  [899] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [900] OP ?      | (op ?: classes V=5 q=0 K=5 e=127 g=0)
  [901] OP ?      | ADDI      Stk[l] = l + 656
  [902] OP ?      | (op ?: classes V=5 q=0 K=1 e=1 g=373)
  [903] OP ?      | ADDI      Stk[l] = l + 495
  [904] OP ?      | (op ?: classes V=5 q=0 K=1 e=90 g=139)
  [905] OP ?      | SUBI      Stk[l] = l - 388
  [906] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [907] OP ?      | (op ?: classes V=5 q=0 K=5 e=45 g=0)
  [908] OP ?      | ADDI      Stk[l] = l + 44
  [909] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [910] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [911] OP ?      | GETTABUP  Stk[l] = env['K[97]']
  [912] OP ?      | GETTABUP  Stk[l] = env['K[695]']
  [913] OP ?      | (op ?: classes V=5 q=5 K=5 e=96 g=105)
  [914] OP ?      | SETREG    Stk[l] = 167
  [915] OP ?      | (op ?: classes V=5 q=0 K=5 e=323 g=0)
  [916] OP ?      | ADDI      Stk[l] = l + 72
  [917] OP ?      | (op ?: classes V=5 q=0 K=5 e=7 g=67)
  [918] OP ?      | CALL      hD(...)
  [919] OP ?      | (op ?: classes V=5 q=0 K=5 e=252 g=67)
  [920] OP ?      | CALL      hD(...)
  [921] OP ?      | CALL      hD(...)
  [922] OP ?      | (op ?: classes V=5 q=5 K=5 e=67 g=68)
  [923] OP ?      | CALL      hD(...)
  [924] OP ?      | (op ?: classes V=5 q=0 K=5 e=252 g=67)
  [925] OP ?      | CALL      hD(...)
  [926] OP ?      | CALL      hD(...)
  [927] OP ?      | (op ?: classes V=5 q=5 K=5 e=67 g=68)
  [928] OP ?      | CALL      hD(...)
  [929] OP ?      | SETREG    Stk[l] = 253
  [930] OP ?      | (op ?: classes V=5 q=0 K=1 e=59 g=52)
  [931] OP ?      | ADDI      Stk[l] = l + 692
  [932] OP ?      | (op ?: classes V=5 q=5 K=5 e=85 g=89)
  [933] OP ?      | (op ?: classes V=5 q=5 K=5 e=79 g=90)
  [934] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=0)
  [935] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=86)
  [936] OP ?      | (op ?: classes V=5 q=0 K=5 e=57 g=0)
  [937] OP ?      | ADDI      Stk[l] = l + 759
  [938] OP ?      | CALL      hD(...)
  [939] OP ?      | (op ?: classes V=5 q=5 K=5 e=81 g=80)
  [940] OP ?      | CALL      hD(...)
  [941] OP ?      | (op ?: classes V=5 q=5 K=5 e=81 g=80)
  [942] OP ?      | ADDI      Stk[l] = l + 12
  [943] OP ?      | (op ?: classes V=5 q=5 K=5 e=142 g=87)
  [944] OP ?      | (op ?: classes V=5 q=5 K=5 e=121 g=192)
  [945] OP ?      | (op ?: classes V=5 q=5 K=5 e=62 g=246)
  [946] OP ?      | (op ?: classes V=5 q=5 K=5 e=214 g=55)
  [947] OP ?      | (op ?: classes V=5 q=5 K=5 e=96 g=181)
  [948] OP ?      | (op ?: classes V=5 q=5 K=5 e=86 g=88)
  [949] OP ?      | (op ?: classes V=5 q=5 K=5 e=87 g=0)
  [950] OP ?      | SETREG    Stk[l] = 186
  [951] OP ?      | ADD       Stk[l] = l + 77
  [952] OP ?      | ADDI      Stk[l] = l + 921
  [953] OP ?      | ADD       Stk[l] = l + 78 ; CALL      hD(...)
  [954] OP ?      | SETREG    Stk[l] = 288
  [955] OP ?      | CALL      hD(...)
  [956] OP ?      | (op ?: classes V=5 q=5 K=5 e=81 g=80)
  [957] OP ?      | GETTABUP  Stk[l] = env['K[80]']
  [958] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [959] OP ?      | SETREG2   v[l] = 331
  [960] OP ?      | SUBI      Stk[l] = l - 245
  [961] OP ?      | CALL      hD(...)
  [962] OP ?      | (op ?: classes V=5 q=5 K=5 e=12 g=5)
  [963] OP ?      | (op ?: classes V=5 q=0 K=5 e=127 g=0)
  [964] OP ?      | SETREG    Stk[l] = 287
  [965] OP ?      | CALL      hD(...)
  [966] OP ?      | (op ?: classes V=5 q=0 K=5 e=582 g=0)
  [967] OP ?      | ADDI      Stk[l] = l + 147
  [968] OP ?      | (op ?: classes V=5 q=0 K=5 e=129 g=0)
  [969] OP ?      | ADDI      Stk[l] = l + 884
  [970] OP ?      | LOADN     Stk[l] = 93
  [971] OP ?      | SUBI      Stk[l] = l - 453
  [972] OP ?      | (op ?: classes V=5 q=5 K=5 e=86 g=90)
  [973] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=0)
  [974] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=87)
  [975] OP ?      | SUBI      Stk[l] = l - 265
  [976] OP ?      | SUBI      Stk[l] = l - 146
  [977] OP ?      | CALL      hD(...)
  [978] OP ?      | CALL      hD(...)
  [979] OP ?      | (op ?: classes V=5 q=0 K=5 e=111 g=0)
  [980] OP ?      | ADDI      Stk[l] = l + 93
  [981] OP ?      | (op ?: classes V=5 q=0 K=5 e=7 g=0)
  [982] OP ?      | SUBI      Stk[l] = l - 360
  [983] OP ?      | SUBI      Stk[l] = l - 371
  [984] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [985] OP ?      | (op ?: classes V=5 q=5 K=1 e=82 g=212)
  [986] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [987] OP ?      | (op ?: classes V=5 q=0 K=5 e=83 g=0)
  [988] OP ?      | SETREG    Stk[l] = 415
  [989] OP ?      | ADD       Stk[l] = l + 4 ; CALL      hD(...)
  [990] OP ?      | SETREG    Stk[l] = 239
  [991] OP ?      | SUBI      Stk[l] = l - 115
  [992] OP ?      | ADDI      Stk[l] = l + 769
  [993] OP ?      | CALL      hD(...)
  [994] OP ?      | (op ?: classes V=5 q=5 K=5 e=12 g=5)
  [995] OP ?      | (op ?: classes V=5 q=0 K=5 e=8 g=0)
  [996] OP ?      | SUBI      Stk[l] = l - 185
  [997] OP ?      | ADD       Stk[l] = l + 714
  [998] OP ?      | ADDI      Stk[l] = l + 665
  [999] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1000] OP ?      | (op ?: classes V=5 q=5 K=5 e=49 g=74)
  [1001] OP ?      | (op ?: classes V=5 q=0 K=5 e=549 g=0)
  [1002] OP ?      | SUBI      Stk[l] = l - 322
  [1003] OP ?      | CALL      hD(...)
  [1004] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=1)
  [1005] OP ?      | (op ?: classes V=5 q=0 K=5 e=580 g=0)
  [1006] OP ?      | ADDI      Stk[l] = l + 526
  [1007] OP ?      | (op ?: classes V=5 q=0 K=1 e=26 g=527)
  [1008] OP ?      | SUBI      Stk[l] = l - 366
  [1009] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=77)
  [1010] OP ?      | (op ?: classes V=5 q=5 K=5 e=68 g=78)
  [1011] OP ?      | (op ?: classes V=5 q=5 K=5 e=77 g=0)
  [1012] OP ?      | (op ?: classes V=5 q=0 K=5 e=7 g=0)
  [1013] OP ?      | SETREG    Stk[l] = 124
  [1014] OP ?      | LOADN     Stk[l] = 125
  [1015] OP ?      | SUBI      Stk[l] = l - 202
  [1016] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [1017] OP ?      | CALL      hD(...)
  [1018] OP ?      | CALL      hD(...)
  [1019] OP ?      | ADDI      Stk[l] = l + 768
  [1020] OP ?      | (op ?: classes V=5 q=0 K=4 e=53 g=259)
  [1021] OP ?      | SUBI      Stk[l] = l - 164
  [1022] OP ?      | SETREG    Stk[l] = 222 ; CALL      hD(...)
  [1023] OP ?      | ADDI      Stk[l] = l + 657
  [1024] OP ?      | SETREG    Stk[l] = 498 ; CALL      hD(...)
  [1025] OP ?      | SETREG    Stk[l] = 55
  [1026] OP ?      | (op ?: classes V=5 q=0 K=5 e=105 g=0)
  [1027] OP ?      | (op ?: classes V=5 q=0 K=5 e=271 g=0)
  [1028] OP ?      | (op ?: classes V=5 q=0 K=5 e=686 g=0)
  [1029] OP ?      | ADDI      Stk[l] = l + 84
  [1030] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1031] OP ?      | (op ?: classes V=5 q=5 K=5 e=34 g=74)
  [1032] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1033] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1034] OP ?      | (op ?: classes V=5 q=5 K=5 e=36 g=74)
  [1035] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1036] OP ?      | (op ?: classes V=5 q=0 K=5 e=39 g=0)
  [1037] OP ?      | ADDI      Stk[l] = l + 579
  [1038] OP ?      | SUBI      Stk[l] = l - 448
  [1039] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [1040] OP ?      | (op ?: classes V=5 q=5 K=5 e=11 g=72)
  [1041] OP ?      | (op ?: classes V=5 q=0 K=5 e=280 g=0)
  [1042] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1043] OP ?      | SUBI      Stk[l] = l - 518
  [1044] OP ?      | ADD       Stk[l] = l + 90
  [1045] OP ?      | SETREG    Stk[l] = 160
  [1046] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1047] OP ?      | CALL      hD(...)
  [1048] OP ?      | (op ?: classes V=5 q=5 K=5 e=77 g=38)
  [1049] OP ?      | ADDI      Stk[l] = l + 427
  [1050] OP ?      | CALL      hD(...)
  [1051] OP ?      | (op ?: classes V=5 q=5 K=2 e=45 g=13)
  [1052] OP ?      | CALL      hD(...)
  [1053] OP ?      | SUBI      Stk[l] = l - 452
  [1054] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1055] OP ?      | (op ?: classes V=5 q=0 K=5 e=38 g=0)
  [1056] OP ?      | SUBI      Stk[l] = l - 87
  [1057] OP ?      | CALL      hD(...)
  [1058] OP ?      | (op ?: classes V=5 q=0 K=5 e=628 g=0)
  [1059] OP ?      | ADDI      Stk[l] = l + 526
  [1060] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [1061] OP ?      | (op ?: classes V=5 q=5 K=5 e=35 g=72)
  [1062] OP ?      | CALL      hD(...)
  [1063] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1064] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [1065] OP ?      | SETREG    Stk[l] = 504
  [1066] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [1067] OP ?      | (op ?: classes V=5 q=5 K=5 e=56 g=70)
  [1068] OP ?      | CALL      hD(...)
  [1069] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1070] OP ?      | SETREG    Stk[l] = 513
  [1071] OP ?      | CALL      hD(...)
  [1072] OP ?      | (op ?: classes V=5 q=5 K=5 e=34 g=18)
  [1073] OP ?      | SETREG    Stk[l] = 446
  [1074] OP ?      | SETREG2   v[l] = 224
  [1075] OP ?      | SETREG    Stk[l] = 531
  [1076] OP ?      | (op ?: classes V=5 q=5 K=2 e=48 g=6)
  [1077] OP ?      | (op ?: classes V=5 q=0 K=5 e=105 g=0)
  [1078] OP ?      | SETREG    Stk[l] = 352
  [1079] OP ?      | CALL      hD(...)
  [1080] OP ?      | CALL      hD(...)
  [1081] OP ?      | CALL      hD(...)
  [1082] OP ?      | SETREG    Stk[l] = 417
  [1083] OP ?      | (op ?: classes V=5 q=0 K=1 e=200 g=660)
  [1084] OP ?      | SUBI      Stk[l] = l - 46
  [1085] OP ?      | ADDI      Stk[l] = l + 113
  [1086] OP ?      | (op ?: classes V=5 q=0 K=5 e=7 g=0)
  [1087] OP ?      | (op ?: classes V=5 q=0 K=5 e=556 g=0)
  [1088] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [1089] OP ?      | (op ?: classes V=5 q=5 K=1 e=83 g=178)
  [1090] OP ?      | ADDI      Stk[l] = l + 524
  [1091] OP ?      | ADDI      Stk[l] = l + 738
  [1092] OP ?      | ADD       Stk[l] = l + 37
  [1093] OP ?      | SETREG    Stk[l] = 151
  [1094] OP ?      | SUBI      Stk[l] = l - 280
  [1095] OP ?      | (op ?: classes V=5 q=5 K=5 e=44 g=88)
  [1096] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=5)
  [1097] OP ?      | (op ?: classes V=5 q=5 K=5 e=2 g=88)
  [1098] OP ?      | (op ?: classes V=5 q=5 K=5 e=88 g=78)
  [1099] OP ?      | SUBI      Stk[l] = l - 238
  [1100] OP ?      | SUBI      Stk[l] = l - 112
  [1101] OP ?      | CALL      hD(...)
  [1102] OP ?      | CALL      hD(...)
  [1103] OP ?      | CALL      hD(...)
  [1104] OP ?      | CALL      hD(...)
  [1105] OP ?      | CALL      hD(...)
  [1106] OP ?      | (op ?: classes V=5 q=5 K=5 e=10 g=0)
  [1107] OP ?      | CALL      hD(...)
  [1108] OP ?      | SETREG    Stk[l] = 109
  [1109] OP ?      | CALL      hD(...)
  [1110] OP ?      | (op ?: classes V=5 q=0 K=5 e=49 g=0)
  [1111] OP ?      | SUBI      Stk[l] = l - 210
  [1112] OP ?      | (op ?: classes V=5 q=0 K=5 e=42 g=0)
  [1113] OP ?      | ADDI      Stk[l] = l + 444
  [1114] OP ?      | SETREG2   v[l] = 498
  [1115] OP ?      | ADD       Stk[l] = l + 403
  [1116] OP ?      | ADDI      Stk[l] = l + 280
  [1117] OP ?      | (op ?: classes V=5 q=5 K=5 e=81 g=0)
  [1118] OP ?      | (op ?: classes V=5 q=0 K=5 e=318 g=0)
  [1119] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=80)
  [1120] OP ?      | GETTABUP  Stk[l] = env['K[80]']
  [1121] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [1122] OP ?      | ADDI      Stk[l] = l + 18
  [1123] OP ?      | ADD       Stk[l] = l + 29
  [1124] OP ?      | SUBI      Stk[l] = l - 126
  [1125] OP ?      | ADD       Stk[l] = l + 28
  [1126] OP ?      | SUBI      Stk[l] = l - 266
  [1127] OP ?      | ADDI      Stk[l] = l + 467
  [1128] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1129] OP ?      | (op ?: classes V=5 q=0 K=5 e=167 g=0)
  [1130] OP ?      | SUBI      Stk[l] = l - 161
  [1131] OP ?      | (op ?: classes V=5 q=5 K=5 e=307 g=482)
  [1132] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1133] OP ?      | SUBI      Stk[l] = l - 181
  [1134] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [1135] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=97)
  [1136] OP ?      | GETTABUP  Stk[l] = env['K[104]'] ; CALL      hD(...)
  [1137] OP ?      | SUBI      Stk[l] = l - 449
  [1138] OP ?      | ADDI      Stk[l] = l + 225
  [1139] OP ?      | (op ?: classes V=5 q=0 K=4 e=562 g=468)
  [1140] OP ?      | ADDI      Stk[l] = l + 491
  [1141] OP ?      | SUBI      Stk[l] = l - 485
  [1142] OP ?      | ADD       Stk[l] = l + 93
  [1143] OP ?      | SUBI      Stk[l] = l - 271
  [1144] OP ?      | (op ?: classes V=5 q=0 K=5 e=222 g=0)
  [1145] OP ?      | ADDI      Stk[l] = l + 310
  [1146] OP ?      | SETREG    Stk[l] = 371
  [1147] OP ?      | SUBI      Stk[l] = l - 342
  [1148] OP ?      | SETREG    Stk[l] = 1 ; CALL      hD(...)
  [1149] OP ?      | SETREG    Stk[l] = 561
  [1150] OP ?      | SETREG    Stk[l] = 523 ; CALL      hD(...)
  [1151] OP ?      | SUBI      Stk[l] = l - 159
  [1152] OP ?      | SETREG2   v[l] = 158
  [1153] OP ?      | ADDI      Stk[l] = l + 708
  [1154] OP ?      | (op ?: classes V=5 q=5 K=5 e=75 g=81)
  [1155] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=81)
  [1156] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=82)
  [1157] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1158] OP ?      | ADDI      Stk[l] = l + 128
  [1159] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1160] OP ?      | (op ?: classes V=5 q=5 K=5 e=19 g=74)
  [1161] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1162] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1163] OP ?      | (op ?: classes V=5 q=5 K=5 e=10 g=74)
  [1164] OP ?      | ADDI      Stk[l] = l + 641
  [1165] OP ?      | CALL      hD(...)
  [1166] OP ?      | (op ?: classes V=5 q=5 K=5 e=111 g=21)
  [1167] OP ?      | (op ?: classes V=5 q=5 K=5 e=140 g=162)
  [1168] OP ?      | (op ?: classes V=5 q=5 K=5 e=181 g=5)
  [1169] OP ?      | (op ?: classes V=5 q=5 K=5 e=122 g=138)
  [1170] OP ?      | (op ?: classes V=5 q=5 K=5 e=23 g=146)
  [1171] OP ?      | (op ?: classes V=5 q=5 K=5 e=253 g=138)
  [1172] OP ?      | CALL      hD(...)
  [1173] OP ?      | (op ?: classes V=5 q=5 K=5 e=23 g=18)
  [1174] OP ?      | CALL      hD(...)
  [1175] OP ?      | SETREG    Stk[l] = 280
  [1176] OP ?      | SETREG    Stk[l] = 293 ; CALL      hD(...)
  [1177] OP ?      | SUBI      Stk[l] = l - 514
  [1178] OP ?      | CALL      hD(...)
  [1179] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=2)
  [1180] OP ?      | SETREG    Stk[l] = 5
  [1181] OP ?      | ADDI      Stk[l] = l + 291
  [1182] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1183] OP ?      | (op ?: classes V=5 q=5 K=5 e=70 g=74)
  [1184] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1185] OP ?      | SUBI      Stk[l] = l - 418
  [1186] OP ?      | (op ?: classes V=5 q=5 K=2 e=55 g=1)
  [1187] OP ?      | (op ?: classes V=5 q=0 K=5 e=401 g=0)
  [1188] OP ?      | SUBI      Stk[l] = l - 332
  [1189] OP ?      | (op ?: classes V=5 q=5 K=5 e=78 g=77)
  [1190] OP ?      | (op ?: classes V=5 q=0 K=5 e=38 g=0)
  [1191] OP ?      | SUBI      Stk[l] = l - 456
  [1192] OP ?      | ADDI      Stk[l] = l + 437
  [1193] OP ?      | (op ?: classes V=5 q=0 K=1 e=334 g=286)
  [1194] OP ?      | SETREG    Stk[l] = 152
  [1195] OP ?      | (op ?: classes V=5 q=5 K=5 e=45 g=85)
  [1196] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1197] OP ?      | ADDI      Stk[l] = l + 31
  [1198] OP ?      | SETREG    Stk[l] = 555
  [1199] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [1200] OP ?      | (op ?: classes V=5 q=5 K=5 e=46 g=72)
  [1201] OP ?      | (op ?: classes V=5 q=0 K=5 e=444 g=0)
  [1202] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1203] OP ?      | SUBI      Stk[l] = l - 212
  [1204] OP ?      | ADDI      Stk[l] = l + 5 ; CALL      hD(...)
  [1205] OP ?      | SETREG    Stk[l] = 264
  [1206] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1207] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=73)
  [1208] OP ?      | (op ?: classes V=5 q=0 K=5 e=134 g=0)
  [1209] OP ?      | SUBI      Stk[l] = l - 110
  [1210] OP ?      | SUBI      Stk[l] = l - 7 ; CALL      hD(...)
  [1211] OP ?      | ADDI      Stk[l] = l + 215
  [1212] OP ?      | (op ?: classes V=5 q=5 K=5 e=44 g=83)
  [1213] OP ?      | (op ?: classes V=5 q=5 K=5 e=10 g=84)
  [1214] OP ?      | CALL      hD(...)
  [1215] OP ?      | (op ?: classes V=5 q=5 K=5 e=3 g=83)
  [1216] OP ?      | (op ?: classes V=5 q=5 K=5 e=83 g=77)
  [1217] OP ?      | (op ?: classes V=5 q=5 K=5 e=84 g=78)
  [1218] OP ?      | ADDI      Stk[l] = l + 342
  [1219] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=99)
  [1220] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [1221] OP ?      | (op ?: classes V=5 q=5 K=5 e=104 g=87)
  [1222] OP ?      | GETTABUP  Stk[l] = env['K[205]'] ; CALL      hD(...)
  [1223] OP ?      | (op ?: classes V=5 q=5 K=5 e=97 g=106)
  [1224] OP ?      | ADDI      Stk[l] = l + 354
  [1225] OP ?      | SUBI      Stk[l] = l - 424
  [1226] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1227] OP ?      | (op ?: classes V=5 q=0 K=5 e=185 g=0)
  [1228] OP ?      | SUBI      Stk[l] = l - 436
  [1229] OP ?      | (op ?: classes V=5 q=0 K=5 e=124 g=0)
  [1230] OP ?      | SUBI      Stk[l] = l - 157
  [1231] OP ?      | CALL      hD(...)
  [1232] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [1233] OP ?      | (op ?: classes V=5 q=5 K=5 e=29 g=70)
  [1234] OP ?      | (op ?: classes V=5 q=0 K=5 e=404 g=0)
  [1235] OP ?      | SUBI      Stk[l] = l - 372
  [1236] OP ?      | CALL      hD(...)
  [1237] OP ?      | (op ?: classes V=5 q=5 K=5 e=12 g=5)
  [1238] OP ?      | SETREG    Stk[l] = 242
  [1239] OP ?      | LOADN     Stk[l] = 2
  [1240] OP ?      | ADDI      Stk[l] = l + 505
  [1241] OP ?      | (op ?: classes V=5 q=0 K=5 e=171 g=0)
  [1242] OP ?      | SETREG    Stk[l] = 299
  [1243] OP ?      | (op ?: classes V=5 q=0 K=4 e=125 g=230)
  [1244] OP ?      | ADDI      Stk[l] = l + 250
  [1245] OP ?      | (op ?: classes V=5 q=0 K=1 e=385 g=340)
  [1246] OP ?      | ADDI      Stk[l] = l + 618
  [1247] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1248] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=4)
  [1249] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=78)
  [1250] OP ?      | SUBI      Stk[l] = l - 62
  [1251] OP ?      | ADDI      Stk[l] = l + 191
  [1252] OP ?      | SETREG    Stk[l] = 588 ; CALL      hD(...)
  [1253] OP ?      | ADDI      Stk[l] = l + 283
  [1254] OP ?      | (op ?: classes V=5 q=5 K=5 e=45 g=85)
  [1255] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1256] OP ?      | ADDI      Stk[l] = l + 97
  [1257] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [1258] OP ?      | (op ?: classes V=5 q=5 K=5 e=20 g=70)
  [1259] OP ?      | CALL      hD(...)
  [1260] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1261] OP ?      | ADDI      Stk[l] = l + 266
  [1262] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=3)
  [1263] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1264] OP ?      | SETREG    Stk[l] = 14
  [1265] OP ?      | SETREG    Stk[l] = 115
  [1266] OP ?      | SETREG    Stk[l] = 415 ; CALL      hD(...)
  [1267] OP ?      | SUBI      Stk[l] = l - 521
  [1268] OP ?      | LOADN     Stk[l] = 0
  [1269] OP ?      | ADDI      Stk[l] = l + 293
  [1270] OP ?      | (op ?: classes V=5 q=0 K=1 e=22 g=97)
  [1271] OP ?      | ADDI      Stk[l] = l + 597
  [1272] OP ?      | (op ?: classes V=5 q=5 K=5 e=55 g=87)
  [1273] OP ?      | CALL      hD(...)
  [1274] OP ?      | (op ?: classes V=5 q=5 K=5 e=30 g=89)
  [1275] OP ?      | SUBI      Stk[l] = l - 304
  [1276] OP ?      | LOADN     Stk[l] = 1
  [1277] OP ?      | SUBI      Stk[l] = l - 169
  [1278] OP ?      | SUBI      Stk[l] = l - 13 ; CALL      hD(...)
  [1279] OP ?      | SETREG    Stk[l] = 24
  [1280] OP ?      | CALL      hD(...)
  [1281] OP ?      | CALL      hD(...)
  [1282] OP ?      | CALL      hD(...)
  [1283] OP ?      | CALL      hD(...)
  [1284] OP ?      | SUBI      Stk[l] = l - 458
  [1285] OP ?      | CALL      hD(...)
  [1286] OP ?      | SETREG    Stk[l] = 511
  [1287] OP ?      | SUBI      Stk[l] = l - 154
  [1288] OP ?      | ADDI      Stk[l] = l + 204 ; CALL      hD(...)
  [1289] OP ?      | ADDI      Stk[l] = l + 255
  [1290] OP ?      | (op ?: classes V=5 q=0 K=5 e=656 g=0)
  [1291] OP ?      | (op ?: classes V=5 q=0 K=5 e=111 g=0)
  [1292] OP ?      | ADDI      Stk[l] = l + 22
  [1293] OP ?      | SETREG2   v[l] = 273
  [1294] OP ?      | SETREG    Stk[l] = 39
  [1295] OP ?      | CALL      hD(...)
  [1296] OP ?      | (op ?: classes V=5 q=5 K=2 e=50 g=19)
  [1297] OP ?      | CALL      hD(...)
  [1298] OP ?      | SETREG    Stk[l] = 219
  [1299] OP ?      | SETREG    Stk[l] = 568
  [1300] OP ?      | (op ?: classes V=5 q=5 K=1 e=79 g=317)
  [1301] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [1302] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=107)
  [1303] OP ?      | GETTABUP  Stk[l] = env['K[632]']
  [1304] OP ?      | GETTABUP  Stk[l] = env['K[566]']
  [1305] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [1306] OP ?      | SUBI      Stk[l] = l - 14
  [1307] OP ?      | ADD       Stk[l] = l + 15
  [1308] OP ?      | ADDI      Stk[l] = l + 398
  [1309] OP ?      | ADDI      Stk[l] = l + 255
  [1310] OP ?      | ADDI      Stk[l] = l + 59
  [1311] OP ?      | (op ?: classes V=5 q=5 K=5 e=2 g=85)
  [1312] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=85)
  [1313] OP ?      | (op ?: classes V=5 q=5 K=5 e=86 g=87)
  [1314] OP ?      | SUBI      Stk[l] = l - 604
  [1315] OP ?      | SETREG2   v[l] = 413
  [1316] OP ?      | SETREG    Stk[l] = 358
  [1317] OP ?      | CALL      hD(...)
  [1318] OP ?      | (op ?: classes V=5 q=5 K=5 e=82 g=81)
  [1319] OP ?      | ADDI      Stk[l] = l + 285
  [1320] OP ?      | ADDI      Stk[l] = l + 352
  [1321] OP ?      | ADDI      Stk[l] = l + 134
  [1322] OP ?      | (op ?: classes V=5 q=5 K=5 e=80 g=71)
  [1323] OP ?      | (op ?: classes V=5 q=5 K=5 e=67 g=135)
  [1324] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=147)
  [1325] OP ?      | (op ?: classes V=5 q=5 K=5 e=54 g=225)
  [1326] OP ?      | (op ?: classes V=5 q=5 K=5 e=137 g=88)
  [1327] OP ?      | (op ?: classes V=5 q=5 K=5 e=34 g=72)
  [1328] OP ?      | CALL      hD(...)
  [1329] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1330] OP ?      | (op ?: classes V=5 q=0 K=5 e=245 g=0)
  [1331] OP ?      | ADDI      Stk[l] = l + 124
  [1332] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1333] OP ?      | (op ?: classes V=5 q=0 K=5 e=87 g=0)
  [1334] OP ?      | ADDI      Stk[l] = l + 198
  [1335] OP ?      | (op ?: classes V=5 q=5 K=5 e=77 g=80)
  [1336] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=80)
  [1337] OP ?      | (op ?: classes V=5 q=0 K=4 e=578 g=31)
  [1338] OP ?      | SUBI      Stk[l] = l - 244
  [1339] OP ?      | (op ?: classes V=5 q=0 K=5 e=690 g=0)
  [1340] OP ?      | SUBI      Stk[l] = l - 291
  [1341] OP ?      | (op ?: classes V=5 q=5 K=5 e=77 g=0)
  [1342] OP ?      | CALL      hD(...)
  [1343] OP ?      | (op ?: classes V=5 q=0 K=5 e=534 g=0)
  [1344] OP ?      | (op ?: classes V=5 q=0 K=5 e=424 g=0)
  [1345] OP ?      | (op ?: classes V=5 q=0 K=5 e=100 g=0)
  [1346] OP ?      | (op ?: classes V=5 q=5 K=1 e=79 g=214)
  [1347] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1348] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=67)
  [1349] OP ?      | (op ?: classes V=5 q=5 K=5 e=27 g=68)
  [1350] OP ?      | CALL      hD(...)
  [1351] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1352] OP ?      | CALL      hD(...)
  [1353] OP ?      | SETREG    Stk[l] = 270
  [1354] OP ?      | (op ?: classes V=5 q=0 K=5 e=387 g=0)
  [1355] OP ?      | ADDI      Stk[l] = l + 419
  [1356] OP ?      | SETREG    Stk[l] = 500 ; CALL      hD(...)
  [1357] OP ?      | ADDI      Stk[l] = l + 251
  [1358] OP ?      | SUBI      Stk[l] = l - 58
  [1359] OP ?      | ADDI      Stk[l] = l + 456
  [1360] OP ?      | (op ?: classes V=5 q=0 K=5 e=555 g=0)
  [1361] OP ?      | SUBI      Stk[l] = l - 622
  [1362] OP ?      | GETTABUP  Stk[l] = env['band']
  [1363] OP ?      | SUBI      Stk[l] = l - 42
  [1364] OP ?      | (op ?: classes V=5 q=0 K=5 e=634 g=0)
  [1365] OP ?      | SUBI      Stk[l] = l - 677
  [1366] OP ?      | SUBI      Stk[l] = l - 353
  [1367] OP ?      | ADDI      Stk[l] = l + 11
  [1368] OP ?      | LOADN     Stk[l] = 22
  [1369] OP ?      | SUBI      Stk[l] = l - 231
  [1370] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=97)
  [1371] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [1372] OP ?      | GETTABUP  Stk[l] = env['K[147]']
  [1373] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1374] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1375] OP ?      | GETTABUP  Stk[l] = env['K[97]']
  [1376] OP ?      | GETTABUP  Stk[l] = env['K[472]']
  [1377] OP ?      | (op ?: classes V=5 q=5 K=5 e=96 g=105)
  [1378] OP ?      | SETREG    Stk[l] = 77
  [1379] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=98)
  [1380] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [1381] OP ?      | GETTABUP  Stk[l] = env['K[198]']
  [1382] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1383] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1384] OP ?      | GETTABUP  Stk[l] = env['K[98]']
  [1385] OP ?      | GETTABUP  Stk[l] = env['K[250]']
  [1386] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1387] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1388] OP ?      | GETTABUP  Stk[l] = env['K[100]']
  [1389] OP ?      | GETTABUP  Stk[l] = env['K[154]']
  [1390] OP ?      | (op ?: classes V=5 q=5 K=5 e=96 g=105)
  [1391] OP ?      | ADDI      Stk[l] = l + 446
  [1392] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [1393] OP ?      | (op ?: classes V=5 q=5 K=5 e=51 g=70)
  [1394] OP ?      | (op ?: classes V=5 q=0 K=5 e=260 g=0)
  [1395] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1396] OP ?      | ADDI      Stk[l] = l + 403
  [1397] OP ?      | (op ?: classes V=5 q=0 K=1 e=515 g=124)
  [1398] OP ?      | SUBI      Stk[l] = l - 328
  [1399] OP ?      | CALL      hD(...)
  [1400] OP ?      | (op ?: classes V=5 q=0 K=5 e=222 g=0)
  [1401] OP ?      | SUBI      Stk[l] = l - 500
  [1402] OP ?      | LOADN     Stk[l] = 36
  [1403] OP ?      | SUBI      Stk[l] = l - 609
  [1404] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1405] OP ?      | (op ?: classes V=5 q=5 K=5 e=67 g=64)
  [1406] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1407] OP ?      | CALL      hD(...)
  [1408] OP ?      | CALL      hD(...)
  [1409] OP ?      | (op ?: classes V=5 q=5 K=5 e=67 g=68)
  [1410] OP ?      | CALL      hD(...)
  [1411] OP ?      | CALL      hD(...)
  [1412] OP ?      | ADDI      Stk[l] = l + 186
  [1413] OP ?      | GETTABUP  Stk[l] = env['K[228]'] ; SUBI      Stk[l] = l - 228
  [1414] OP ?      | SETREG    Stk[l] = 104
  [1415] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1416] OP ?      | ADDI      Stk[l] = l + 88
  [1417] OP ?      | ADDI      Stk[l] = l + 154 ; CALL      hD(...)
  [1418] OP ?      | SETREG    Stk[l] = 11
  [1419] OP ?      | SETTABUP  Stk[string] = ...
  [1420] OP ?      | SUBI      Stk[l] = l - 430
  [1421] OP ?      | SETTABUP  Stk[89] = ...
  [1422] OP ?      | SETREG    Stk[l] = 107
  [1423] OP ?      | (op ?: classes V=5 q=5 K=5 e=88 g=80)
  [1424] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=81)
  [1425] OP ?      | (op ?: classes V=5 q=5 K=5 e=44 g=88)
  [1426] OP ?      | ADDI      Stk[l] = l + 126
  [1427] OP ?      | ADDI      Stk[l] = l + 452
  [1428] OP ?      | SUBI      Stk[l] = l - 405 ; CALL      hD(...)
  [1429] OP ?      | SETREG    Stk[l] = 189
  [1430] OP ?      | (op ?: classes V=5 q=0 K=5 e=440 g=0)
  [1431] OP ?      | SETREG    Stk[l] = 64
  [1432] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1433] OP ?      | CALL      hD(...)
  [1434] OP ?      | CALL      hD(...)
  [1435] OP ?      | (op ?: classes V=5 q=0 K=5 e=663 g=0)
  [1436] OP ?      | SUBI      Stk[l] = l - 448
  [1437] OP ?      | SETREG    Stk[l] = 643
  [1438] OP ?      | (op ?: classes V=5 q=5 K=5 e=249 g=180)
  [1439] OP ?      | (op ?: classes V=5 q=5 K=5 e=232 g=202)
  [1440] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=250)
  [1441] OP ?      | CALL      hD(...)
  [1442] OP ?      | SETREG    Stk[l] = 424
  [1443] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=93)
  [1444] OP ?      | (op ?: classes V=5 q=5 K=5 e=88 g=94)
  [1445] OP ?      | (op ?: classes V=5 q=5 K=5 e=86 g=95)
  [1446] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1447] OP ?      | (op ?: classes V=5 q=5 K=5 e=86 g=69)
  [1448] OP ?      | SETREG    Stk[l] = 485
  [1449] OP ?      | ADDI      Stk[l] = l + 101 ; CALL      hD(...)
  [1450] OP ?      | SETREG    Stk[l] = 83
  [1451] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1452] OP ?      | (op ?: classes V=5 q=5 K=5 e=7 g=74)
  [1453] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1454] OP ?      | (op ?: classes V=5 q=0 K=5 e=442 g=0)
  [1455] OP ?      | ADDI      Stk[l] = l + 95
  [1456] OP ?      | ADD       Stk[l] = l + 4 ; CALL      hD(...)
  [1457] OP ?      | SETREG    Stk[l] = 210
  [1458] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1459] OP ?      | (op ?: classes V=5 q=5 K=5 e=12 g=74)
  [1460] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1461] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1462] OP ?      | SETREG    Stk[l] = 246
  [1463] OP ?      | SUBI      Stk[l] = l - 110
  [1464] OP ?      | SUBI      Stk[l] = l - 211
  [1465] OP ?      | CALL      hD(...)
  [1466] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=70)
  [1467] OP ?      | (op ?: classes V=5 q=5 K=5 e=21 g=71)
  [1468] OP ?      | SUBI      Stk[l] = l - 690
  [1469] OP ?      | SETTABUP  Stk[lrotate] = ...
  [1470] OP ?      | SETREG    Stk[l] = 95
  [1471] OP ?      | SETREG2   v[l] = 169
  [1472] OP ?      | SUBI      Stk[l] = l - 141
  [1473] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=93)
  [1474] OP ?      | (op ?: classes V=5 q=5 K=5 e=87 g=94)
  [1475] OP ?      | (op ?: classes V=5 q=5 K=5 e=88 g=95)
  [1476] OP ?      | SETREG    Stk[l] = 496
  [1477] OP ?      | CALL      hD(...)
  [1478] OP ?      | (op ?: classes V=5 q=0 K=5 e=175 g=0)
  [1479] OP ?      | SETREG    Stk[l] = 735
  [1480] OP ?      | ADD       Stk[l] = l + 67
  [1481] OP ?      | SETREG    Stk[l] = 387
  [1482] OP ?      | SUBI      Stk[l] = l - 513
  [1483] OP ?      | SETREG    Stk[l] = 257
  [1484] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1485] OP ?      | (op ?: classes V=5 q=0 K=5 e=567 g=0)
  [1486] OP ?      | ADDI      Stk[l] = l + 257
  [1487] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1488] OP ?      | (op ?: classes V=5 q=5 K=5 e=46 g=74)
  [1489] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1490] OP ?      | CALL      hD(...)
  [1491] OP ?      | CALL      hD(...)
  [1492] OP ?      | SETREG    Stk[l] = 487
  [1493] OP ?      | SUBI      Stk[l] = l - 346 ; CALL      hD(...)
  [1494] OP ?      | SETREG    Stk[l] = 673
  [1495] OP ?      | CALL      hD(...)
  [1496] OP ?      | (op ?: classes V=5 q=5 K=5 e=19 g=5)
  [1497] OP ?      | CALL      hD(...)
  [1498] OP ?      | CALL      hD(...)
  [1499] OP ?      | SETREG    Stk[l] = 275
  [1500] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1501] OP ?      | (op ?: classes V=5 q=5 K=5 e=51 g=74)
  [1502] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1503] OP ?      | (op ?: classes V=5 q=0 K=5 e=65 g=0)
  [1504] OP ?      | ADDI      Stk[l] = l + 269
  [1505] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [1506] OP ?      | (op ?: classes V=5 q=5 K=5 e=23 g=72)
  [1507] OP ?      | CALL      hD(...)
  [1508] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1509] OP ?      | SUBI      Stk[l] = l - 366
  [1510] OP ?      | LOADN     Stk[l] = 77
  [1511] OP ?      | SUBI      Stk[l] = l - 366
  [1512] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [1513] OP ?      | (op ?: classes V=5 q=5 K=5 e=25 g=72)
  [1514] OP ?      | CALL      hD(...)
  [1515] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1516] OP ?      | (op ?: classes V=5 q=0 K=5 e=49 g=0)
  [1517] OP ?      | SUBI      Stk[l] = l - 62
  [1518] OP ?      | (op ?: classes V=5 q=5 K=5 e=177 g=144)
  [1519] OP ?      | (op ?: classes V=5 q=5 K=5 e=32 g=74)
  [1520] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1521] OP ?      | SETREG    Stk[l] = 386
  [1522] OP ?      | SETREG    Stk[l] = 683
  [1523] OP ?      | CALL      hD(...)
  [1524] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=0)
  [1525] OP ?      | CALL      hD(...)
  [1526] OP ?      | (op ?: classes V=5 q=5 K=5 e=60 g=0)
  [1527] OP ?      | SETREG    Stk[l] = 391
  [1528] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [1529] OP ?      | (op ?: classes V=5 q=5 K=5 e=19 g=70)
  [1530] OP ?      | CALL      hD(...)
  [1531] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1532] OP ?      | SUBI      Stk[l] = l - 173
  [1533] OP ?      | SUBI      Stk[l] = l - 282 ; CALL      hD(...)
  [1534] OP ?      | SUBI      Stk[l] = l - 357
  [1535] OP ?      | ADD       Stk[l] = l + 68
  [1536] OP ?      | SETREG    Stk[l] = 725
  [1537] OP ?      | (op ?: classes V=5 q=5 K=5 e=75 g=80)
  [1538] OP ?      | (op ?: classes V=5 q=5 K=5 e=81 g=82)
  [1539] OP ?      | SUBI      Stk[l] = l - 69
  [1540] OP ?      | ADD       Stk[l] = l + 0
  [1541] OP ?      | SUBI      Stk[l] = l - 350
  [1542] OP ?      | SETREG    Stk[l] = 249
  [1543] OP ?      | ADD       Stk[l] = l + 18
  [1544] OP ?      | SETREG    Stk[l] = 363
  [1545] OP ?      | (op ?: classes V=5 q=5 K=2 e=66 g=18)
  [1546] OP ?      | SETREG    Stk[l] = 324
  [1547] OP ?      | SETREG    Stk[l] = 593 ; CALL      hD(...)
  [1548] OP ?      | ADDI      Stk[l] = l + 72
  [1549] OP ?      | (op ?: classes V=5 q=0 K=5 e=409 g=0)
  [1550] OP ?      | ADDI      Stk[l] = l + 193
  [1551] OP ?      | SETREG    Stk[l] = 212 ; CALL      hD(...)
  [1552] OP ?      | SUBI      Stk[l] = l - 95
  [1553] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=7)
  [1554] OP ?      | (op ?: classes V=5 q=5 K=5 e=2 g=88)
  [1555] OP ?      | (op ?: classes V=5 q=5 K=5 e=88 g=82)
  [1556] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=83)
  [1557] OP ?      | ADDI      Stk[l] = l + 249
  [1558] OP ?      | (op ?: classes V=5 q=0 K=1 e=34 g=201)
  [1559] OP ?      | SETREG    Stk[l] = 174
  [1560] OP ?      | SETREG    Stk[l] = 129
  [1561] OP ?      | LOADN     Stk[l] = 0
  [1562] OP ?      | SUBI      Stk[l] = l - 517
  [1563] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1564] OP ?      | SUBI      Stk[l] = l - 582
  [1565] OP ?      | CALL      hD(...)
  [1566] OP ?      | CALL      hD(...)
  [1567] OP ?      | CALL      hD(...)
  [1568] OP ?      | CALL      hD(...)
  [1569] OP ?      | CALL      hD(...)
  [1570] OP ?      | CALL      hD(...)
  [1571] OP ?      | ADDI      Stk[l] = l + 298
  [1572] OP ?      | SETREG    Stk[l] = 377 ; CALL      hD(...)
  [1573] OP ?      | SUBI      Stk[l] = l - 235
  [1574] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1575] OP ?      | SETREG    Stk[l] = 70
  [1576] OP ?      | SUBI      Stk[l] = l - 539
  [1577] OP ?      | SETREG    Stk[l] = 75 ; CALL      hD(...)
  [1578] OP ?      | SETREG    Stk[l] = 595
  [1579] OP ?      | ADD       Stk[l] = l + 104
  [1580] OP ?      | SUBI      Stk[l] = l - 613
  [1581] OP ?      | SUBI      Stk[l] = l - 287
  [1582] OP ?      | (op ?: classes V=5 q=0 K=5 e=518 g=0)
  [1583] OP ?      | SUBI      Stk[l] = l - 469
  [1584] OP ?      | CALL      hD(...)
  [1585] OP ?      | ADDI      Stk[l] = l + 19
  [1586] OP ?      | (op ?: classes V=5 q=0 K=1 e=58 g=72)
  [1587] OP ?      | SUBI      Stk[l] = l - 323
  [1588] OP ?      | (op ?: classes V=5 q=0 K=4 e=67 g=619)
  [1589] OP ?      | ADDI      Stk[l] = l + 71
  [1590] OP ?      | CALL      hD(...)
  [1591] OP ?      | (op ?: classes V=5 q=0 K=5 e=13 g=0)
  [1592] OP ?      | SUBI      Stk[l] = l - 736
  [1593] OP ?      | (op ?: classes V=5 q=0 K=4 e=43 g=471)
  [1594] OP ?      | SETREG    Stk[l] = 695
  [1595] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1596] OP ?      | (op ?: classes V=5 q=5 K=5 e=17 g=74)
  [1597] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1598] OP ?      | SETREG    Stk[l] = 786
  [1599] OP ?      | (op ?: classes V=5 q=5 K=5 e=67 g=68)
  [1600] OP ?      | CALL      hD(...)
  [1601] OP ?      | CALL      hD(...)
  [1602] OP ?      | (op ?: classes V=5 q=5 K=5 e=67 g=68)
  [1603] OP ?      | CALL      hD(...)
  [1604] OP ?      | SUBI      Stk[l] = l - 688
  [1605] OP ?      | LOADN     Stk[l] = 81
  [1606] OP ?      | SUBI      Stk[l] = l - 169
  [1607] OP ?      | SETTABUP  Stk[118] = ...
  [1608] OP ?      | SUBI      Stk[l] = l - 319
  [1609] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1610] OP ?      | (op ?: classes V=5 q=5 K=5 e=21 g=74)
  [1611] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1612] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1613] OP ?      | (op ?: classes V=5 q=5 K=5 e=6 g=74)
  [1614] OP ?      | SETREG    Stk[l] = 509
  [1615] OP ?      | SUBI      Stk[l] = l - 199 ; CALL      hD(...)
  [1616] OP ?      | SETREG    Stk[l] = 481
  [1617] OP ?      | SETREG    Stk[l] = 475
  [1618] OP ?      | LOADN     Stk[l] = 0
  [1619] OP ?      | SETREG    Stk[l] = 654
  [1620] OP ?      | SETREG    Stk[l] = 456
  [1621] OP ?      | SETREG    Stk[l] = 544
  [1622] OP ?      | (op ?: classes V=5 q=0 K=5 e=322 g=0)
  [1623] OP ?      | SUBI      Stk[l] = l - 337
  [1624] OP ?      | (op ?: classes V=5 q=0 K=5 e=530 g=83)
  [1625] OP ?      | (op ?: classes V=5 q=5 K=5 e=43 g=83)
  [1626] OP ?      | GETTABUP  Stk[l] = env['setfenv']
  [1627] OP ?      | SUBI      Stk[l] = l - 645
  [1628] OP ?      | ADD       Stk[l] = l + 78 ; CALL      hD(...)
  [1629] OP ?      | SUBI      Stk[l] = l - 539
  [1630] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1631] OP ?      | ADDI      Stk[l] = l + 235
  [1632] OP ?      | CALL      hD(...)
  [1633] OP ?      | CALL      hD(...)
  [1634] OP ?      | (op ?: classes V=5 q=5 K=5 e=34 g=18)
  [1635] OP ?      | SUBI      Stk[l] = l - 54
  [1636] OP ?      | SUBI      Stk[l] = l - 754
  [1637] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1638] OP ?      | (op ?: classes V=5 q=5 K=5 e=26 g=74)
  [1639] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1640] OP ?      | (op ?: classes V=5 q=5 K=5 e=72 g=73)
  [1641] OP ?      | (op ?: classes V=5 q=5 K=5 e=40 g=74)
  [1642] OP ?      | ADDI      Stk[l] = l + 202
  [1643] OP ?      | CALL      hD(...)
  [1644] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=84)
  [1645] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=82)
  [1646] OP ?      | CALL      hD(...)
  [1647] OP ?      | (op ?: classes V=5 q=5 K=5 e=83 g=82)
  [1648] OP ?      | SUBI      Stk[l] = l - 532
  [1649] OP ?      | CALL      hD(...)
  [1650] OP ?      | (op ?: classes V=5 q=5 K=5 e=33 g=250)
  [1651] OP ?      | (op ?: classes V=5 q=5 K=5 e=37 g=63)
  [1652] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=18)
  [1653] OP ?      | (op ?: classes V=5 q=5 K=5 e=57 g=26)
  [1654] OP ?      | (op ?: classes V=5 q=5 K=5 e=39 g=22)
  [1655] OP ?      | (op ?: classes V=5 q=5 K=5 e=116 g=150)
  [1656] OP ?      | CALL      hD(...)
  [1657] OP ?      | (op ?: classes V=5 q=5 K=5 e=39 g=18)
  [1658] OP ?      | SETREG    Stk[l] = 650
  [1659] OP ?      | SETTABUP  Stk[112] = ...
  [1660] OP ?      | SUBI      Stk[l] = l - 757
  [1661] OP ?      | SETREG    Stk[l] = 214
  [1662] OP ?      | SETTABUP  Stk[band] = ... ; CALL      hD(...)
  [1663] OP ?      | SETREG    Stk[l] = 439
  [1664] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=80)
  [1665] OP ?      | (op ?: classes V=5 q=5 K=5 e=75 g=81)
  [1666] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=81)
  [1667] OP ?      | (op ?: classes V=5 q=5 K=5 e=74 g=82)
  [1668] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1669] OP ?      | SUBI      Stk[l] = l - 383
  [1670] OP ?      | (op ?: classes V=5 q=5 K=2 e=58 g=30)
  [1671] OP ?      | (op ?: classes V=5 q=0 K=5 e=687 g=0)
  [1672] OP ?      | SUBI      Stk[l] = l - 816
  [1673] OP ?      | SUBI      Stk[l] = l - 90
  [1674] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [1675] OP ?      | (op ?: classes V=5 q=5 K=5 e=3 g=70)
  [1676] OP ?      | CALL      hD(...)
  [1677] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1678] OP ?      | (op ?: classes V=5 q=0 K=5 e=116 g=0)
  [1679] OP ?      | SETREG    Stk[l] = 739
  [1680] OP ?      | SUBI      Stk[l] = l - 393
  [1681] OP ?      | CALL      hD(...)
  [1682] OP ?      | SUBI      Stk[l] = l - 582
  [1683] OP ?      | (op ?: classes V=5 q=0 K=5 e=27 g=0)
  [1684] OP ?      | SUBI      Stk[l] = l - 138
  [1685] OP ?      | (op ?: classes V=5 q=0 K=5 e=108 g=0)
  [1686] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1687] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [1688] OP ?      | GETTABUP  Stk[l] = env['K[309]']
  [1689] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [1690] OP ?      | SETREG    Stk[l] = 99
  [1691] OP ?      | GETTABUP  Stk[l] = env['K[309]']
  [1692] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [1693] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [1694] OP ?      | GETTABUP  Stk[l] = env['K[309]']
  [1695] OP ?      | GETTABUP  Stk[l] = env['K[85]']
  [1696] OP ?      | ADDI      Stk[l] = l + 181
  [1697] OP ?      | LOADN     Stk[l] = 10
  [1698] OP ?      | SUBI      Stk[l] = l - 679
  [1699] OP ?      | (op ?: classes V=5 q=0 K=5 e=506 g=0)
  [1700] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [1701] OP ?      | CALL      hD(...)
  [1702] OP ?      | CALL      hD(...)
  [1703] OP ?      | SUBI      Stk[l] = l - 424
  [1704] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1705] OP ?      | (op ?: classes V=5 q=0 K=5 e=63 g=0)
  [1706] OP ?      | SUBI      Stk[l] = l - 160
  [1707] OP ?      | ADDI      Stk[l] = l + 140
  [1708] OP ?      | (op ?: classes V=5 q=5 K=5 e=85 g=89)
  [1709] OP ?      | (op ?: classes V=5 q=5 K=5 e=83 g=90)
  [1710] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=0)
  [1711] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=88)
  [1712] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=89)
  [1713] OP ?      | (op ?: classes V=5 q=5 K=5 e=86 g=90)
  [1714] OP ?      | (op ?: classes V=5 q=5 K=5 e=87 g=91)
  [1715] OP ?      | SETREG    Stk[l] = 566
  [1716] OP ?      | SETREG    Stk[l] = 569
  [1717] OP ?      | SETREG    Stk[l] = 690
  [1718] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=67)
  [1719] OP ?      | (op ?: classes V=5 q=5 K=5 e=42 g=68)
  [1720] OP ?      | CALL      hD(...)
  [1721] OP ?      | SUBI      Stk[l] = l - 375
  [1722] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=107)
  [1723] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [1724] OP ?      | GETTABUP  Stk[l] = env['K[86]']
  [1725] OP ?      | GETTABUP  Stk[l] = env['K[588]']
  [1726] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [1727] OP ?      | SUBI      Stk[l] = l - 24
  [1728] OP ?      | SETTABUP  Stk[band] = ... ; CALL      hD(...)
  [1729] OP ?      | SETREG    Stk[l] = 333
  [1730] OP ?      | ADD       Stk[l] = l + 69
  [1731] OP ?      | SETREG    Stk[l] = 708
  [1732] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1733] OP ?      | CALL      hD(...)
  [1734] OP ?      | (op ?: classes V=5 q=0 K=5 e=137 g=0)
  [1735] OP ?      | SUBI      Stk[l] = l - 315
  [1736] OP ?      | CALL      hD(...)
  [1737] OP ?      | SUBI      Stk[l] = l - 421
  [1738] OP ?      | (op ?: classes V=5 q=5 K=5 e=83 g=198)
  [1739] OP ?      | (op ?: classes V=5 q=5 K=5 e=84 g=81)
  [1740] OP ?      | (op ?: classes V=5 q=0 K=5 e=497 g=0)
  [1741] OP ?      | SUBI      Stk[l] = l - 273
  [1742] OP ?      | SETTABUP  Stk[96] = ...
  [1743] OP ?      | SETREG    Stk[l] = 195
  [1744] OP ?      | SETTABUP  Stk[338] = ...
  [1745] OP ?      | SUBI      Stk[l] = l - 204
  [1746] OP ?      | GETTABUP  Stk[l] = env['K[157]'] ; SUBI      Stk[l] = l - 157
  [1747] OP ?      | SUBI      Stk[l] = l - 78
  [1748] OP ?      | GETTABUP  Stk[l] = env['find'] ; SETREG    Stk[l] = 16
  [1749] OP ?      | SETREG    Stk[l] = 78
  [1750] OP ?      | SUBI      Stk[l] = l - 204 ; CALL      hD(...)
  [1751] OP ?      | SETREG    Stk[l] = 298
  [1752] OP ?      | (op ?: classes V=5 q=5 K=2 e=60 g=5)
  [1753] OP ?      | CALL      hD(...)
  [1754] OP ?      | CALL      hD(...)
  [1755] OP ?      | CALL      hD(...)
  [1756] OP ?      | CALL      hD(...)
  [1757] OP ?      | CALL      hD(...)
  [1758] OP ?      | CALL      hD(...)
  [1759] OP ?      | SETREG    Stk[l] = 737
  [1760] OP ?      | LOADN     Stk[l] = 126
  [1761] OP ?      | SETREG    Stk[l] = 342
  [1762] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=71)
  [1763] OP ?      | (op ?: classes V=5 q=5 K=5 e=39 g=72)
  [1764] OP ?      | CALL      hD(...)
  [1765] OP ?      | SUBI      Stk[l] = l - 334
  [1766] OP ?      | (op ?: classes V=5 q=0 K=5 e=49 g=0)
  [1767] OP ?      | ADDI      Stk[l] = l + 7
  [1768] OP ?      | SETTABUP  Stk[bor] = ...
  [1769] OP ?      | SETREG    Stk[l] = 652
  [1770] OP ?      | (op ?: classes V=5 q=5 K=2 e=81 g=29)
  [1771] OP ?      | SUBI      Stk[l] = l - 303
  [1772] OP ?      | SETREG2   v[l] = 164
  [1773] OP ?      | SUBI      Stk[l] = l - 680
  [1774] OP ?      | SUBI      Stk[l] = l - 228
  [1775] OP ?      | SETTABUP  Stk[bit32] = ...
  [1776] OP ?      | SETREG    Stk[l] = 430
  [1777] OP ?      | (op ?: classes V=5 q=5 K=5 e=58 g=31)
  [1778] OP ?      | CALL      hD(...)
  [1779] OP ?      | (op ?: classes V=5 q=5 K=5 e=30 g=88)
  [1780] OP ?      | (op ?: classes V=5 q=5 K=5 e=89 g=85)
  [1781] OP ?      | (op ?: classes V=5 q=5 K=5 e=2 g=88)
  [1782] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1783] OP ?      | SUBI      Stk[l] = l - 586
  [1784] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1785] OP ?      | (op ?: classes V=5 q=5 K=5 e=69 g=67)
  [1786] OP ?      | (op ?: classes V=5 q=0 K=5 e=415 g=0)
  [1787] OP ?      | SETREG    Stk[l] = 739
  [1788] OP ?      | CALL      hD(...)
  [1789] OP ?      | CALL      hD(...)
  [1790] OP ?      | (op ?: classes V=5 q=5 K=5 e=83 g=82)
  [1791] OP ?      | (op ?: classes V=5 q=5 K=5 e=81 g=0)
  [1792] OP ?      | SETREG    Stk[l] = 477
  [1793] OP ?      | SETREG    Stk[l] = 354 ; CALL      hD(...)
  [1794] OP ?      | SETREG    Stk[l] = 580
  [1795] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [1796] OP ?      | (op ?: classes V=5 q=5 K=5 e=49 g=70)
  [1797] OP ?      | (op ?: classes V=5 q=0 K=5 e=706 g=0)
  [1798] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1799] OP ?      | SUBI      Stk[l] = l - 335
  [1800] OP ?      | (op ?: classes V=5 q=5 K=5 e=66 g=69)
  [1801] OP ?      | (op ?: classes V=5 q=5 K=5 e=2 g=70)
  [1802] OP ?      | CALL      hD(...)
  [1803] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1804] OP ?      | (op ?: classes V=5 q=0 K=5 e=541 g=0)
  [1805] OP ?      | SETREG    Stk[l] = 415
  [1806] OP ?      | SUBI      Stk[l] = l - 85
  [1807] OP ?      | SUBI      Stk[l] = l - 817
  [1808] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [1809] OP ?      | GETTABUP  Stk[l] = env['K[682]']
  [1810] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1811] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1812] OP ?      | GETTABUP  Stk[l] = env['K[100]']
  [1813] OP ?      | GETTABUP  Stk[l] = env['type']
  [1814] OP ?      | (op ?: classes V=5 q=5 K=5 e=96 g=105)
  [1815] OP ?      | SETREG    Stk[l] = 44
  [1816] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=108)
  [1817] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [1818] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=109)
  [1819] OP ?      | GETTABUP  Stk[l] = env['Luraph']
  [1820] OP ?      | GETTABUP  Stk[l] = env['K[89]']
  [1821] OP ?      | GETTABUP  Stk[l] = env['K[669]']
  [1822] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [1823] OP ?      | SETREG    Stk[l] = 435
  [1824] OP ?      | (op ?: classes V=5 q=5 K=5 e=10 g=39)
  [1825] OP ?      | CALL      hD(...)
  [1826] OP ?      | CALL      hD(...)
  [1827] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=39)
  [1828] OP ?      | (op ?: classes V=5 q=5 K=5 e=39 g=38)
  [1829] OP ?      | SETREG    Stk[l] = 584
  [1830] OP ?      | (op ?: classes V=5 q=0 K=5 e=19 g=0)
  [1831] OP ?      | (op ?: classes V=5 q=0 K=5 e=56 g=0)
  [1832] OP ?      | CALL      hD(...)
  [1833] OP ?      | CALL      hD(...)
  [1834] OP ?      | CALL      hD(...)
  [1835] OP ?      | SETREG    Stk[l] = 398
  [1836] OP ?      | (op ?: classes V=5 q=0 K=5 e=594 g=0)
  [1837] OP ?      | SUBI      Stk[l] = l - 291
  [1838] OP ?      | SUBI      Stk[l] = l - 321
  [1839] OP ?      | (op ?: classes V=5 q=5 K=5 e=110 g=0)
  [1840] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=109)
  [1841] OP ?      | GETTABUP  Stk[l] = env['K[89]']
  [1842] OP ?      | GETTABUP  Stk[l] = env['K[317]']
  [1843] OP ?      | (op ?: classes V=5 q=5 K=5 e=106 g=113)
  [1844] OP ?      | SETREG    Stk[l] = 712
  [1845] OP ?      | (op ?: classes V=5 q=5 K=5 e=73 g=0)
  [1846] OP ?      | (op ?: classes V=5 q=0 K=5 e=157 g=0)
  [1847] OP ?      | SETREG    Stk[l] = 792
  [1848] OP ?      | (op ?: classes V=5 q=5 K=5 e=44 g=88)
  [1849] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=6)
  [1850] OP ?      | (op ?: classes V=5 q=5 K=5 e=2 g=88)
  [1851] OP ?      | SUBI      Stk[l] = l - 429
  [1852] OP ?      | (op ?: classes V=5 q=5 K=5 e=426 g=509)
  [1853] OP ?      | SUBI      Stk[l] = l - 157
  [1854] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1855] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1856] OP ?      | GETTABUP  Stk[l] = env['K[99]']
  [1857] OP ?      | GETTABUP  Stk[l] = env['K[220]']
  [1858] OP ?      | (op ?: classes V=5 q=5 K=5 e=96 g=105)
  [1859] OP ?      | SETREG    Stk[l] = 502
  [1860] OP ?      | SETREG2   v[l] = 735
  [1861] OP ?      | SUBI      Stk[l] = l - 553
  [1862] OP ?      | CALL      hD(...)
  [1863] OP ?      | (op ?: classes V=5 q=0 K=5 e=106 g=0)
  [1864] OP ?      | SUBI      Stk[l] = l - 713
  [1865] OP ?      | SETTABUP  Stk[rep] = ...
  [1866] OP ?      | SUBI      Stk[l] = l - 810
  [1867] OP ?      | SETTABUP  Stk[string] = ...
  [1868] OP ?      | SETREG    Stk[l] = 905
  [1869] OP ?      | SUBI      Stk[l] = l - 919
  [1870] OP ?      | (op ?: classes V=5 q=0 K=5 e=275 g=0)
  [1871] OP ?      | (op ?: classes V=5 q=0 K=5 e=180 g=0)
  [1872] OP ?      | (op ?: classes V=5 q=0 K=5 e=31 g=0)
  [1873] OP ?      | (op ?: classes V=5 q=5 K=4 e=84 g=455)
  [1874] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=0)
  [1875] OP ?      | (op ?: classes V=5 q=5 K=5 e=34 g=28)
  [1876] OP ?      | (op ?: classes V=5 q=0 K=5 e=388 g=0)
  [1877] OP ?      | SUBI      Stk[l] = l - 763
  [1878] OP ?      | (op ?: classes V=5 q=5 K=5 e=85 g=83)
  [1879] OP ?      | SUBI      Stk[l] = l - 459
  [1880] OP ?      | (op ?: classes V=5 q=5 K=5 e=100 g=0)
  [1881] OP ?      | (op ?: classes V=5 q=5 K=5 e=0 g=97)
  [1882] OP ?      | GETTABUP  Stk[l] = env['K[567]']
  [1883] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1884] OP ?      | GETTABUP  Stk[l] = env['K[104]']
  [1885] OP ?      | GETTABUP  Stk[l] = env['K[97]']
  [1886] OP ?      | GETTABUP  Stk[l] = env['K[396]']
  [1887] OP ?      | (op ?: classes V=5 q=5 K=5 e=96 g=105)
  [1888] OP ?      | SUBI      Stk[l] = l - 823
  [1889] OP ?      | SETTABUP  Stk[84] = ...
  [1890] OP ?      | SUBI      Stk[l] = l - 121
  [1891] OP ?      | (op ?: classes V=5 q=0 K=5 e=50 g=0)
  [1892] OP ?      | SUBI      Stk[l] = l - 316
