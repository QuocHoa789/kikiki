#!/usr/bin/env python3
"""
Luraph Obfuscator v14.7 Deobfuscator / Unpacker
================================================
Recovers the hidden VM loader source + VM bytecode from Luau files protected
with Luraph Obfuscator v14.7 (https://lura.ph/).

Pipeline (reverse-engineered from the samples):
  [obfuscated .lua]
      |
      |  1. Lua-lexer-accurate extraction of long-bracket payloads ([[..]] / [=[..]=])
      |  2. Stage-1 decode: Luraph ASCII85 variant
      |       - strip 4-byte magic "LPH?" prefix
      |       - gsub 'z' -> '!!!!!'  (zero run expansion)
      |       - base85, big-endian, 5 chars -> 4 bytes (string.pack "<I4")
      |  3. Stage-2 decode (per obfuscation configuration):
      |       CONFIG A : custom LZ77 + range coder (adaptive binary models)
      |                   -> two streams: VM loader source + VM bytecode buffer
      |                   -> handled by generating an instrumented Luau hook script
      |                      and running it with the `luau` interpreter
      |       CONFIG B : Zstandard frames (Roblox EncodingService at runtime)
      |                   -> decompressed directly in Python (compression.zstd)
      |       CONFIG C : self-contained VM wrapper (loader is flattened VM code)
      |                   - C/zstd: payload is one zstd frame -> decompressed here
      |                   - C/range: payload uses a per-build range-coder variant;
      |                     the raw decoded blob is dumped for manual analysis
      |
      v
  [out/<name>/
     loader.lua      <- recovered VM loader source (readable Lua)
     bytecode.bin    <- raw Luraph VM bytecode buffer (if recovered)
     payload_N.bin   <- stage-1 decoded blobs
     strings.txt     <- printable strings recovered from loader + bytecode
     report.txt      <- summary]

Usage:
    python3 luraph_deobf.py <file.lua> [file2.lua ...] [-o OUTDIR]

Requirements: Python 3.14+ (compression.zstd), `luau` interpreter on PATH
              (only needed for CONFIG A samples).
"""

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

try:
    import compression.zstd as _zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False

LURAPH_MAGIC = b"LPH"
ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"


# ----------------------------------------------------------------------------
# Payload extraction
# ----------------------------------------------------------------------------

def extract_payloads(src: str):
    """Scan like a real Lua lexer: return (code_with_placeholders, [payload_texts])."""
    out, payloads = [], []
    i, n, last = 0, len(src), 0
    while i < n - 1:
        if src[i] == "[":
            j = i + 1
            while j < n and src[j] == "=":
                j += 1
            if j < n and src[j] == "[":
                level = j - i - 1
                close = "]" + "=" * level + "]"
                end = src.find(close, j + 1)
                if end != -1:
                    payloads.append(src[j + 1:end])
                    out.append(src[last:i])
                    out.append(f"<<PAYLOAD{len(payloads)-1}>>")
                    last = end + len(close)
                    i = last
                    continue
        i += 1
    out.append(src[last:])
    return "".join(out), payloads


# ----------------------------------------------------------------------------
# Stage-1 decode: Luraph ASCII85 variant
# ----------------------------------------------------------------------------

def luraph_ascii85_decode(data: str) -> bytes:
    """
    Luraph v14.7 stage-1 encoding:
      sub(payload, 5)          -- strips the 4-byte "LPH?" magic + 1 guard char
      gsub(x, "z", "!!!!!")    -- zero-run expansion
      gsub(x, ".....", tbl)    -- 5 chars -> 4 bytes, base85 big-endian,
                                -- packed little-endian ("<I4")
    """
    data = data.replace("z", "!!!!!")
    out = bytearray()
    for i in range(0, len(data) // 5 * 5, 5):
        L, v, W, G, j = (ord(c) for c in data[i:i + 5])
        t = (j - 33) + (G - 33) * 85 + (W - 33) * 7225 + (v - 33) * 614125 \
            + (L - 33) * 52200625
        out += (t & 0xFFFFFFFF).to_bytes(4, "little")
    return bytes(out)


def zstd_decompress_tolerant(data: bytes):
    """Zstd decompress trying small trailing trims (Luraph pads frames)."""
    if not HAS_ZSTD:
        return None
    for trim in range(0, 9):
        try:
            return _zstd.decompress(data[: len(data) - trim])
        except Exception:
            continue
    return None


# ----------------------------------------------------------------------------
# CONFIG A: instrumented Luau hook (range-coder streams inside the wrapper)
# ----------------------------------------------------------------------------

INSTRUMENT_TMPL = r'''local realbuf=buffer; local SLOG,NLOG={{}},{{}}; local sb,fb=0,0;
buffer=setmetatable({{}},{{__index=function(_,k) local fn=realbuf[k];
if type(fn)~="function" then return fn end
return function(b,...) local r={{fn(b,...)}};
if k=="readstring" then sb=sb+1; SLOG[sb]=tostring(r[1]);
elseif k=="readf64" or k=="readf32" then fb=fb+1; NLOG[fb]=tostring(r[1]);
end; return table.unpack(r); end end}});
print("\x1eLOADER_BEGIN\x1e");print({src});print("\x1eLOADER_END\x1e");
print("\x1eSTRINGS_BEGIN\x1e");print(table.concat(SLOG,"\x1f"));print("\x1eSTRINGS_END\x1e");
print("\x1eNUMS_BEGIN\x1e");print(table.concat(NLOG,"\x1f"));print("\x1eNUMS_END\x1e");
local hx={{}}
for i=0,buffer.len({buf})-1 do hx[i+1]=string.format("%02x",realbuf.readu8({buf},i)) end
print("\x1eBC_BEGIN\x1e");print(table.concat(hx));print("\x1eBC_END\x1e");
end)();'''

# compile call:  <ok>,<fn> = <pcall>(<loader>, <src>, "Luraph"..X(" ",N), nil)
COMPILE_RE = re.compile(
    r'(?P<assign>(?:local\s+)?(?P<ok>\w+),(?P<fn>\w+)\s*=\s*'
    r'(?P<pcall>\w+)\((?P<loader>\w+),(?P<src>\w+),"Luraph"\.\.)'
)
RETURN_RE = re.compile(
    r'return\s+(?P<fn>\w+)\((?P<buf>\w+)\)\s*;\s*end\s*\)\s*\(\s*\)?\s*'
    r'\(\s*\.\.\.\s*\)\s*;\s*$'
)


def try_config_a(src: str):
    """Detect and unpack CONFIG A (dual range-coded streams via luau hook)."""
    m = COMPILE_RE.search(src)
    if not m:
        return None
    src_var = m.group("src")
    r = RETURN_RE.search(src)
    if not r:
        return None
    buf_var = r.group("buf")
    if shutil.which("luau") is None:
        print("  [!] CONFIG A detected but `luau` interpreter not found on PATH")
        return None

    instrument = INSTRUMENT_TMPL.format(src=src_var, buf=buf_var)
    hooked = src[: m.start("assign")] + instrument

    with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False,
                                     encoding="utf-8") as f:
        f.write(hooked)
        hook_path = f.name
    try:
        proc = subprocess.run(["luau", hook_path], capture_output=True,
                              text=True, timeout=300)
    finally:
        os.unlink(hook_path)

    txt = proc.stdout
    result = {}
    for a, b in (("LOADER_BEGIN", "LOADER_END"), ("BC_BEGIN", "BC_END"),
                 ("STRINGS_BEGIN", "STRINGS_END"), ("NUMS_BEGIN", "NUMS_END")):
        ta, tb = f"\x1e{a}\x1e", f"\x1e{b}\x1e"
        if ta in txt and tb in txt:
            result[a.split("_")[0].lower()] = txt[txt.index(ta) + len(ta):
                                                  txt.index(tb)].strip("\n")
    if "loader" not in result:
        return None
    return {
        "loader": result["loader"],
        "bytecode_hex": result.get("bc", ""),
        "strings_trace": result.get("strings", ""),
        "nums_trace": result.get("nums", ""),
    }


# ----------------------------------------------------------------------------
# --trace mode: instrumented run of the recovered loader (read-semantic trace)
# ----------------------------------------------------------------------------

TRACE_DRIVER_TMPL = '''-- generated by luraph_deobf --trace
local realbuf = buffer;
local LOG, GN = {}, 0;
buffer = setmetatable({}, {__index=function(_,k) local f=realbuf[k];
if type(f)~="function" then return f end
return function(b,...) local r={f(b,...)}; GN=GN+1;
if k=="readstring" then LOG[GN]="readstring "..string.format("%q",tostring(r[1]));
else LOG[GN]=k.." "..tostring(r[1]); end;
return table.unpack(r) end end});
local src = "@@LOADER@@";
local fn = loadstring(src, "loader");
local data = buffer.fromstring("@@BYTECODE@@");
local res = fn(data);
print("\\x1eNREADS\\x1e"..GN);
print("\\x1eTRACE\\x1e"..table.concat(LOG,"\\n"));
print("\\x1eEND\\x1e"..type(res));
'''


def run_trace(loader_path: str, bytecode_path: str, outdir: str):
    """Run the recovered loader with an instrumented buffer library and dump
    the full read sequence (constants, opcodes, structure)."""
    loader = open(loader_path, encoding="utf-8").read()
    bc = open(bytecode_path, "rb").read()

    def esc(s):
        if isinstance(s, bytes):
            s = s.decode("latin-1")
        return "".join("\\%03d" % ord(c) if (ord(c) < 32 or ord(c) > 126 or c in '"\\') else c
                       for c in s)

    code = (TRACE_DRIVER_TMPL
            .replace("@@LOADER@@", esc(loader))
            .replace("@@BYTECODE@@", esc(bc)))
    with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False,
                                     encoding="utf-8") as f:
        f.write(code)
        drv = f.name
    try:
        proc = subprocess.run(["luau", drv], capture_output=True,
                              timeout=300)
    finally:
        os.unlink(drv)

    txt = (proc.stdout or b"").decode("utf-8", errors="replace")
    stderr = (proc.stderr or b"").decode("utf-8", errors="replace")
    if "\x1eTRACE\x1e" not in txt:
        print("  [!] trace failed:", stderr[:200])
        return None
    n = txt.split("\x1eNREADS\x1e")[1].split("\n")[0]
    body = txt[txt.index("\x1eTRACE\x1e") + 7: txt.index("\x1eEND\x1e")]
    with open(os.path.join(outdir, "read_trace.txt"), "w",
              encoding="utf-8", errors="replace") as f:
        f.write(body)
    print(f"  trace    : {n} buffer reads -> read_trace.txt")
    return body


def analyze_trace(body: str):
    """Summarize the read trace: number constants, opcodes, strings, structure."""
    from collections import Counter
    import re as _re
    lines = [l for l in body.split("\n") if l.strip()]
    kinds = Counter(l.split(" ")[0] for l in lines
                    if not l.startswith("readstring"))
    out = [f"total reads: {len(lines)}  "
           f"({', '.join(f'{k}={v}' for k, v in sorted(kinds.items()))})"]
    # string constants
    strings = []
    for l in lines:
        m = _re.match(r'readstring "(.*)"$', l)
        if m:
            try:
                s = m.group(1).encode().decode("unicode_escape")
            except Exception:
                s = m.group(1)
            strings.append(s)
    if strings:
        out.append(f"string constants ({len(strings)}):")
        for s in strings[:120]:
            out.append("  " + repr(s)[:100])
    nums = [l for l in lines if l.startswith(("readf64", "readf32"))]
    if nums:
        out.append("number constants:")
        for l in nums:
            out.append("  " + l.split("-> ")[-1])
    u16 = [l for l in lines if l.startswith("readu16")]
    if u16:
        vals = [l.split("-> ")[-1] for l in u16]
        out.append(f"readu16 values (VM opcode ids / counts): "
                   f"{', '.join(vals[:40])}" + (" ..." if len(vals) > 40 else ""))
    return "\n".join(out), nums, [l.split("-> ")[-1] for l in u16]




PRINTABLE_RE = re.compile(rb"[\x20-\x7e]{4,}")


def extract_strings(blob: bytes, limit=500):
    seen, out = set(), []
    for m in PRINTABLE_RE.finditer(blob):
        s = m.group().decode("ascii")
        if s not in seen:
            seen.add(s)
            out.append(s)
        if len(out) >= limit:
            break
    return out


# ----------------------------------------------------------------------------
# Main unpacker
# ----------------------------------------------------------------------------

def unpack(path: str, out_root: str):
    name = os.path.splitext(os.path.basename(path))[0]
    src = open(path, encoding="utf-8", errors="replace").read()
    is_luraph = "Luraph Obfuscator v14.7" in src or "LPH>" in src or "LPH?" in src
    print(f"\n=== {os.path.basename(path)} "
          f"{'(Luraph v14.7)' if 'Luraph Obfuscator v14.7' in src else ''}")

    outdir = os.path.join(out_root, name)
    os.makedirs(outdir, exist_ok=True)
    report = [f"input     : {os.path.abspath(path)}",
              f"size      : {len(src)} bytes"]

    code, payloads = extract_payloads(src)
    report.append(f"payloads  : {len(payloads)} long-bracket string(s)")

    decoded = []
    for k, p in enumerate(payloads):
        d = luraph_ascii85_decode(p[4:]) if p.startswith("LPH") else b""
        decoded.append(d)
        with open(os.path.join(outdir, f"payload_{k}.bin"), "wb") as f:
            f.write(d)
        report.append(f"  payload_{k}: {len(p)} chars -> {len(d)} bytes "
                      f"({'zstd' if d[:4] == ZSTD_MAGIC else 'range-coder' if d else 'unknown'})")

    loader = None
    bytecode = None

    # --- CONFIG A: dual streams, range-coder inside wrapper -> luau hook ---
    res = try_config_a(src)
    if res:
        print("  config A : range-coder dual stream -> unpacked via luau hook")
        loader = res["loader"]
        try:
            bytecode = bytes.fromhex(res["bytecode_hex"])
        except ValueError:
            bytecode = None
        with open(os.path.join(outdir, "trace_strings.txt"), "w",
                  encoding="utf-8", errors="replace") as f:
            f.write(res.get("strings_trace", "").replace("\x1f", "\n"))
        with open(os.path.join(outdir, "trace_numbers.txt"), "w",
                  encoding="utf-8", errors="replace") as f:
            f.write(res.get("nums_trace", "").replace("\x1f", "\n"))

    # --- CONFIG B / C-zstd: zstd payloads ---
    if loader is None and HAS_ZSTD:
        for k, d in enumerate(decoded):
            if d[:4] != ZSTD_MAGIC:
                continue
            dec = zstd_decompress_tolerant(d)
            if dec is None:
                continue
            head = dec[:12].lstrip()
            if head.startswith(b"local") or b"function" in dec[:200]:
                with open(os.path.join(outdir, f"stream_{k}.bin"), "wb") as f:
                    f.write(dec)
                if loader is None:
                    loader = dec.decode("utf-8", errors="replace")
                    print(f"  config B/C: zstd payload_{k} -> loader source "
                          f"({len(dec)} bytes)")
                else:
                    bytecode = bytecode or dec
                    print(f"  config B/C: zstd payload_{k} -> second stream "
                          f"({len(dec)} bytes)")
            else:
                with open(os.path.join(outdir, f"stream_{k}.bin"), "wb") as f:
                    f.write(dec)
                if bytecode is None:
                    bytecode = dec
                print(f"  config B/C: zstd payload_{k} -> data stream "
                      f"({len(dec)} bytes)")

    # --- outputs ---
    if loader:
        with open(os.path.join(outdir, "loader.lua"), "w",
                  encoding="utf-8", errors="replace") as f:
            f.write(loader)
        report.append(f"loader    : {len(loader)} chars  -> loader.lua")
    if bytecode:
        with open(os.path.join(outdir, "bytecode.bin"), "wb") as f:
            f.write(bytecode)
        report.append(f"bytecode  : {len(bytecode)} bytes -> bytecode.bin")

    # strings from loader + bytecode
    strings = []
    if bytecode:
        strings += [f"[bytecode] {s}" for s in extract_strings(bytecode, 400)]
    if loader:
        strings += [f"[loader]   {s}" for s in extract_strings(loader.encode(), 200)]
    if strings:
        with open(os.path.join(outdir, "strings.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(strings))
        report.append(f"strings    : {len(strings)} recovered -> strings.txt")

    if not loader and not bytecode:
        report.append("STATUS    : stage-2 format not supported automatically "
                      "(per-build range-coder variant). Raw decoded payloads "
                      "saved above for manual analysis.")
    else:
        report.append("STATUS    : UNPACKED")

    with open(os.path.join(outdir, "report.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(report) + "\n")
    for line in report:
        print("  " + line)
    return bool(loader or bytecode)


def main():
    ap = argparse.ArgumentParser(description="Luraph v14.7 deobfuscator/unpacker")
    ap.add_argument("files", nargs="*", help="obfuscated .lua file(s)")
    ap.add_argument("-o", "--out", default="out", help="output directory")
    ap.add_argument("--trace", nargs=2, metavar=("LOADER", "BYTECODE"),
                    help="run a read-semantic trace of an already unpacked "
                         "loader.lua + bytecode.bin pair")
    ap.add_argument("-O", "--trace-out", default=".", help="trace output dir")
    args = ap.parse_args()

    if args.trace:
        loader, bc = args.trace
        body = run_trace(loader, bc, args.trace_out)
        if body:
            summary, _, _ = analyze_trace(body)
            print(summary)
            with open(os.path.join(args.trace_out, "trace_summary.txt"), "w",
                      encoding="utf-8") as f:
                f.write(summary + "\n")
        return

    ok = 0
    for path in args.files:
        try:
            ok += 1 if unpack(path, args.out) else 0
        except Exception as e:
            print(f"  [!] error: {type(e).__name__}: {e}")
    print(f"\n{ok}/{len(args.files)} file(s) unpacked -> {args.out}/")


if __name__ == "__main__":
    main()
