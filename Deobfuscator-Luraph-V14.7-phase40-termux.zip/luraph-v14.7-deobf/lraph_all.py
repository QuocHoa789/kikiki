#!/usr/bin/env python3
"""
Luraph v14.7 ALL-IN-ONE deobfuscator
====================================
ONE command runs the whole pipeline:
  obfuscated .lua -> loader.lua + bytecode.bin + static dump + pseudo-Lua listing

Usage:
  python3 lraph_all.py <file.lua> [-o OUTDIR]

Requires: Python 3.14+, `luau` on PATH (for the unpack stage).
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"

try:
    import compression.zstd as _zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False

MICROP = {0: 'GETG', 1: 'ADD', 2: 'SETL', 4: 'SETT', 7: 'LOAD'}

INSTRUMENT_TMPL = r'''local realbuf=buffer; local SLOG,NLOG={{}},{{}}; local sb,fb=0,0;
buffer=setmetatable({{}},{{__index=function(_,k) local fn=realbuf[k];
if type(fn)~="function" then return fn end
return function(b,...) local r={{fn(b,...)}};
if k=="readstring" then sb=sb+1; SLOG[sb]=tostring(r[1]);
elseif k=="readf64" or k=="readf32" then fb=fb+1; NLOG[fb]=tostring(r[1]);
end; return table.unpack(r); end end}});
print("\x1eLOADER_BEGIN\x1e");print({src});print("\x1eLOADER_END\x1e");
print("\x1eSTRINGS_BEGIN\x1e");print(table.concat(SLOG,"\x1f"));print("\x1eSTRINGS_END\x1e");
print("\x1eNUMS_BEGIN\x1e");print(table.concat(NLOG,"\x1f"));print("\x1eNUMS_END\x1e");
local hx={{}}
for i=0,buffer.len({buf})-1 do hx[i+1]=string.format("%02x",realbuf.readu8({buf},i)) end
print("\x1eBC_BEGIN\x1e");print(table.concat(hx));print("\x1eBC_END\x1e");
end)();'''

COMPILE_RE = re.compile(
    r'(?P<assign>(?:local\s+)?(?P<ok>\w+),(?P<fn>\w+)\s*=\s*'
    r'(?P<pcall>\w+)\((?P<loader>\w+),(?P<src>\w+),"Luraph"\.\.)'
)
RETURN_RE = re.compile(
    r'return\s+(?P<fn>\w+)\((?P<buf>\w+)\)\s*;\s*end\s*\)\s*\(\s*\)?\s*'
    r'\(\s*\.\.\.\s*\)\s*;\s*$'
)

# ============================================================================
# Stage 1: payload extraction
# ============================================================================

def extract_payloads(src):
    out, payloads = [], []
    i, n, last = 0, len(src), 0
    while i < n - 1:
        if src[i] == "[":
            j = i + 1
            while j < n and src[j] == "=":
                j += 1
            if j < n and src[j] == "[":
                level = j - i - 1
                close = "]" + "=" * level + "]"
                end = src.find(close, j + 1)
                if end != -1:
                    payloads.append(src[j + 1:end])
                    out.append(src[last:i])
                    out.append(f"<<PAYLOAD{len(payloads)-1}>>")
                    last = end + len(close)
                    i = last
                    continue
        i += 1
    out.append(src[last:])
    return "".join(out), payloads


def luraph_ascii85_decode(data):
    data = data.replace("z", "!!!!!")
    out = bytearray()
    for i in range(0, len(data) // 5 * 5, 5):
        L, v, W, G, j = (ord(c) for c in data[i:i + 5])
        t = (j - 33) + (G - 33) * 85 + (W - 33) * 7225 \
            + (v - 33) * 614125 + (L - 33) * 52200625
        out += (t & 0xFFFFFFFF).to_bytes(4, "little")
    return bytes(out)


def zstd_decompress_tolerant(data):
    if not HAS_ZSTD:
        return None
    for trim in range(0, 9):
        try:
            return _zstd.decompress(data[:len(data) - trim])
        except Exception:
            continue
    return None

# ============================================================================
# Stage 2: unpack via instrumented luau hook (config A)
# ============================================================================

def unpack_config_a(src):
    m = COMPILE_RE.search(src)
    if not m:
        return None
    r = RETURN_RE.search(src)
    if not r:
        return None
    if shutil.which("luau") is None:
        return None
    instrument = INSTRUMENT_TMPL.format(src=m.group("src"), buf=r.group("buf"))
    hooked = src[:m.start("assign")] + instrument
    with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False,
                                     encoding="utf-8") as f:
        f.write(hooked)
        hp = f.name
    try:
        proc = subprocess.run(["luau", hp], capture_output=True, timeout=300)
    finally:
        os.unlink(hp)
    txt = (proc.stdout or b"").decode("utf-8", errors="replace")
    result = {}
    for a, key in (("LOADER", "loader"), ("BC", "bc"),
                   ("STRINGS", "strings"), ("NUMS", "nums")):
        ta, tb = f"\x1e{a}_BEGIN\x1e", f"\x1e{a}_END\x1e"
        if ta in txt and tb in txt:
            result[key] = txt[txt.index(ta) + len(ta):txt.index(tb)].strip("\n")
    if "loader" not in result:
        return None
    try:
        bytecode = bytes.fromhex(result.get("bc", "").strip())
    except ValueError:
        bytecode = None
    return {"loader": result["loader"], "bytecode": bytecode,
            "strings_trace": result.get("strings", "").replace("\x1f", "\n"),
            "nums_trace": result.get("nums", "")}

# ============================================================================
# Stage 3: static parse + pseudo-Lua decompile (pure Python)
# ============================================================================

def leb128(buf, pos):
    val, shift = 0, 0
    while pos < len(buf):
        b = buf[pos]
        val |= (b & 0x7F) << shift
        shift += 7
        pos += 1
        if not (b & 0x80):
            break
    return val, pos


def static_parse(data):
    """Walk the buffer: tagged fields -> constants pool + instruction list."""
    events = []
    pos = 4  # header
    const_pool, instrs = [], []
    cur_op, cur_operands = None, []

    def flush():
        nonlocal cur_op, cur_operands
        if cur_op is not None:
            instrs.append((cur_op, list(cur_operands)))
        cur_op, cur_operands = None, []

    while pos < len(data):
        b = data[pos]
        if b == 0xB4:
            ln, p2 = leb128(data, pos + 1)
            if p2 + ln <= len(data) and 0 < ln < 1_000_000:
                events.append(('string', len(const_pool), pos))
                const_pool.append(data[p2:p2 + ln])
                flush()
                pos = p2 + ln
                continue
            events.append(('byte', b, pos)); pos += 1
        elif b == 0x7B and pos + 3 <= len(data):
            op = int.from_bytes(data[pos+1:pos+3], 'little')
            flush()
            events.append(('opcode', op, pos))
            cur_op = (op, pos)
            pos += 3
        elif b == 0xA1 and pos + 2 <= len(data):
            v = data[pos+1]
            events.append(('operand', v, pos))
            if cur_op is not None:
                cur_operands.append(v)
            pos += 2
        else:
            events.append(('byte', b, pos)); pos += 1
    flush()
    return events, const_pool, instrs


def write_static_dump(out, events, const_pool, instrs, bytecode):
    out.write("; Luraph v14.7 static parse\n")
    out.write(f"; {len(const_pool)} constants, {len(instrs)} instructions\n\n")
    out.write("; -- constant pool --\n")
    for i, s in enumerate(const_pool):
        if all(32 <= c < 127 or c in (9, 10, 13) for c in s):
            txt = s.decode('ascii', errors='replace')[:60]
            out.write(f'  K[{i}] = "{txt}"\n')
        else:
            out.write(f"  K[{i}] = <{len(s)}B binary> {s[:16].hex(' ')}\n")
    out.write("\n; -- instructions --\n")
    for idx, ((op, pos), _operands) in enumerate(instrs):
        out.write(f"  [{idx:4d}] OP {op:<6d} @0x{pos:05x}\n")


def write_pseudo_lua(out, const_pool, instrs):
    out.write("; Luraph v14.7 pseudo-Lua listing\n\n")
    out.write("; -- constants --\n")
    for i, s in enumerate(const_pool):
        if all(32 <= c < 127 or c in (9, 10, 13) for c in s):
            txt = s.decode('ascii', errors='replace')[:60]
            out.write(f'  K[{i}] = "{txt}"\n')
        else:
            out.write(f"  K[{i}] = <{len(s)}B binary>\n")
    out.write("\n; -- code --\n")
    for n, ((op, pos), operands) in enumerate(instrs):
        parts = []
        for ob in operands:
            cls, reg = ob % 8, ob // 8
            mn = MICROP.get(cls, f'c{cls}')
            parts.append(f"{mn}(r{reg})")
        out.write(f"  [{n:4d}] OP {op:<6d} {' '.join(parts)}\n")

# ============================================================================
# Main
# ============================================================================

def main():
    ap = argparse.ArgumentParser(description="Luraph v14.7 all-in-one deobfuscator")
    ap.add_argument("file", help="obfuscated .lua file")
    ap.add_argument("-o", "--out", default="out", help="output directory")
    args = ap.parse_args()

    name = os.path.splitext(os.path.basename(args.file))[0]
    src = open(args.file, encoding="utf-8", errors="replace").read()
    outdir = os.path.join(args.out, name)
    os.makedirs(outdir, exist_ok=True)

    print(f"=== {os.path.basename(args.file)} (Luraph v14.7)")

    # -- stage 1: payloads --
    _, payloads = extract_payloads(src)
    print(f"  payloads : {len(payloads)}")

    # -- stage 2: unpack --
    bytecode = None
    loader = None
    res = unpack_config_a(src)
    if res:
        print("  config A : unpacked via luau hook")
        loader = res["loader"]
        bytecode = res["bytecode"]
        with open(os.path.join(outdir, "trace_strings.txt"), "w",
                  encoding="utf-8", errors="replace") as f:
            f.write(res["strings_trace"])
    else:
        # zstd fallback
        for k, p in enumerate(payloads):
            if not p.startswith("LPH"):
                continue
            d = luraph_ascii85_decode(p[4:])
            if d[:4] == ZSTD_MAGIC:
                dec = zstd_decompress_tolerant(d)
                if dec and (b"function" in dec[:200] or dec[:5].lstrip().startswith(b"local")):
                    bytecode = dec
                    print(f"  config B : zstd stream_{k} -> data ({len(dec)} B)")
                    break

    # -- outputs --
    if loader:
        with open(os.path.join(outdir, "loader.lua"), "w",
                  encoding="utf-8", errors="replace") as f:
            f.write(loader)
        print(f"  loader   : {len(loader)} chars -> loader.lua")
    if bytecode:
        with open(os.path.join(outdir, "bytecode.bin"), "wb") as f:
            f.write(bytecode)
        print(f"  bytecode : {len(bytecode)} bytes -> bytecode.bin")

        # -- stage 3: static parse + pseudo-Lua --
        events, cp, instrs = static_parse(bytecode)
        with open(os.path.join(outdir, "static_dump.txt"), "w",
                  encoding="utf-8", errors="replace") as f:
            write_static_dump(f, events, cp, instrs, bytecode)
        with open(os.path.join(outdir, "decomp.lua"), "w",
                  encoding="utf-8", errors="replace") as f:
            write_pseudo_lua(f, cp, instrs)
        print(f"  static   : {len(cp)} constants, {len(instrs)} instructions"
              f" -> static_dump.txt + decomp.lua")
    else:
        print("  STATUS   : unpack not supported (per-build variant)")
        return 1

    print(f"  => {outdir}/")
    return 0


if __name__ == '__main__':
    sys.exit(main())
