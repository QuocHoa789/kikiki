# Luraph v14.7 Deobfuscator / Unpacker

Tool giải mã (unpack) các file Luau được bảo vệ bởi **Luraph Obfuscator v14.7** — khôi phục
**source của VM loader** và **bytecode VM** từ sample đã obfuscate.

## Disassembler (work/lraph_disasm.py)

Replay bản đồ cấu trúc 100% chính xác + decode micro-op class (mod-8/div-8 packing)
→ disassembly có ngữ nghĩa:

```bash
cd work
python3 lraph_disasm.py ../out/trace/annot_1.json -o disasm_1.dis
```

```
; Luraph v14.7 bytecode disassembly
  [  0] OP 256    c3(11) c5(8) SLT(12) SLT(0) LDN(11) SLT(1) LDN(8) K6 K5 ADD(3) ...
  [  1] OP 305    STB(3) STB(11) ADD(7) ADD(15) c5(20) c6(24)
  [  2] OP 286    c6(13) c6(15) K6 c6(8) c3(31) c3(18) c6(30) K4 ...
  [  3] OP 1293                                                  <- proto boundary
  [  5] OP 3616   ADD(20) c3(14) c6(19) i16-12296 c6(10) K6 ...
```

**Micro-op classes** (từ `nD` executor, decode = `class = byte % 8`, `reg = byte // 8`):

| Class | Ý nghĩa |
|-------|---------|
| `GTB(0)` | GETGLOBAL/GETTABUP (`(L)[l] = env[A]`) |
| `LDN(7)` | LOADN/LOADK (`(T)[l] = A`) |
| `ADD(1)` | ADD (`T[l] = l + A`) |
| `STB(4)` | SETTABUP (`c:QT`) |
| `SLT(2)` | SETLIST (`c:KT/c:vT`) |
| `K==0` | CALL (`c:hD`) |

`K<n>` = hằng chuỗi, `u32/i32/i16` = hằng số.

## Trace mode (phân tích bytecode)

Chạy trace đọc buffer của loader đã unpack — cho ra toàn bộ chuỗi hằng số,
opcode VM và cấu trúc stream:

```bash
python3 luraph_deobf.py --trace out/1/loader.lua out/1/bytecode.bin -O out/trace
```

Output: `read_trace.txt` (toàn bộ buffer reads) + `trace_summary.txt`:

```
total reads: 32620  (readf32=2, readf64=5, readi16=40, readi32=28,
                     readstring=90, readu16=179, readu32=64, readu8=32174)
string constants (86): 'string', 'bit32', 'pcall', 'typeof', 'getfenv',
  'traceback', 'loadstring', ... , ' --[[%s]] return setfenv(function(...)
  return %s(...) end, setmetatable({ ["%s"] = ... }, { __index ...
number constants: 5 doubles + 2 floats
readu16 values (VM opcode ids): 256, 305, 286, 1293, 1837, ...
```

Phát hiện thêm từ trace (replay 100% chính xác — 36363/36363 bytes, 0 mismatch):
- **Format chuỗi**: `TAG(0xB4) + varint_length + raw_chars` — 90 chuỗi, tag ổn định.
- **Opcode fetch**: `TAG(0x7B) + readu16` (giá trị ≥ 256) — 179 instructions.
- **Bytecode stream dùng LEB128-style varint** + byte key xen kẽ (mỗi file một key,
  ví dụ sample 1 = `0xa1`, sample 3 = `0x2c`, sample 4 = `0x47`).
- Header 4 byte; opcode đầu tiên (256) = LOAD CONSTANTS — đọc pool inline:
  cặp `(0xA1, byte)` + chuỗi `(0xB4, len, chars)` + số qua readi16/readi32/readu32.
- Luraph build chunk bằng template: `` --[[%s]] return setfenv(function(...) return %s(...) end, setmetatable(...) ``

## Sử dụng

```bash
python3 luraph_deobf.py <file.lua> [file2.lua ...] [-o OUTDIR]
```

Yêu cầu: Python 3.14+ (module `compression.zstd`) và `luau` trên PATH (chỉ cần cho CONFIG A).

## Pipeline đã reverse-engineer

```
[obfuscated .lua]
   │
   ├─ 1. Trích payload long-bracket ([[..]] / [=[..]=]) bằng scanner đúng chuẩn lexer Lua
   │
   ├─ 2. Giai đoạn 1 — biến thể ASCII85 của Luraph:
   │       sub(payload, 5)         ← bỏ magic 4 byte "LPH?" + 1 ký tự guard
   │       gsub(x, "z", "!!!!!")   ← mở rộng run số 0
   │       5 ký tự → 4 byte: base85 big-endian, đóng gói little-endian ("<I4")
   │
   └─ 3. Giai đoạn 2 — tùy cấu hình obfuscation:
         CONFIG A : LZ77 + range coder (mô hình nhị phân thích nghi) — 2 luồng:
                    loader source + bytecode buffer → giải qua hook luau
         CONFIG B : khung Zstandard (chạy thật qua Roblox EncodingService)
                    → giải trực tiếp bằng compression.zstd của Python
         CONFIG C : wrapper VM tự chứa (loader là code VM đã flatten)
                    - C/zstd  : payload là 1 khung zstd → giải ở đây
                    - C/range : biến thể range-coder theo từng build → chỉ dump blob
```

## Kết quả trên 10 sample của repo

| Sample | Config | loader.lua | bytecode.bin | Ghi chú |
|--------|--------|-----------|--------------|---------|
| 1.lua  | A (range-coder) | ✅ 48,085 chars | ✅ 36,363 B | |
| 2.lua  | C/zstd | ✅ 97,489 chars | — | loader = VM flatten |
| 3.lua  | A | ✅ 44,987 chars | ✅ 61,383 B | |
| 4.lua  | B (Zstd) | ✅ 44,340 chars | ✅ 61,912 B | Roblox EncodingService |
| 5.lua  | A | ✅ 44,034 chars | ✅ 61,903 B | |
| 6.lua  | A | ✅ 48,119 chars | ✅ 72,649 B | |
| 7.lua  | A | ✅ 48,119 chars | ✅ 72,649 B | trùng sample 6 |
| 8.lua  | C/range | ❌ | ❌ | blob đã decode, biến thể range-coder riêng |
| 9.lua  | B (Zstd) | ✅ 43,356 chars | ✅ 77,879 B | |
| 10.lua | C/range | ❌ | ❌ | như 8.lua |

**8/10 sample được giải tự động.**

## Output

```
out/<name>/
  loader.lua        <- source VM loader đã khôi phục (Lua đọc được)
  bytecode.bin      <- buffer bytecode VM Luraph (nếu có)
  payload_N.bin     <- blob giải giai đoạn 1
  stream_N.bin      <- luồng giải giai đoạn 2 (config B/C)
  strings.txt       <- chuỗi in được trích từ bytecode + loader
  trace_strings.txt <- trace buffer.readstring (config A)
  trace_numbers.txt <- trace buffer.readf64/readf32 (config A)
  report.txt        <- tóm tắt
```

### Lệnh trace (sau khi unpack):

```bash
python3 luraph_deobf.py --trace out/<name>/loader.lua out/<name>/bytecode.bin -O out/trace
# -> out/trace/read_trace.txt, out/trace/trace_summary.txt
```

## Phát hiện kỹ thuật chính

1. **Anti-tamper**: wrapper kiểm tra `loadstring` với đầu vào rác (`\x1BLuaP`, số, `function:...`);
   nếu môi trường chấp nhận đầu vào rác, offset strip bị poison `I=20` → giải sai.
2. **Chunk name** của loader được compile: `"Luraph   "` (`"Luraph"..(" "):rep(N)`).
3. **Đọc bytecode**: deserializer đọc byte-by-byte qua `buffer.readu8`
   (tên hàm giấu trong `P = '\114e\z a\x64\z u\56'` = `"readu8"`), chuỗi qua
   `buffer.readstring`, số qua `readf64/readf32/readu16`.
4. **Loader** có dạng `local R = ...; return({<các method>}):F();` — `F()` deserialize
   bytecode rồi chạy VM ngay trong đó.
5. **CONFIG C** (2/8/10): toàn bộ loader được flatten thành state-machine VM
   (opaque predicate dạng `while 179 and 15 and (220 or 94)`, state trả về số).
6. **VM executor đã giải mã** (`nD` method): kiến trúc **3-phase micro-op**:
   - Phase 1 (Z=92, class `V`): V==0 GETGLOBAL/GETTABUP, V==7 LOADN, V==1 ADD,
     V==4 SETTABUP, V==2 SETLIST
   - Phase 2 (Z=11, class `q`): q==7 MOVE, q==1 ADDI, q==4 SUBI, q==2 vT
   - Class `K`: K==0 CALL (`c:hD`), K==7 SETREG, K==1/4 arithmetic, K==2 SETLIST
   - Mỗi opcode ID (256, 305, 286, ...) = tổ hợp 3 class (V, q, K) + operands —
     mapping được tính trong dispatch từ bảng `I={47568,1797373223,...}`.

## Giới hạn

- CONFIG C/range (8.lua, 10.lua + 7 file mới từ Zain20m/Xyraniz: Z_s2, Z_s5, Z_s6, Z_s7,
  X_4345454, X_489e74537834, X_09289129203982): wrapper là VM flatten tự chứa với
  constants mã hóa — field names (vd `new`) được decrypt lúc runtime từ constant pool.
  Cần: (1) decode wrapper VM, hoặc (2) emulate đầy đủ môi trường Roblox
  (Instance/Random/Vector3/CFrame/game/workspace...). Blob đã decode giai đoạn 1
  được lưu để phân tích thủ công.
- **Opcode semantics**: opcode ID bị transform trong dispatch (bảng `I={47568,1797373223,...}`
  + bit32 arithmetic) — chưa map trực tiếp sang tên lệnh. Đã có đủ:
  disassembly 179 instructions, VM execution trace (11,162 steps qua `nD`),
  constant pool — cần decode tiếp bảng I trong `loader.lua`.
- Tool khôi phục tới mức **unpack + strings + loader source + disassembly**; chuyển bytecode VM
  Luraph ngược thành Lua nguồn (devirtualization đầy đủ) cần decode tiếp deserializer
  trong `loader.lua` (đã flatten, đọc được nhưng tốn công).

## Config C — kiến trúc wrapper VM (đã trace)

7 file config C (Z_s2, Z_s5, Z_s6, Z_s7, X_4345454, X_489e74537834, X_09289129203982):
wrapper là VM flatten tự chứa, kick-off qua `({...method table}):<fn>()(...)`:

| File | Kick-off |
|------|----------|
| Z_s2.lua | `o` |
| Z_s5.lua | `m` |
| X_4345454.lua | `m` |

Execution trace (Z_s2): `o(0) → K(3) → ok → F(4) → ✗ index nil with number`

Phát hiện:
- Methods table index bằng **number keys** (`k[0x2a]`, `k[43]`, `k[0x33]`) — VM dispatch ẩn danh.
- Captured methods: `O = buffer`, `x = coroutine` (`coroutine.wrap`/`yield`), `n = getfenv`.
- Field names (vd `'new'`) được **decrypt runtime** từ constant pool — không có literal.
- Failing state: `F` nhận `O=nil` từ state machine — cần decode tiếp chuỗi state
  (Sm/K/Fm) hoặc emulate đầy đủ Roblox environment.
