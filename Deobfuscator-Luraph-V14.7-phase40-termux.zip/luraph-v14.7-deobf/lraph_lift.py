#!/usr/bin/env python3
"""
Luraph v14.7 COMPLETE semantic lifter
=====================================
Lifts EVERY executed VM instruction into real logic from the nD execution trace,
correlated with the constant pool for real global/constant names.

Usage:
  python3 lraph_lift.py nd_trace.txt decomp.lua -o lifted.lua
"""
import re
import sys


def main():
    nd_path, cp_path = sys.argv[1], sys.argv[2]
    out_path = sys.argv[4] if len(sys.argv) > 4 else 'lifted.lua'

    # constant pool (from decomp listing: K[i] = "...")
    cp = []
    for l in open(cp_path, encoding='utf-8', errors='replace'):
        m = re.match(r'\s*K\[(\d+)\] = "(.*)"$', l.rstrip())
        if m:
            cp.append(m.group(2))

    data = open(nd_path, encoding='utf-8', errors='replace').read()
    body = data[data.index('\x1eNDLOG\x1e') + 7: data.index('\x1eEND\x1e')]

    # nD executor semantics (reverse-engineered from loader):
    # phase1 (Z=92): V=0 GETTABUP(L[l]=env[A]) | V=7 LOADN(T[l]=A)
    #                V=1 ADD(T[l]=l+A) | V=4 SETTAB(QT) | V=2 SETLIST(KT)
    # phase2 (Z=11): q=7 SETREG(z[l]=e) | q=1 ADDI(z[l]=l+e) | q=4 SUBI(z[l]=l-e)
    #                q=0 dT | q=2 vT ; K=0 CALL(hD) | K=7 v[l]=g
    #                K=1 v[l]=l+g | K=4 v[l]=l-g | K=2 SETLIST(rD/ZD/wD)

    def cname(e):
        try:
            i = int(e)
            if 0 <= i < len(cp):
                s = cp[i]
                if len(s) < 45:
                    return f"'{s}'"
                return f"'{s[:40]}...'"
        except ValueError:
            pass
        return None

    lifted = 0
    vip_seq = []   # (vip, action) in execution order
    for c in body.split('\n'):
        a = c.split(',')
        if len(a) < 17:
            continue
        try:
            l = int(a[2])
        except ValueError:
            continue
        V, K, q, Z, e, g, A = a[5], a[10], a[11], a[14], a[12], a[16], a[8]
        vip = l  # VM instruction pointer (VIP)
        acts = []
        if Z == '92':  # phase 1
            if V == '0':
                nm = cname(e) or f'K[{e}]'
                acts.append(f"GETTABUP  Stk[{vip}] = env[{nm}]")
            elif V == '1':
                acts.append(f"ADD       Stk[{vip}] = Stk[{vip}] + {e}")
            elif V == '7':
                acts.append(f"LOADN     Stk[{vip}] = {e}")
            elif V == '4':
                nm = cname(e)
                acts.append(f"SETTABUP  Stk[{nm or e}] = Stk[...]")
            elif V == '2':
                acts.append("SETLIST   KT(...)")
        else:  # phase 2 (Z=11)
            if q == '7':
                acts.append(f"SETREG    Stk[{vip}] = {e}")
            elif q == '1':
                acts.append(f"ADDI      Stk[{vip}] = Stk[{vip}] + {e}")
            elif q == '4':
                acts.append(f"SUBI      Stk[{vip}] = Stk[{vip}] - {e}")
            elif q == '0':
                acts.append(f"DT        dT(x,{e},{vip})")
            elif q == '2':
                acts.append(f"VT        vT(...)")
            if K == '0':
                acts.append("CALL      call Stk[A](...)")
            elif K == '7':
                acts.append(f"SETREG2   Upv[{vip}] = {g}")
            elif K == '1':
                acts.append(f"ADDU      Upv[{vip}] = Upv[{vip}] + {g}")
            elif K == '4':
                acts.append(f"SUBU      Upv[{vip}] = Upv[{vip}] - {g}")
            elif K == '2':
                acts.append("SETLIST2  rD/ZD/wD(...)")
        for act in acts:
            vip_seq.append((vip, act))
            lifted += 1

    out = open(out_path, 'w')
    out.write("-- Luraph v14.7 FULL semantic decompilation\n")
    out.write(f"-- {lifted} lifted actions from VM execution trace\n")
    out.write(f"-- (execution order, polymorphic re-encodes included)\n\n")
    for vip, act in vip_seq:
        out.write(f"  [VIP {vip:4d}] {act}\n")
    out.close()
    print(f"lifted {lifted} actions, {len(set(v for v, _ in vip_seq))} unique VIPs -> {out_path}")


if __name__ == '__main__':
    main()
