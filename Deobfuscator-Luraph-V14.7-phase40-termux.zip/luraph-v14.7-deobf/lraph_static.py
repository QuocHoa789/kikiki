#!/usr/bin/env python3
"""
Luraph v14.7 static bytecode parser (config A format)
=====================================================
Parses the VM bytecode buffer directly using the format map reverse-engineered
from the read-trace annotation (no luau execution needed).

Format (sample 1 / gsub-era config):
  header : 4 raw bytes
  stream : tagged fields, LEB128-style varints + per-file key byte interleaved
  tags   : 0xB4=string, 0x7B=opcode, 0xA1=byte-field, ... numeric tags

Usage:
  python3 lraph_static.py bytecode.bin [-o dump.txt]
"""
import struct
import sys


def leb128(buf, pos):
    """LEB128 varint: first byte = LSB. Returns (value, new_pos)."""
    val = 0
    shift = 0
    while pos < len(buf):
        b = buf[pos]
        val |= (b & 0x7F) << shift
        shift += 7
        pos += 1
        if not (b & 0x80):
            break
    return val, pos


def parse(data, verbose=True):
    """Walk the buffer producing a structure-annotated event list."""
    events = []
    pos = 0

    # 4-byte header
    header = data[:4]
    events.append(('header', header.hex(' '), 0, 4))
    pos = 4

    n_instr = 0
    n_str = 0
    const_pool = []
    instrs = []

    while pos < len(data):
        b = data[pos]
        if b == 0xB4:  # string field: tag + varint len + chars
            ln, p2 = leb128(data, pos + 1)
            # sanity: length must be plausible (< remaining)
            if p2 + ln <= len(data) and 0 < ln < 1_000_000:
                s = data[p2:p2 + ln]
                events.append(('string', ln, pos, p2 + ln - pos))
                const_pool.append(s)
                pos = p2 + ln
                n_str += 1
            else:
                events.append(('byte', b, pos, 1))
                pos += 1
        elif b == 0x7B and pos + 3 <= len(data):  # opcode: tag + 2 bytes LE
            op = int.from_bytes(data[pos+1:pos+3], 'little')
            events.append(('opcode', op, pos, 3))
            instrs.append((n_instr, op, pos))
            n_instr += 1
            pos += 3
        elif b == 0xA1:  # byte field: tag + 1 data byte
            if pos + 2 <= len(data):
                v = data[pos+1]
                events.append(('field', v, pos, 2))
                pos += 2
            else:
                events.append(('byte', b, pos, 1))
                pos += 1
        else:
            events.append(('byte', b, pos, 1))
            pos += 1

    return events, const_pool, instrs, header


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    data = open(sys.argv[1], 'rb').read()
    events, const_pool, instrs, header = parse(data)

    out = sys.stdout
    if len(sys.argv) > 3 and sys.argv[2] == '-o':
        out = open(sys.argv[3], 'w')

    out.write("; Luraph v14.7 static parse\n")
    out.write(f"; header: {header.hex(' ')}\n")
    out.write(f"; strings: {len(const_pool)}\n")
    out.write(f"; opcodes: {len(instrs)}\n\n")

    out.write("; -- constant pool --\n")
    for i, s in enumerate(const_pool):
        printable = all(32 <= c < 127 or c in (9, 10, 13) for c in s)
        if printable:
            out.write(f"  K[{i}] = {s!r}\n")
        else:
            out.write(f"  K[{i}] = <{len(s)} bytes binary> {s[:24].hex(' ')}\n")

    out.write("\n; -- instructions --\n")
    for idx, op, pos in instrs:
        out.write(f"  [{idx:3d}] OP {op:<6d} @0x{pos:05x}\n")

    # stats
    from collections import Counter
    tags = Counter(e[0] for e in events)
    out.write(f"\n; -- stats --\n")
    for k, v in sorted(tags.items()):
        out.write(f";   {k}: {v}\n")

    if out is not sys.stdout:
        out.close()
    print(f"parsed: {len(const_pool)} strings, {len(instrs)} opcodes, "
          f"{len(events)} events")


if __name__ == '__main__':
    main()
