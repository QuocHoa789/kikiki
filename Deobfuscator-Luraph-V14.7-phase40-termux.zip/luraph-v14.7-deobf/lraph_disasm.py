#!/usr/bin/env python3
"""
Luraph v14.7 VM bytecode disassembler (v1)
==========================================
Replays the read-semantic trace (annot_*.json produced from luraph_deobf --trace)
and emits a structured disassembly: constants pool + tagged instructions.

Serialization model (reverse-engineered, sample 1):
  header  : 4 raw bytes
  fields  : every field is prefixed by a TAG byte:
      0xB4 (180) : string  -> varint length + raw chars
      0x7B (123) : opcode  -> 2 bytes LE (>= 256)
      0xA1 (161) : 1-byte field
      0xC6 (198) / 0x80 (128) / 0x47 (71) : numeric constant tags
  numbers : read via buffer.readi16/readi32/readu32/readf64/readf32
"""
import json
import struct
import sys


def load_annot(path):
    return json.load(open(path))


def disasm(annot, out):
    # group into "instruction groups" starting at each tag-123 opcode fetch
    groups = []   # list of (op_value, [events])
    cur = None
    i = 0
    events = []
    # convert annotation into a flat event stream, merging string length bytes
    while i < len(annot):
        off, kind, val, nb = annot[i]
        if kind == 'readu8' and val == 180 and i + 2 < len(annot) \
                and annot[i+2][1] == 'string':
            # string field: tag + length + content
            ln = annot[i+2][3]
            events.append(('str', ln))
            i += 3
            continue
        if kind == 'readu8' and val == 123 and i + 1 < len(annot) \
                and annot[i+1][1] == 'readu16':
            events.append(('op', annot[i+1][2]))
            i += 2
            continue
        if kind == 'readu8':
            events.append(('b', val))
            i += 1
            continue
        events.append((kind.replace('read', ''), val))
        i += 1

    for kind, val in events:
        if kind == 'op':
            cur = {'op': val, 'ops': []}
            groups.append(cur)
        elif cur is not None:
            cur['ops'].append((kind, val))

    # emit
    # VM decode scheme (reverse-engineered from loader aT/NT/RT):
    #   operand byte X packs class = X % 8 (micro-op class), value = X // 8
    #   micro-op classes (from nD executor):
    #     0: GETGLOBAL/GETTABUP/CALL-setup, 1: ADD, 2: SETLIST/T,
    #     4: SETTABUP/SUB, 7: LOADN/MOVE/SETREG
    MICROP = {0: 'GTB', 1: 'ADD', 2: 'SLT', 4: 'STB', 7: 'LDN'}
    for gi, g in enumerate(groups):
        op = g['op']
        ops = g['ops']
        parts = []
        j = 0
        while j < len(ops):
            k, v = ops[j]
            if k == 'b' and v == 161 and j + 1 < len(ops):
                k2, v2 = ops[j+1]
                if k2 == 'b':
                    cls, val = v2 % 8, v2 // 8
                    mn = MICROP.get(cls, f'c{cls}')
                    parts.append(f"{mn}({val})")
                    j += 2
                    continue
                elif k2 == 'str':
                    parts.append(f"K{v2}")
                    j += 2
                    continue
            if k == 'b':
                cls, val = v % 8, v // 8
                parts.append(f"{MICROP.get(cls, f'c{cls}')}({val})")
            elif k == 'str':
                parts.append(f"K{v}")
            else:
                parts.append(f"{k}{v}")
            j += 1
        out.write(f"  [{gi:3d}] OP {op:<6d} {' '.join(parts)}\n")


def main():
    if len(sys.argv) < 2:
        print("usage: lraph_disasm.py annot_1.json [-o out.dis]")
        return
    annot = load_annot(sys.argv[1])
    if len(sys.argv) > 3 and sys.argv[2] == '-o':
        f = open(sys.argv[3], 'w')
    else:
        f = sys.stdout
    f.write("; Luraph v14.7 bytecode disassembly\n")
    disasm(annot, f)
    if f is not sys.stdout:
        f.close()


if __name__ == '__main__':
    main()
