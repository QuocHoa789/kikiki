#!/usr/bin/env python3
"""Replay the read trace -> annotated offsets (restores annot_*.json)."""
import struct, json, sys

trace, bc_path, out = sys.argv[1], sys.argv[2], sys.argv[3]
data = open(trace, encoding='utf-8', errors='replace').read()
bc = open(bc_path, 'rb').read()
raw_lines = data.split('\n')
lines = [l for l in raw_lines if l.strip()]

# join multi-line %q readstring values (Luau %q: newline = backslash + real newline)
events = []
i = 0
while i < len(lines):
    l = lines[i]
    if l.startswith('readstring "'):
        val = l[len('readstring '):]
        while not (val.endswith('"') and not val.endswith('\\"')):
            i += 1
            if i >= len(lines): break
            val += '\n' + lines[i]
        events.append(('readstring', val)); i += 1; continue
    kind, _, rest = l.partition(' ')
    events.append((kind, rest)); i += 1

def unquote(v):
    if v.startswith('"') and v.endswith('"'): v = v[1:-1]
    out_c = []; j = 0
    while j < len(v):
        c = v[j]
        if c == '\\' and j+1 < len(v):
            n = v[j+1]
            if n == 'n': out_c.append('\n'); j += 2
            elif n == 'r': out_c.append('\r'); j += 2
            elif n == 't': out_c.append('\t'); j += 2
            elif n == '"': out_c.append('"'); j += 2
            elif n == '\\': out_c.append('\\'); j += 2
            elif n == '\n': out_c.append('\n'); j += 2
            elif n.isdigit():
                d = ''
                while j+1 < len(v) and len(d) < 3 and v[j+1].isdigit():
                    d += v[j+1]; j += 1
                out_c.append(chr(int(d) & 0xff)); j += 1
            else: out_c.append(n); j += 2
        else:
            out_c.append(c); j += 1
    return ''.join(out_c)

NB = {'readu8':1,'readu16':2,'readi16':2,'readu32':4,'readi32':4,'readf64':8,'readf32':4}
pos = 0; nstr = 0; mism = 0
annot = []; pending = None
for i,(kind,rest) in enumerate(events):
    if kind == 'fromstring': continue
    if kind == 'readstring':
        if pending is None: pending = 0
        annot.append([pos,'string',f'len={pending}',pending])
        pos += pending; nstr += 1; pending = None
        continue
    try:
        val = float(rest) if kind in ('readf64','readf32') else int(rest)
    except ValueError:
        continue
    nb = NB.get(kind)
    if nb is None: continue
    seg = bc[pos:pos+nb] if pos+nb<=len(bc) else b''
    ok = True
    if kind=='readu8': ok = (seg[0] == val) if seg else False
    elif kind=='readu16': ok = (int.from_bytes(seg,'little') == val)
    elif kind in ('readu32','readi32'): ok = (int.from_bytes(seg,'little') == val)
    elif kind=='readi16': ok = (int.from_bytes(seg,'little',signed=True) == val)
    elif kind=='readf32': ok = (abs(struct.unpack('<f', seg)[0] - val) < 1e-3)
    elif kind=='readf64': ok = (abs(struct.unpack('<d', seg)[0] - val) < 1e-9)
    if not ok: mism += 1
    if kind=='readu8':
        nxt = events[i+1] if i+1 < len(events) else None
        if nxt and nxt[0]=='readstring':
            run = [val]; k = i-1
            while k >= 0 and events[k][0]=='readu8' and len(run) < 4:
                try: run.insert(0, int(events[k][1]))
                except ValueError: break
                k -= 1
            approx = len(unquote(nxt[1]).encode('latin-1', errors='replace'))
            best = None
            for kk in (1,2,3):
                if kk > len(run): break
                bs = run[-kk:]
                L = 0; sh = 0
                for b in bs:
                    L |= (b & 0x7f) << sh; sh += 7
                d = abs(L - approx)
                if best is None or d < best[0]: best = (d, L)
            pending = best[1] if best else val
    annot.append([pos,kind,val,nb])
    pos += nb
f = open(out, 'w')
json.dump(annot, f)
f.close()
print("saved", len(json.dumps(annot)), "bytes JSON to", out)
print(f"replay: strings={nstr} mismatches={mism} bytes={pos}/{len(bc)} -> {out}")
