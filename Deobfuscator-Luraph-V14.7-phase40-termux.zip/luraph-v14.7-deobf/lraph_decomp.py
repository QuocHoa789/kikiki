#!/usr/bin/env python3
"""
Luraph v14.7 pseudo-Lua decompiler (static, config A format)
============================================================
Parses the VM bytecode buffer directly and correlates constant references
with the constant pool to emit a readable pseudo-Lua listing.

Instruction model (reverse-engineered):
  TAG(0x7B) + opcode(readu16 LE)
  operands  : 0xA1-tagged packed bytes (class = byte%8, reg = byte//8)
  strings   : 0xB4 + varint len + chars  -> constant pool
  numbers   : readi16/readi32/readu32/readf64/readf32

Micro-op classes (from nD executor):
  0: GETGLOBAL/GETTABUP, 1: ADD, 2: SETLIST/T,
  4: SETTABUP/SUB, 7: LOADN/MOVE/SETREG
"""
import struct
import sys
from collections import Counter

MICROP = {0: 'GETG', 1: 'ADD', 2: 'SETL', 4: 'SETT', 7: 'LOAD'}


def leb128(buf, pos):
    val, shift = 0, 0
    while pos < len(buf):
        b = buf[pos]
        val |= (b & 0x7F) << shift
        shift += 7
        pos += 1
        if not (b & 0x80):
            break
    return val, pos


def parse(data):
    events = []
    pos = 4  # skip header
    const_pool = []
    instrs = []
    cur_op = None
    cur_operands = []

    def flush():
        nonlocal cur_op, cur_operands
        if cur_op is not None:
            instrs.append((cur_op, cur_operands))
        cur_op, cur_operands = None, []

    while pos < len(data):
        b = data[pos]
        if b == 0xB4:  # string constant
            ln, p2 = leb128(data, pos + 1)
            if p2 + ln <= len(data) and 0 < ln < 1_000_000:
                events.append(('string', len(const_pool), pos))
                const_pool.append(data[p2:p2 + ln])
                flush()
                pos = p2 + ln
                continue
            events.append(('byte', b, pos)); pos += 1
        elif b == 0x7B and pos + 3 <= len(data):
            op = int.from_bytes(data[pos+1:pos+3], 'little')
            flush()
            events.append(('opcode', op, pos))
            cur_op = (op, pos)
            pos += 3
        elif b == 0xA1 and pos + 2 <= len(data):
            v = data[pos+1]
            events.append(('operand', v, pos))
            if cur_op is not None:
                cur_operands.append(v)
            pos += 2
        else:
            events.append(('byte', b, pos)); pos += 1
    flush()
    return events, const_pool, instrs


def render_value(ki, const_pool):
    if ki < len(const_pool):
        s = const_pool[ki]
        if all(32 <= c < 127 or c in (9, 10, 13) for c in s):
            return f'"{s.decode("ascii", errors="replace")[:40]}"'
        return f'<{len(s)}B>'
    return f'K[{ki}]'


def main():
    if len(sys.argv) < 2:
        print(__doc__); return
    data = open(sys.argv[1], 'rb').read()
    events, const_pool, instrs = parse(data)

    out = sys.stdout
    if len(sys.argv) > 3 and sys.argv[2] == '-o':
        out = open(sys.argv[3], 'w')

    out.write("; Luraph v14.7 pseudo-Lua listing (static)\n")
    out.write(f"; {len(const_pool)} constants, {len(instrs)} instructions\n\n")

    out.write("; -- constants --\n")
    for i, s in enumerate(const_pool):
        if all(32 <= c < 127 or c in (9, 10, 13) for c in s):
            txt = s.decode('ascii', errors='replace')
            if len(txt) > 60:
                txt = txt[:57] + '...'
            out.write(f'  K[{i}] = "{txt}"\n')
        else:
            out.write(f"  K[{i}] = <{len(s)}B binary>\n")

    out.write("\n; -- code --\n")
    for n, ((op, pos), operands) in enumerate(instrs):
        # decode operands: class(reg)
        parts = []
        for opbyte in operands:
            cls, reg = opbyte % 8, opbyte // 8
            mn = MICROP.get(cls, f'c{cls}')
            parts.append(f"{mn}(r{reg})")
        out.write(f"  [{n:4d}] OP {op:<6d} {' '.join(parts)}\n")

    if out is not sys.stdout:
        out.close()
    print(f"listing: {len(const_pool)} constants, {len(instrs)} instructions")


OPERANDS = {}


def _collect(data):
    """Second pass: collect operand bytes per instruction."""
    events, const_pool, instrs = parse(data)
    ops = []
    n = -1
    for ev, val, pos in events:
        if ev == 'opcode':
            n += 1
            OPERANDS[n] = []
        elif ev == 'operand' and n >= 0:
            OPERANDS[n].append(val)
    return events, const_pool, instrs


if __name__ == '__main__':
    data = open(sys.argv[1], 'rb').read()
    events, const_pool, instrs = _collect(data)
    main()
