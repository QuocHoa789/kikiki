-- harness_pre.lua — Luraph deobfuscation sandbox prelude
-- Defines: R (real globals), env (sandbox env with real_globals proxy),
--          log/missing/lookup_log, LPH_DUMP (IR capture), __ROBLOX loader hook
-- Wired by lraph_all.py: __ROBLOX <- runtime/*.luau, loader source <- protected

local R = {}
-- direct references (getfenv pairs can miss in restricted envs)
R.string, R.table, R.math, R.debug = string, table, math, debug
R.print, R.pcall, R.pairs, R.ipairs = print, pcall, pairs, ipairs
R.unpack, R.select, R.next, R.type = unpack, select, next, type
R.tostring, R.tonumber, R.setmetatable, R.getmetatable = tostring, tonumber, setmetatable, getmetatable
R.rawset, R.rawget, R.rawequal, R.error = rawset, rawget, rawequal, error
R.setfenv, R.getfenv, R.loadstring = setfenv, getfenv, loadstring
R.byte, R.char, R.sub, R.rep = string.byte, string.char, string.sub, string.rep
R.gsub, R.find, R.match, R.fmt = string.gsub, string.find, string.match, string.format
R.format, R.concat, R.insert, R.remove = string.format, table.concat, table.insert, table.remove
R.floor, R.max, R.min, R.huge, R.clock = math.floor, math.max, math.min, math.huge, os.clock
R.newproxy = newproxy
R.os, R.bit32, R.coroutine = os, bit32, coroutine
for _, k in ipairs({
    "byte","clock","concat","error","find","floor","fmt","getfenv",
    "getmetatable","gsub","huge","insert","ipairs","loadstring","match","max",
    "newproxy","next","pairs","pcall","print","rawequal","rawget","rawset",
    "remove","rep","select","setfenv","setmetatable","sort","sub","tostring",
    "type","unpack","write","format","char",
}) do
    if R[k] == nil then
        local src = (_G or getfenv())[k]
        if src ~= nil then R[k] = src end
    end
end
R.print = R.print or print
R.fmt = R.fmt or string.format
R.getfenv = R.getfenv or getfenv
R.setfenv = R.setfenv or setfenv
R.loadstring = R.loadstring or loadstring

HARNESS_SRC0 = "lraph_sandbox"
__LPH_RUNTIME = __LPH_RUNTIME or {}   -- runtime version marker (set by lraph_all.py)

-- log infrastructure (used by harness_post + instrument-injected LPH_DUMP)
local LOGS = {}
local function log(s)
    LOGS[#LOGS + 1] = tostring(s)
    R.print("\0LOG " .. tostring(s))
end

local missing, lookup_log = {}, {}
local lookup_count = {}

-- the sandbox env: real globals first, missing ones logged + stubbed
local real_globals = {}
local env = setmetatable({}, {
    __index = function(t, k)
        local v = real_globals[k]
        if v == nil then
            if k ~= "_G" and k ~= "script" and k ~= "game" then
                lookup_log[#lookup_log + 1] = tostring(k)
                lookup_count[k] = (lookup_count[k] or 0) + 1
                if missing[k] == nil then missing[k] = 0 end
                missing[k] = missing[k] + 1
            end
            return nil
        end
        return v
    end,
    __newindex = function(t, k, v)
        real_globals[k] = v   -- script's globals land here (same source)
    end,
})

-- expose real stdlib through the env
for k, v in pairs(R) do
    if env[k] == nil then env[k] = v end
end
env._G = env
env.__REALGLOBALS = real_globals

-- IR capture: injected by instrument.py as LPH_DUMP(..., ...)
local DUMPS = {}
function LPH_DUMP(...)
    local parts = {}
    for i = 1, select("#", ...) do
        local v = select(i, ...)
        local t = type(v)
        if t == "table" then
            parts[i] = "T" .. i
            DUMPS[#DUMPS + 1] = v
        elseif t == "function" then
            parts[i] = "fn"
        else
            parts[i] = tostring(v)
        end
    end
    log("DUMP: " .. table.concat(parts, ",") .. " | tables=" .. #DUMPS)
    return unpack(parts)
end

-- expose the runtime tables wired by lraph_all.py:
--   __ROBLOX = { enums=..., classes=..., datatypes={...} }
if __ROBLOX_WIRE then
    __ROBLOX = __ROBLOX_WIRE
end

