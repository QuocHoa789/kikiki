-- lifted Lua source - proto #4
-- 141 instructions (linear order, control flow via labels/gotos)
::L1::
goto L76
r9 = 98
goto L5
if not (not(V[A[n]]<KA[n])) then goto L84 end
::L5::
goto L24
if not (KA[n]<V[A[n]]) then goto L7 end
::L7::
goto L125
if not (not(V[A[n]]<KA[n])) then goto L40 end
::L9::
goto L36
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
-- ??? opcode 30 (UNKNOWN)
::L16::
goto L123
-- ??? opcode 43 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 14 (UNKNOWN)
r82 = r19[r389]
-- ??? opcode 134 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
::L24::
goto L52
r4 = <upvalue table index>
::L26::
goto L113
r11 = r11 + nil
-- ??? opcode 59 (UNKNOWN)
-- ??? opcode 114 (UNKNOWN)
-- ??? opcode 15 (UNKNOWN)
-- ??? opcode 42 (UNKNOWN)
-- ??? opcode 109 (UNKNOWN)
-- ??? opcode 138 (UNKNOWN)
-- ??? opcode 131 (UNKNOWN)
::L36::
goto L96
if not (KA[n]<V[A[n]]) then goto L40 end
::L38::
goto L72
r4 = <upvalue table index>
::L40::
goto L137
if not (not(V[A[n]]<KA[n])) then goto L5 end
::L42::
goto L86
::L43::
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 52 (UNKNOWN)
r8 = nil
r9 = 91
goto L94
if not (r10 == 106) then goto L133 end
::L50::
goto L89
if not (not(V[A[n]]<KA[n])) then goto L94 end
::L52::
goto L127
r11 = upvalue_index
r12 = r6
r11 = upvalue_index(r6)
r4 = (upvalue_index(r6))
::L57::
goto L58
::L58::
goto L61
-- numeric for-loop (var r7+3, jump L48)
goto L91
::L61::
-- ??? opcode 127 (UNKNOWN)
r7 = 14
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r9 = 27
::L66::
goto L109
if not (KA[n]<V[A[n]]) then goto L137 end
::L68::
goto L9
r11 = 61
r12 = 172
r13 = 93
::L72::
goto L137  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r9 = 89
::L76::
goto L5
-- numeric for-loop (var rNone+3, jump LNone)
r3 = 910280373
r4 = <upvalue table index>
r5 = 851787187
r6 = <upvalue table index>
r7 = 106
r8 = 176
::L84::
goto L107
if not (KA[n]<V[A[n]]) then goto L113 end
::L86::
goto L112
r9 = 100
-- ??? opcode 33 (UNKNOWN)
::L89::
goto L5
if not (not(V[A[n]]<V[B[n]])) then goto L26 end
::L91::
goto L117
-- ??? opcode 52 (UNKNOWN)
if not (notV[A[n]]) then goto L42 end
::L94::
goto L57
if not (KA[n]<V[A[n]]) then goto L50 end
::L96::
goto L135
r5 = 851787187 - nil
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 99 (UNKNOWN)
-- ??? opcode 112 (UNKNOWN)
r3 = 148385591
r11 = 61 - nil
::L107::
goto L16
r9 = 70
::L109::
goto L58  -- for-loop prep (init, limit, step in regs)
::L110::
goto L113  -- for-loop prep (init, limit, step in regs)
if not (notV[A[n]]) then goto L139 end
::L112::
goto L68
::L113::
-- numeric for-loop (var r7+3, jump L3)
goto L43
if not (not(V[A[n]]<KA[n])) then goto L66 end
::L117::
goto L38
r6 = r1
::L119::
goto L52
r12 = 106
r13 = 176
r10 = (61 - nil) .. 106 .. 176
::L123::
goto L94
-- ??? opcode 52 (UNKNOWN)
::L125::
goto L139
::L127::
goto L42
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r8 = 0
r10 = upvalue_index
r11 = r1
::L133::
goto L119
if not (upvalue_index == 176) then goto L58 end
::L135::
goto L110
::L137::
goto L1
-- numeric for-loop (var r11+3, jump L115)
::L139::
goto L123
r4 = r2
goto L58
