-- lifted Lua source - proto #2
-- 5489 instructions (linear order, control flow via labels/gotos)
::L1::
goto L2415
::L2::
goto L1765
::L3::
goto L3610
r165 = r166 .. r167 .. r168
::L5::
goto L2494
r157 = 1
r154 = r155 .. r156 .. 1
::L8::
goto L4411
if not (r5 == 24) then goto L4192 end
::L10::
goto L714
r155 = r155()
r156 = r148[55]
r157 = 2
r154 = (r155()) .. r148[55] .. 2
::L15::
goto L1921
if not (r153 == 197) then goto L2146 end
::L17::
goto L811
if not (r5 == 8) then goto L460 end
::L19::
goto L4955
-- ??? opcode 52 (UNKNOWN)
r163 = r1[52]
r163 = r162[r1[52]]
r164 = r1[37]
r163 = r162[r1[52]][r1[37]]
r163 = r162[r1[52]][r1[37]] * nil
::L26::
goto L3748
r107 = r1[155]
r108 = r1[155]
r109 = r1[155]
r110 = r1[155]
r111 = r1[155]
::L32::
goto L2612
::L33::
goto L919
r161 = Z  -- loader upvalue
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
::L37::
goto L389
r165 = r82
r166 = 973662225
r165 = r82(973662225)
r160 = (r82(973662225))
::L42::
goto L1299
r165 = 1
r166 = r4[4]
r167 = r4[8]
::L46::
goto L1702
r154 = r147[8]
-- ??? opcode 162 (UNKNOWN)
::L49::
goto L4468
-- ??? opcode 52 (UNKNOWN)
r155 = r1[155]
r156 = r1[155]
r157 = r1[155]
r5 = 13
::L55::
goto L1777
::L56::
goto L1910
::L57::
goto L2913
r159 = r149
r160 = r1[155]
r161 = "StarterPlayer"
-- ??? opcode 65 (UNKNOWN)
::L62::
goto L4007
r5 = 53
::L64::
goto L4558
r176 = r4[8]
r177 = r162
r176 = r4[8](r162)
::L68::
goto L3176
if not (r151 == 119) then goto L193 end
::L70::
goto L1032
r154 = r99
r155 = r57
r155 = r57()
r156 = r148[48]
r157 = 1
r154 = (r57()) .. r148[48] .. 1
::L77::
goto L3050
r145 = r25
-- ??? opcode 79 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r145 = r2
-- ??? opcode 79 (UNKNOWN)
r144 = r141
::L88::
goto L4624
r44 = Vector2  -- global
r45 = {}
r46 = r1[165]
::L92::
goto L3797
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L95::
goto L2529
::L96::
goto L4351
::L97::
goto L351
r161 = r1[154]
r161 = r1[155][r1[154]]
r161 = r1[155][r1[154]] * nil
-- ??? opcode 101 (UNKNOWN)
::L102::
goto L4260
r167 = r4[8] % nil
r168 = 1
r169 = (r4[8] % nil)
r170 = 1
::L107::
goto L1360  -- for-loop prep (init, limit, step in regs)
r92 = r1[155]
r93 = nil
r94 = r1[155]
r95 = r1[155]
r5 = 106
::L113::
goto L3095
::L114::
goto L5233
r165 = r120
r166 = r149
r167 = r1[47]
-- ??? opcode 65 (UNKNOWN)
::L119::
goto L222
::L120::
goto L2329
r165 = r141
r166 = r1[21]
r166 = r1[155][r1[21]]
-- ??? opcode 79 (UNKNOWN)
::L125::
goto L1681
if not (r149 == 27) then goto L1133 end
::L127::
goto L56
r149 = r152
r152 = r126
r153 = r1[143]
r152 = r126(r1[143])
r150 = (r126(r1[143]))
::L133::
goto L5286
if not (not(V[A[n]]<KA[n])) then goto L746 end
::L135::
goto L2654
r120 = r1[155]
r121 = r79
-- ??? opcode 79 (UNKNOWN)
r5 = 90
::L140::
goto L4558
if not (KA[n]<V[A[n]]) then goto L2449 end
::L142::
goto L4850
if not (not(V[A[n]]<KA[n])) then goto L1675 end
::L144::
goto L4474
r167 = r1[155]
r168 = 36
::L147::
goto L3908
r163 = true
r160 = (r1[155][r1[154]] * nil) .. r162 .. true
r160 = r1[155]
::L151::
goto L3254
if not (not(V[A[n]]<KA[n])) then goto L2068 end
::L153::
goto L5054
if not (not(V[A[n]]<KA[n])) then goto L3635 end
::L155::
goto L1219
r169 = r1[129]
r170 = r4[8]
r169 = r1[129](r4[8])
::L159::
goto L786
r5 = 26
::L161::
goto L3707
if not (not(V[A[n]]<KA[n])) then goto L1295 end
::L163::
goto L1300
::L164::
goto L3773
r150 = r1[155]
r151 = r57
r151 = r57()
r152 = r148[25]
::L169::
goto L1484
r32 = r1[155]
r5 = 87
::L172::
goto L211
r150 = r1[155]
r151 = r57
r151 = r57()
::L176::
goto L2002
r145 = r141
r146 = r47
-- ??? opcode 79 (UNKNOWN)
::L180::
goto L1177
if not (r152 == 100) then goto L2298 end
::L182::
goto L2199
r158 = r1[43]
r158 = (r57())[r1[43]]
r158 = (r57())[r1[43]]["Left"]
r159 = r1[56]
r158 = (r57())[r1[43]]["Left"][r1[56]]
::L188::
goto L5230
r171 = r171(r172, r173)
if not (notV[A[n]]) then goto L1404 end
::L191::
goto L1325
if not (r152 == 44) then goto L721 end
::L193::
goto L2748
if not ((r57()) == 106) then goto L2459 end
::L195::
goto L96
r151 = 133
r152 = 13
::L198::
goto L3820  -- for-loop prep (init, limit, step in regs)
r149 = 82
::L200::
goto L3306
r161 = r56
r162 = r34
r163 = r1[59]
-- numeric for-loop (var rNone+3, jump LNone)
::L205::
goto L2622
r150 = r147[10]
-- ??? opcode 162 (UNKNOWN)
r150 = r99
r151 = r57
r151 = r57()
::L211::
goto L2674
if not (87 == 33) then goto L2346 end
::L213::
goto L2517
-- ??? opcode 52 (UNKNOWN)
r161 = r99
r162 = #r4
r163 = 9
r164 = r1[136]
r161 = #r4 .. 9 .. r1[136]
r161 = 1
r162 = 9
::L222::
goto L3456
-- numeric for-loop (var r161+3, jump L5268)
::L224::
goto L3434
r169 = r1[155]
r170 = 13
::L227::
goto L2950
r156 = r148[48](1)
r156 = not (r148[48](1))
r157 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L232::
goto L2672
::L233::
goto L4483
::L234::
-- ??? opcode 65 (UNKNOWN)
r5 = 118
::L236::
goto L2720
-- ??? opcode 31 (UNKNOWN)
r165 = r141(r1[155][r1[21]])
r166 = r1[155]
::L240::
goto L3910
::L241::
goto L1152
r158 = r1[155]
r159 = r8
r160 = not ((r148[48](1)))
::L245::
goto L3954
::L246::
goto L670
r130 = r47
r131 = r39
r132 = r129
::L250::
goto L5124
r152 = 48
::L252::
goto L3300  -- for-loop prep (init, limit, step in regs)
if not (118 == 94) then goto L2948 end
::L254::
goto L5172
r37 = r1[113]
r5 = 33
::L257::
goto L784
if not (33 == 37) then goto L2656 end
::L259::
goto L224
r162 = r148
r163 = r1[52]
r163 = 1[r1[52]]
::L263::
goto L2175
::L264::
goto L4530
if not (V[A[n]]<=KA[n]) then goto L2227 end
::L266::
goto L4959
r165 = r1[155] .. r1[155] .. 36
::L268::
goto L2867
if not (V[A[n]]<=KA[n]) then goto L2274 end
::L270::
goto L2687
r173 = 0.7209806717079436
r174 = r1[136]
r171 = r172 .. 0.7209806717079436 .. r1[136]
::L274::
goto L5398
-- ??? opcode 65 (UNKNOWN)
r157 = r1[155]
r158 = r1[110]
::L278::
goto L962
-- numeric for-loop (var rNone+3, jump LNone)
::L280::
goto L848
r152 = r1[155]
::L282::
goto L2873
-- ??? opcode 65 (UNKNOWN)
r127 = r1[155]
r128 = r14
::L286::
goto L555
::L287::
goto L4740  -- for-loop prep (init, limit, step in regs)
r142 = r141
r143 = r1[113]
-- ??? opcode 79 (UNKNOWN)
r142 = r141
::L292::
goto L1171
r128 = r1[25]
-- ??? opcode 65 (UNKNOWN)
r126 = r1[155]
::L296::
goto L2359
r5 = 71
-- numeric for-loop (var rNone+3, jump LNone)
::L299::
goto L2780
r164 = 42
r165 = r99
r166 = 366
-- ??? opcode 31 (UNKNOWN)
r169 = 284
::L305::
goto L3235
r154 = r148[63]
-- ??? opcode 162 (UNKNOWN)
::L308::
goto L696
r171 = r99
r172 = r47
r173 = 284
-- ??? opcode 65 (UNKNOWN)
r171 = r63
::L314::
goto L4084
::L315::
goto L1297
if not (not(V[A[n]]<KA[n])) then goto L462 end
::L317::
goto L3965
r126 = r1[155]
r127 = r71
r128 = "concat"
-- ??? opcode 65 (UNKNOWN)
r5 = 108
::L323::
goto L1515
r169 = r1[155]
-- numeric for-loop (var rNone+3, jump LNone)
::L326::
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 52 (UNKNOWN)
r150 = 21
r151 = 84
r152 = 21
::L331::
goto L1490  -- for-loop prep (init, limit, step in regs)
::L332::
goto L4055
if not (not(V[A[n]]<KA[n])) then goto L1698 end
::L334::
goto L689
r179 = r86
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r181 = 36
-- ??? opcode 65 (UNKNOWN)
::L343::
goto L4946
r158 = r1[37]
r157 = r1[155][r1[37]]
r157 = r1[155][r1[37]] * nil
-- ??? opcode 101 (UNKNOWN)
::L348::
goto L4037
if not (KA[n]<V[A[n]]) then goto L161 end
::L350::
goto L4250
::L351::
goto L1260
r152 = r1[155]
r153 = r1[44]
r152 = r1[155](r1[44])
::L355::
goto L127
r120 = r1[155]
r121 = Vector2
-- ??? opcode 79 (UNKNOWN)
r5 = 75
::L360::
goto L3745
r71 = r1[54]
r5 = 49
::L363::
goto L3485
r126 = r1[155]
r127 = r11
r128 = r1[111]
::L367::
goto L4588
r126 = r1[155]
r127 = r39
r128 = r1[5]
::L371::
goto L1049
-- numeric for-loop (var r172+3, jump L479)
::L373::
goto L5331
if not (not(V[A[n]]<KA[n])) then goto L2806 end
::L375::
goto L1283
r152 = r148[63]
r153 = 1
r150 = 84 .. r148[63] .. 1
::L379::
goto L4711
r144 = r141
r145 = r90
r146 = r1[155]
-- ??? opcode 65 (UNKNOWN)
::L384::
goto L681
::L385::
goto L1792
if not (notV[A[n]]) then goto L144 end
::L387::
goto L4131
if not (82 == 89) then goto L180 end
::L389::
goto L4838
r163 = r63
r164 = r148
r165 = "f"
::L393::
goto L2202
if not (V[A[n]]<=KA[n]) then goto L3289 end
::L395::
goto L5211
if not (KA[n]<=V[A[n]]) then goto L4776 end
::L397::
goto L2104
if not (49 == 65) then goto L4042 end
::L399::
goto L1732
r156 = r147[9]
r157 = 1
r154 = (r57()) .. r147[9] .. 1
::L403::
goto L3734
r40 = r1[16]
r41 = r1[155]
r42 = r1[155]
r43 = r1[155]
r5 = 6
::L409::
goto L2244
r154 = r148[22]
-- ??? opcode 162 (UNKNOWN)
::L412::
goto L3454
r156 = r148[54]
r157 = 1
r154 = (r57()) .. r148[54] .. 1
::L416::
goto L2395
::L417::
goto L3542
::L418::
goto L5254
if not (KA[n]<V[A[n]]) then goto L3111 end
::L420::
goto L2992
r145 = r141
r146 = r39
-- ??? opcode 79 (UNKNOWN)
r5 = 49
::L425::
goto L3707
r150 = r148[56]
-- ??? opcode 162 (UNKNOWN)
r149 = 92
::L429::
goto L3898
r168 = r148
r169 = r1[52]
r169 = r148[r1[52]]
::L433::
goto L653
-- numeric for-loop (var r164+3, jump L4913)
::L435::
goto L5102
if not (not(V[A[n]]<KA[n])) then goto L2722 end
::L437::
goto L4574
r5 = 38
::L439::
goto L1546
r149 = 52
r150 = r148[19]
-- ??? opcode 162 (UNKNOWN)
::L443::
goto L4537
r160 = r125
r161 = 0
r162 = 4
::L447::
goto L1245
if not (V[A[n]]<=KA[n]) then goto L5224 end
::L449::
goto L2827
if not (KA[n]<V[A[n]]) then goto L332 end
::L451::
goto L662
-- numeric for-loop (var r150+3, jump L1598)
::L453::
goto L1126
-- ??? opcode 52 (UNKNOWN)
r161 = r1[155]
r162 = 111
r163 = 272
r164 = 77
::L459::
goto L1465
::L460::
goto L2214
if not (38 == 13) then goto L5361 end
::L462::
goto L2895
if not (KA[n]<V[A[n]]) then goto L315 end
::L464::
goto L3683
if not (KA[n]<V[A[n]]) then goto L3342 end
::L466::
goto L2478
if not (not(V[A[n]]<KA[n])) then goto L3263 end
::L468::
goto L3394
if not (not(V[A[n]]<KA[n])) then goto L4982 end
::L470::
goto L5281
r150 = r148[7]
-- ??? opcode 141 (UNKNOWN)
-- ??? opcode 143 (UNKNOWN)
-- ??? opcode 70 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r149 = 9
::L477::
goto L3306
r5 = 54
goto L466
if not (r175 == 58) then goto L1083 end
::L481::
goto L873
-- ??? opcode 65 (UNKNOWN)
r5 = 126
::L484::
goto L1515
r177 = 13 % nil
r177 = (13 % nil) + nil
r172 = r1[155][((13 % nil) + nil)]
::L488::
goto L2520
::L489::
goto L891
if not (272 == 296) then goto L3687 end
::L491::
goto L2396
if not (126 == 63) then goto L897 end
::L493::
goto L4022
::L494::
goto L4539
if not (77 == 385) then goto L1681 end
::L496::
goto L4584
r168 = 630
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
r166 = r1[155] .. 630 .. r148[r1[52]]
r166 = r99
r167 = 0.9246411305714305
-- ??? opcode 31 (UNKNOWN)
::L506::
goto L1858
::L507::
goto L3969
r159 = 0
r158 = 90
::L510::
goto L2817
::L511::
goto L2095
if not (KA[n]<V[A[n]]) then goto L373 end
::L513::
goto L46
if not (126 == 23) then goto L3663 end
::L515::
goto L379
r164 = 0
r165 = 0
-- numeric for-loop (var rNone+3, jump LNone)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 45 (UNKNOWN)
-- ??? opcode 65 (UNKNOWN)
r153 = r1[155]
r154 = 61
r155 = 183
r156 = 122
::L526::
goto L2068  -- for-loop prep (init, limit, step in regs)
if not (126 == 117) then goto L778 end
::L528::
goto L2942
::L529::
goto L3100
r154 = 183 .. 122 .. 1
::L531::
goto L3820
r5 = 98
::L533::
goto L1378
r176 = ((13 % nil) + nil) .. r178 .. r86
::L535::
goto L5155
-- ??? opcode 65 (UNKNOWN)
r126 = r1[155]
r127 = r50
::L539::
goto L292
r169 = {}
r170 = r1[132]
-- numeric for-loop (var rNone+3, jump LNone)
{}[r1[132]] = r63
::L544::
goto L4731
r150 = r148[2]
-- ??? opcode 162 (UNKNOWN)
r150 = r99
r151 = r148[2]
r152 = r57
r152 = r57()
r153 = 1
r150 = r148[2] .. (r57()) .. 1
r150 = 13
r151 = 30
::L555::
goto L1212
r129 = r1[155]
r130 = r1[136]
r127 = r1[5] .. r1[155] .. r1[136]
r127 = r1[155]
goto L4695
-- ??? opcode 94 (UNKNOWN)
::L563::
-- ??? opcode 127 (UNKNOWN)
if not (KA[n]<V[A[n]]) then goto L3194 end
::L565::
goto L3041
if not (V[A[n]]<=KA[n]) then goto L3302 end
::L567::
goto L3487
r165 = r141
r166 = r1[100]
r166 = r125[r1[100]]
::L571::
goto L1757
-- numeric for-loop (var rNone+3, jump LNone)
r82 = tostring  -- global
r86 = r1[104]
r88 = {}
::L576::
goto L975
goto L5012
::L578::
r272 = B  -- loader upvalue
r166 = r125[r1[100]](0.9246411305714305, 630)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r168 = r1[136]
r165 = (r125[r1[100]](0.9246411305714305, 630)) .. 0.9246411305714305 .. r1[136]
::L587::
goto L49
r161 = 0
r162 = -1
-- ??? opcode 58 (UNKNOWN)
::L591::
goto L5196
r155 = r1[155]
r156 = 58
r157 = 175
r158 = 117
::L596::
goto L3852  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 128 (UNKNOWN)
r56 = r1[155]
r57 = nil
::L600::
goto L5090
r161 = 0
r162 = 0
r163 = 0
r164 = 0
-- ??? opcode 58 (UNKNOWN)
::L606::
goto L3992
r152 = r148[19]
r153 = 1
r150 = 30 .. r148[19] .. 1
r149 = 3
::L611::
goto L4537
-- numeric for-loop (var r150+3, jump L5481)
::L613::
goto L4299
r150 = r148[6]
-- ??? opcode 162 (UNKNOWN)
::L616::
goto L854
if not (r1[113] == 75) then goto L750 end
::L618::
goto L2386
r53 = r1[155]
r54 = r1[155]
r5 = 58
::L622::
goto L4816
r125 = r1[155]
r126 = r89
r127 = r1[169]
-- ??? opcode 65 (UNKNOWN)
r125 = r1[155]
r5 = 82
::L629::
goto L3784
if not (not(V[A[n]]<KA[n])) then goto L1358 end
::L631::
goto L4053
r154 = r1[155] .. 58 .. 175
::L633::
goto L4715
r147 = r141
r148 = r63
-- ??? opcode 79 (UNKNOWN)
r5 = 48
::L638::
goto L919
r149 = 52
r150 = {}
r151 = r1[36]
r152 = r1[39]
r151 = r1[36](r1[39])
-- ??? opcode 31 (UNKNOWN)
::L645::
goto L3860
r158 = 117[0]
r159 = r1[136]
-- ??? opcode 65 (UNKNOWN)
-- ??? opcode 31 (UNKNOWN)
r159 = 0.4545454680919647
r157 = 175(117[0], 0.4545454680919647)
r158 = 27
::L653::
goto L4460
r170 = r1[37]
r169 = {}[r1[37]]
r170 = true
-- ??? opcode 65 (UNKNOWN)
::L658::
goto L2094
r162 = 0 + nil
::L660::
goto L389
if not (not(V[A[n]]<KA[n])) then goto L5166 end
::L662::
goto L5220
if not (not(V[A[n]]<KA[n])) then goto L332 end
::L664::
goto L135
r157 = 1
r154 = r1[155] .. 58 .. 1
r154 = r141[17]
::L668::
goto L3511
if not (KA[n]<V[A[n]]) then goto L5107 end
::L670::
goto L4865
r154 = r99
r155 = nil
r155 = nil()
::L674::
goto L1338
r160 = r1[155]
r161 = r1[182]
r161 = (nil())[r1[182]]
r162 = r1[182]
::L679::
goto L3086
if not (not(V[A[n]]<KA[n])) then goto L1719 end
::L681::
goto L1608
r144 = r141
r145 = r1[155]
-- ??? opcode 79 (UNKNOWN)
::L685::
goto L1192
r167 = 0.6761756414049878
r168 = r1[136]
r165 = (r125[r1[100]](0.9246411305714305, 630)) .. 0.6761756414049878 .. r1[136]
::L689::
goto L236
if not (KA[n]<V[A[n]]) then goto L1698 end
::L691::
goto L3822
r53 = 7609290
r5 = 81
::L694::
goto L4816
r149 = 100
::L696::
goto L140
-- numeric for-loop (var r150+3, jump L1052)
::L698::
goto L5121
r161 = 1
-- numeric for-loop (var rNone+3, jump LNone)
::L701::
-- numeric for-loop (var rNone+3, jump LNone)
r156 = r141[12]
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r154 = (nil()) .. r141[12] .. 1
::L706::
goto L2363
r156 = 38
::L708::
goto L2956
r160 = 100
r161 = (nil())
r162 = "RunService"
::L712::
goto L5271
if not (0.4545454680919647 == 175) then goto L3852 end
::L714::
goto L3752
-- ??? opcode 128 (UNKNOWN)
r5 = 23
::L717::
goto L2409
if not (23 == 1) then goto L3009 end
goto L317
if not (r178 == 101) then goto L4887 end
::L721::
goto L2079
if not (100 == 5) then goto L125 end
::L723::
goto L2988
::L724::
goto L403
r123 = r1[1]
r122 = r31[r1[1]]
r5 = 51
::L728::
goto L2720
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
r157 = r1[155]
::L732::
goto L1759
r162 = "RunService"(0)
r163 = r1[136]
r160 = (nil()) .. ("RunService"(0)) .. r1[136]
::L736::
goto L3838
r149 = 26
::L738::
goto L4699
r5 = 98
goto L919
-- numeric for-loop (var rNone+3, jump LNone)
::L742::
-- ??? opcode 152 (UNKNOWN)
-- ??? opcode 52 (UNKNOWN)
r150 = r63[54]
-- ??? opcode 162 (UNKNOWN)
::L746::
goto L4720
if not (not(V[A[n]]<KA[n])) then goto L3109 end
::L748::
goto L2603
if not (98 == 64) then goto L257 end
::L750::
goto L539
if not (r1[113] == 90) then goto L3220 end
::L752::
goto L1990
if not (not(V[A[n]]<KA[n])) then goto L782 end
::L754::
goto L1105
r150 = r63[40]
-- ??? opcode 162 (UNKNOWN)
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = r63[40]
r153 = 1
::L762::
goto L4453
r121 = r1[99]
r122 = r1[90]
r1[155][r1[99]] = r1[90]
::L766::
goto L4560
r154 = r63[65]
-- ??? opcode 162 (UNKNOWN)
::L769::
goto L2572
::L770::
goto L1297
r110 = r1[127]
r5 = 114
::L773::
goto L2735
-- ??? opcode 162 (UNKNOWN)
r149 = 2
::L776::
goto L435
if not (114 == 43) then goto L4093 end
::L778::
goto L4300
if not (114 == 80) then goto L3941 end
::L780::
goto L3579
if not (KA[n]<V[A[n]]) then goto L3635 end
::L782::
goto L153
if not (not(V[A[n]]<KA[n])) then goto L2075 end
::L784::
goto L1832
if not (V[A[n]]<=KA[n]) then goto L4906 end
::L786::
goto L1207
r168 = r1[136]({}[r1[37]])
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r167 = 0.6761756414049878((r1[136]({}[r1[37]])), {}[r1[37]])
r168 = 11
r166 = (r125[r1[100]](0.9246411305714305, 630))((0.6761756414049878((r1[136]({}[r1[37]])), {}[r1[37]])), 11)
::L793::
goto L1503
r152 = r16
r153 = r1[144]
r153 = r1[113][r1[144]]
r154 = r1[136]
::L798::
goto L5016
r171 = 0
r172 = 255
r173 = 1
::L802::
goto L3840
r144 = r99
r145 = r140
r146 = r141
r146 = r141()
r147 = r1[136]
r144 = r140 .. (r141()) .. r1[136]
r144 = r99
r145 = r141
::L811::
goto L5433
r154 = r1[136][15]
-- ??? opcode 162 (UNKNOWN)
goto L2363
r171 = r1[155]
r172 = r1[155]
r173 = 74
r174 = 230
::L819::
goto L4800
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = r63[39]
::L824::
goto L1497
r154 = r63[67]
-- ??? opcode 162 (UNKNOWN)
r154 = r1[155]
r155 = nil
r155 = nil()
r156 = r63[67]
r157 = 1
::L832::
goto L631
r142 = r141
r143 = tostring
-- ??? opcode 79 (UNKNOWN)
::L836::
goto L3618
-- ??? opcode 52 (UNKNOWN)
r150 = r63[64]
-- ??? opcode 162 (UNKNOWN)
r149 = 50
::L841::
goto L4537
r160 = (nil())
::L843::
goto L4713
if not (KA[n]<V[A[n]]) then goto L1824 end
::L845::
goto L1685
r170 = r1[61]
-- ??? opcode 65 (UNKNOWN)
::L848::
goto L2563
r140 = r1[155]
r141 = r1[155]
r5 = 84
::L852::
goto L1546
if not ((nil()) == 89) then goto L2455 end
::L854::
goto L4178
r150 = r99
r151 = nil
r151 = nil()
r152 = r63[6]
r153 = 1
r150 = (nil()) .. r63[6] .. 1
r150 = r63[33]
-- ??? opcode 162 (UNKNOWN)
r150 = r99
r151 = nil
r151 = nil()
r152 = r63[33]
::L867::
goto L3196
::L868::
goto L4369
-- ??? opcode 31 (UNKNOWN)
r170 = 0.8666666746139526
r168 = 11({}[r1[37]], 0.8666666746139526)
r163 = (11({}[r1[37]], 0.8666666746139526))
::L873::
goto L4585
r176 = (0.6761756414049878((r1[136]({}[r1[37]])), {}[r1[37]]))
r177 = ((r125[r1[100]](0.9246411305714305, 630))((0.6761756414049878((r1[136]({}[r1[37]])), {}[r1[37]])), 11))
r176 = (0.6761756414049878((r1[136]({}[r1[37]])), {}[r1[37]]))(((r125[r1[100]](0.9246411305714305, 630))((0.6761756414049878((r1[136]({}[r1[37]])), {}[r1[37]])), 11)))
r171 = ((0.6761756414049878((r1[136]({}[r1[37]])), {}[r1[37]]))(((r125[r1[100]](0.9246411305714305, 630))((0.6761756414049878((r1[136]({}[r1[37]])), {}[r1[37]])), 11))))
::L878::
goto L5331
r157 = 1
r154 = (nil()) .. r63[67] .. 1
::L881::
goto L451
if not (KA[n]<V[A[n]]) then goto L4018 end
::L883::
goto L2981
r160 = nil
::L885::
goto L1463
r70 = error  -- global
r71 = r1[155]
r72 = r1[155]
goto L3762
if not (not(V[A[n]]<KA[n])) then goto L3803 end
::L891::
goto L3392
r149 = 91
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = r63[66]
::L897::
goto L4943
if not (84 == 96) then goto L491 end
::L899::
goto L3537
if not (V[A[n]]<=KA[n]) then goto L3157 end
::L901::
goto L5292
if not (not(V[A[n]]<KA[n])) then goto L3969 end
::L903::
goto L5203
r153 = 2
r150 = (nil()) .. r63[66] .. 2
r150 = 55
r151 = 283
r152 = 38
goto L1921  -- for-loop prep (init, limit, step in regs)
::L910::
-- ??? opcode 94 (UNKNOWN)
r158 = (nil())[27]
-- ??? opcode 79 (UNKNOWN)
::L913::
goto L2956
if not (notV[A[n]]) then goto L3159 end
::L915::
goto L1089
if not (KA[n]<V[A[n]]) then goto L4111 end
::L917::
goto L489
if not (KA[n]<V[A[n]]) then goto L919 end
::L919::
goto L4311
if not (KA[n]<V[A[n]]) then goto L2315 end
::L921::
goto L1850
r122 = r1[155]
r5 = 36
::L924::
goto L2720
-- ??? opcode 79 (UNKNOWN)
r141 = 25
::L927::
goto L2112
r153 = 2
r150 = 283 .. 38 .. 2
r150 = r63[62]
-- ??? opcode 162 (UNKNOWN)
r149 = 1
::L933::
goto L4742
::L934::
goto L3097
if not (not(V[A[n]]<KA[n])) then goto L2419 end
::L936::
goto L2851
r152 = r1[136][7]
r153 = 2
r150 = 283 .. r1[136][7] .. 2
r150 = 24
::L941::
goto L195
r163 = r1[136]
r160 = (nil()) .. ("RunService"(0)) .. r1[136]
::L944::
goto L4635
r162 = r1[144]
r162 = 1[r1[144]]
r163 = r1[136]
-- ??? opcode 65 (UNKNOWN)
r161 = r81
r162 = r1[155]
-- numeric for-loop (var rNone+3, jump LNone)
::L952::
goto L988
r154 = r63[61]
-- ??? opcode 162 (UNKNOWN)
::L955::
goto L1921
-- ??? opcode 43 (UNKNOWN)
::L957::
goto L1431
r152 = r63[13]
r153 = 1
r150 = 283 .. r63[13] .. 1
r149 = 125
::L962::
goto L5061
r158 = (nil())[(nil())[27]]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
-- ??? opcode 65 (UNKNOWN)
::L969::
goto L4077
r164 = 0.27272728085517883
r162 = r1[155](r1[136], 0.27272728085517883)
r163 = 122
r164 = 232
r165 = 52
::L975::
goto L2907  -- for-loop prep (init, limit, step in regs)
r89 = r1[155]
r90 = r1[155]
r91 = r1[155]
::L979::
goto L4707
r149 = 14
r150 = r99
r151 = r63[35]
r152 = nil
r152 = nil()
r153 = 2
r150 = r63[35] .. (nil()) .. 2
::L987::
goto L1719
::L988::
goto L2538
r162 = (r1[155](r1[136], 0.27272728085517883))(122)
r162 = not ((r1[155](r1[136], 0.27272728085517883))(122))
r163 = r1[136]
-- ??? opcode 65 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
r155 = r1[34]
r151 = r61[r1[34]]
::L996::
goto L2393
::L997::
goto L4713
r140 = r1[173]
r131 = Vector2[r1[173]]
r5 = 64
::L1001::
goto L3878
r150 = r63[45]
-- ??? opcode 162 (UNKNOWN)
::L1004::
goto L4819
if not (not(V[A[n]]<KA[n])) then goto L3527 end
::L1006::
goto L2425
r156 = r63[50]
r157 = 2
r154 = r1[34] .. r63[50] .. 2
::L1010::
goto L4332
-- ??? opcode 128 (UNKNOWN)
::L1012::
goto L1302
-- numeric for-loop (var rNone+3, jump LNone)
r169 = r1[155]
r170 = r1[155]
r171 = r1[155]
r172 = 39
r173 = 65
r174 = 19
::L1020::
goto L1432
-- ??? opcode 52 (UNKNOWN)
::L1022::
goto L3996
if not (232 == 82) then goto L494 end
::L1024::
goto L3415
::L1025::
goto L2626
::L1026::
goto L2784
r163 = r81[r1[136]]
r163 = r81[r1[136]]["Scale"]
r164 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L1031::
goto L4593
::L1032::
goto L211
r152 = r1[155]
r153 = r1[155]
r154 = "new"
-- ??? opcode 65 (UNKNOWN)
r152 = 25
r153 = r1[155]
r154 = r1[155]
::L1040::
goto L3899
if not (not(V[A[n]]<KA[n])) then goto L2817 end
::L1042::
goto L507
r141 = 1060116490
r143 = 28
::L1045::
goto L750
r154 = r1[34] .. r63[50] .. 2
goto L451
if not (r178 == 135) then goto L2646 end
::L1049::
goto L5157
-- ??? opcode 65 (UNKNOWN)
r5 = 69
goto L1515
if not (KA[n]<V[A[n]]) then goto L2292 end
::L1054::
goto L305
r150 = r1[155]
r151 = nil
r151 = nil()
::L1058::
goto L4839
r168 = r1[155]
r169 = r1[61]
r169 = r81[r1[136]]["Scale"][r1[61]]
::L1062::
goto L845
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 44
::L1065::
goto L668
-- numeric for-loop (var r156+3, jump L3241)
::L1067::
goto L1240
r150 = r1[155]
r151 = nil
r151 = nil()
::L1071::
goto L2351
r159 = r89
r160 = r1[76]
r161 = r63[50]
::L1075::
goto L1538
::L1076::
goto L4280
::L1077::
goto L955
r165 = 1
r166 = r1[124]
r167 = r1[159]
r168 = r1[102]
::L1082::
goto L155
::L1083::
goto L1963
if not (r175 == 39) then goto L371 end
::L1085::
goto L3106
r161 = r63[50]
r160 = r1[76](r63[50])
r161 = r1[136]
::L1089::
goto L4761
r169 = r65
-- ??? opcode 30 (UNKNOWN)
::L1092::
goto L3159
if not (44 == 93) then goto L8 end
::L1094::
goto L933
if not (44 == 83) then goto L2561 end
::L1096::
goto L3316
r152 = {}
r147 = {}
r151 = 120
::L1100::
goto L3296
-- ??? opcode 79 (UNKNOWN)
r142 = 1060116490
r143 = r1[104]
-- ??? opcode 79 (UNKNOWN)
::L1105::
goto L437
::L1106::
goto L819
-- ??? opcode 31 (UNKNOWN)
r171 = r1[155](39)
r166 = (r1[155](39))
::L1110::
goto L4445
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r167 = r1[136]
-- ??? opcode 79 (UNKNOWN)
::L1118::
goto L1146
r147 = r1[155]
r148 = r1[155]
r149 = r1[155]
r150 = r1[155]
r151 = 61
::L1124::
goto L193
-- ??? opcode 68 (UNKNOWN)
::L1126::
goto L3792
::L1127::
goto L2468
r176 = r1[155]
r177 = (r1[155](39))
r178 = r65
r179 = r1[136]
r176 = (r1[155](39)) .. r65 .. r1[136]
::L1133::
goto L5155
if not (r1[155] == 62) then goto L191 end
::L1135::
goto L5432
r177 = r26
r178 = r1[136]
-- ??? opcode 33 (UNKNOWN)
r177 = r26(r1[136], r1[136])
r171 = (r26(r1[136], r1[136]))
::L1141::
goto L2520
r160 = r89
r161 = r1[76]
r160 = r89(r1[76])
r155 = (r89(r1[76]))
::L1146::
goto L1065
r166 = r1[104]
r167 = r1[76]
r168 = r1[155]
::L1150::
goto L3385
if not (not(V[A[n]]<KA[n])) then goto L466 end
::L1152::
goto L4572
r147 = r1[155]
r148 = r1[155]
r149 = r1[173]
-- ??? opcode 65 (UNKNOWN)
r5 = 115
goto L32
if not (r1[136] == 486) then goto L4802 end
::L1160::
goto L2926
r168 = 51
::L1162::
goto L3908
r33[r34] = r35
r28 = r33
r5 = 74
::L1166::
goto L1031
r156 = r63[50]()
r157 = 2
r154 = (r89(r1[76])) .. (r63[50]()) .. 2
::L1170::
goto L1921
::L1171::
goto L1433
r143 = r34
-- ??? opcode 79 (UNKNOWN)
r142 = 1060116490
::L1175::
goto L2435
if not (not(V[A[n]]<KA[n])) then goto L4343 end
::L1177::
goto L3304
r5 = 74
::L1179::
goto L133
r161 = 13
r162 = 97
r163 = 84
::L1183::
goto L4766
r163 = r25
r164 = r64
r164 = r64()
r165 = "\":(%d+)[:\\r\\"
r163 = r25((r64()), "\":(%d+)[:\\r\\")
r163 = (r25((r64()), "\":(%d+)[:\\r\\")) + nil
r164 = r1[155]
r165 = (r141())
::L1192::
goto L3717
r144 = r1[155]
r5 = 40
::L1195::
goto L3707
if not (KA[n]<V[A[n]]) then goto L1976 end
::L1197::
goto L4791
r141 = 1060116490 / nil
-- ??? opcode 79 (UNKNOWN)
r5 = 31
::L1201::
goto L3878
r166 = r1[76]
::L1203::
goto L1635
r163 = 6
-- ??? opcode 58 (UNKNOWN)
r160 = r1[155]
::L1207::
goto L600
::L1208::
goto L3376
-- numeric for-loop (var rNone+3, jump LNone)
r76 = r12
r77 = 2048
::L1212::
goto L3275
r152 = 17
::L1214::
goto L5088  -- for-loop prep (init, limit, step in regs)
r157 = r1[52]
r157 = (r89(r1[76]))[r1[52]]
r158 = r1[37]
r157 = (r89(r1[76]))[r1[52]][r1[37]]
::L1219::
goto L1423
r146 = r1[155]
r5 = 29
::L1222::
goto L919
::L1223::
goto L674
r171 = r1[155]
-- ??? opcode 31 (UNKNOWN)
r172 = 39(65)
r173 = 0.34075997016204335
::L1228::
goto L3933
r162 = 97 * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L1232::
goto L259
r154 = r1[155][44]
-- ??? opcode 141 (UNKNOWN)
-- ??? opcode 143 (UNKNOWN)
-- ??? opcode 70 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
::L1238::
goto L3454
if not (29 == 2) then goto L2487 end
::L1240::
goto L2048
-- ??? opcode 52 (UNKNOWN)
r156 = nil
r157 = r1[155]
r158 = 100
::L1245::
goto L3354
r163 = 0
r164 = 0
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
r158 = r1[155]
::L1251::
goto L4576
if not (not(V[A[n]]<KA[n])) then goto L5155 end
::L1253::
goto L5130
-- numeric for-loop (var rNone+3, jump LNone)
r142 = (1060116490 / nil)
r143 = r29
::L1257::
goto L1100
-- ??? opcode 65 (UNKNOWN)
r5 = 57
::L1260::
goto L5274
r126 = r1[155]
r127 = r1[127]
r128 = r1[122]
-- ??? opcode 65 (UNKNOWN)
::L1265::
goto L3737
::L1266::
goto L4635
-- ??? opcode 52 (UNKNOWN)
::L1268::
goto L477
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 64
::L1271::
goto L2735
r122 = r1[155]
r123 = r29
r124 = r1[31]
::L1275::
goto L1257
r162 = r1[154]
r162 = r1[155][r1[154]]
r162 = r1[155][r1[154]] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L1281::
goto L4733
if not (not(V[A[n]]<KA[n])) then goto L4075 end
::L1283::
goto L4615
if not (KA[n]<V[A[n]]) then goto L2806 end
::L1285::
goto L2028
-- numeric for-loop (var rNone+3, jump LNone)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
r106 = r1[155]
::L1293::
goto L26
if not (KA[n]<V[A[n]]) then goto L5046 end
::L1295::
goto L3573
if not (KA[n]<V[A[n]]) then goto L5105 end
::L1297::
goto L4288
-- numeric for-loop (var r156+3, jump L1633)
::L1299::
goto L2416
::L1300::
goto L222
-- numeric for-loop (var rNone+3, jump LNone)
::L1302::
goto L107
r6 = r1[155]
r7 = r1[155]
r8 = r1[155]
::L1306::
goto L2252
r177 = 18
::L1308::
goto L1582  -- for-loop prep (init, limit, step in regs)
r41 = r1[35]
r5 = 45
::L1311::
goto L2244
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 94
goto L2735
if not (KA[n]<V[A[n]]) then goto L4443 end
::L1316::
goto L2463
-- ??? opcode 58 (UNKNOWN)
r159 = r1[155]
r160 = -0.125
::L1320::
goto L2014
if not (KA[n]<V[A[n]]) then goto L4379 end
::L1322::
goto L4860
r162 = 579
r163 = 93
::L1325::
goto L222  -- for-loop prep (init, limit, step in regs)
::L1326::
goto L308
-- numeric for-loop (var r165+3, jump L5118)
::L1328::
goto L1020
r164 = r65
-- ??? opcode 30 (UNKNOWN)
::L1331::
goto L658
r151 = 100
r165 = r1[52]
r165 = r65[r1[52]]
r165 = r65[r1[52]] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L1338::
goto L1494
r156 = r1[155][3]
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r154 = (r89(r1[76])) .. r1[155][3] .. r1[155]
::L1343::
goto L451
if not (not(V[A[n]]<KA[n])) then goto L660 end
::L1345::
goto L95
r158 = r16
r159 = r1[136]
r156 = r1[155] .. r16 .. r1[136]
r156 = 107
::L1350::
goto L1362
if not (not(V[A[n]]<KA[n])) then goto L1736 end
::L1352::
goto L1818
if not (579 == 214) then goto L3336 end
::L1354::
goto L2257
if not (notV[A[n]]) then goto L1160 end
::L1356::
goto L3003
-- ??? opcode 65 (UNKNOWN)
::L1358::
goto L4917
-- numeric for-loop (var r162+3, jump L5145)
::L1360::
goto L1730
-- numeric for-loop (var r168+3, jump L2172)
::L1362::
goto L4016
if not (not(V[A[n]]<KA[n])) then goto L2060 end
::L1364::
goto L4476
r149 = 4
r150 = r99
r151 = r1[155][8]
r152 = nil
::L1369::
goto L2474
::L1370::
goto L3784
r150 = r99
r151 = nil
r151 = nil()
r152 = r1[155][6]
r153 = 2
r150 = (nil()) .. r1[155][6] .. 2
r149 = 51
::L1378::
goto L3144
if not (94 == 89) then goto L3832 end
::L1380::
goto L3367
r165 = r1[155]
r166 = 107
r167 = -0.125[r16]
::L1384::
goto L1934
::L1385::
goto L4668
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
r156 = 80
r157 = 197
r158 = 39
::L1393::
goto L1065  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L1399::
goto L3820
-- ??? opcode 31 (UNKNOWN)
r162 = r1[117]
r160 = -0.125(13, r1[117])
r155 = (-0.125(13, r1[117]))
::L1404::
goto L1708
-- numeric for-loop (var r164+3, jump L3675)
::L1406::
goto L3115
r171 = r99
-- ??? opcode 31 (UNKNOWN)
r172 = (39(65))(0.34075997016204335)
::L1410::
goto L3397
::L1411::
goto L2869
r146 = r65
::L1413::
goto L1931
r158 = r1[155]
r159 = r1[155]
r160 = 17
r161 = 409
::L1418::
goto L3233
r166 = r1[155]
r167 = r65
r168 = r1[155]
-- ??? opcode 65 (UNKNOWN)
::L1423::
goto L4594
r157 = 197 * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 141 (UNKNOWN)
-- ??? opcode 143 (UNKNOWN)
-- ??? opcode 70 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r151 = 108
::L1431::
goto L899
::L1432::
goto L1183
::L1433::
goto L371  -- for-loop prep (init, limit, step in regs)
r126 = r1[155]
r127 = r1[155]
r128 = r1[133]
::L1437::
goto L4509
-- ??? opcode 128 (UNKNOWN)
r116 = r1[155]
r117 = r1[155]
r118 = nil
r119 = r1[155]
r5 = 104
::L1444::
goto L4558
if not (104 == 64) then goto L1887 end
::L1446::
goto L5175
if not (r65 == 97) then goto L2986 end
::L1448::
goto L3161
if not ((197 * nil) == 37) then goto L3148 end
::L1450::
goto L1823
if not (KA[n]<V[A[n]]) then goto L4980 end
::L1452::
goto L4889
::L1453::
goto L2288
-- ??? opcode 68 (UNKNOWN)
::L1455::
goto L5113
if not (KA[n]<=V[A[n]]) then goto L1141 end
::L1457::
goto L2131
::L1458::
goto L4223
r116 = r1[97]
r5 = 39
::L1461::
goto L4558
if not (KA[n]<V[A[n]]) then goto L4742 end
::L1463::
goto L488
if not (V[A[n]]<=KA[n]) then goto L565 end
::L1465::
goto L5341
::L1466::
goto L1358  -- for-loop prep (init, limit, step in regs)
if not (409 == 60) then goto L5463 end
::L1468::
goto L2233
::L1469::
goto L1297  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 52 (UNKNOWN)
::L1471::
goto L1124
if not (108 == 61) then goto L68 end
::L1473::
goto L4519
if not (not(V[A[n]]<KA[n])) then goto L4683 end
::L1475::
goto L3817
-- ??? opcode 107 (UNKNOWN)
r167 = 1
::L1478::
goto L4107  -- for-loop prep (init, limit, step in regs)
r146 = r18
-- ??? opcode 79 (UNKNOWN)
r5 = 33
::L1482::
goto L133
if not (KA[n]<V[A[n]]) then goto L1281 end
::L1484::
goto L1458
r153 = 2
r150 = 108 .. r1[155][6] .. 2
r150 = r1[155][24]
-- ??? opcode 162 (UNKNOWN)
r150 = r99
::L1490::
goto L4644
-- numeric for-loop (var r150+3, jump L418)
::L1492::
goto L5387
if not (80 == 72) then goto L3107 end
::L1494::
goto L3866
::L1495::
goto L1683
if not (V[A[n]]<=KA[n]) then goto L3661 end
::L1497::
goto L4489
r153 = 1
r150 = 108 .. r1[155][6] .. 1
r150 = r1[155][8]
::L1501::
goto L4910
if not (KA[n]<V[A[n]]) then goto L3882 end
::L1503::
goto L4846
r167 = r4[4]
-- ??? opcode 82 (UNKNOWN)
-- ??? opcode 107 (UNKNOWN)
r167 = 1
::L1508::
goto L286
r150 = r1[155][38]
-- ??? opcode 162 (UNKNOWN)
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = r1[155][38]
::L1515::
goto L4674
if not (33 == 126) then goto L3781 end
::L1517::
goto L367
::L1518::
goto L3828
if not (KA[n]<V[A[n]]) then goto L3480 end
::L1520::
goto L4494
if not (not(V[A[n]]<KA[n])) then goto L1406 end
::L1522::
goto L2809
::L1523::
goto L4365
::L1524::
goto L2411
::L1525::
goto L451
::L1526::
goto L2006
r160 = 80
r161 = r1[144]
r161 = (197 * nil)[r1[144]]
r162 = r1[136]
r159 = 80 .. (197 * nil)[r1[144]] .. r1[136]
r159 = r1[47]
r159 = 80[r1[47]]
r160 = r1[155]
r161 = 98
goto L1322
if not (80[r1[47]] == 221) then goto L3600 end
::L1538::
goto L3651
r159 = 80[r1[47]](r1[155], 98)
r157 = (80[r1[47]](r1[155], 98))
r159 = 51
r160 = (80[r1[47]](r1[155], 98))
r161 = r1[76]
-- ??? opcode 65 (UNKNOWN)
r159 = r1[155]
::L1546::
goto L1526
if not (33 == 77) then goto L2670 end
::L1548::
goto L832
r167 = r1[21]
-- ??? opcode 65 (UNKNOWN)
::L1551::
goto L1681
::L1552::
goto L4238
if not (KA[n]<V[A[n]]) then goto L3440 end
::L1554::
goto L1010
r2 = r1[50]
r5 = 57
::L1557::
goto L3448
-- ??? opcode 52 (UNKNOWN)
::L1559::
goto L3046
r161 = (-0.125(13, r1[117]))[r1[76]]
r162 = r1[176]
-- ??? opcode 65 (UNKNOWN)
::L1563::
goto L769
r50 = r1[25]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 4 (UNKNOWN)
-- ??? opcode 54 (UNKNOWN)
-- ??? opcode 18 (UNKNOWN)
-- ??? opcode 71 (UNKNOWN)
r51 = r1[152]
r51 = r31[r1[152]]
r52 = 114825436
::L1574::
goto L618
r168 = r1[155]
r169 = 1366594817
r168 = r1[155](1366594817)
r163 = (r1[155](1366594817))
::L1579::
goto L3810
::L1580::
goto L4129
r151 = 89
::L1582::
goto L1683
-- numeric for-loop (var r175+3, jump L719)
goto L1469
if not (KA[n]<V[A[n]]) then goto L2909 end
::L1586::
goto L2966
r168 = r1[155]
r169 = r1[52]
r169 = (r1[155](1366594817))[r1[52]]
::L1590::
goto L2923
r147 = {}
r145 = {}
r147 = (1060116490 / nil)
r148 = r14
-- ??? opcode 79 (UNKNOWN)
::L1596::
goto L2136
if not (not(V[A[n]]<KA[n])) then goto L2124 end
goto L4513
if not (not(V[A[n]]<KA[n])) then goto L4136 end
::L1600::
goto L4095
r150 = (1060116490 / nil)[3]
-- ??? opcode 162 (UNKNOWN)
r150 = 27
r151 = 73
r152 = 18
::L1606::
goto L3395  -- for-loop prep (init, limit, step in regs)
if not (KA[n]<V[A[n]]) then goto L5042 end
::L1608::
goto L1612
r150 = r14[26]
-- ??? opcode 162 (UNKNOWN)
r149 = 21
::L1612::
goto L1719
if not (KA[n]<=V[A[n]]) then goto L3622 end
::L1614::
goto L5379
::L1615::
goto L1998
r147 = r112
r148 = r61
r149 = {}
{}[3009181429] = 1018292838
{}[416419418] = 346848665
{}[1206092505] = 252184675
{}[739165830] = 2067906798
{}[2999896545] = 1371368108
-- ??? opcode 65 (UNKNOWN)
goto L2558
::L1626::
-- ??? opcode 103 (UNKNOWN)
r154 = r61[30]
-- ??? opcode 162 (UNKNOWN)
::L1629::
goto L1921
if not (not(V[A[n]]<KA[n])) then goto L3620 end
::L1631::
goto L425
if not (not(V[A[n]]<KA[n])) then goto L3820 end
goto L5082
if not (KA[n]<V[A[n]]) then goto L4535 end
::L1635::
goto L1495
-- ??? opcode 128 (UNKNOWN)
r167 = r1[155]
r168 = r1[155]
r5 = 94
::L1640::
goto L2656
-- ??? opcode 31 (UNKNOWN)
-- ??? opcode 79 (UNKNOWN)
::L1643::
goto L1065
if not (V[A[n]]<=KA[n]) then goto L4507 end
goto L3653
if not (not(V[A[n]]<KA[n])) then goto L3880 end
::L1647::
goto L2262
r170 = r1[155]
r171 = r115
-- numeric for-loop (var rNone+3, jump LNone)
if not (V[A[n]]<=KA[n]) then goto L447 end
::L1652::
goto L881
if not (KA[n]<V[A[n]]) then goto L4207 end
::L1654::
goto L3360
r150 = r99
r151 = r61[7]
r152 = nil
r152 = nil()
r153 = 1
r150 = r61[7] .. (nil()) .. 1
::L1661::
goto L3819
r15 = 6666
r16 = r1[45]
r5 = 65
::L1665::
goto L264
r160 = r99
r161 = r1[151]
r162 = r1[155]
r163 = (-0.125(13, r1[117]))
r162 = r1[155]((-0.125(13, r1[117])))
::L1671::
goto L941
-- ??? opcode 162 (UNKNOWN)
r175 = 101
r176 = 173
::L1675::
goto L1306
if not (not(V[A[n]]<KA[n])) then goto L901 end
::L1677::
goto L1950
r154 = (-0.125(13, r1[117])) .. 80 .. (80[r1[47]](r1[155], 98))
r154 = r61[27]
-- ??? opcode 162 (UNKNOWN)
::L1681::
goto L1524
-- numeric for-loop (var r161+3, jump L1158)
::L1683::
goto L49
if not (r61[7] == 100) then goto L3168 end
::L1685::
goto L4138
r150 = r61[25]
-- ??? opcode 162 (UNKNOWN)
r149 = 2
::L1689::
goto L843
goto L1253
if not (V[A[n]]<=KA[n]) then goto L1643 end
::L1692::
goto L4362
r151 = r61[37]
r152 = nil
r152 = nil()
::L1696::
goto L4808
if not (V[A[n]]<=KA[n]) then goto L2714 end
::L1698::
goto L2527
if not (KA[n]<V[A[n]]) then goto L1736 end
::L1700::
goto L1350
if not (65 == 23) then goto L5200 end
::L1702::
goto L4880
-- ??? opcode 33 (UNKNOWN)
r167 = r4[4]
-- ??? opcode 33 (UNKNOWN)
r167 = r4[2]
-- ??? opcode 33 (UNKNOWN)
::L1708::
goto L1723
::L1709::
goto L3852
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
if not (notV[A[n]]) then goto L4594 end
::L1713::
goto L1722
if not (65 == 26) then goto L3707 end
::L1715::
goto L420
::L1716::
goto L1463
-- ??? opcode 65 (UNKNOWN)
r5 = 89
::L1719::
goto L919
if not (KA[n]<V[A[n]]) then goto L1961 end
::L1721::
goto L979
::L1722::
goto L1012
::L1723::
goto L4939
r167 = r4[4]
-- ??? opcode 82 (UNKNOWN)
r167 = r4[2]
-- ??? opcode 33 (UNKNOWN)
-- ??? opcode 107 (UNKNOWN)
r167 = 1
::L1730::
goto L1326  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 52 (UNKNOWN)
::L1732::
goto L1179
r164 = r58
r164 = r58()
r162 = (r1[155]((-0.125(13, r1[117]))))((-0.125(13, r1[117])), (r58()))
::L1736::
goto L4780
if not (KA[n]<V[A[n]]) then goto L4558 end
::L1738::
goto L2391
r158 = r1[49]
r155 = r61[r1[49]]
r5 = 71
::L1742::
goto L1777
if not (71 == 35) then goto L4988 end
::L1744::
goto L3693
r154 = r112[14]
-- ??? opcode 162 (UNKNOWN)
::L1747::
goto L3820
::L1748::
goto L2565
r142 = r1[155]
r143 = 75
::L1751::
goto L750
if not ((r58()) == 183) then goto L4008 end
::L1753::
goto L987
r31 = r1[125]
r33 = r1[172]
r32 = r1[125][r1[172]]
::L1757::
goto L5390
-- ??? opcode 79 (UNKNOWN)
::L1759::
goto L1681
r158 = r1[155]
r159 = 0.5
r160 = 3
::L1763::
goto L587
if not (r1[155] == 112) then goto L2790 end
::L1765::
goto L1517
-- ??? opcode 52 (UNKNOWN)
r150 = r1[155]
r151 = nil
r151 = nil()
::L1770::
goto L3209
r101 = iscclosure  -- global
::L1772::
goto L1285
::L1773::
goto L2582
r154 = r1[155]
r155 = nil
r155 = nil()
::L1777::
goto L399
if not (not(V[A[n]]<KA[n])) then goto L3738 end
::L1779::
goto L2525
r126 = r1[155]
r127 = r1[50]
r128 = r1[81]
-- ??? opcode 65 (UNKNOWN)
r5 = 18
::L1785::
goto L3113
if not (not(V[A[n]]<KA[n])) then goto L3144 end
::L1787::
goto L3786
if not (KA[n]<V[A[n]]) then goto L2372 end
::L1789::
goto L1001
r167 = r1[100]
-- ??? opcode 65 (UNKNOWN)
::L1792::
goto L1681
r154 = r99
r155 = nil
r155 = nil()
r156 = r112[3]
r157 = 1
::L1798::
goto L2445
r165 = r99
-- ??? opcode 31 (UNKNOWN)
r168 = 0.5
::L1802::
goto L578
r145 = (1060116490 / nil)
r146 = r100
-- ??? opcode 79 (UNKNOWN)
r145 = (1060116490 / nil)
::L1807::
goto L3450
r153 = 2
r150 = (nil()) .. (nil()) .. 2
r149 = 17
::L1811::
goto L1457
::L1812::
goto L2387
if not (not(V[A[n]]<KA[n])) then goto L3395 end
::L1814::
goto L4956
r156 = r61[70]
r157 = 2
r154 = (nil()) .. r61[70] .. 2
::L1818::
goto L5088
r120 = r1[155]
r121 = r62
-- ??? opcode 79 (UNKNOWN)
r5 = 46
::L1823::
goto L4558
::L1824::
goto L5192
if not (KA[n]<V[A[n]]) then goto L4982 end
::L1826::
goto L468
r127 = r1[155]
r128 = r22
r129 = r1[83]
::L1830::
goto L2820
r166 = 94
::L1832::
goto L2563  -- for-loop prep (init, limit, step in regs)
if not (KA[n]<V[A[n]]) then goto L2075 end
::L1834::
goto L3793
-- numeric for-loop (var r152+3, jump L5086)
::L1836::
goto L1747
::L1837::
goto L1753
-- ??? opcode 52 (UNKNOWN)
r5 = 8
::L1840::
goto L1777
r169 = r1[137]
r169 = (-0.125(13, r1[117]))[r1[137]]
r170 = r1[137]
-- ??? opcode 65 (UNKNOWN)
goto L2563
r164 = r1[155]
r165 = r1[158]
r166 = r1[155]
r167 = (-0.125(13, r1[117]))
::L1850::
goto L1709
if not (not(V[A[n]]<KA[n])) then goto L2315 end
::L1852::
goto L2402
r157 = 2[r1[155]]
r158 = r1[136]
-- ??? opcode 65 (UNKNOWN)
r156 = r1[155]
r151 = 1
::L1858::
goto L899
r168 = 0.5((-0.125(13, r1[117]))[r1[137]])
r169 = true
r166 = (-0.125(13, r1[117])) .. (0.5((-0.125(13, r1[117]))[r1[137]])) .. true
::L1862::
goto L4381
-- ??? opcode 128 (UNKNOWN)
::L1864::
goto L1905
r156 = r1[155]
r157 = 0
r158 = 247
r159 = 0
r160 = 152
::L1870::
goto L4546
r168 = r1[155]
r169 = (-0.125(13, r1[117]))["NextUnitVector"]
r170 = r1[18]
-- ??? opcode 65 (UNKNOWN)
::L1875::
goto L2563
r126 = r1[155]
r127 = r48
r128 = r1[94]
::L1879::
goto L535
if not (8 == 59) then goto L2082 end
::L1881::
goto L1311
r149 = 105
r150 = r112
r151 = r1[78]
goto L4254
if not (r1[155] == 13) then goto L1446 end
::L1887::
goto L576
if not (8 == 41) then goto L4058 end
::L1889::
goto L119
r162 = 247
r161 = r1[151](247)
r162 = r1[70]
::L1893::
goto L147
r154 = r99
r155 = r61[61]
r156 = nil
::L1897::
goto L1166
r132 = 7609290 % nil
-- ??? opcode 82 (UNKNOWN)
r132 = (7609290 % nil) / nil
-- ??? opcode 79 (UNKNOWN)
r131 = r1[155]
::L1903::
goto L3118
r164 = 55
::L1905::
goto L2867
r76 = r1[17]
r77 = r1[155]
r78 = r1[155]
::L1909::
goto L531
::L1910::
goto L2068
r156 = 77
r157 = (1060116490 / nil)
r158 = r1[68]
::L1914::
goto L3534
r168 = r1[155]
r169 = r1[142]
r169 = (-0.125(13, r1[117]))[r1[142]]
r170 = r1[142]
-- ??? opcode 65 (UNKNOWN)
r168 = r1[155]
::L1921::
goto L1840
-- numeric for-loop (var r150+3, jump L4198)
::L1923::
goto L2
r122 = r1[155]
r123 = r1[104]
r124 = r1[34]
-- ??? opcode 65 (UNKNOWN)
r5 = 68
::L1929::
goto L5274
if not (KA[n]<V[A[n]]) then goto L5264 end
::L1931::
goto L4610
-- ??? opcode 52 (UNKNOWN)
r5 = 65
::L1934::
goto L1463
r168 = r1[136]
r165 = ((-0.125(13, r1[117])) .. (0.5((-0.125(13, r1[117]))[r1[137]])) .. true) .. (-0.125(13, r1[117])) .. r1[136]
r165 = r99
r166 = r1[155]
r167 = 152
::L1940::
goto L2838
r127 = "assert"
-- ??? opcode 65 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r126 = error
r127 = r1[135]
::L1950::
goto L3854
if not (KA[n]<V[A[n]]) then goto L901 end
::L1952::
goto L3066
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 27
::L1955::
goto L668
r151 = r1[78]()
r152 = r61[34]
r153 = 1
r150 = (r1[78]()) .. r61[34] .. 1
r149 = 83
::L1961::
goto L3194
if not (KA[n]<V[A[n]]) then goto L679 end
::L1963::
goto L4127
r157 = r61
r158 = r1[52]
r158 = r61[61][r1[52]]
r159 = r1[37]
r158 = r61[61][r1[52]][r1[37]]
r159 = r1[136]
-- ??? opcode 65 (UNKNOWN)
-- ??? opcode 31 (UNKNOWN)
r159 = 0.2222222238779068
r157 = r61(r61[61][r1[52]][r1[37]], 0.2222222238779068)
r156 = (r61(r61[61][r1[52]][r1[37]], 0.2222222238779068))
r151 = 91
::L1976::
goto L3295
if not (not(V[A[n]]<KA[n])) then goto L4481 end
::L1978::
goto L4010
-- numeric for-loop (var r167+3, jump L814)
goto L5161
r175 = 68
r176 = 135
r177 = 67
::L1984::
goto L3767  -- for-loop prep (init, limit, step in regs)
r150 = r61[46]
-- ??? opcode 162 (UNKNOWN)
r150 = r1[155]
r151 = nil
r151 = nil()
::L1990::
goto L2802
r143 = 113
r140 = 388640511
::L1993::
goto L750
::L1994::
goto L97
r150 = r1[155]
r151 = nil
r151 = nil()
::L1998::
goto L606
r150 = r99
r151 = nil
r151 = nil()
::L2002::
goto L5372
r152 = r112[13]
r153 = 1
r150 = (nil()) .. r112[13] .. 1
::L2006::
goto L694
r154 = r99
r155 = nil
r155 = nil()
::L2010::
goto L1814
r161 = r1[70] .. (-0.125(13, r1[117])) .. 55
r161 = 82
r162 = 674
::L2014::
goto L3671
r161 = 1
r162 = 0
r163 = 3
::L2018::
goto L728
r165 = 1
r166 = r1[102]
r167 = r1[179]
r168 = r1[106]
::L2023::
goto L4101
r155 = r81
r156 = r1[155]
r157 = r1[157]
r157 = r1[45][r1[157]]
::L2028::
goto L227
r154 = r99
r155 = nil
r155 = nil()
r156 = r112[14]
r157 = 1
::L2034::
goto L529
r165 = r1[155]
r166 = 1
r167 = 0.2222222238779068
r168 = r112[14]
r169 = 152
r167 = 0.2222222238779068(r112[14], 152)
r168 = r1[136]
goto L3
::L2043::
-- ??? opcode 101 (UNKNOWN)
r154 = r1[155]
r155 = nil
r155 = nil()
r156 = r61[44]
::L2048::
goto L2792
::L2049::
goto L3388
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 65
::L2052::
goto L668
r145 = (1060116490 / nil)
r146 = r21
-- ??? opcode 79 (UNKNOWN)
r5 = 123
::L2057::
goto L4587
if not (r1[136] == 137) then goto L3321 end
::L2059::
goto L3701
::L2060::
goto L3243
r157 = r1[155]
r158 = r1[40]
r158 = (nil())[r1[40]]
::L2064::
goto L4827
r173 = 556
r174 = r1[136]
r171 = ((39(65))(0.34075997016204335)) .. 556 .. r1[136]
::L2068::
goto L3387
-- numeric for-loop (var r154+3, jump L2580)
::L2070::
goto L2059
r150 = r61[37]
-- ??? opcode 162 (UNKNOWN)
r150 = r99
::L2074::
goto L1692
::L2075::
goto L4162
if not (KA[n]<V[A[n]]) then goto L435 end
::L2077::
goto L5252
if not (KA[n]<V[A[n]]) then goto L2084 end
::L2079::
goto L240
r179 = (((39(65))(0.34075997016204335)) .. 556 .. r1[136])[1]
-- ??? opcode 162 (UNKNOWN)
::L2082::
goto L1582
if not (123 == 31) then goto L4852 end
::L2084::
goto L770
if not (not(V[A[n]]<KA[n])) then goto L4963 end
::L2086::
goto L4270
r154 = r61[3]
-- ??? opcode 162 (UNKNOWN)
::L2089::
goto L451
r5 = 8
::L2091::
goto L460
-- ??? opcode 31 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
::L2094::
-- numeric for-loop (var rNone+3, jump LNone)
::L2095::
goto L433
r19 = r1[134]
r19 = r13[r1[134]]
r20 = r1[33]
r21 = r13["defer"]
::L2100::
goto L3971
r158 = r1[108]
r156 = r61[r1[108]]
r5 = 122
::L2104::
goto L3222
::L2105::
goto L2617
r154 = r61[68]
-- ??? opcode 162 (UNKNOWN)
::L2108::
goto L1490
r154 = r99
r155 = nil
r155 = nil()
::L2112::
goto L5422
if not (KA[n]<=V[A[n]]) then goto L4357 end
::L2114::
goto L3430
r150 = r61[1]
-- ??? opcode 162 (UNKNOWN)
r149 = 56
::L2118::
goto L3194
r127 = r1[155]
r128 = r18
r129 = r1[107]
::L2122::
goto L2958
if not ((nil()) == 79) then goto L4685 end
::L2124::
goto L2205
if not (KA[n]<V[A[n]]) then goto L1175 end
::L2126::
goto L3435
r142 = (1060116490 / nil)
r143 = r1[97]
-- ??? opcode 79 (UNKNOWN)
r5 = 77
::L2131::
goto L1546
r160 = 56
r161 = (nil())
r162 = r1[76]
-- ??? opcode 65 (UNKNOWN)
::L2136::
goto L1065
r5 = 79
::L2138::
goto L919
if not (not(V[A[n]]<KA[n])) then goto L2084 end
::L2140::
goto L2077
-- ??? opcode 52 (UNKNOWN)
r160 = r99
r161 = r1[155]
::L2144::
goto L1889
if not (KA[n]<V[A[n]]) then goto L449 end
::L2146::
goto L2246
r154 = r99
r155 = r112[15]
r156 = nil
r156 = nil()
::L2151::
goto L664
-- ??? opcode 128 (UNKNOWN)
::L2153::
goto L88
r25 = r1[85]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
r26 = r9[r26]
r27 = r1[167]
r28 = r1[155]
r29 = nil
r30 = r1[155]
r31 = r1[155]
::L2165::
goto L169
if not (KA[n]<V[A[n]]) then goto L451 end
::L2167::
goto L245
r164 = r1[70]
-- ??? opcode 121 (UNKNOWN)
::L2170::
goto L3814
-- ??? opcode 65 (UNKNOWN)
goto L2986
r172 = nil
-- ??? opcode 30 (UNKNOWN)
::L2175::
goto L1360
r164 = r1[37]
r163 = 3[r1[37]]
r164 = r1[136]
-- ??? opcode 65 (UNKNOWN)
-- ??? opcode 31 (UNKNOWN)
::L2181::
goto L969
r149 = 111
r150 = r1[155]
r151 = nil
r151 = nil()
::L2186::
goto L2891
r145 = (1060116490 / nil)
r146 = r22
-- ??? opcode 79 (UNKNOWN)
r145 = (1060116490 / nil)
r146 = r62
r147 = {}
::L2193::
goto L3593
::L2194::
goto L4120
r62 = r1[105]
r63 = r1[168]
r63 = r61[r1[168]]
r64 = r1[114]
::L2199::
goto L4276
::L2200::
goto L3029
r5 = 106
::L2202::
goto L1463
r163 = 3[r1[37]](r1[136], r1[155])
if not (notV[A[n]]) then goto L1328 end
::L2205::
goto L1076
r165 = r1[154]
r165 = r1[136][r1[154]]
r165 = r1[136][r1[154]] * nil
::L2209::
goto L2365
r179 = (((39(65))(0.34075997016204335)) .. 556 .. r1[136])[1](r180, 36)
r180 = r1[155]
r181 = 152
r180 = r1[155](152)
::L2214::
goto L3287
r154 = r1[155]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r155 = r112[15]()
r156 = r61[32]
r157 = 2
r154 = (r112[15]()) .. r61[32] .. 2
::L2225::
goto L2764
if not (106 == 84) then goto L2429 end
::L2227::
goto L3783
if not (V[A[n]]<=KA[n]) then goto L3283 end
::L2229::
goto L1661
r95 = r1[23]
-- numeric for-loop (var rNone+3, jump LNone)
r100 = r1[155]
::L2233::
goto L4871
r162 = r1[52]
r162 = 2[r1[52]]
r162 = 2[r1[52]] * nil
-- ??? opcode 101 (UNKNOWN)
::L2238::
goto L5400
::L2239::
goto L2487
r176 = 135(67)
r170 = (135(67))
::L2242::
goto L371
r5 = 66
::L2244::
goto L3448
if not (V[A[n]]<=KA[n]) then goto L3805 end
::L2246::
goto L1308
::L2247::
goto L2691
r145 = (1060116490 / nil)
r146 = r31[r1[152]]
-- ??? opcode 79 (UNKNOWN)
r5 = 87
::L2252::
goto L133
r9 = r1[155]
r10 = r1[155]
r11 = r1[155]
r12 = r1[155]
::L2257::
goto L3525
r163 = r1[155]
r164 = r1[108]
r165 = r1[173]
-- ??? opcode 65 (UNKNOWN)
::L2262::
goto L3046
r154 = r61[70]
-- ??? opcode 162 (UNKNOWN)
::L2265::
goto L5088
if not (87 == 88) then goto L3976 end
::L2267::
goto L350
r13 = r1[5]
r12 = r1[155][r1[5]]
::L2270::
goto L3629
-- ??? opcode 52 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 64
::L2274::
goto L2656
r123 = r1[155]
r124 = r1[113]
r125 = r1[51]
-- ??? opcode 65 (UNKNOWN)
r123 = r1[155]
r124 = r1[155]
r5 = 102
::L2282::
goto L460
::L2283::
goto L4200
r143 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r142 = r1[155]
r5 = 77
::L2288::
goto L1450
r60 = r1[32]
r59 = r1[155][r1[32]]
r60 = r1[155]
::L2292::
goto L5417
r154 = r99
r155 = r61[45]
r156 = nil
r156 = nil()
r157 = 1
::L2298::
goto L4617
if not (111 == 98) then goto L387 end
::L2300::
goto L4640
-- ??? opcode 96 (UNKNOWN)
r128 = r1[136]
-- numeric for-loop (var rNone+3, jump LNone)
::L2304::
goto L246
-- ??? opcode 162 (UNKNOWN)
r150 = r99
r151 = r61[14]
r152 = nil
::L2309::
goto L4965
r147 = r1[155]
r148 = error
r149 = r1[173]
-- ??? opcode 65 (UNKNOWN)
::L2314::
goto L738
::L2315::
goto L5394
if not (not(V[A[n]]<KA[n])) then goto L1473 end
::L2317::
goto L3477
-- numeric for-loop (var rNone+3, jump LNone)
r166 = nil
r167 = r1[90]
::L2321::
goto L4947
r150 = r61[14] .. nil .. 1
::L2323::
goto L1508
if not (V[A[n]]<=KA[n]) then goto L2034 end
::L2325::
goto L4569
-- ??? opcode 52 (UNKNOWN)
r150 = r1[155][11]
-- ??? opcode 162 (UNKNOWN)
::L2329::
goto L2716
r140 = r31[r1[152]]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r142 = 508
r143 = r65
r141 = (1060116490 / nil)(508, r65)
-- ??? opcode 79 (UNKNOWN)
::L2340::
goto L4335
if not (KA[n]<V[A[n]]) then goto L1552 end
::L2342::
goto L1554
r144 = r1[155]
-- numeric for-loop (var rNone+3, jump LNone)
r144 = r1[155]((1060116490 / nil))
::L2346::
goto L1748
if not (77 == 87) then goto L2984 end
::L2348::
goto L1024
goto L2421
if not (nil == 122) then goto L3581 end
::L2351::
goto L3695
r152 = error[4]
r153 = 1
r150 = r61[14] .. error[4] .. 1
goto L198
r165 = r99
r166 = r1[155]
r167 = r4[r1[108]]
::L2359::
goto L2663
r5 = 16
goto L3542
::L2362::
-- numeric for-loop (var rNone+3, jump LNone)
::L2363::
goto L1077
-- numeric for-loop (var r150+3, jump L3265)
::L2365::
goto L1
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r151 = 98
::L2369::
goto L3827
r154 = error[50]
-- ??? opcode 162 (UNKNOWN)
::L2372::
goto L451
if not (not(V[A[n]]<KA[n])) then goto L1461 end
::L2374::
goto L2991
::L2375::
goto L4596
r158 = 39
::L2377::
goto L2817
r1[155][r62] = r1[155]
r121 = r1[80]
-- ??? opcode 41 (UNKNOWN)
::L2381::
goto L762
-- ??? opcode 52 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
r161 = r1[155]()
r162 = r1[155]
::L2386::
goto L5314
::L2387::
goto L802
r158 = r99
r159 = r1[65]
r160 = nil
::L2391::
goto L1085
if not (not(V[A[n]]<KA[n])) then goto L4558 end
::L2393::
goto L4581
r5 = 122
::L2395::
goto L2780
::L2396::
goto L611
r164 = error
r165 = r1[52]
r165 = r99[r1[52]]
r166 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L2402::
goto L2954
::L2403::
goto L2309
r165 = r1[155]
-- ??? opcode 31 (UNKNOWN)
r166 = r1[136](r4[r1[108]])
::L2407::
goto L685
if not (122 == 114) then goto L3878 end
::L2409::
goto L3960
if not (122 == 118) then goto L1092 end
::L2411::
goto L3576
r150 = r1[155]
r151 = nil
r151 = nil()
::L2415::
goto L957
::L2416::
goto L4026
-- ??? opcode 52 (UNKNOWN)
r5 = 17
::L2419::
goto L2780
if not (not(V[A[n]]<KA[n])) then goto L1195 end
::L2421::
goto L4227
r154 = r1[155]
r155 = nil
r155 = nil()
::L2425::
goto L5475
if not (KA[n]<V[A[n]]) then goto L3527 end
::L2427::
goto L3517
if not (17 == 1) then goto L4143 end
::L2429::
goto L2733
r126 = r1[155]
r127 = r1[16]
r128 = r1[12]
-- ??? opcode 65 (UNKNOWN)
r126 = r1[155]
::L2435::
goto L2503
r143 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r142 = ((1060116490 / nil)(508, r65))
::L2439::
goto L3458
r79 = r1[48]
r80 = r1[155]
r81 = r1[155]
r82 = r1[155]
r5 = 96
::L2445::
goto L3334
r154 = (nil()) .. (nil()) .. 1
::L2447::
goto L3395
-- ??? opcode 52 (UNKNOWN)
::L2449::
goto L3996
r150 = r1[155][13]
-- ??? opcode 162 (UNKNOWN)
if not (r1[172] == 500548151) then goto L4653 end
::L2453::
goto L172
-- ??? opcode 65 (UNKNOWN)
::L2455::
goto L1582
if not ((nil()) == 54) then goto L2865 end
::L2457::
goto L4735
if not (KA[n]<V[A[n]]) then goto L1785 end
::L2459::
goto L4315
if not ((nil()) == 120) then goto L1471 end
::L2461::
goto L5242
if not (r1[136] == 118) then goto L3908 end
::L2463::
goto L1721
r154 = r99
r155 = r1[155][5]
r156 = nil
r156 = nil()
::L2468::
goto L3998
-- ??? opcode 52 (UNKNOWN)
r150 = r99
r151 = nil
r151 = nil()
r152 = error[20]
::L2474::
goto L927
r152 = error[20]()
r153 = 1
r150 = (nil()) .. (error[20]()) .. 1
::L2478::
goto L435
r164 = r1[52]
r164 = r1[65][r1[52]]
r164 = r1[65][r1[52]] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L2484::
goto L2590
r3 = r1[140]
r5 = 68
::L2487::
goto L3448
if not (68 == 121) then goto L1238 end
::L2489::
goto L2300
r120 = r1[155]
r121 = r1[17]
-- ??? opcode 79 (UNKNOWN)
r5 = 28
::L2494::
goto L4558
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 31 (UNKNOWN)
-- ??? opcode 79 (UNKNOWN)
::L2498::
goto L5428
r170 = r1[72]
-- ??? opcode 65 (UNKNOWN)
::L2501::
goto L1557
-- ??? opcode 52 (UNKNOWN)
::L2503::
goto L5479
r127 = r1[155]
r128 = r1[118]
-- ??? opcode 65 (UNKNOWN)
r5 = 9
::L2508::
goto L1369
::L2509::
goto L3513
r150 = (nil()) .. (error[20]()) .. 1
r150 = 21
r151 = 80
r152 = 59
::L2514::
goto L4449
r153 = 1
r150 = 80 .. 59 .. 1
::L2517::
goto L3011
r30 = r1[155]["readu32"]
r5 = 12
::L2520::
goto L211
-- numeric for-loop (var r173+3, jump L5109)
::L2522::
goto L3166
r154 = error[72]
-- ??? opcode 162 (UNKNOWN)
::L2525::
goto L3411
if not (KA[n]<V[A[n]]) then goto L3738 end
::L2527::
goto L5347
::L2528::
goto L3227
::L2529::
goto L164
r161 = error
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
r162 = nil[r1[155]]
r163 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L2538::
goto L2745
r165 = r1[155]
r166 = r1[100]
r166 = nil[r1[100]]
::L2542::
goto L1789
r177 = r1[165]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
-- ??? opcode 33 (UNKNOWN)
r180 = (r1[155](152))(152, r182)
r177 = r1[136] .. ((((39(65))(0.34075997016204335)) .. 556 .. r1[136])[1](r180, 36)) .. ((r1[155](152))(152, r182))
::L2552::
goto L4331
if not (12 == 12) then goto L211 end
::L2554::
goto L1836
r154 = r1[155][5] .. (nil()) .. 1
r154 = error[34]
-- ??? opcode 162 (UNKNOWN)
::L2558::
goto L1921
r147 = r1[155]
r5 = 124
::L2561::
goto L4093
if not (124 == 66) then goto L5274 end
::L2563::
goto L1271
-- numeric for-loop (var r164+3, jump L2724)
::L2565::
goto L1557
-- ??? opcode 52 (UNKNOWN)
r152 = r1[144]
(80 .. 59 .. 1)[r1[144]] = r1[173]
r152 = r1[155]
r153 = r1[163]
r152 = r1[155](r1[163])
::L2572::
goto L2695
-- numeric for-loop (var r150+3, jump L1584)
::L2574::
goto L326
r160 = (nil())
r159 = r1[65]((nil()))
r160 = r1[153]
r161 = r1[136]
r158 = (r1[65]((nil()))) .. r1[153] .. r1[136]
goto L3043
if not (KA[n]<V[A[n]]) then goto L151 end
::L2582::
goto L4291
r142 = ((1060116490 / nil)(508, r65))
r143 = r1[167]
-- ??? opcode 79 (UNKNOWN)
::L2586::
goto L4933
r154 = r99
r155 = nil
r155 = nil()
::L2590::
goto L3444
-- ??? opcode 52 (UNKNOWN)
r160 = nil
r151 = 30
::L2594::
goto L4713
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r155 = nil
r155 = nil()
r156 = error[17]
::L2603::
goto L5
if not (KA[n]<V[A[n]]) then goto L3109 end
::L2605::
goto L3686
-- ??? opcode 162 (UNKNOWN)
r164 = error
r165 = r1[154]
r165 = ((r1[65]((nil()))) .. r1[153] .. r1[136])[r1[154]]
r166 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L2612::
goto L2954
r112 = r1[155]
r113 = r1[155]
r5 = 59
r114 = nil
::L2617::
goto L2735
r163 = ((r1[65]((nil()))) .. r1[153] .. r1[136])
r164 = 1802046596
r163 = ((r1[65]((nil()))) .. r1[153] .. r1[136])(1802046596)
::L2621::
goto L1903
::L2622::
goto L4713
if not (V[A[n]]) then goto L3814 end
::L2624::
goto L5044
if not (not(V[A[n]]<KA[n])) then goto L2457 end
::L2626::
goto L1370
r33 = {}
r34 = r1[136]
-- ??? opcode 162 (UNKNOWN)
r34 = r1[136]
r35 = r1[59]
::L2632::
goto L1162
r154 = error[15]
-- ??? opcode 162 (UNKNOWN)
::L2635::
goto L3454
-- ??? opcode 52 (UNKNOWN)
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = error[16]
r153 = 1
r150 = (nil()) .. error[16] .. 1
r150 = error[35]
-- ??? opcode 162 (UNKNOWN)
r149 = 43
::L2646::
goto L1719
if not (r1[136] == 68) then goto L3767 end
::L2648::
goto L2209
::L2649::
goto L4744
if not (KA[n]<V[A[n]]) then goto L5385 end
goto L3466
-- ??? opcode 133 (UNKNOWN)
goto L418
::L2654::
r15 = B  -- loader upvalue
if not (KA[n]<V[A[n]]) then goto L746 end
::L2656::
goto L3024
if not (59 == 94) then goto L748 end
::L2658::
goto L4555
r7 = r1[148]
r8 = r1[62]
r9 = r1[121]
r5 = 23
::L2663::
goto L4806
r166 = r1[136](r4[r1[108]])
r167 = r1[19]
-- ??? opcode 65 (UNKNOWN)
::L2667::
goto L4582
-- ??? opcode 58 (UNKNOWN)
error[35][error[17]] = 1
::L2670::
goto L1834
if not (23 == 84) then goto L3520 end
::L2672::
goto L5074
r5 = 60
::L2674::
goto L2780
r152 = r1[155][10]
r153 = 2
r150 = (nil()) .. r1[155][10] .. 2
r149 = 24
::L2679::
goto L3144
if not (KA[n]<V[A[n]]) then goto L4297 end
::L2681::
goto L5358
r164 = 1802046596 * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r164 = error
r165 = (((r1[65]((nil()))) .. r1[153] .. r1[136])(1802046596))["X"]
::L2687::
goto L4861
r123 = r1[155]
r124 = r1[167]
r125 = r1[96]
::L2691::
goto L233
r120 = r1[64]
r117 = r61[r1[64]]
r5 = 113
::L2695::
goto L4558
r153 = r1[144]
r1[155][10][r1[144]] = ((nil()) .. r1[155][10] .. 2)
-- ??? opcode 31 (UNKNOWN)
r155 = (nil())(error[17])
r156 = r1[23]
r157 = r1[96]
r158 = 0
r159 = 3
r160 = 0.3125
r161 = 8
-- ??? opcode 58 (UNKNOWN)
r158 = r1[96]
r159 = 0
r160 = 0
r161 = 0
r162 = 0
::L2712::
goto L1316
if not (113 == 49) then goto L3218 end
::L2714::
goto L1208
if not (error == 191) then goto L4971 end
::L2716::
goto L114
r150 = r99
r151 = nil
r151 = nil()
::L2720::
goto L4498
if not (V[A[n]]<=KA[n]) then goto L268 end
::L2722::
goto L724
if not (KA[n]<V[A[n]]) then goto L752 end
goto L1364
if not (r1[19] == 199) then goto L4190 end
::L2726::
goto L1914
-- numeric for-loop (var rNone+3, jump LNone)
r121 = r1[155]
r5 = 66
::L2730::
goto L5274
r150 = error[66]
-- ??? opcode 162 (UNKNOWN)
::L2733::
goto L4742
::L2734::
goto L2933
::L2735::
goto L1994
if not (66 == 37) then goto L4709 end
::L2737::
goto L1268
r158 = ((nil())(error[17]))
r157 = r1[96](((nil())(error[17])))
r158 = r1[65]
r159 = r1[136]
r156 = (r1[96](((nil())(error[17])))) .. r1[65] .. r1[136]
r156 = r1[155]
r157 = 94
::L2745::
goto L3043
r161 = r1[155]
r151 = 89
::L2748::
goto L852
r150 = error[71]
-- ??? opcode 162 (UNKNOWN)
r149 = 27
::L2752::
goto L191
if not (error == 40) then goto L3001 end
::L2754::
goto L3429
r126 = r1[64]
r127 = r1[85]
r128 = r1[112]
::L2758::
goto L3426
-- ??? opcode 65 (UNKNOWN)
r5 = 56
::L2761::
goto L660
r168 = true
r165 = (r1[136](r4[r1[108]])) .. r1[19] .. true
::L2764::
goto L222
r154 = error[42]
-- ??? opcode 162 (UNKNOWN)
::L2767::
goto L1490
r166 = (r1[136](r4[r1[108]]))(r1[19])
r167 = r1[19]
r168 = r1[136]
r165 = ((r1[136](r4[r1[108]]))(r1[19])) .. r1[19] .. r1[136]
r165 = r1[56]
::L2773::
goto L3312
if not (V[A[n]]<=KA[n]) then goto L1223 end
::L2775::
goto L1106
::L2776::
goto L334
r157 = 94 * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L2780::
goto L899
if not (V[A[n]]<=KA[n]) then goto L4884 end
::L2782::
goto L2946
r151 = 100
::L2784::
goto L315
r151 = 126
r157 = r1[154]
r157 = r1[155][r1[154]]
r158 = r1[37]
r157 = r1[155][r1[154]][r1[37]]
::L2790::
goto L2776
if not (r1[37] == 15) then goto L1763 end
::L2792::
goto L4378
r157 = 2
r154 = ((nil())(error[17])) .. r1[155] .. 2
::L2795::
goto L3454
r150 = error[69]
-- ??? opcode 162 (UNKNOWN)
r149 = 21
::L2799::
goto L1606
if not (KA[n]<V[A[n]]) then goto L4391 end
::L2801::
goto L2118
::L2802::
goto L1590
r152 = error[46]
r153 = 2
r150 = 126 .. error[46] .. 2
::L2806::
goto L4923
if not (KA[n]<V[A[n]]) then goto L1631 end
::L2808::
goto L2962
::L2809::
goto L4994
r171 = r1[155]
-- ??? opcode 31 (UNKNOWN)
r172 = nil(556)
::L2813::
goto L270
r168 = r1[64]
r169 = r1[72]
r169 = (((r1[65]((nil()))) .. r1[153] .. r1[136])(1802046596))[r1[72]]
::L2817::
goto L2498
if not (KA[n]<V[A[n]]) then goto L1040 end
::L2819::
goto L2091
::L2820::
goto L660
-- ??? opcode 65 (UNKNOWN)
r5 = 32
::L2823::
goto L4297
if not (r1[19] == 105) then goto L2563 end
::L2825::
goto L1058
r166 = 9
::L2827::
goto L3810  -- for-loop prep (init, limit, step in regs)
r164 = r1[160]
r158 = r1[155][r1[160]]
::L2830::
goto L4984
r154 = r1[155]
r155 = nil
r155 = nil()
r156 = error[15]
r157 = 2
::L2836::
goto L3746
if not (not(V[A[n]]<KA[n])) then goto L780 end
::L2838::
goto L3170
r166 = 9(r1[19])
r167 = r1[153]
r168 = r1[136]
r165 = (9(r1[19])) .. r1[153] .. r1[136]
::L2843::
goto L3523
if not (32 == 58) then goto L4816 end
::L2845::
goto L691
r155 = (nil())["Scale"]
r155 = (nil())["Scale"] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r155 = error
::L2851::
goto L3755
r154 = error[49]
-- ??? opcode 162 (UNKNOWN)
::L2854::
goto L1921
r126 = r1[64]
r127 = r1[155]
r128 = r1[93]
::L2858::
goto L3130
-- ??? opcode 31 (UNKNOWN)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r164 = r1[160](((9(r1[19])) .. r1[153] .. r1[136]), (9(r1[19])))
::L2863::
goto L4687
if not (not(V[A[n]]<KA[n])) then goto L4297 end
::L2865::
goto L2679
if not (126 == 115) then goto L2952 end
::L2867::
goto L5294
if not (not(V[A[n]]<KA[n])) then goto L5377 end
::L2869::
goto L5112
r161 = r1[30]
r158 = r61[r1[30]]
r5 = 120
::L2873::
goto L1715
r155 = r1[84]
r156 = 101
r157 = 232
r158 = 120
::L2878::
goto L3838  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 65 (UNKNOWN)
r5 = 115
::L2881::
goto L2265
r154 = error[55]
-- ??? opcode 162 (UNKNOWN)
r154 = r1[155]
r155 = nil
::L2886::
goto L10
-- ??? opcode 31 (UNKNOWN)
r162 = r1[67]
r160 = 0(r1[30], r1[67])
r155 = (0(r1[30], r1[67]))
::L2891::
goto L314
r152 = error[52]
r153 = 2
r150 = 126 .. error[52] .. 2
::L2895::
goto L843
::L2896::
goto L3247
-- ??? opcode 128 (UNKNOWN)
r143 = r1[10]
r144 = ((1060116490 / nil)(508, r65))
r145 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r144 = ((1060116490 / nil)(508, r65))
::L2903::
goto L77
r150 = error[13]
-- ??? opcode 162 (UNKNOWN)
r149 = 22
::L2907::
goto L4818
-- numeric for-loop (var r163+3, jump L2349)
::L2909::
goto L19
if not (not(V[A[n]]<KA[n])) then goto L2572 end
goto L766
if not (2 == 49) then goto L4263 end
::L2913::
goto L331
r150 = r1[155]
r151 = nil
r151 = nil()
::L2917::
goto L4048
-- ??? opcode 52 (UNKNOWN)
::L2919::
goto L5359
r150 = error[60]
-- ??? opcode 162 (UNKNOWN)
::L2922::
goto L387
::L2923::
goto L363
r170 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L2926::
goto L4869
r165 = r1[155]
r166 = 101
-- ??? opcode 31 (UNKNOWN)
r169 = 120
r167 = r1[153](r1[136], 120)
r168 = r1[136]
::L2933::
goto L4601
r63 = r1[170]
r60 = r1[121][r1[170]]
r5 = 108
::L2937::
goto L4765
r156 = (0(r1[30], r1[67]))
r158 = 115
::L2940::
goto L3354
if not (KA[n]<V[A[n]]) then goto L5303 end
::L2942::
goto L3567
r50 = r1[94]
r48 = r1[155][r1[94]]
r5 = 80
::L2946::
goto L778
if not (not(V[A[n]]<KA[n])) then goto L280 end
::L2948::
goto L591
if not (80 == 64) then goto L1879 end
::L2950::
goto L4204
if not (r1[136] == 13) then goto L798 end
::L2952::
goto L5005
if not ((nil()) == 100) then goto L852 end
::L2954::
goto L2314
-- numeric for-loop (var r160+3, jump L4069)
::L2956::
goto L2590
if not ((0(r1[30], r1[67])) == 38) then goto L1492 end
::L2958::
goto L55
-- ??? opcode 65 (UNKNOWN)
::L2960::
goto L4211
if not ((r1[160](((9(r1[19])) .. r1[153] .. r1[136]), (9(r1[19])))) == 66) then goto L3078 end
::L2962::
goto L4321
if not (not(V[A[n]]<KA[n])) then goto L1631 end
::L2964::
goto L1773
-- ??? opcode 65 (UNKNOWN)
::L2966::
goto L1297
r154 = r99
r155 = nil
r155 = nil()
r156 = error[65]
r157 = 2
r154 = (nil()) .. error[65] .. 2
r154 = error[32]
-- ??? opcode 162 (UNKNOWN)
::L2975::
goto L326
r149 = 106
r150 = r99
r151 = r1[155][8]
r152 = nil
r152 = nil()
::L2981::
goto L2514
::L2982::
goto L3639
r149 = 36
::L2984::
goto L3144
if not (80 == 74) then goto L2552 end
::L2986::
goto L4612
-- numeric for-loop (var r161+3, jump L1885)
::L2988::
goto L4364
r150 = error[29]
-- ??? opcode 162 (UNKNOWN)
::L2991::
goto L5179
::L2992::
goto L4001
if not (KA[n]<V[A[n]]) then goto L2105 end
::L2994::
goto L2586
r145 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r144 = ((1060116490 / nil)(508, r65))
r145 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r5 = 23
::L3001::
goto L513
if not ((r1[160](((9(r1[19])) .. r1[153] .. r1[136]), (9(r1[19])))) == 164) then goto L3996 end
::L3003::
goto L2018
r169 = r65
-- ??? opcode 30 (UNKNOWN)
::L3006::
goto L1160
::L3007::
goto L1875
if not (KA[n]<V[A[n]]) then goto L3870 end
::L3009::
goto L5421
if not (23 == 91) then goto L3500 end
::L3011::
goto L867
if not (KA[n]<V[A[n]]) then goto L4225 end
::L3013::
goto L5270
r156 = r1[150]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r158 = 0
r159 = 0
r160 = 0
r161 = 0
::L3024::
goto L2667
r145 = ((1060116490 / nil)(508, r65))
r146 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r145 = ((1060116490 / nil)(508, r65))
::L3029::
goto L1478
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = error[60]
r153 = 2
::L3035::
goto L2321
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 31 (UNKNOWN)
r160 = 0.25
r158 = 0(0, 0.25)
r159 = r1[155]
::L3041::
goto L4071
if not (not(V[A[n]]<KA[n])) then goto L3194 end
::L3043::
goto L493
if not (2 == 31) then goto L3812 end
goto L1811
::L3046::
goto L27  -- for-loop prep (init, limit, step in regs)
-- numeric for-loop (var r159+3, jump L3673)
goto L1837
if not (KA[n]<V[A[n]]) then goto L5147 end
::L3050::
goto L2108
::L3051::
goto L4715
r149 = 43
::L3053::
goto L1606
-- ??? opcode 128 (UNKNOWN)
r5 = 74
::L3056::
goto L784
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 31 (UNKNOWN)
r166 = 0.1666666716337204
::L3060::
goto L3382
r122 = r1[64]
r123 = r1[97]
r124 = r1[75]
-- ??? opcode 65 (UNKNOWN)
r5 = 83
::L3066::
goto L5274
r149 = 3
r150 = {}
r151 = r1[73]
r152 = r1[8]
r151 = r1[73](r1[8])
-- ??? opcode 31 (UNKNOWN)
r153 = 1
r154 = -1
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 45 (UNKNOWN)
r148 = {}
::L3078::
goto L3969
r165 = r99
r166 = r1[74]
r167 = r1[62]
r168 = 0.25
r167 = r1[62](0.25)
r168 = r1[136]
r165 = r1[74] .. (r1[62](0.25)) .. r1[136]
::L3086::
goto L3223
-- ??? opcode 65 (UNKNOWN)
r160 = r1[64]
r161 = r1[145]
r161 = (nil())[r1[145]]
r162 = r1[145]
-- ??? opcode 65 (UNKNOWN)
r160 = r1[64]
r161 = r1[176]
::L3095::
goto L1559
-- numeric for-loop (var rNone+3, jump LNone)
::L3097::
goto L668
-- ??? opcode 128 (UNKNOWN)
r5 = 24
::L3100::
goto L2409
r151 = 0
-- ??? opcode 31 (UNKNOWN)
r163 = 0.2857142984867096
r161 = r1[176](r1[145], 0.2857142984867096)
goto L841
::L3106::
goto L39  -- for-loop prep (init, limit, step in regs)
::L3107::
goto L64
if not (r1[150] == 77) then goto L2956 end
::L3109::
goto L3589
if not (KA[n]<V[A[n]]) then goto L1293 end
::L3111::
goto L2186
if not (1 == 42) then goto L5245 end
::L3113::
goto L459
if not (not(V[A[n]]<KA[n])) then goto L4986 end
::L3115::
goto L3978
-- ??? opcode 52 (UNKNOWN)
r5 = 44
::L3118::
goto L1463
r132 = r1[155]
r133 = r1[155]
r5 = 37
-- numeric for-loop (var rNone+3, jump LNone)
::L3123::
goto L3878
r159 = r99
r160 = r1[144]
r160 = 2[r1[144]]
r161 = r1[45]
-- ??? opcode 65 (UNKNOWN)
r159 = r1[155]
::L3130::
goto L2375
-- ??? opcode 65 (UNKNOWN)
r5 = 35
::L3133::
goto L3784
r154 = r1[155]
r155 = nil
r155 = nil()
r156 = {}[49]
r157 = 1
::L3139::
goto L4134
r163 = nil
r164 = 2[r1[144]]
r163 = nil(2[r1[144]])
r164 = r1[136]
::L3144::
goto L2010
if not (KA[n]<V[A[n]]) then goto L1518 end
::L3146::
goto L5260
if not (KA[n]<V[A[n]]) then goto L3113 end
::L3148::
goto L4568
if not (1 == 94) then goto L3043 end
::L3150::
goto L182
if not (35 == 49) then goto L1713 end
::L3152::
goto L2508
r163 = ((1060116490 / nil)(508, r65))
r164 = (0(0, 0.25))
r165 = {}
-- ??? opcode 65 (UNKNOWN)
::L3157::
goto L3046
if not (0 == 126) then goto L4831 end
::L3159::
goto L1082
r168 = 118
::L3161::
goto L3908
r165 = r99
r166 = r1[155]
r167 = r4
r166 = r1[155](r4)
::L3166::
goto L5024
-- ??? opcode 52 (UNKNOWN)
::L3168::
goto L1978
if not (0 == 89) then goto L2122 end
::L3170::
goto L1331
r147 = r1[64]
r148 = r1[155]
r149 = r1[173]
-- ??? opcode 65 (UNKNOWN)
r5 = 100
::L3176::
goto L919
r169 = (135(67))
r176 = r4
r177 = (0(0, 0.25))
goto L2239
if not (r4 == 10) then goto L1586 end
::L3182::
goto L1551
if not (not(V[A[n]]<KA[n])) then goto L4005 end
::L3184::
goto L4322
r149 = 112
r150 = r99
r151 = r1[155][69]
r152 = nil
r152 = nil()
r153 = 1
r150 = r1[155][69] .. (nil()) .. 1
r150 = r1[155][23]
-- ??? opcode 162 (UNKNOWN)
::L3194::
goto L1606
if not (KA[n]<V[A[n]]) then goto L1929 end
::L3196::
goto L263
r153 = 2
r150 = r1[155][69] .. (nil()) .. 2
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
::L3203::
goto L4894
r126 = r1[64]
r127 = r1[155]
r128 = r1[20]
-- ??? opcode 65 (UNKNOWN)
r5 = 29
::L3209::
goto L2265
r152 = r1[64][17]
r153 = 2
r150 = r1[155][69] .. r1[64][17] .. 2
r150 = r1[64][16]
-- ??? opcode 162 (UNKNOWN)
r150 = r1[155]
r151 = nil
r151 = nil()
::L3218::
goto L4823
if not (29 == 26) then goto L3485 end
::L3220::
goto L360
if not (r1[10] == 113) then goto L3293 end
::L3222::
goto L1042
::L3223::
goto L1777
-- ??? opcode 52 (UNKNOWN)
r161 = r99
r162 = r1[65]
::L3227::
goto L3139
r165 = r1[155]
r166 = r1[144]
r166 = 1[r1[144]]
r167 = r1[144]
r167 = 1[r1[144]]
::L3233::
goto L2761
r162 = 98
::L3235::
goto L4984  -- for-loop prep (init, limit, step in regs)
r170 = 955
-- ??? opcode 58 (UNKNOWN)
r168 = r1[136]
::L3239::
goto L266
if not (KA[n]<V[A[n]]) then goto L1777 end
goto L2374
if not (KA[n]<V[A[n]]) then goto L1455 end
::L3243::
goto L5096
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 31 (UNKNOWN)
r156 = 0.75
::L3247::
goto L3915
r125 = r1[64]
r126 = r17
r127 = r1[53]
-- ??? opcode 65 (UNKNOWN)
::L3252::
goto L2089
if not (not(V[A[n]]<KA[n])) then goto L3239 end
::L3254::
goto L1738
r161 = 62
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r163 = 4
::L3259::
goto L3523  -- for-loop prep (init, limit, step in regs)
r151 = 112
r152 = r1[45]
r153 = r1[115]
::L3263::
goto L2758
if not (KA[n]<V[A[n]]) then goto L1150 end
goto L1615
if not (KA[n]<V[A[n]]) then goto L4116 end
::L3267::
goto L15
::L3268::
goto L4733
r151 = 101
r161 = r1[155]
r162 = r1[52]
r162 = r1[155][r1[52]]
r163 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L3275::
goto L2621
r76 = r1[17](r1[155])
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r5 = 92
::L3283::
goto L3652
r13 = r1[156]
r14 = r1[63]
r5 = 106
::L3287::
goto L4473
((1060116490 / nil)(508, r65))[((((39(65))(0.34075997016204335)) .. 556 .. r1[136])[1](r180, 36))] = ((r1[155](152))(152, r182))
::L3289::
goto L3767
r131 = r1[6]
r130 = r1[121][r1[6]]
r131 = r1[155]
::L3293::
goto L1897
if not (r1[10] == 28) then goto L616 end
::L3295::
goto L2342
::L3296::
goto L899
::L3297::
goto L193
r153 = 2
r150 = 101 .. r1[45] .. 2
::L3300::
goto L4699
-- numeric for-loop (var r150+3, jump L2911)
::L3302::
goto L742
if not (106 == 120) then goto L4063 end
::L3304::
goto L200
if not (KA[n]<V[A[n]]) then goto L4343 end
::L3306::
goto L2369
if not (V[A[n]]<=KA[n]) then goto L470 end
::L3308::
goto L1654
r150 = r1[155][21]
-- ??? opcode 162 (UNKNOWN)
r149 = 6
::L3312::
goto L4537
r160 = 0.75[r1[155]]
::L3314::
goto L3523
if not (not(V[A[n]]<KA[n])) then goto L2267 end
::L3316::
goto L5140
r122 = r1[64]
r123 = r1[155]
r124 = "tostring"
-- ??? opcode 65 (UNKNOWN)
::L3321::
goto L3331
if not (r1[136] == 155) then goto L1582 end
::L3323::
goto L1522
r151 = 101()
r152 = r1[155][64]
r153 = 2
r150 = (101()) .. r1[155][64] .. 2
goto L4537
-- ??? opcode 115 (UNKNOWN)
-- ??? opcode 147 (UNKNOWN)
::L3331::
-- ??? opcode 65 (UNKNOWN)
r122 = r1[13]
r121 = r1[156][r1[13]]
::L3334::
goto L921
-- numeric for-loop (var rNone+3, jump LNone)
::L3336::
goto L897
r163 = r1[173]
r158 = r68[r1[173]]
::L3339::
goto L3046
r165 = 24
r166 = 14
::L3342::
goto L4869  -- for-loop prep (init, limit, step in regs)
r164 = r1[154]
r164 = r1[155][r1[154]]
r164 = r1[155][r1[154]] * nil
::L3346::
goto L3416
-- ??? opcode 128 (UNKNOWN)
r125 = r1[64]
r126 = r1[155]
::L3350::
goto L4690
-- ??? opcode 65 (UNKNOWN)
r157 = r1[52]
r157 = 0.75[r1[52]]
::L3354::
goto L343
if not (r68[r1[173]] == 115) then goto L1071 end
::L3356::
goto L2937
r156 = r1[155][28]
r157 = 2
r154 = (nil()) .. r1[155][28] .. 2
::L3360::
goto L696
if not (6 == 105) then goto L439 end
goto L2734
::L3363::
-- ??? opcode 142 (UNKNOWN)
r157 = r1[136]
-- ??? opcode 65 (UNKNOWN)
r155 = r1[155]
::L3367::
goto L2782
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 89
::L3370::
goto L1378
r150 = r1[155][51]
-- ??? opcode 162 (UNKNOWN)
r149 = 122
goto L4223
-- ??? opcode 153 (UNKNOWN)
::L3376::
-- ??? opcode 46 (UNKNOWN)
r40 = r1[22]
r38 = r1[155][r1[22]]
r40 = r1[5]
r39 = r1[155][r1[5]]
::L3381::
goto L723
::L3382::
goto L3056
r164 = (r1[155][r1[154]] * nil)(24, 14)
r151 = 79
::L3385::
goto L1683
-- ??? opcode 65 (UNKNOWN)
::L3387::
goto L1730
::L3388::
goto L5398
-- ??? opcode 96 (UNKNOWN)
r127 = r1[121][r1[6]]
r5 = 121
::L3392::
goto L2238
if not (KA[n]<V[A[n]]) then goto L3803 end
::L3394::
goto L1127
::L3395::
goto L4183
-- numeric for-loop (var r150+3, jump L1314)
::L3397::
goto L2325
r173 = 0.34075997016204335
r174 = r1[136]
r171 = (nil(556)) .. 0.34075997016204335 .. r1[136]
r171 = r1[155]
::L3402::
goto L4424
-- ??? opcode 52 (UNKNOWN)
r156 = r99
r157 = r1[144]
r157 = r1[155][r1[144]]
::L3407::
goto L1345
r149 = 118
r150 = r1[64][1]
-- ??? opcode 162 (UNKNOWN)
::L3411::
goto L3144
-- numeric for-loop (var r150+3, jump L3048)
::L3413::
goto L232
r149 = 80
::L3415::
goto L843
::L3416::
goto L3471
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r164 = r1[155]
r165 = r1[154]
r165 = r1[155][r1[154]]
r166 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L3424::
goto L2954
r150 = 79 .. r1[155][64] .. 2
::L3426::
goto L1606
-- ??? opcode 65 (UNKNOWN)
r5 = 63
::L3429::
goto L3113
::L3430::
goto L42
r140 = r1[155]
r142 = r13[r1[134]]
-- numeric for-loop (var rNone+3, jump LNone)
::L3434::
goto L924
::L3435::
goto L2494
r154 = r1[155][20]
-- ??? opcode 162 (UNKNOWN)
::L3438::
goto L2468
-- ??? opcode 79 (UNKNOWN)
::L3440::
goto L4984
if not (not(V[A[n]]<KA[n])) then goto L3448 end
::L3442::
goto L2484
if not (not(V[A[n]]<KA[n])) then goto L5138 end
::L3444::
goto L113
r156 = r1[155][68]
r157 = 1
r154 = r1[155] .. r1[155][68] .. 1
::L3448::
goto L1490
if not (not(V[A[n]]<KA[n])) then goto L1552 end
::L3450::
goto L2340
r146 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r5 = 103
::L3454::
goto L4287
-- numeric for-loop (var r150+3, jump L1690)
::L3456::
goto L2635
r163 = 1
::L3458::
goto L4582  -- for-loop prep (init, limit, step in regs)
r143 = r1[5]
-- ??? opcode 79 (UNKNOWN)
r142 = ((1060116490 / nil)(508, r65))
goto L2283
r169 = nil
-- ??? opcode 30 (UNKNOWN)
::L3465::
goto L4107
::L3466::
goto L3569
r68 = r1[175]
r5 = 22
::L3469::
goto L5385
if not (not(V[A[n]]<KA[n])) then goto L2138 end
::L3471::
goto L2801
r165 = r1[64]
r166 = r1[21]
r166 = 0.75[r1[155]][r1[21]]
::L3475::
goto L1548
r5 = 96
::L3477::
goto L3113
-- numeric for-loop (var rNone+3, jump LNone)
r149 = 50
::L3480::
goto L3969
if not (KA[n]<V[A[n]]) then goto L2457 end
::L3482::
goto L2624
r157 = r1[155]
r158 = 112
::L3485::
goto L2790
if not (96 == 92) then goto L2712 end
::L3487::
goto L1862
r161 = r1[155]
r162 = "tostring"
-- numeric for-loop (var rNone+3, jump LNone)
r163 = r1[155]
r164 = r1[64]
-- numeric for-loop (var rNone+3, jump LNone)
r165 = r1[155]
r166 = r74
-- numeric for-loop (var rNone+3, jump LNone)
::L3497::
goto L385
r173 = 182
r174 = 35
::L3500::
goto L5155  -- for-loop prep (init, limit, step in regs)
if not (96 == 69) then goto L1515 end
::L3502::
goto L3006
r151 = 50
r161 = r1[155]
r162 = r1[154]
r162 = 0.75[r1[155]][r1[154]]
r163 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L3509::
goto L996
if not (KA[n]<V[A[n]]) then goto L660 end
::L3511::
goto L1343
-- ??? opcode 162 (UNKNOWN)
::L3513::
goto L2363
r145 = ((1060116490 / nil)(508, r65))
r146 = r1[155][r1[94]]
-- ??? opcode 79 (UNKNOWN)
::L3517::
goto L1579
r154 = r1[155][17]
-- ??? opcode 162 (UNKNOWN)
::L3520::
goto L611
if not (96 == 38) then goto L3952 end
::L3522::
goto L2126
::L3523::
goto L2100
-- numeric for-loop (var r161+3, jump L4188)
::L3525::
goto L3223
r5 = 93
::L3527::
goto L4806
if not (KA[n]<V[A[n]]) then goto L611 end
::L3529::
goto L2594
r16 = r1[155]
r17 = r1[155]
r18 = nil
r5 = 119
::L3534::
goto L264
r158 = r1[155][112]
-- ??? opcode 79 (UNKNOWN)
::L3537::
goto L2956
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 63
::L3540::
goto L897
if not (V[A[n]]<=KA[n]) then goto L1520 end
::L3542::
goto L2074
if not (V[A[n]]<=KA[n]) then goto L2799 end
::L3544::
goto L3740
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r151 = nil
r151 = nil()
r152 = r1[155][43]
r153 = 1
r150 = (nil()) .. r1[155][43] .. 1
::L3556::
goto L544
r150 = r1[155][53]
-- ??? opcode 162 (UNKNOWN)
r149 = 60
::L3560::
goto L4223
::L3561::
goto L5131
r160 = 60
r161 = r1[155]
r162 = r1[67]
::L3565::
goto L2964
if not (63 == 57) then goto L1094 end
::L3567::
goto L1923
if not (not(V[A[n]]<KA[n])) then goto L5303 end
::L3569::
goto L2086
r126 = r1[64]
r127 = r1[33]
r128 = r1[3]
::L3573::
goto L2878
if not (not(V[A[n]]<KA[n])) then goto L5046 end
::L3575::
goto L2247
::L3576::
goto L2052
r56 = r1[166]
r5 = 93
::L3579::
goto L2409
r49 = r1[180]
::L3581::
goto L1563
r167 = r1[155]
r168 = r1[154]
r168 = r1[67][r1[154]]
r169 = r1[37]
r168 = r1[67][r1[154]][r1[37]]
r169 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L3589::
goto L19
r156 = 72
r157 = ((1060116490 / nil)(508, r65))
r158 = r1[110]
::L3593::
goto L910
-- ??? opcode 65 (UNKNOWN)
::L3595::
goto L4012
r126 = r1[64]
r127 = r1[155]
r128 = r1[69]
-- ??? opcode 65 (UNKNOWN)
::L3600::
goto L3465
r160 = r99
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
r162 = r1[155]
r163 = r1[155]
goto L732
-- ??? opcode 129 (UNKNOWN)
::L3610::
r389 = B  -- loader upvalue
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r151 = nil
::L3618::
goto L1955
r5 = 72
::L3620::
goto L1546
if not (not(V[A[n]]<KA[n])) then goto L4804 end
::L3622::
goto L163
r149 = 14
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = r1[155][58]
r153 = 1
::L3629::
goto L3424
r13 = r1[155]
r14 = r1[155]
r15 = r1[155]
::L3633::
goto L3529
if not (V[A[n]]<=KA[n]) then goto L464 end
::L3635::
goto L2858
if not (not(V[A[n]]<KA[n])) then goto L917 end
::L3637::
goto L5365
if not (72 == 35) then goto L1546 end
::L3639::
goto L1689
r164 = ((1060116490 / nil)(508, r65))
r165 = r1[130]
r165 = 72[r1[130]]
::L3643::
goto L3438
if not (KA[n]<V[A[n]]) then goto L3152 end
::L3645::
goto L395
if not (not(V[A[n]]<KA[n])) then goto L4471 end
goto L1893
::L3648::
-- ??? opcode 45 (UNKNOWN)
r157 = r1[155]
::L3650::
goto L3721
::L3651::
goto L3872
::L3652::
goto L1665
::L3653::
goto L3485
if not (KA[n]<V[A[n]]) then goto L2830 end
::L3655::
goto L409
r126 = r1[64]
r127 = r1[155]
r128 = r1[87]
-- ??? opcode 65 (UNKNOWN)
r5 = 1
::L3661::
goto L1515
if not (V[A[n]]) then goto L769 end
::L3663::
goto L1222
r144 = ((1060116490 / nil)(508, r65))
r145 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r5 = 10
::L3668::
goto L513
-- ??? opcode 67 (UNKNOWN)
r5 = 6
::L3671::
goto L1501
r163 = 101
goto L1681  -- for-loop prep (init, limit, step in regs)
if not (V[A[n]]<=KA[n]) then goto L3643 end
goto L1352
r168 = r1[170]
r169 = r1[155]
r170 = "slf"
-- numeric for-loop (var rNone+3, jump LNone)
r171 = nil
r172 = "[C]"
r173 = r1[170]
::L3683::
goto L188
::L3684::
goto L3925
if not ((nil()) == 101) then goto L3753 end
::L3686::
goto L528
::L3687::
goto L176
r164 = r1[52]
r164 = r1[110][r1[52]]
r164 = r1[110][r1[52]] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L3693::
goto L2954
r125 = r1[27]
::L3695::
goto L3475
r167 = r1[154]
r167 = r1[155][r1[154]]
r168 = r1[37]
r167 = r1[155][r1[154]][r1[37]]
r167 = r1[155][r1[154]][r1[37]] * nil
::L3701::
goto L4098
r179 = r1[104]
r180 = "[C]"
r181 = r1[37]
-- ??? opcode 65 (UNKNOWN)
::L3706::
goto L1582
::L3707::
goto L1418
if not (6 == 103) then goto L5143 end
::L3709::
goto L3560
r152 = r1[64][2]
r153 = 1
r150 = (nil()) .. r1[64][2] .. 1
r149 = 89
::L3714::
goto L140
r123 = r1[4]
r5 = 13
::L3717::
goto L460
r166 = 101
r167 = true
r164 = 72[r1[130]] .. 101 .. true
::L3721::
goto L3848
::L3722::
goto L2023
r149 = 98
::L3724::
goto L140
-- ??? opcode 65 (UNKNOWN)
r127 = r1[64]
r128 = r1[4]
r129 = "unpack"
::L3729::
goto L4903
r165 = r1[155]
r166 = r1[52]
r166 = (72[r1[130]] .. 101 .. true)[r1[52]]
r167 = r1[136]
::L3734::
goto L1356
::L3735::
goto L3820
if not (KA[n]<V[A[n]]) then goto L2940 end
::L3737::
goto L5446
::L3738::
goto L3655
if not (not(V[A[n]]<KA[n])) then goto L3252 end
::L3740::
goto L5317
r127 = r1[173]
r126 = r1[48][r1[173]]
r5 = 47
::L3744::
goto L5111
::L3745::
goto L696  -- for-loop prep (init, limit, step in regs)
::L3746::
goto L4558
r154 = r1[155] .. 72 .. r1[155]
::L3748::
goto L3454
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r163 = r1[155]
::L3752::
goto L5367
::L3753::
goto L708
if not ((nil()) == 95) then goto L4713 end
::L3755::
goto L3502
r156 = r1[154]
r156 = (r1[155] .. 72 .. r1[155])[r1[154]]
r157 = r1[37]
r156 = (r1[155] .. 72 .. r1[155])[r1[154]][r1[37]]
::L3760::
goto L5322
if not (not(V[A[n]]<KA[n])) then goto L449 end
::L3762::
goto L2144
r73 = r1[155]
r74 = r1[155]
r5 = 26
r75 = nil
::L3767::
goto L3485
-- numeric for-loop (var r175+3, jump L1047)
::L3769::
goto L2501
r152 = r1[155][11]
r153 = 1
r150 = (nil()) .. r1[155][11] .. 1
::L3773::
goto L2919
r150 = r1[155][57]
-- ??? opcode 162 (UNKNOWN)
r149 = 49
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = r1[155][57]
::L3781::
goto L3297
if not (26 == 108) then goto L717 end
::L3783::
goto L5151
::L3784::
goto L2854
if not (V[A[n]]<=KA[n]) then goto L2225 end
::L3786::
goto L1742
r150 = r1[64][4]
-- ??? opcode 162 (UNKNOWN)
r150 = r99
r151 = r1[64][4]
r152 = nil
::L3792::
goto L4663
::L3793::
goto L4233
r150 = r1[155][36]
-- ??? opcode 162 (UNKNOWN)
r149 = 111
::L3797::
goto L435
r46 = r1[121][r1[165]]
r47 = r1[155]
r48 = r1[155]
r49 = r1[155]
r5 = 110
::L3803::
goto L778
if not (KA[n]<V[A[n]]) then goto L1251 end
::L3805::
goto L1411
if not (110 == 45) then goto L4450 end
::L3807::
goto L2151
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 114
::L3810::
goto L3878
-- numeric for-loop (var r164+3, jump L4717)
::L3812::
goto L2808
if not (r1[37] == 64) then goto L1448 end
::L3814::
goto L5168
r163 = r65
-- ??? opcode 30 (UNKNOWN)
::L3817::
goto L2200
if not (KA[n]<V[A[n]]) then goto L4683 end
::L3819::
goto L4628
::L3820::
goto L1984
-- numeric for-loop (var r150+3, jump L5149)
::L3822::
goto L4468
r120 = {}
r118 = {}
r120 = {}
r121 = r1[147]
::L3827::
goto L4520
::L3828::
goto L1683
-- ??? opcode 31 (UNKNOWN)
r161 = r1[91]
r159 = r1[155](r99, r1[91])
::L3832::
goto L5319
r79 = {}
{}[5] = 1
{}[4] = 3
{}[10] = 6
r78 = {}
::L3838::
goto L2439
-- numeric for-loop (var r156+3, jump L1536)
::L3840::
goto L1265
::L3841::
goto L5479  -- for-loop prep (init, limit, step in regs)
if not (KA[n]<V[A[n]]) then goto L1067 end
::L3843::
goto L4088
r153 = 2
r150 = r1[64][4] .. nil .. 2
r150 = r1[155][58]
-- ??? opcode 162 (UNKNOWN)
::L3848::
goto L3051
r164 = 1
r165 = r1[155]
r166 = 1
::L3852::
goto L1404  -- for-loop prep (init, limit, step in regs)
-- numeric for-loop (var r156+3, jump L4194)
::L3854::
goto L3402
-- ??? opcode 65 (UNKNOWN)
r125 = {}
r126 = r1[166]
r127 = r1[46]
-- ??? opcode 65 (UNKNOWN)
::L3860::
goto L622
r153 = 1
r154 = -1
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 45 (UNKNOWN)
r147 = r1[155][58]
::L3866::
goto L3969
-- ??? opcode 31 (UNKNOWN)
r157 = r1[37](r1[110])
if not (notV[A[n]]) then goto L3721 end
::L3870::
goto L3482
if not (not(V[A[n]]<KA[n])) then goto L2940 end
::L3872::
goto L3735
r154 = r1[155]
r155 = nil
r155 = nil()
::L3876::
goto L412
r152 = 30
::L3878::
goto L3454  -- for-loop prep (init, limit, step in regs)
if not (114 == 37) then goto L4386 end
::L3880::
goto L997
if not (KA[n]<V[A[n]]) then goto L5088 end
::L3882::
goto L1525
if not (not(V[A[n]]<KA[n])) then goto L1501 end
::L3884::
goto L3668
-- ??? opcode 65 (UNKNOWN)
r147 = {}
r148 = r1[155]
r149 = r1[173]
::L3889::
goto L1716
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r148 = r1[4]
-- ??? opcode 79 (UNKNOWN)
r5 = 85
::L3898::
goto L919
::L3899::
goto L4699
-- ??? opcode 65 (UNKNOWN)
r151 = 106
::L3902::
goto L193
r154 = r1[155]
r155 = nil
r155 = nil()
r156 = r1[4][41]
r157 = 2
::L3908::
goto L1677
if not (r1[37] == 36) then goto L4429 end
::L3910::
goto L1354
-- ??? opcode 31 (UNKNOWN)
r169 = 35
r170 = 976
-- ??? opcode 58 (UNKNOWN)
::L3915::
goto L496
r154 = r1[155]((nil()), r1[4][41])
r155 = r1[154]
r155 = (r1[155]((nil()), r1[4][41]))[r1[154]]
::L3919::
goto L2845
r127 = {}
r128 = r1[170]
r129 = r1[168]
-- ??? opcode 65 (UNKNOWN)
r5 = 9
::L3925::
goto L4297
r156 = r1[154]
r156 = (r1[155]((nil()), r1[4][41]))[r1[154]][r1[154]]
r157 = r1[37]
r156 = (r1[155]((nil()), r1[4][41]))[r1[154]][r1[154]][r1[37]]
r156 = (r1[155]((nil()), r1[4][41]))[r1[154]][r1[154]][r1[37]] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L3933::
goto L4338
r174 = true
r171 = "[C]" .. r1[170] .. true
::L3936::
goto L5398
r167 = r1[136](r1[37])
r168 = r4[6]
-- ??? opcode 33 (UNKNOWN)
r166 = 1((r1[136](r1[37])))
::L3941::
goto L1475
if not (9 == 110) then goto L526 end
::L3943::
goto L4229
r155 = r1[155]
r156 = 26
r157 = 86
r158 = 20
goto L1468
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 131 (UNKNOWN)
r464 = r1[155] % nil
::L3952::
-- ??? opcode 60 (UNKNOWN)
if not (9 == 72) then goto L3637 end
::L3954::
goto L1772
r159 = (r1[155](r99, r1[91]))(r99)
r160 = r1[57]
r161 = true
r158 = ((r1[155](r99, r1[91]))(r99)) .. r1[57] .. true
r157 = 31
::L3960::
goto L3043
r140 = r31[r1[152]]
r141 = r13[r1[134]]
-- numeric for-loop (var rNone+3, jump LNone)
r141 = r13[r1[134]](((1060116490 / nil)(508, r65)))
::L3965::
goto L4813
r151 = 115
-- ??? opcode 31 (UNKNOWN)
r158 = 0.6666666865348816
::L3969::
goto L5152
if not (KA[n]<V[A[n]]) then goto L142 end
::L3971::
goto L638
r22 = r1[83]
r22 = r1[155][r1[83]]
r23 = 0
r24 = r1[138]
::L3976::
goto L2153
if not (9 == 29) then goto L5262 end
::L3978::
goto L1170
if not (KA[n]<V[A[n]]) then goto L4986 end
::L3980::
goto L1779
r176 = r1[155]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r178 = ("[C]" .. r1[170] .. true)
r179 = true
::L3989::
goto L533
-- ??? opcode 65 (UNKNOWN)
r5 = 54
::L3992::
goto L919
r161 = {}
r162 = 0
r163 = 0
::L3996::
goto L515
-- numeric for-loop (var r161+3, jump L5408)
::L3998::
goto L2381
r157 = 1
r154 = r1[155] .. 26 .. 1
::L4001::
goto L2325
r149 = 108
r150 = r99
r151 = r1[4][62]
::L4005::
goto L4169
if not (KA[n]<V[A[n]]) then goto L3182 end
::L4007::
goto L1770
::L4008::
goto L3123
if not (1 == 587) then goto L1022 end
::L4010::
goto L1798
if not (KA[n]<V[A[n]]) then goto L4481 end
::L4012::
goto L4609
r145 = nil
r146 = r1[155]
r5 = 78
::L4016::
goto L919
-- ??? opcode 52 (UNKNOWN)
::L4018::
goto L1837
r164 = {}
r165 = r1[130]
r165 = 26[r1[130]]
::L4022::
goto L4680
::L4023::
goto L571
r160 = r65
-- ??? opcode 30 (UNKNOWN)
::L4026::
goto L3648
-- numeric for-loop (var rNone+3, jump LNone)
r2 = r1[155]
r3 = r1[155]
r4 = r1[155]
::L4031::
goto L2242
r147 = (r13[r1[134]](((1060116490 / nil)(508, r65))))
r148 = r1[166]
r149 = r1[155]
::L4035::
goto L3884
r160 = {} .. 0 .. 0
::L4037::
goto L1297
-- ??? opcode 162 (UNKNOWN)
r157 = r1[166]
r158 = 26["Y"]
r159 = r1[37]
::L4042::
goto L645
-- ??? opcode 46 (UNKNOWN)
r164 = r1[155]
r165 = r1[155]
r166 = r1[155]
r5 = 3
::L4048::
goto L1501
r152 = r1[166][71]
r153 = 2
r150 = r1[4][62] .. r1[166][71] .. 2
r149 = 62
::L4053::
goto L4567
r161 = V  -- loader upvalue
::L4055::
goto L1358
r154 = r1[166][47]
-- ??? opcode 162 (UNKNOWN)
::L4058::
goto L3300
if not (3 == 116) then goto L2407 end
::L4060::
goto L278
r150 = (r13[r1[134]](((1060116490 / nil)(508, r65))))[6]
-- ??? opcode 162 (UNKNOWN)
::L4063::
goto L2982
r161 = r1[141]
r159 = r61[r1[141]]
r5 = 119
::L4067::
goto L1463
r161 = 0
goto L852
if not (KA[n]<V[A[n]]) then goto L915 end
::L4071::
goto L3633
r160 = 94
r161 = 713
r162 = 101
::L4075::
goto L4932
if not (KA[n]<V[A[n]]) then goto L3760 end
::L4077::
goto L2489
r157 = (r13[r1[134]](((1060116490 / nil)(508, r65))))
r158 = r1[40]
r158 = r1[155][r1[40]]
-- ??? opcode 79 (UNKNOWN)
::L4082::
goto L706
if not (62 == 3) then goto L5451 end
::L4084::
goto L3308
r172 = 976
r173 = "l"
r171 = ("[C]" .. r1[170] .. true)(976, "l")
::L4088::
goto L4927
r150 = r99
r151 = r1[166][51]
r152 = nil
r152 = nil()
::L4093::
goto L1807
if not (119 == 124) then goto L776 end
::L4095::
goto L4244
r154 = r1[166][41]
-- ??? opcode 162 (UNKNOWN)
::L4098::
goto L451
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L4101::
goto L2907
r169 = r1[155][5]
r170 = 30
r168 = r4[6](r1[155][5], 30)
r169 = r1[155][3]
-- ??? opcode 33 (UNKNOWN)
::L4107::
goto L3936
-- numeric for-loop (var r165+3, jump L3462)
::L4109::
goto L2447
if not (V[A[n]]<=KA[n]) then goto L2323 end
::L4111::
goto L4719
r164 = r1[154]
r164 = r1[155][r1[40]][r1[154]]
r164 = r1[155][r1[40]][r1[154]] * nil
-- ??? opcode 101 (UNKNOWN)
::L4116::
goto L2605
r154 = r99
r155 = nil
r155 = nil()
::L4120::
goto L701
r142 = r65
-- ??? opcode 30 (UNKNOWN)
goto L3807
if not (not(V[A[n]]<KA[n])) then goto L4759 end
::L4125::
goto L70
r69 = r1[29]
::L4127::
goto L885
if not (not(V[A[n]]<KA[n])) then goto L679 end
::L4129::
goto L4306
r5 = 88
::L4131::
goto L133
r167 = r65
-- ??? opcode 30 (UNKNOWN)
::L4134::
goto L144
r154 = (nil()) .. 26 .. (r13[r1[134]](((1060116490 / nil)(508, r65))))
::L4136::
goto L1921
if not (KA[n]<V[A[n]]) then goto L4702 end
::L4138::
goto L4196
::L4139::
goto L3729
-- ??? opcode 68 (UNKNOWN)
::L4141::
goto L2917
if not (KA[n]<V[A[n]]) then goto L3395 end
::L4143::
goto L1812
if not (88 == 108) then goto L2427 end
goto L417
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 143 (UNKNOWN)
r284 = r251 / nil
r36 = Z  -- loader upvalue
r228[nil] = nil
::L4151::
-- ??? opcode 79 (UNKNOWN)
if not (88 == 115) then goto L2265 end
::L4153::
goto L2922
-- ??? opcode 52 (UNKNOWN)
r161 = 40
r162 = 164
r163 = 62
::L4158::
goto L3996  -- for-loop prep (init, limit, step in regs)
r175 = true
r172 = "l" .. true .. true
r172 = 64
::L4162::
goto L3497
r171 = r99
r172 = 0.9759943678333985
-- ??? opcode 31 (UNKNOWN)
r173 = "l"(true)
r174 = r1[136]
r171 = 0.9759943678333985 .. ("l"(true)) .. r1[136]
::L4169::
goto L4549
r152 = nil
r152 = nil()
r153 = 1
r150 = r1[166][51] .. (nil()) .. 1
::L4174::
goto L2730
if not (KA[n]<V[A[n]]) then goto L5084 end
::L4176::
goto L4217
if not (r1[166][51] == 0) then goto L3684 end
::L4178::
goto L1993
r151 = 100
-- ??? opcode 31 (UNKNOWN)
r164 = 0.2142857164144516
r162 = 164(62, 0.2142857164144516)
::L4183::
goto L4067
r147 = r1[155]
r148 = r1[35]
r149 = {}
{}[29592426] = 906026978
goto L4605
if not (V[A[n]]<=KA[n]) then goto L2960 end
::L4190::
goto L4767
if not (r65 == 293) then goto L4874 end
::L4192::
goto L4639
if not (88 == 23) then goto L2409 end
goto L1452
if not (r61[r1[141]] == 58) then goto L712 end
::L4196::
goto L1399
if not (not(V[A[n]]<KA[n])) then goto L4702 end
goto L5227
if not (KA[n]<V[A[n]]) then goto L4471 end
::L4200::
goto L3645
r127 = {}
r128 = r1[147]
r129 = r1[13]
::L4204::
goto L3724
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 31
::L4207::
goto L2735
r149 = 105
r150 = r1[155]
r151 = nil
::L4211::
goto L3323
r127 = {}
r128 = r13[r1[134]]
r129 = r1[134]
-- ??? opcode 65 (UNKNOWN)
r5 = 62
::L4217::
goto L4297
r127 = {}
r128 = r13["defer"]
r129 = r1[28]
-- ??? opcode 65 (UNKNOWN)
r5 = 5
::L4223::
goto L4297
if not (KA[n]<V[A[n]]) then goto L5209 end
::L4225::
goto L3841
if not (not(V[A[n]]<KA[n])) then goto L3011 end
::L4227::
goto L2648
if not (KA[n]<V[A[n]]) then goto L1195 end
::L4229::
goto L1626
r50 = r1[119]
r47 = r1[155][r1[119]]
r5 = 117
::L4233::
goto L778
-- ??? opcode 52 (UNKNOWN)
r169 = r1[155]
-- ??? opcode 2 (UNKNOWN)
r169 = r1[155]
::L4238::
goto L4854
r168 = r1[52]
r168 = 62[r1[52]]
r168 = 62[r1[52]] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L4244::
goto L4689
r148 = r1[155]
r149 = r1[155]
r150 = {}
{}[1497953423] = 346514605
::L4249::
goto L5020
::L4250::
goto L2140
r92 = r1[69]
r90 = r1[155][r1[69]]
r5 = 33
::L4254::
goto L161
r152 = {}
{}[3474045020] = 1987350569
{}[975160751] = 1445538490
{}[2772836251] = 390570790
-- ??? opcode 65 (UNKNOWN)
::L4260::
goto L506
-- ??? opcode 162 (UNKNOWN)
r151 = 95
::L4263::
goto L4713
r154 = r99
r155 = nil
r155 = nil()
r156 = r1[155][47]
r157 = 1
r154 = (nil()) .. r1[155][47] .. 1
::L4270::
goto L3300
if not (KA[n]<V[A[n]]) then goto L4963 end
::L4272::
goto L633
r143 = r1[5](((1060116490 / nil)(508, r65)), nil)
r142 = r65((r1[5](((1060116490 / nil)(508, r65)), nil)))
if not (notV[A[n]]) then goto L3807 end
::L4276::
goto L2193
r64 = r61[r1[114]]
-- numeric for-loop (var rNone+3, jump LNone)
r66 = nil
::L4280::
goto L4751
r150 = r1[155][59]
-- ??? opcode 162 (UNKNOWN)
r150 = r99
r151 = nil
r151 = nil()
r152 = r1[155][59]
::L4287::
goto L4771
::L4288::
goto L3707
r89 = r1[58]
r5 = 74
::L4291::
goto L161
::L4292::
goto L5305
-- ??? opcode 162 (UNKNOWN)
r150 = r1[155]
r151 = nil
r151 = nil()
::L4297::
goto L936
if not (not(V[A[n]]<KA[n])) then goto L5084 end
::L4299::
goto L4174
::L4300::
goto L4411
-- ??? opcode 128 (UNKNOWN)
r148 = nil
-- numeric for-loop (var rNone+3, jump LNone)
r150 = r1[155]
r5 = 22
::L4306::
goto L660
::L4307::
goto L4374
r128 = r1[172]
-- ??? opcode 65 (UNKNOWN)
r5 = 91
::L4311::
goto L1515
r147 = {}
r148 = r1[148]
r149 = "new"
::L4315::
goto L3989
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = {}[1]
r153 = 1
::L4321::
goto L5135
::L4322::
goto L1380
r102 = r1[140]
r100 = r1[140]["pack"]
r5 = 100
::L4326::
goto L4005
r140 = r1[155]
r141 = r1[155]
r142 = r1[155]
r143 = 90
::L4331::
goto L750
::L4332::
goto L2520
r154 = r1[148][12]
-- ??? opcode 162 (UNKNOWN)
::L4335::
goto L451
r132 = r1[161]
r5 = 116
::L4338::
goto L3878
r156 = r1[148]
r157 = r1[154]
r157 = (nil())[r1[154]]
r158 = r1[37]
::L4343::
goto L1852
if not (not(V[A[n]]<KA[n])) then goto L3870 end
::L4345::
goto L3007
if not (("[C]" .. r1[170] .. true) == 173) then goto L2057 end
::L4347::
goto L2775
r154 = r99
r155 = nil
r155 = nil()
::L4351::
goto L1006
r151 = "new"
r152 = 90
r153 = r1[42]
-- ??? opcode 65 (UNKNOWN)
r151 = r1[155]
::L4357::
goto L793
r142 = r1[155]
r143 = r1[166]
r144 = r31[r1[152]]
r145 = r1[155]
::L4362::
goto L4272
if not (KA[n]<V[A[n]]) then goto L1232 end
::L4364::
goto L5266
::L4365::
goto L213
r179 = r1[104]
r180 = ("l"(true))
r181 = (62[r1[52]] * nil)
::L4369::
goto L2453
r126 = {}
r127 = r1[155][r1[22]]
r128 = r1[22]
::L4373::
goto L481
::L4374::
goto L453
r150 = r1[155]
r151 = nil
r151 = nil()
::L4378::
goto L5078
::L4379::
goto L57
if not (KA[n]<V[A[n]]) then goto L4908 end
::L4381::
goto L5169
r166 = nil
r167 = 108
r168 = 192
r169 = 21
::L4386::
goto L5398  -- for-loop prep (init, limit, step in regs)
if not (116 == 31) then goto L1444 end
::L4388::
goto L4326
r150 = (nil()) .. 90 .. r1[42]
r149 = 98
::L4391::
goto L387
r127 = {}
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r129 = r1[152]
-- ??? opcode 65 (UNKNOWN)
r127 = {}
r128 = r1[155][r1[119]]
r129 = r1[119]
-- ??? opcode 65 (UNKNOWN)
r127 = {}
r128 = r1[13]
r129 = r1[1]
-- ??? opcode 65 (UNKNOWN)
r5 = 66
goto L416
if not (KA[n]<V[A[n]]) then goto L1275 end
::L4411::
goto L1466
-- ??? opcode 52 (UNKNOWN)
r150 = r1[148][48]
-- ??? opcode 162 (UNKNOWN)
r150 = 126
::L4416::
goto L4797
r150 = r99
r151 = nil
r151 = nil()
r152 = r1[148][36]
r153 = 1
r150 = (nil()) .. r1[148][36] .. 1
r150 = r1[148][39]
::L4424::
goto L773
-- ??? opcode 31 (UNKNOWN)
r174 = 300
r175 = 576
-- ??? opcode 58 (UNKNOWN)
::L4429::
goto L2064
if not (192 == 51) then goto L2461 end
::L4431::
goto L913
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r169 = r1[58]
r170 = 62
r169 = r1[58](62)
r170 = r1[153]
r171 = r1[136]
r168 = (r1[58](62)) .. r1[153] .. r1[136]
::L4443::
goto L3810
if not (not(V[A[n]]<KA[n])) then goto L4141 end
::L4445::
goto L384
r171 = r99
r172 = 654
-- ??? opcode 31 (UNKNOWN)
::L4449::
goto L4724
::L4450::
goto L3411  -- for-loop prep (init, limit, step in regs)
r42 = r1[26]
r5 = 40
::L4453::
goto L2244
r150 = (nil()) .. r1[148][36] .. 1
r149 = 5
::L4456::
goto L191
r120 = r1[155]
r121 = r1[175]
-- ??? opcode 79 (UNKNOWN)
::L4460::
goto L62
r159 = 93
r160 = 33
::L4463::
goto L4733  -- for-loop prep (init, limit, step in regs)
if not (r1[155] == 230) then goto L484 end
::L4465::
goto L4586
::L4466::
goto L5483
if not (KA[n]<V[A[n]]) then goto L2863 end
::L4468::
goto L2282
-- ??? opcode 52 (UNKNOWN)
r149 = 119
::L4471::
goto L3011
if not (not(V[A[n]]<KA[n])) then goto L5094 end
::L4473::
goto L952
::L4474::
goto L264
if not (KA[n]<V[A[n]]) then goto L1675 end
::L4476::
goto L4565
r157 = r1[155]
r158 = r1[68]
r158 = (nil())[r1[68]]
r159 = "IsClient"
::L4481::
goto L274
if not (not(V[A[n]]<KA[n])) then goto L1921 end
::L4483::
goto L5103
-- ??? opcode 52 (UNKNOWN)
r150 = r99
r151 = r1[148][18]
r152 = nil
r152 = nil()
::L4489::
goto L903
r160 = r99
r161 = r1[155]
r162 = (nil())["Parent"]
r163 = r1[136]
::L4494::
goto L4035
if not (not(V[A[n]]<KA[n])) then goto L3480 end
::L4496::
goto L205
r5 = 87
::L4498::
goto L784
r152 = {}[11]
r153 = 2
r150 = r1[148][18] .. {}[11] .. 2
r150 = {}[2]
-- ??? opcode 162 (UNKNOWN)
goto L3722
r169 = r58
-- ??? opcode 30 (UNKNOWN)
::L4507::
goto L4740
if not (2 == 240) then goto L4756 end
::L4509::
goto L4465
-- ??? opcode 65 (UNKNOWN)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
::L4513::
goto L2265
r154 = r99
r155 = r1[148][5]
r156 = nil
r156 = nil()
r157 = 2
::L4519::
goto L1045
::L4520::
goto L1096
r122 = r1[149]
r1[155][r1[175]] = r1[149]
r121 = r1[14]
-- ??? opcode 41 (UNKNOWN)
r121 = r1[9]
-- ??? opcode 41 (UNKNOWN)
r121 = r1[123]
r122 = r1[146]
r1[155][r1[123]] = r1[146]
::L4530::
goto L4782
r150 = r1[148][31]
-- ??? opcode 162 (UNKNOWN)
r150 = r99
r151 = r1[148][31]
::L4535::
goto L4934
if not ("IsClient" == 26) then goto L3561 end
::L4537::
goto L4701
if not (KA[n]<V[A[n]]) then goto L4082 end
::L4539::
goto L1652
r150 = r99
r151 = nil
r151 = nil()
r152 = r1[148][1]
r153 = 2
r150 = (nil()) .. r1[148][1] .. 2
::L4546::
goto L3370
-- ??? opcode 58 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L4549::
goto L2565
::L4550::
goto L5398
r149 = 58
r150 = r1[155]
r151 = nil
r151 = nil()
::L4555::
goto L375
-- ??? opcode 128 (UNKNOWN)
r5 = 37
::L4558::
goto L2656
if not (not(V[A[n]]<KA[n])) then goto L1281 end
::L4560::
goto L1482
r121 = r1[183]
r122 = r1[136]
r1[155][r1[183]] = r1[136]
r119 = r1[155]
::L4565::
goto L2726
::L4566::
goto L1881
::L4567::
goto L466
::L4568::
goto L191
::L4569::
goto L2754
r165 = r1[160]
2[r1[160]] = r99
::L4572::
goto L222
if not (KA[n]<V[A[n]]) then goto L466 end
::L4574::
goto L1118
if not (KA[n]<V[A[n]]) then goto L2722 end
::L4576::
goto L4416
r159 = {}
r160 = 0
r161 = 3
r162 = 0
::L4581::
goto L1203
::L4582::
goto L4456
-- numeric for-loop (var r161+3, jump L2355)
::L4584::
goto L4153
::L4585::
goto L567
::L4586::
goto L5282
::L4587::
goto L2542
::L4588::
goto L133
-- ??? opcode 65 (UNKNOWN)
r5 = 54
::L4591::
goto L2265
if not (54 == 65) then goto L33 end
::L4593::
goto L1410
::L4594::
goto L852
-- ??? opcode 68 (UNKNOWN)
::L4596::
goto L4373
-- ??? opcode 128 (UNKNOWN)
r158 = nil
r159 = r1[155]
r5 = 61
::L4601::
goto L883
r165 = nil .. 108 .. ((r1[58](62)) .. r1[153] .. r1[136])
::L4603::
goto L1681
-- ??? opcode 52 (UNKNOWN)
::L4605::
goto L3996
58[2531023576] = 819698706
58[24971204] = 1015215902
-- ??? opcode 65 (UNKNOWN)
::L4609::
goto L5363
::L4610::
goto L2881
if not (not(V[A[n]]<KA[n])) then goto L5264 end
::L4612::
goto L2903
r29 = r1[82]
r5 = 33
::L4615::
goto L211
::L4616::
goto L355
::L4617::
goto L3013
r154 = r1[148][5] .. (nil()) .. 2
r154 = r1[148][28]
-- ??? opcode 162 (UNKNOWN)
r154 = r99
r155 = nil
r155 = nil()
::L4624::
goto L3356
r145 = r1[33]
-- ??? opcode 79 (UNKNOWN)
r144 = r1[155]
::L4628::
goto L2994
::L4629::
goto L4031
r150 = r99
r151 = nil
r151 = nil()
r152 = r1[148][9]
r153 = 1
::L4635::
goto L2509
-- ??? opcode 52 (UNKNOWN)
r156 = r99
r157 = r1[82]
::L4639::
goto L2737
::L4640::
goto L2813
r149 = 89
r150 = r1[148][11]
-- ??? opcode 162 (UNKNOWN)
::L4644::
goto L387
r151 = nil
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
r152 = r1[148][24]
r153 = 2
::L4653::
goto L4388
r36 = Z - nil
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 99 (UNKNOWN)
-- ??? opcode 112 (UNKNOWN)
r52 = 745213628
if not (r498 == nil) then goto L234 end
-- ??? opcode 57 (UNKNOWN)
-- ??? opcode 141 (UNKNOWN)
::L4663::
goto L694
r152 = r1[148][24]()
r153 = 1
r150 = nil .. (r1[148][24]()) .. 1
r150 = {}[7]
::L4668::
goto L4292
r150 = r99
r151 = nil
r151 = nil()
::L4672::
goto L3709
if not (not(V[A[n]]<KA[n])) then goto L1834 end
::L4674::
goto L4616
r153 = 1
r150 = (nil()) .. (r1[148][24]()) .. 1
r150 = 10
r151 = 60
r152 = 39
::L4680::
goto L2572  -- for-loop prep (init, limit, step in regs)
r166 = "IsA"
-- ??? opcode 65 (UNKNOWN)
::L4683::
goto L4984
if not (KA[n]<V[A[n]]) then goto L2138 end
::L4685::
goto L3469
if not (60 == 98) then goto L1683 end
::L4687::
goto L5048
r159 = 0.2142857164144516
::L4689::
goto L2954
::L4690::
goto L4869
r127 = "xpcall"
-- ??? opcode 65 (UNKNOWN)
r125 = r1[155]
r126 = r1[136]
::L4695::
goto L1940
r128 = r1[155]
r129 = r1[155]
r5 = 2
::L4699::
goto L2487
if not (KA[n]<V[A[n]]) then goto L3620 end
::L4701::
goto L1629
::L4702::
goto L2886
if not (KA[n]<V[A[n]]) then goto L2124 end
::L4704::
goto L1596
-- ??? opcode 31 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
::L4707::
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 87
::L4709::
goto L161
if not (87 == 41) then goto L252 end
::L4711::
goto L4763
if not (KA[n]<V[A[n]]) then goto L4550 end
::L4713::
goto L613
if not (60 == 30) then goto L5276 end
::L4715::
goto L3268
-- numeric for-loop (var r150+3, jump L4123)
goto L1266
if not (108 == 134) then goto L1574 end
::L4719::
goto L4431
::L4720::
goto L37
r150 = 93
r151 = 381
r152 = 118
::L4724::
goto L611  -- for-loop prep (init, limit, step in regs)
r175 = 384
r176 = 660
-- ??? opcode 58 (UNKNOWN)
r174 = r1[136]
r171 = 654 .. ("l"(true)) .. r1[136]
goto L5398
::L4731::
r134 = #r287
r168 = r58
::L4733::
goto L323
-- numeric for-loop (var r158+3, jump L4409)
::L4735::
goto L3035
r162 = r1[52]
r162 = 3[r1[52]]
r163 = r1[37]
r162 = 3[r1[52]][r1[37]]
::L4740::
goto L1228
-- numeric for-loop (var r165+3, jump L4504)
::L4742::
goto L4603
if not (not(V[A[n]]<KA[n])) then goto L2372 end
::L4744::
goto L1787
r150 = {}[18]
-- ??? opcode 162 (UNKNOWN)
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = {}[18]
::L4751::
goto L3843
-- numeric for-loop (var rNone+3, jump LNone)
r68 = r1[155]
r69 = r1[155]
r5 = 83
::L4756::
goto L5385
r154 = r1[148][16]
-- ??? opcode 162 (UNKNOWN)
::L4759::
goto L3454
if not (KA[n]<V[A[n]]) then goto L4715 end
::L4761::
goto L824
r158 = 0.2142857164144516 .. 0 .. 3
::L4763::
goto L1413
r113 = r1[171]
::L4765::
goto L1437
::L4766::
goto L2427
::L4767::
goto L2986  -- for-loop prep (init, limit, step in regs)
r165 = r99
r166 = r1[58]
r167 = 0.2142857164144516
::L4771::
goto L2767
r153 = 1
r150 = (nil()) .. {}[18] .. 1
r150 = 60
r151 = 240
::L4776::
goto L3876
r163 = r1[155]
r164 = 125
r165 = 134
::L4780::
goto L2825
r5 = 44
::L4782::
goto L397
r121 = r1[79]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 103 (UNKNOWN)
-- ??? opcode 57 (UNKNOWN)
-- ??? opcode 163 (UNKNOWN)
r121 = r1[86]
r122 = r1[177]
::L4791::
goto L2377
r154 = r99
r155 = nil
r155 = nil()
r156 = r1[148][30]
r157 = 1
::L4797::
goto L2554
r151 = 209
r152 = 83
::L4800::
goto L4715  -- for-loop prep (init, limit, step in regs)
r175 = 78
::L4802::
goto L2520  -- for-loop prep (init, limit, step in regs)
if not (125 == 284) then goto L1751 end
::L4804::
goto L120
if not (KA[n]<V[A[n]]) then goto L4699 end
::L4806::
goto L1614
if not (V[A[n]]<=KA[n]) then goto L4915 end
::L4808::
goto L1700
r153 = 1
r150 = 209 .. 83 .. 1
r150 = r1[148][52]
-- ??? opcode 162 (UNKNOWN)
::L4813::
goto L3413
-- ??? opcode 79 (UNKNOWN)
r5 = 41
::L4816::
goto L3878
if not (41 == 81) then goto L2843 end
::L4818::
goto L5278
::L4819::
goto L3194
r150 = 96
r151 = 211
r152 = 115
::L4823::
goto L3744
r152 = {}[16]
r153 = 2
r150 = 211 .. {}[16] .. 2
::L4827::
goto L1600
r159 = r1[40]
-- ??? opcode 65 (UNKNOWN)
r156 = 78
::L4831::
goto L1362
r157 = r1[148]
r158 = r1[154]
r158 = 78[r1[154]]
r159 = r1[37]
r158 = 78[r1[154]][r1[37]]
r159 = r1[136]
::L4838::
goto L3350
::L4839::
goto L5336
r152 = r1[148][53]
r153 = 1
r150 = 211 .. r1[148][53] .. 1
r150 = r1[148][4]
-- ??? opcode 162 (UNKNOWN)
r149 = 107
::L4846::
goto L4223
r167 = 0
r168 = 3[r1[52]][r1[37]] - nil
r169 = 1
::L4850::
goto L1978  -- for-loop prep (init, limit, step in regs)
if not (not(V[A[n]]<KA[n])) then goto L4060 end
::L4852::
goto L1384
if not (41 == 114) then goto L2735 end
::L4854::
goto L5068
-- ??? opcode 2 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
r169 = 1()
-- ??? opcode 2 (UNKNOWN)
r169 = r1[155]
::L4860::
goto L1647
::L4861::
goto L3902
r166 = r1[136]
-- ??? opcode 65 (UNKNOWN)
r164 = 10
::L4865::
goto L3339
if not (41 == 65) then goto L1062 end
::L4867::
goto L2049
-- ??? opcode 65 (UNKNOWN)
::L4869::
goto L4733
-- numeric for-loop (var r164+3, jump L3180)
::L4871::
goto L3381
r101 = r1[155]
r5 = 89
::L4874::
goto L4005
if not (0 == 11) then goto L2823 end
::L4876::
goto L1870
r163 = r1[58]
r164 = 3[r1[52]][r1[37]]
r163 = r1[58](3[r1[52]][r1[37]])
::L4880::
goto L2167
r13 = r1[111]
r11 = r1[155][r1[111]]
r5 = 97
::L4884::
goto L4806
if not (not(V[A[n]]<KA[n])) then goto L3943 end
::L4886::
goto L1385
::L4887::
goto L2043
if not (("[C]" .. r1[170] .. true) == 119) then goto L4345 end
::L4889::
goto L5115
r143 = r1[155]
r144 = r1[155]
-- ??? opcode 79 (UNKNOWN)
r5 = 72
::L4894::
goto L1450
-- ??? opcode 162 (UNKNOWN)
r150 = r99
r151 = nil
r151 = nil()
r152 = r1[148][10]
r153 = 2
r150 = (nil()) .. r1[148][10] .. 2
r149 = 80
::L4903::
goto L435
-- ??? opcode 65 (UNKNOWN)
r5 = 82
::L4906::
goto L4297
if not (V[A[n]]<=KA[n]) then goto L3053 end
::L4908::
goto L254
if not (not(V[A[n]]<KA[n])) then goto L451 end
::L4910::
goto L2165
-- ??? opcode 162 (UNKNOWN)
r149 = 121
goto L435
if not (not(V[A[n]]<KA[n])) then goto L868 end
::L4915::
goto L429
if not (KA[n]<V[A[n]]) then goto L2658 end
::L4917::
goto L3314
-- ??? opcode 31 (UNKNOWN)
-- ??? opcode 79 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
::L4923::
goto L4566
r150 = 56
r151 = 549
r152 = 45
::L4927::
goto L451  -- for-loop prep (init, limit, step in regs)
r172 = r99
r173 = r1[155]
r174 = (654 .. ("l"(true)) .. r1[136])
-- ??? opcode 65 (UNKNOWN)
::L4932::
goto L1404
::L4933::
goto L2954  -- for-loop prep (init, limit, step in regs)
::L4934::
goto L287
r152 = nil
r152 = nil()
r153 = 2
r150 = 549 .. (nil()) .. 2
::L4939::
goto L2114
r164 = r1[170]
r165 = (r1[58](3[r1[52]][r1[37]]))
r166 = r1[88]
::L4943::
goto L2317
r153 = 2
r150 = 549 .. (nil()) .. 2
::L4946::
goto L4742
::L4947::
goto L1582
r168 = r1[170]
r166 = r1[88](0, r1[170])
if not (notV[A[n]]) then goto L4594 end
::L4951::
goto L3706
r127 = r1[155]
r128 = r61[r1[114]]
r129 = r1[114]
::L4955::
goto L282
::L4956::
goto L3346
r154 = {}[5]
-- ??? opcode 162 (UNKNOWN)
::L4959::
goto L3395
r17 = r1[120]
r19 = r1[107]
r18 = r1[111][r1[107]]
::L4963::
goto L510
if not (KA[n]<V[A[n]]) then goto L780 end
::L4965::
goto L2836
r152 = (nil())()
r153 = 1
r150 = 549 .. ((nil())()) .. 1
r150 = r1[148][9]
-- ??? opcode 162 (UNKNOWN)
::L4971::
goto L4629
r165 = r1[155]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r167 = r1[155]
-- ??? opcode 65 (UNKNOWN)
::L4980::
goto L222
if not (not(V[A[n]]<KA[n])) then goto L1450 end
::L4982::
goto L5273
if not (not(V[A[n]]<KA[n])) then goto L843 end
::L4984::
goto L2528
-- numeric for-loop (var r160+3, jump L1650)
::L4986::
goto L4249
if not (not(V[A[n]]<KA[n])) then goto L3146 end
::L4988::
goto L3595
r126 = r1[155]
r127 = r1[155]
r128 = r1[178]
-- ??? opcode 65 (UNKNOWN)
r5 = 84
::L4994::
goto L3784
-- ??? opcode 52 (UNKNOWN)
r164 = r1[155]
r165 = r1[62]
r166 = (r1[58](3[r1[52]][r1[37]]))
r165 = r1[62]((r1[58](3[r1[52]][r1[37]])))
r166 = r1[103]
r167 = r1[136]
r164 = (r1[62]((r1[58](3[r1[52]][r1[37]])))) .. r1[103] .. r1[136]
r164 = 11
r165 = 327
::L5005::
goto L1830
r171 = 327 * nil
r171 = (327 * nil) + nil
r169 = ((327 * nil) + nil) % nil
r170 = 8
::L5010::
goto L2950
if not (not(V[A[n]]<KA[n])) then goto L5290 end
::L5012::
goto L1826
r165 = r1[155]
r166 = r1[155]
r167 = r1[136]
::L5016::
goto L2170
r151 = ((nil())()) .. 1 .. {}[5]
r151 = nil
r152 = r1[155]
::L5020::
goto L296
r1[148][9][3892798618] = 1005091601
-- ??? opcode 65 (UNKNOWN)
r5 = 43
::L5024::
goto L4093
r167 = r1[109]
r168 = r1[136]
r165 = r1[155] .. r1[109] .. r1[136]
::L5028::
goto L2986
-- ??? opcode 52 (UNKNOWN)
r167 = r1[155]
-- ??? opcode 31 (UNKNOWN)
r168 = r1[136]((((327 * nil) + nil) % nil))
r169 = 0.03372985938936341
r170 = r1[136]
r167 = (r1[136]((((327 * nil) + nil) % nil))) .. 0.03372985938936341 .. r1[136]
-- ??? opcode 31 (UNKNOWN)
r169 = 23
r170 = 793
-- ??? opcode 58 (UNKNOWN)
::L5040::
goto L102
r154 = (nil()) .. 78 .. r1[148]
::L5042::
goto L3454
if not (KA[n]<V[A[n]]) then goto L2795 end
::L5044::
goto L3184
if not (notV[A[n]]) then goto L3814 end
::L5046::
goto L4876
if not (KA[n]<V[A[n]]) then goto L5138 end
::L5048::
goto L3442
r165 = r1[148]
r166 = r1[154]
r166 = 11[r1[154]]
r167 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L5054::
goto L1580
-- ??? opcode 31 (UNKNOWN)
r158 = 78[r1[154]][r1[37]](r1[136])
r153 = (78[r1[154]][r1[37]](r1[136]))
r158 = (78[r1[154]][r1[37]](r1[136])) * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L5061::
goto L2068
::L5062::
goto L3194
r36 = 609423723
r37 = nil
r38 = r1[155]
r39 = nil
::L5067::
goto L4496
::L5068::
goto L133
-- numeric for-loop (var rNone+3, jump LNone)
-- numeric for-loop (var rNone+3, jump LNone)
r5 = 41
goto L2735
if not (KA[n]<V[A[n]]) then goto L2773 end
::L5074::
goto L3540
r142 = r1[173]
r140 = (r1[17](r1[155]))[r1[173]]
r5 = 35
::L5078::
goto L1546
r152 = r1[148][26]
r153 = 1
r150 = nil .. r1[148][26] .. 1
::L5082::
goto L2070
if not (KA[n]<V[A[n]]) then goto L3820 end
::L5084::
goto L1393
if not (KA[n]<V[A[n]]) then goto L5010 end
goto L3919
if not (KA[n]<V[A[n]]) then goto L4672 end
::L5088::
goto L5171
-- numeric for-loop (var r150+3, jump L1645)
::L5090::
goto L836
r58 = r1[155]
r59 = r1[155]
r5 = 118
::L5094::
goto L2409
if not (KA[n]<V[A[n]]) then goto L2419 end
::L5096::
goto L934
if not (r1[136] == 158) then goto L4704 end
::L5098::
goto L1640
r162 = 0
r163 = -3
-- ??? opcode 58 (UNKNOWN)
::L5102::
goto L443
::L5103::
goto L5282
if not (KA[n]<V[A[n]]) then goto L1921 end
::L5105::
goto L3133
if not (not(V[A[n]]<KA[n])) then goto L161 end
::L5107::
goto L348
if not (KA[n]<=V[A[n]]) then goto L2229 end
goto L1952
if not (V[A[n]]<=KA[n]) then goto L4463 end
::L5111::
goto L1135
::L5112::
goto L3542
::L5113::
goto L2403
-- ??? opcode 52 (UNKNOWN)
::L5115::
goto L1065
r179 = ((327 * nil) + nil)[3]
-- ??? opcode 162 (UNKNOWN)
goto L1582
r169 = r1[155]
-- ??? opcode 30 (UNKNOWN)
::L5121::
goto L1326
-- ??? opcode 52 (UNKNOWN)
r149 = 7
::L5124::
goto L4711
r131 = r1[155](r1[161])
r132 = 1
-- ??? opcode 65 (UNKNOWN)
r130 = r1[155]
r5 = 81
::L5130::
goto L393
::L5131::
goto L3980
r145 = r1[155]
r146 = r1[138]
-- ??? opcode 79 (UNKNOWN)
::L5135::
goto L159
r150 = nil .. r1[148][26] .. 1
r149 = 93
::L5138::
goto L3144
if not (not(V[A[n]]<KA[n])) then goto L133 end
::L5140::
goto L3575
-- ??? opcode 128 (UNKNOWN)
r5 = 24
::L5143::
goto L4806
if not (24 == 40) then goto L3150 end
goto L1802
if not (KA[n]<V[A[n]]) then goto L629 end
::L5147::
goto L1110
if not (not(V[A[n]]<KA[n])) then goto L3411 end
goto L2522
if not (not(V[A[n]]<KA[n])) then goto L511 end
::L5151::
goto L1744
::L5152::
goto L5410
r156 = 78(r1[148], ((78[r1[154]][r1[37]](r1[136])) * nil))
r155 = (78(r1[148], ((78[r1[154]][r1[37]](r1[136])) * nil)))
::L5155::
goto L315
-- numeric for-loop (var r172+3, jump L889)
::L5157::
goto L1931
-- ??? opcode 145 (UNKNOWN)
r179 = ((327 * nil) + nil)[3] + nil
r169 = (((327 * nil) + nil)[3] + nil) % nil
::L5161::
goto L3767
-- ??? opcode 52 (UNKNOWN)
r165 = 201
r167 = r55
r167 = r55()
::L5166::
goto L1201
if not (KA[n]<V[A[n]]) then goto L3509 end
::L5168::
goto L3259
::L5169::
goto L241
if not (not(V[A[n]]<KA[n])) then goto L4908 end
::L5171::
goto L2348
::L5172::
goto L1864
r107 = r1[2]
r5 = 37
::L5175::
goto L2735
r140 = r1[155]
r141 = 7609290 % nil
-- ??? opcode 82 (UNKNOWN)
::L5179::
goto L1197
r150 = r1[155]
r151 = nil
r151 = nil()
r152 = r1[148][29]
r153 = 1
r150 = (nil()) .. r1[148][29] .. 1
r150 = 1
r151 = 49
::L5188::
goto L250
r161 = r1[52]
r161 = 0[r1[52]]
r161 = 0[r1[52]] * nil
::L5192::
goto L92
r157 = 64
r158 = r99
r159 = r1[58]
::L5196::
goto L2574
r159 = r1[155]
r160 = 0
r161 = -7
::L5200::
goto L5098
r10 = r1[131]
r5 = 10
::L5203::
goto L4806
r150 = {}[12]
-- ??? opcode 162 (UNKNOWN)
r150 = 125
r151 = 269
r152 = 72
::L5209::
goto L2363  -- for-loop prep (init, limit, step in regs)
if not (V[A[n]]<=KA[n]) then goto L1054 end
::L5211::
goto L3556
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r132 = 7609290
-- ??? opcode 79 (UNKNOWN)
r5 = 124
::L5220::
goto L393
r151 = r1[31]
r150 = r61[r1[31]]
r5 = 125
::L5224::
goto L2819
r164 = r1[92]
r159 = (78(r1[148], ((78[r1[154]][r1[37]](r1[136])) * nil)))[r1[92]]
::L5227::
goto L2140
r154 = r1[148][5]
-- ??? opcode 162 (UNKNOWN)
::L5230::
goto L451
r156 = r99["Back"]
r157 = 37
::L5233::
goto L3043
r145 = (7609290 % nil)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
-- ??? opcode 79 (UNKNOWN)
r5 = 12
::L5242::
goto L5067
-- numeric for-loop (var rNone+3, jump LNone)
r151 = 119
::L5245::
goto L193
r154 = r1[155]
r155 = nil
r155 = nil()
r156 = r1[148][42]
r157 = 1
r154 = (nil()) .. r1[148][42] .. 1
::L5252::
goto L1490
if not (not(V[A[n]]<KA[n])) then goto L435 end
::L5254::
goto L1075
r63 = r1[136]
r64 = r1[71]
r65 = "The debug library is required on Luau platforms. Please open a support ticket."
r63 = r1[136](r1[71], "The debug library is required on Luau platforms. Please open a support ticket.")
r61 = (r1[136](r1[71], "The debug library is required on Luau platforms. Please open a support ticket."))
::L5260::
goto L2194
if not (not(V[A[n]]<KA[n])) then goto L1518 end
::L5262::
goto L3407
if not (12 == 54) then goto L4151 end
::L5264::
goto L3203
if not (not(V[A[n]]<KA[n])) then goto L563 end
::L5266::
goto L1523
if not (not(V[A[n]]<KA[n])) then goto L2632 end
goto L4886
if not (KA[n]<V[A[n]]) then goto L1696 end
::L5270::
goto L4109
::L5271::
goto L2975
-- ??? opcode 65 (UNKNOWN)
::L5273::
goto L3852
::L5274::
goto L2896
if not (12 == 68) then goto L3565 end
::L5276::
goto L3060
if not (119 == 50) then goto L4176 end
::L5278::
goto L5188
r55 = r1[11]
r54 = r1[121][r1[11]]
::L5281::
goto L596
::L5282::
goto L2181
-- ??? opcode 52 (UNKNOWN)
r164 = r1[154]
r164 = -3[r1[154]]
::L5286::
goto L2681
r152 = 117
r153 = 271
r154 = 93
::L5290::
goto L1834  -- for-loop prep (init, limit, step in regs)
if not (not(V[A[n]]<KA[n])) then goto L2863 end
::L5292::
goto L4466
if not (119 == 91) then goto L1214 end
::L5294::
goto L1025
r151 = 54
r162 = r1[148]
r163 = r1[154]
goto L1026
-- ??? opcode 80 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
goto L80  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 4 (UNKNOWN)
::L5303::
-- ??? opcode 70 (UNKNOWN)
if not (not(V[A[n]]<KA[n])) then goto L4379 end
::L5305::
goto L1320
r158 = r1[148]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r160 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L5314::
goto L1909
r163 = r1[155]
r5 = 65
::L5317::
goto L397
if not (KA[n]<V[A[n]]) then goto L3252 end
::L5319::
goto L3522
r157 = (78(r1[148], ((78[r1[154]][r1[37]](r1[136])) * nil)))[r1[92]]
r158 = 15
::L5322::
goto L2790
r157 = r1[136]
-- ??? opcode 65 (UNKNOWN)
r155 = 93["Y"]
r156 = r1[37]
r155 = 93["Y"][r1[37]]
r155 = 93["Y"][r1[37]] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
::L5331::
goto L5469
-- ??? opcode 52 (UNKNOWN)
r172 = r99
r173 = ((((327 * nil) + nil)[3] + nil) % nil)
r174 = 793
::L5336::
goto L4158
r149 = 100
r150 = r99
r151 = nil
r151 = nil()
::L5341::
goto L3769
if not (KA[n]<V[A[n]]) then goto L698 end
::L5343::
goto L4591
r152 = r1[148][23]
r153 = 2
r150 = (nil()) .. r1[148][23] .. 2
::L5347::
goto L736
r158 = r1[155]
r159 = 91
r160 = 647
r161 = 123
::L5352::
goto L3046  -- for-loop prep (init, limit, step in regs)
r162 = r1[148][r1[155]]
r162 = r1[148][r1[155]] * nil
-- ??? opcode 101 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r151 = 115
::L5358::
goto L852
::L5359::
goto L4951
if not (V[A[n]]<=KA[n]) then goto L3648 end
::L5361::
goto L4023
if not (65 == 102) then goto L17 end
::L5363::
goto L3714
r5 = 88
::L5365::
goto L466
if not (KA[n]<V[A[n]]) then goto L917 end
::L5367::
goto L3889
r164 = 52
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r166 = 53
::L5372::
goto L433  -- for-loop prep (init, limit, step in regs)
r152 = r1[148][56]
r153 = 1
r150 = 115 .. r1[148][56] .. 1
r150 = r1[148][43]
::L5377::
goto L3544
if not (KA[n]<V[A[n]]) then goto L2867 end
::L5379::
goto L299
r150 = r1[155]
r151 = nil
r151 = nil()
goto L5343
r159 = 91 + nil
::L5385::
goto L4139
if not (not(V[A[n]]<KA[n])) then goto L2649 end
::L5387::
goto L4125
-- ??? opcode 52 (UNKNOWN)
r149 = 44
::L5390::
goto L191
r33 = 500546608
r34 = r1[15]
r35 = r1[155]
::L5394::
goto L5062
r162 = r1[154]
r162 = 123[r1[154]]
r163 = r1[37]
::L5398::
goto L5352
-- numeric for-loop (var r167+3, jump L5072)
::L5400::
goto L5028
-- ??? opcode 162 (UNKNOWN)
r162 = r1[148]
r163 = r1[136]["Y"]
r164 = r1[136]
goto L4867
r162 = "The debug library is required on Luau platforms. Please open a support ticket."
-- ??? opcode 30 (UNKNOWN)
goto L1453
if not (r1[136] == 102) then goto L2752 end
::L5410::
goto L2362
r126 = r1[155]
r127 = r1[138]
r128 = r1[66]
-- ??? opcode 65 (UNKNOWN)
r126 = r1[155]
r127 = r1[125][r1[172]]
::L5417::
goto L4307
r61 = r1[155]
r62 = r1[155]
r5 = 1
::L5421::
goto L2427
::L5422::
goto L4347
r156 = r1[148][72]
r157 = 1
r154 = (93["Y"][r1[37]] * nil) .. r1[148][72] .. 1
r154 = r1[148][18]
-- ??? opcode 162 (UNKNOWN)
::L5428::
goto L3411
-- ??? opcode 31 (UNKNOWN)
-- ??? opcode 79 (UNKNOWN)
r161 = r1[155]
::L5432::
goto L944
::L5433::
goto L754
r146 = r1[173]
r146 = r1[173]()
r147 = r1[136]
r144 = (7609290 % nil) .. (r1[173]()) .. r1[136]
-- numeric for-loop (var rNone+3, jump LNone)
r140 = r1[155]
r141 = 34
goto L2112
r172 = ((327 * nil) + nil)[10]
r173 = ((327 * nil) + nil)[5]
r174 = ((327 * nil) + nil)[4]
r175 = ((327 * nil) + nil)[6]
::L5446::
goto L1671
r154 = r1[155]
r155 = nil
r155 = nil()
r156 = r1[148][27]
::L5451::
goto L878
r150 = r99
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r151 = (nil())()
r152 = r1[148][21]
r153 = 1
r150 = ((nil())()) .. r1[148][21] .. 1
r150 = r1[148][14]
::L5463::
goto L2304
r162 = r1[148]
r163 = r1[154]
r163 = 1[r1[154]]
r164 = r1[136]
-- ??? opcode 65 (UNKNOWN)
::L5469::
goto L3267
r155 = r1[148]
r156 = r1[52]
r156 = r1[155][r1[52]]
r157 = r1[37]
r156 = r1[155][r1[52]][r1[37]]
::L5475::
goto L3363
r156 = r1[148][12]
r157 = 2
r154 = r1[148] .. r1[148][12] .. 2
::L5479::
goto L451
-- numeric for-loop (var r171+3, jump L1980)
goto L2270
if not (not(V[A[n]]<KA[n])) then goto L1004 end
::L5483::
goto L3650
r154 = r1[155]
r155 = nil
r155 = nil()
r156 = r1[148][22]
r157 = 1
goto L5040
