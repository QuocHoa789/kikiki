-- lifted Lua source - proto #1
-- 343 instructions (linear order, control flow via labels/gotos)
::L1::
goto L120
r2[111] = "gsub"
r2[51] = "rawget"
r2[164] = "readu8"
r2[8] = "\ucf65\ucd15\ucd8b\ub8fc\uc68a\ubd56\ubdab\ub7ba"
r2[12] = "next"
::L7::
goto L96
-- ??? opcode 162 (UNKNOWN)
r2[182] = "GetAsync"
r2[39] = "\u1101\u1175\u11af\u110e\u1172\u11af\u110a\u116d\u11aa\u1103\u116d\u11b1\u110d\u1167\u11aa\u1104\u116f\u11b0"
r2[21] = "FromName"
::L12::
goto L241
r2[55] = "setstack"
r3 = Random  -- global
-- ??? opcode 162 (UNKNOWN)
::L16::
goto L207
r3 = Random["new"]
-- ??? opcode 141 (UNKNOWN)
-- ??? opcode 143 (UNKNOWN)
-- ??? opcode 70 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r2[130] = "IsA"
r2[153] = "userdata"
::L24::
goto L290
r2[24] = "Instance"
r2[74] = "Enum"
r2[135] = "error"
r3 = unpack  -- global
::L29::
goto L324
-- ??? opcode 162 (UNKNOWN)
r2[67] = "HttpService"
r3 = rawset  -- global
goto L121
::L35::
-- ??? opcode 45 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r2[19] = "number"
r2[158] = "function"
r2[75] = "tonumber"
-- ??? opcode 31 (UNKNOWN)
r2 = r2(rawset)
::L42::
goto L278
(r2(rawset))[77] = "Connect"
(r2(rawset))[88] = "sl"
r3 = bit32  -- global
r3 = bit32["bor"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[94] = "status"
::L49::
goto L299
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 22 (UNKNOWN)
-- ??? opcode 71 (UNKNOWN)
r3 = bit32["bor"]["format"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[20] = "sub"
(r2(rawset))[96] = "rawset"
(r2(rawset))[72] = "Clone"
(r2(rawset))[103] = "Random"
::L60::
goto L1
(r2(rawset))[93] = "format"
(r2(rawset))[116] = "getstack"
r3 = Enum  -- global
::L64::
goto L7
(r2(rawset))[178] = "gmatch"
r3 = utf8  -- global
r3 = utf8["nfdnormalize"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[147] = "what"
::L70::
goto L307
-- ??? opcode 162 (UNKNOWN)
r3 = CFrame  -- global
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[139] = "ClassName"
(r2(rawset))[83] = "delay"
::L76::
goto L193
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[141] = "getupvalue"
r3 = utf8  -- global
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[13] = "wait"
r3 = buffer  -- global
-- ??? opcode 162 (UNKNOWN)
r3 = string  -- global
r3 = string["unpack"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[1] = "wrap"
r3 = bit32  -- global
r3 = bit32["bnot"]
-- ??? opcode 162 (UNKNOWN)
r3 = rawget  -- global
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[46] = "pcall"
(r2(rawset))[114] = "traceback"
::L96::
goto L295
(r2(rawset))[95] = "Disconnect"
r3 = bit32  -- global
r3 = bit32["rshift"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[134] = "spawn"
::L102::
goto L60
r3 = string  -- global
r3 = string["gmatch"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[169] = "type"
(r2(rawset))[162] = "\":(%d+)[:\\r\\"
(r2(rawset))[34] = "setmetatable"
(r2(rawset))[137] = "Shuffle"
r3 = table  -- global
r3 = table["concat"]
-- ??? opcode 162 (UNKNOWN)
r3 = select  -- global
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[150] = "Position"
::L116::
goto L12
(r2(rawset))[136] = true
r3 = string  -- global
r3 = string["byte"]
::L120::
goto L170
::L121::
goto L229
-- ??? opcode 162 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 87 (UNKNOWN)
-- ??? opcode 62 (UNKNOWN)
(r2(rawset))[145] = "PostAsync"
(r2(rawset))[86] = "source"
(r2(rawset))[119] = "resume"
(r2(rawset))[5] = "create"
(r2(rawset))[28] = "defer"
r3 = string  -- global
r3 = string["rep"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[22] = "running"
(r2(rawset))[100] = "FromValue"
(r2(rawset))[3] = "byte"
(r2(rawset))[110] = "IsServer"
::L138::
goto L189
(r2(rawset))[9] = "linedefined"
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 87 (UNKNOWN)
-- ??? opcode 62 (UNKNOWN)
(r2(rawset))[101] = "setconstant"
r3 = debug  -- global
::L145::
goto L76
(r2(rawset))[38] = "DescendantRemoving"
(r2(rawset))[64] = "getinfo"
r3 = identifyexecutor  -- global
::L149::
goto L198
(r2(rawset))[80] = "currentline"
(r2(rawset))[90] = "[C]"
(r2(rawset))[57] = "EnumItem"
(r2(rawset))[53] = "select"
r3 = islclosure  -- global
::L155::
goto L70
(r2(rawset))[170] = "tostring"
(r2(rawset))[31] = "getmetatable"
(r2(rawset))[146] = ""
(r2(rawset))[176] = "RequestAsync"
(r2(rawset))[59] = false
::L161::
goto L249
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[11] = "writeu16"
(r2(rawset))[157] = "GetChildren"
::L166::
goto L225
(r2(rawset))[160] = "Name"
r3 = getmetatable  -- global
-- ??? opcode 162 (UNKNOWN)
::L170::
goto L221
-- ??? opcode 162 (UNKNOWN)
r3 = UDim2  -- global
r3 = UDim2["new"]
-- ??? opcode 162 (UNKNOWN)
::L175::
goto L166
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[107] = "cancel"
r3 = string  -- global
r3 = string["match"]
-- ??? opcode 162 (UNKNOWN)
r3 = table  -- global
-- ??? opcode 162 (UNKNOWN)
::L183::
goto L155
r3 = table["lrotate"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[43] = "NormalId"
r3 = game  -- global
-- ??? opcode 162 (UNKNOWN)
::L189::
goto L102
(r2(rawset))[44] = "ScreenGui"
(r2(rawset))[52] = "Y"
r3 = setmetatable  -- global
::L193::
goto L49
(r2(rawset))[149] = "C"
(r2(rawset))[69] = "char"
(r2(rawset))[61] = "NextInteger"
(r2(rawset))[25] = "yield"
::L198::
goto L138
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[66] = "insert"
r3 = Path2DControlPoint  -- global
::L202::
goto L16
-- ??? opcode 162 (UNKNOWN)
r3 = xpcall  -- global
-- ??? opcode 162 (UNKNOWN)
r3 = bit32  -- global
::L207::
goto L183
(r2(rawset))[109] = "table"
(r2(rawset))[92] = "Value"
(r2(rawset))[42] = "Workspace"
r3 = string  -- global
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[87] = "pack"
(r2(rawset))[18] = "NextUnitVector"
::L215::
goto L116
r3 = bit32  -- global
r3 = bit32["lshift"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[47] = "WaitForChild"
(r2(rawset))[165] = "writeu8"
::L221::
goto L42
(r2(rawset))[181] = "setupvalue"
(r2(rawset))[132] = "__index"
(r2(rawset))[117] = "RunService"
::L225::
goto L149
(r2(rawset))[144] = "Parent"
r3 = coroutine  -- global
-- ??? opcode 162 (UNKNOWN)
::L229::
goto L280
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 72 (UNKNOWN)
(r2(rawset))[30] = "getupvalues"
(r2(rawset))[152] = "close"
(r2(rawset))[40] = "IsStudio"
(r2(rawset))[89] = "slnaf"
r3 = UDim  -- global
r3 = UDim["new"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[173] = "new"
::L241::
goto L215
r3 = typeof  -- global
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[60] = "Connected"
(r2(rawset))[168] = "info"
(r2(rawset))[56] = "EnumType"
(r2(rawset))[6] = "copy"
(r2(rawset))[91] = "StarterPlayer"
::L249::
goto L314
(r2(rawset))[108] = "getconstant"
(r2(rawset))[122] = "unpack"
r3 = string  -- global
r3 = string["sub"]
::L254::
goto L263
(r2(rawset))[123] = "namewhat"
(r2(rawset))[183] = "isvararg"
(r2(rawset))[142] = "NextNumber"
r3 = workspace  -- global
::L259::
goto L267
r3 = table  -- global
r3 = table["insert"]
-- ??? opcode 162 (UNKNOWN)
::L263::
goto L161
-- ??? opcode 162 (UNKNOWN)
r3 = Vector3  -- global
-- ??? opcode 162 (UNKNOWN)
::L267::
goto L24
-- ??? opcode 162 (UNKNOWN)
r3 = bit32  -- global
r3 = bit32["countlz"]
::L271::
goto L175
(r2(rawset))[70] = "string"
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 87 (UNKNOWN)
-- ??? opcode 62 (UNKNOWN)
(r2(rawset))[98] = "ChildAdded"
r3 = tonumber  -- global
::L278::
goto L202
-- numeric for-loop (var rNone+3, jump LNone)
::L280::
-- numeric for-loop (var rNone+3, jump LNone)
(r2(rawset))[37] = "Scale"
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 87 (UNKNOWN)
-- ??? opcode 62 (UNKNOWN)
r3 = loadstring  -- global
-- ??? opcode 162 (UNKNOWN)
r3 = math  -- global
-- ??? opcode 162 (UNKNOWN)
r3 = assert  -- global
::L290::
goto L35
(r2(rawset))[76] = "Folder"
(r2(rawset))[163] = "Path2D"
(r2(rawset))[99] = "short_src"
(r2(rawset))[177] = "=[C]"
::L295::
goto L254
r3 = next  -- global
-- ??? opcode 162 (UNKNOWN)
r3 = bit32  -- global
::L299::
goto L29
r3 = bit32  -- global
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[151] = "Enums"
::L307::
goto L145
r3 = Instance  -- global
-- ??? opcode 162 (UNKNOWN)
r3 = bit32  -- global
r3 = bit32["countrz"]
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[112] = "match"
::L314::
goto L336
r3 = string  -- global
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 12 (UNKNOWN)
-- ??? opcode 142 (UNKNOWN)
-- ??? opcode 69 (UNKNOWN)
-- ??? opcode 162 (UNKNOWN)
r3 = utf8  -- global
r3 = utf8["nfcnormalize"]
-- ??? opcode 162 (UNKNOWN)
::L324::
goto L259
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[115] = "DataModel"
r3 = pcall  -- global
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[128] = "abs"
(r2(rawset))[49] = "getconstants"
(r2(rawset))[32] = "writeu32"
(r2(rawset))[81] = "find"
(r2(rawset))[65] = "The metatable is locked"
(r2(rawset))[14] = "nparams"
(r2(rawset))[79] = "lastlinedefined"
::L336::
goto L64
(r2(rawset))[143] = "Frame"
r3 = task  -- global
-- ??? opcode 162 (UNKNOWN)
r3 = type  -- global
-- ??? opcode 162 (UNKNOWN)
(r2(rawset))[154] = "X"
goto L271
