-- lifted Lua source - proto #9
-- 78 instructions (linear order, control flow via labels/gotos)
::L1::
goto L28
r2 = 589165855
r508 = r508(r509, r510)
-- ??? opcode 107 (UNKNOWN)
::L8::
goto L70
if not (r6 == 500546635) then goto L11 end
::L11::
goto L31
r6 = r6 + nil
goto L42
::L16::
if not (V[A[n]]<=KA[n]) then goto L354 end
r6 = r4
::L18::
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 4 (UNKNOWN)
-- ??? opcode 54 (UNKNOWN)
-- ??? opcode 18 (UNKNOWN)
-- ??? opcode 71 (UNKNOWN)
r5 = 50
::L26::
goto L70
-- numeric for-loop (var r5+3, jump L29)
::L28::
goto L59
goto L32
if not (KA[n]<=V[A[n]]) then goto L68 end
::L31::
goto L66
::L32::
goto L16
-- numeric for-loop (var rNone+3, jump LNone)
r2 = 529868157
r3 = <upvalue table index>
::L37::
goto L74
r5 = 105
r4 = not r4
::L40::
goto L70
r7 = 28
::L42::
goto L26  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 99 (UNKNOWN)
-- ??? opcode 112 (UNKNOWN)
-- ??? opcode 59 (UNKNOWN)
-- ??? opcode 114 (UNKNOWN)
-- ??? opcode 15 (UNKNOWN)
-- ??? opcode 42 (UNKNOWN)
-- ??? opcode 109 (UNKNOWN)
-- ??? opcode 138 (UNKNOWN)
-- ??? opcode 131 (UNKNOWN)
r6 = r4 + nil
::L59::
goto L1
-- ??? opcode 52 (UNKNOWN)
r3 = not upvalue_index
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
::L64::
goto L70
if not (105 == 105) then goto L72 end
::L66::
goto L8
::L68::
goto L26
r3 = r1
::L70::
goto L26
if not (105 == 50) then goto L64 end
::L72::
goto L37
if not (105 == 95) then goto L70 end
::L74::
goto L18
r4 = <upvalue table index>
r5 = 7
r6 = 35
goto L40
