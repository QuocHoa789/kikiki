-- lifted Lua source - proto #6
-- 196 instructions (linear order, control flow via labels/gotos)
::L1::
goto L138
if not (r13 == 295) then goto L110 end
::L3::
goto L151
r4 = r6
::L5::
goto L128
-- numeric for-loop (var r9+3, jump L57)
::L7::
goto L70
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
::L10::
goto L16
if not (not(V[A[n]]<V[B[n]])) then goto L40 end
::L12::
goto L66
if not (notV[A[n]]) then goto L63 end
::L14::
goto L7
if not (KA[n]<V[A[n]]) then goto L148 end
::L16::
goto L3
if not (not(V[A[n]]<KA[n])) then goto L177 end
::L18::
goto L59
if not (r13 == 404) then goto L1 end
::L20::
goto L130
-- ??? opcode 52 (UNKNOWN)
r10 = <upvalue table index>
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r12 = 196
r13 = 41
::L27::
goto L78
r14 = 69
r15 = 105
r16 = 24
::L31::
goto L105  -- for-loop prep (init, limit, step in regs)
if not (KA[n]<V[A[n]]) then goto L68 end
::L33::
goto L46
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
::L38::
goto L31
if not (not(V[A[n]]<KA[n])) then goto L31 end
::L40::
goto L183
r5 = 840159002
::L44::
goto L156
if not (69 == 126) then goto L98 end
::L46::
goto L84
::L48::
goto L52
r6 = r3
r8 = 2
-- ??? opcode 56 (UNKNOWN)
::L52::
goto L105
::L53::
-- numeric for-loop (var rNone+3, jump LNone)
r13 = 70
r14 = 150
r15 = 80
goto L79  -- for-loop prep (init, limit, step in regs)
if not (not(V[A[n]]<KA[n])) then goto L186 end
::L59::
goto L108
r4 = r3
::L61::
goto L106
r6 = r3
::L63::
goto L128
goto L106
if not (V[A[n]]<=KA[n]) then goto L44 end
::L66::
goto L173
-- ??? opcode 56 (UNKNOWN)
::L68::
goto L128
if not (not(V[A[n]]<KA[n])) then goto L120 end
::L70::
goto L180
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
if not (notV[A[n]]) then goto L52 end
::L78::
goto L91
::L79::
goto L134  -- for-loop prep (init, limit, step in regs)
-- numeric for-loop (var r13+3, jump L136)
::L81::
goto L171
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
::L84::
goto L14
r15 = r3
r16 = 2
r17 = r9
r18 = upvalue_index
r15 = 2 .. r9 .. upvalue_index
goto L33
::L91::
-- ??? opcode 84 (UNKNOWN)
r4 = 1
r9 = <upvalue table index>
r10 = 77
r11 = 520
r12 = 109
::L97::
goto L128  -- for-loop prep (init, limit, step in regs)
::L98::
goto L70
r10 = 1
::L101::
goto L134
r17 = 1
-- ??? opcode 30 (UNKNOWN)
::L104::
goto L79
::L105::
goto L20
::L106::
-- numeric for-loop (var r14+3, jump L175)
-- ??? opcode 52 (UNKNOWN)
::L108::
goto L128
::L110::
goto L5
if not (70 == 77) then goto L128 end
::L112::
goto L61
r14 = r3
r15 = 2
r13 = 70(r3, 2)
r4 = (70(r3, 2))
if not (notV[A[n]]) then goto L97 end
::L118::
goto L53
if not (2 == 150) then goto L79 end
::L120::
goto L101
if not (KA[n]<V[A[n]]) then goto L31 end
goto L38
if not ((70(r3, 2)) == 186) then goto L18 end
::L124::
goto L150
r8 = 1
::L128::
goto L10
-- numeric for-loop (var r10+3, jump L122)
::L130::
goto L104
::L132::
goto L20
r4 = <upvalue table index>
::L134::
goto L79
-- numeric for-loop (var r11+3, jump L64)
goto L33
if not (2 == 70) then goto L118 end
::L138::
goto L132
-- numeric for-loop (var rNone+3, jump LNone)
r4 = <upvalue table index>
r5 = 845520309
r6 = nil
r7 = 378524138
r8 = <upvalue table index>
r9 = 15
r10 = 142
r11 = 31
::L148::
goto L5  -- for-loop prep (init, limit, step in regs)
if not (not(V[A[n]]<KA[n])) then goto L14 end
::L150::
goto L153
::L151::
goto L124
if not (notV[A[n]]) then goto L27 end
::L153::
goto L81
r14 = 120
r6 = r1
::L156::
goto L14
r7 = 378524138 + nil
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 99 (UNKNOWN)
-- ??? opcode 112 (UNKNOWN)
-- ??? opcode 82 (UNKNOWN)
r336 = r225 - nil
r209 = r209()
-- ??? opcode 28 (UNKNOWN)
-- ??? opcode 145 (UNKNOWN)
-- ??? opcode 60 (UNKNOWN)
-- ??? opcode 101 (UNKNOWN)
::L171::
goto L128
-- ??? opcode 52 (UNKNOWN)
::L173::
goto L97
r6 = <upvalue table index>
goto L134
if not (1 == 69) then goto L194 end
::L177::
goto L48
r6 = r2
r18 = 44
::L180::
goto L16
r8 = 1
r11 = 79
::L183::
goto L31
-- ??? opcode 33 (UNKNOWN)
r11 = 98
::L186::
goto L31
r6 = r1
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 66 (UNKNOWN)
-- ??? opcode 78 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
r13 = upvalue_index
::L194::
goto L112
if not (1 == 93) then goto L105 end
goto L12
