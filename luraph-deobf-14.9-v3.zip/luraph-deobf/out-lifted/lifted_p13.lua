-- lifted Lua source - proto #13
-- 44 instructions (linear order, control flow via labels/gotos)
::L1::
goto L29
r1 = <upvalue table index>
r2 = <upvalue table index>
r3 = 1
::L5::
goto L35
r6 = <upvalue table index>
r7 = upvalue_index
r8 = 16
r6 = upvalue_index(upvalue_index, 16)
goto L39
::L11::
-- ??? opcode 55 (UNKNOWN)
r5 = r5 * nil
r6 = <upvalue table index>
r7 = 1
::L15::
goto L24
::L16::
-- numeric for-loop (var rNone+3, jump LNone)
r8 = 8
r6 = upvalue_index(1, 8)
-- ??? opcode 129 (UNKNOWN)
-- ??? opcode 135 (UNKNOWN)
-- ??? opcode 161 (UNKNOWN)
-- ??? opcode 124 (UNKNOWN)
::L24::
goto L15
r8 = 32
r6 = (upvalue_index(1, 8))(1, 32)
r6 = ((upvalue_index(1, 8))(1, 32)) * nil
-- ??? opcode 33 (UNKNOWN)
::L29::
goto L5
::L30::
goto L1
r6 = r4
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r5 = (r5 * nil)(r4, 1)
::L35::
goto L11
r4 = 4
-- numeric for-loop (var rNone+3, jump LNone)
r5 = <upvalue table index>
::L39::
goto L30
r6 = r4 * nil
-- ??? opcode 33 (UNKNOWN)
r6 = <upvalue table index>
r7 = upvalue_index
goto L16
