-- lifted Lua source - proto #10
-- 79 instructions (linear order, control flow via labels/gotos)
::L1::
goto L66
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r2 = 65566606
r3 = 55310058
::L7::
goto L25
r4 = r4 - nil
r3 = 55310058 + nil
::L12::
goto L55
::L13::
goto L50
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 30 (UNKNOWN)
-- numeric for-loop (var rNone+3, jump LNone)
::L17::
goto L51
::L18::
goto L12
::L19::
goto L63  -- for-loop prep (init, limit, step in regs)
r5 = <upvalue table index>
r7 = nil
::L24::
::L25::
goto L33
-- ??? opcode 121 (UNKNOWN)
::L29::
goto L17
-- numeric for-loop (var r2+3, jump L60)
goto L62
if not (not(V[A[n]]<KA[n])) then goto L13 end
::L33::
goto L19
-- ??? opcode 59 (UNKNOWN)
-- ??? opcode 114 (UNKNOWN)
-- ??? opcode 15 (UNKNOWN)
-- ??? opcode 42 (UNKNOWN)
-- ??? opcode 109 (UNKNOWN)
-- ??? opcode 138 (UNKNOWN)
-- ??? opcode 131 (UNKNOWN)
::L43::
goto L63
r0 = r0[r1]
-- ??? opcode 3 (UNKNOWN)
-- ??? opcode 72 (UNKNOWN)
r2 = 1
r3 = #r0[r1]
r4 = 1
::L50::
goto L29  -- for-loop prep (init, limit, step in regs)
::L51::
-- numeric for-loop (var rNone+3, jump LNone)
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 32 (UNKNOWN)
r1 = 2
::L55::
goto L43
r2 = 1 + nil
if not (KA[n]<V[A[n]]) then goto L24 end
-- ??? opcode 124 (UNKNOWN)
goto L50
r0[r1][upvalue_index] = 2
::L62::
goto L29
::L63::
goto L62
-- numeric for-loop (var r1+3, jump L31)
goto L1
::L66::
r509 = r509(r510, r511)
r1 = 126
r2 = 229
r3 = 68
goto L18
r1 = 126 + nil
-- ??? opcode 1 (UNKNOWN)
-- ??? opcode 153 (UNKNOWN)
-- ??? opcode 38 (UNKNOWN)
-- ??? opcode 151 (UNKNOWN)
-- ??? opcode 118 (UNKNOWN)
-- ??? opcode 131 (UNKNOWN)
goto L7
