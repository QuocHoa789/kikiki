-- lifted Lua source - proto #12
-- 148 instructions (linear order, control flow via labels/gotos)
::L1::
goto L127
r16 = <upvalue table index>
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
r15 = r15(upvalue_index)
r16 = <upvalue table index>
::L7::
goto L100
-- ??? opcode 52 (UNKNOWN)
::L9::
goto L98
r15 = <upvalue table index>
r16 = <upvalue table index>
r16 = upvalue_index()
r17 = <upvalue table index>
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
::L16::
goto L44
::L17::
goto L73
r15 = <upvalue table index>
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
r15 = r5[upvalue_index]
if not (V[A[n]]) then goto L44 end
::L26::
goto L9
r3 = 1
::L28::
goto L59  -- for-loop prep (init, limit, step in regs)
-- ??? opcode 52 (UNKNOWN)
r1 = <upvalue table index>
r2 = <upvalue table index>
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
r3 = <upvalue table index>
::L38::
goto L61
r11 = r11()
r12 = <upvalue table index>
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
r11 = <upvalue table index>
::L44::
goto L116
r5[r14] = r5[upvalue_index]
r14 = <upvalue table index>
r14 = upvalue_index()
::L48::
goto L106
r8 = 1
goto L90  -- for-loop prep (init, limit, step in regs)
r14 = <upvalue table index>
r14 = upvalue_index()
if not (notV[A[n]]) then goto L17 end
::L54::
goto L114
r5[(upvalue_index())] = r5[upvalue_index]
r14 = <upvalue table index>
r15 = <upvalue table index>
r15 = upvalue_index()
::L59::
goto L1
-- numeric for-loop (var r1+3, jump L86)
::L61::
goto L28
-- numeric for-loop (var rNone+3, jump LNone)
::L63::
-- numeric for-loop (var rNone+3, jump LNone)
r12 = upvalue_index()
r13 = <upvalue table index>
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
r5[r10] = upvalue_index
r10 = <upvalue table index>
r11 = <upvalue table index>
::L71::
goto L38
-- numeric for-loop (var r10+3, jump L50)
::L73::
goto L7
r15 = <upvalue table index>
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
goto L54
r10 = 0
r11 = 255
r12 = 1
::L84::
goto L96
-- ??? opcode 52 (UNKNOWN)
::L86::
goto L86
r5 = {}
r6 = 0
r7 = 255
::L90::
goto L48
-- numeric for-loop (var r6+3, jump L128)
::L92::
goto L115
r14 = <upvalue table index>
r14 = upvalue_index()
goto L17
::L96::
-- ??? opcode 104 (UNKNOWN)
::L97::
goto L71  -- for-loop prep (init, limit, step in regs)
::L98::
goto L98  -- for-loop prep (init, limit, step in regs)
-- numeric for-loop (var r6+3, jump L80)
::L100::
goto L84
r16 = (upvalue_index())()
r17 = <upvalue table index>
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 45 (UNKNOWN)
{}[(upvalue_index())] = upvalue_index
::L106::
goto L71
r15 = <upvalue table index>
r15 = upvalue_index()
if not (notV[A[n]]) then goto L54 end
::L110::
goto L16
r1 = 1
r2 = <upvalue table index>
r2 = upvalue_index()
::L114::
goto L26
::L115::
goto L92
::L116::
goto L141
r12 = <upvalue table index>
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
r13 = <upvalue table index>
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
{}[0] = 255
::L127::
goto L90
goto L110
r10 = <upvalue table index>
r11 = <upvalue table index>
-- ??? opcode 122 (UNKNOWN)
-- ??? opcode 136 (UNKNOWN)
-- ??? opcode 102 (UNKNOWN)
-- call via loader upvalue
r12 = <upvalue table index>
-- numeric for-loop (var rNone+3, jump LNone)
-- ??? opcode 152 (UNKNOWN)
r11 = <upvalue table index>
r12 = <upvalue table index>
::L141::
goto L63
-- ??? opcode 52 (UNKNOWN)
-- ??? opcode 85 (UNKNOWN)
-- ??? opcode 9 (UNKNOWN)
r7 = <upvalue table index>
r7 = upvalue_index()
r8 = 1
goto L97
